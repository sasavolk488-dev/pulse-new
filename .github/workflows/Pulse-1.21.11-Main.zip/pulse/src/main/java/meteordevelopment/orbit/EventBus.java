package meteordevelopment.orbit;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import meteordevelopment.orbit.listeners.IListener;
import meteordevelopment.orbit.listeners.LambdaListener;

public class EventBus implements IEventBus {
   private final Map<Object, List<IListener>> listenerCache = new ConcurrentHashMap<>();
   private final Map<Class<?>, List<IListener>> staticListenerCache = new ConcurrentHashMap<>();
   private final Map<Class<?>, EventBus.ListenerList> listenerMap = new ConcurrentHashMap<>();
   private final List<EventBus.LambdaFactoryInfo> lambdaFactoryInfos = new ArrayList<>();

   @Override
   public void registerLambdaFactory(String var1, LambdaListener.Factory var2) {
      synchronized (this.lambdaFactoryInfos) {
         this.lambdaFactoryInfos.add(new EventBus.LambdaFactoryInfo(var1, var2));
      }
   }

   @Override
   public boolean isListening(Class<?> var1) {
      EventBus.ListenerList var2 = this.listenerMap.get(var1);
      return var2 != null && !var2.isEmpty();
   }

   @Override
   public <T> T post(T var1) {
      EventBus.ListenerList var2 = this.listenerMap.get(var1.getClass());
      if (var2 != null) {
         IListener[] var3 = var2.snapshot;

         for (int var4 = 0; var4 < var3.length; var4++) {
            var3[var4].call(var1);
         }
      }

      return (T)var1;
   }

   @Override
   public <T extends ICancellable> T post(T var1) {
      EventBus.ListenerList var2 = this.listenerMap.get(var1.getClass());
      if (var2 != null) {
         var1.setCancelled(false);
         IListener[] var3 = var2.snapshot;

         for (int var4 = 0; var4 < var3.length; var4++) {
            var3[var4].call(var1);
            if (var1.isCancelled()) {
               break;
            }
         }
      }

      return (T)var1;
   }

   @Override
   public void subscribe(Object var1) {
      this.subscribe(this.getListeners(var1.getClass(), var1), false);
   }

   @Override
   public void subscribe(Class<?> var1) {
      this.subscribe(this.getListeners(var1, null), true);
   }

   @Override
   public void subscribe(IListener var1) {
      this.subscribe(var1, false);
   }

   private void subscribe(List<IListener> var1, boolean var2) {
      for (IListener var4 : var1) {
         this.subscribe(var4, var2);
      }
   }

   private void subscribe(IListener var1, boolean var2) {
      if (var2) {
         if (var1.isStatic()) {
            this.listenerMap.computeIfAbsent(var1.getTarget(), var0 -> new EventBus.ListenerList()).insert(var1);
         }
      } else {
         this.listenerMap.computeIfAbsent(var1.getTarget(), var0 -> new EventBus.ListenerList()).insert(var1);
      }
   }

   @Override
   public void unsubscribe(Object var1) {
      this.unsubscribe(this.getListeners(var1.getClass(), var1), false);
   }

   @Override
   public void unsubscribe(Class<?> var1) {
      this.unsubscribe(this.getListeners(var1, null), true);
   }

   @Override
   public void unsubscribe(IListener var1) {
      this.unsubscribe(var1, false);
   }

   private void unsubscribe(List<IListener> var1, boolean var2) {
      for (IListener var4 : var1) {
         this.unsubscribe(var4, var2);
      }
   }

   private void unsubscribe(IListener var1, boolean var2) {
      EventBus.ListenerList var3 = this.listenerMap.get(var1.getTarget());
      if (var3 != null) {
         if (var2) {
            if (var1.isStatic()) {
               var3.remove(var1);
            }
         } else {
            var3.remove(var1);
         }
      }
   }

   private List<IListener> getListeners(Class<?> var1, Object var2) {
      Function var3 = var3x -> {
         CopyOnWriteArrayList var4 = new CopyOnWriteArrayList();
         this.getListeners(var4, var1, var2);
         return var4;
      };
      if (var2 == null) {
         return this.staticListenerCache.computeIfAbsent(var1, var3);
      } else {
         for (Object var5 : this.listenerCache.keySet()) {
            if (var5 == var2) {
               return this.listenerCache.get(var2);
            }
         }

         List var6 = (List)var3.apply(var2);
         this.listenerCache.put(var2, var6);
         return var6;
      }
   }

   private void getListeners(List<IListener> var1, Class<?> var2, Object var3) {
      for (Method var7 : var2.getDeclaredMethods()) {
         if (this.isValid(var7)) {
            var1.add(new LambdaListener(this.getLambdaFactory(var2), var2, var3, var7));
         }
      }

      if (var2.getSuperclass() != null) {
         this.getListeners(var1, var2.getSuperclass(), var3);
      }
   }

   private boolean isValid(Method var1) {
      if (!var1.isAnnotationPresent(EventHandler.class)) {
         return false;
      } else if (var1.getReturnType() != void.class) {
         return false;
      } else {
         return var1.getParameterCount() != 1 ? false : !var1.getParameters()[0].getType().isPrimitive();
      }
   }

   private LambdaListener.Factory getLambdaFactory(Class<?> var1) {
      synchronized (this.lambdaFactoryInfos) {
         for (EventBus.LambdaFactoryInfo var4 : this.lambdaFactoryInfos) {
            if (var1.getName().startsWith(var4.packagePrefix)) {
               return var4.factory;
            }
         }
      }

      throw new NoLambdaFactoryException(var1);
   }

   private static class LambdaFactoryInfo {
      public final String packagePrefix;
      public final LambdaListener.Factory factory;

      public LambdaFactoryInfo(String var1, LambdaListener.Factory var2) {
         this.packagePrefix = var1;
         this.factory = var2;
      }
   }

   private static final class ListenerList {
      private final CopyOnWriteArrayList<IListener> list = new CopyOnWriteArrayList<>();
      volatile IListener[] snapshot = new IListener[0];

      void insert(IListener var1) {
         int var2 = 0;

         while (var2 < this.list.size() && var1.getPriority() <= this.list.get(var2).getPriority()) {
            var2++;
         }

         this.list.add(var2, var1);
         this.snapshot = this.list.toArray(new IListener[0]);
      }

      void remove(IListener var1) {
         if (this.list.remove(var1)) {
            this.snapshot = this.list.toArray(new IListener[0]);
         }
      }

      boolean isEmpty() {
         return this.list.isEmpty();
      }
   }
}
