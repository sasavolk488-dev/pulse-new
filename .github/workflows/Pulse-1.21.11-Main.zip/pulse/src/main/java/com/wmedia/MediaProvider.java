package com.wmedia;

import com.sun.jna.Memory;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.wmedia.internal.WMediaNative;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

public final class MediaProvider {
   private static final WMediaNative NATIVE = WMediaNative.INSTANCE;
   private static final AtomicBoolean shutdownCalled = new AtomicBoolean(false);
   private static final int WCHAR_SIZE = 2;
   private static final ReentrantLock mediaLock = new ReentrantLock();
   private static final ReentrantLock audioLock = new ReentrantLock();
   private static Memory titleBuf;
   private static Memory artistBuf;
   private static byte[] albumArtBuf;
   private static IntByReference albumArtSize;
   private static IntByReference isPlaying;
   private static LongByReference durationMs;
   private static LongByReference positionMs;
   private static FloatByReference masterPeak;
   private static FloatByReference leftPeak;
   private static FloatByReference rightPeak;
   private static float[] channelPeaks;
   private static IntByReference channelCount;
   private static volatile boolean buffersInitialized = false;

   private MediaProvider() {
   }

   private static void ensureBuffersInitialized() {
      if (!buffersInitialized) {
         synchronized (MediaProvider.class) {
            if (!buffersInitialized) {
               titleBuf = new Memory(1024L);
               artistBuf = new Memory(1024L);
               albumArtBuf = new byte[10485760];
               albumArtSize = new IntByReference(0);
               isPlaying = new IntByReference(0);
               durationMs = new LongByReference(0L);
               positionMs = new LongByReference(0L);
               masterPeak = new FloatByReference(0.0F);
               leftPeak = new FloatByReference(0.0F);
               rightPeak = new FloatByReference(0.0F);
               channelPeaks = new float[8];
               channelCount = new IntByReference(0);
               buffersInitialized = true;
            }
         }
      }
   }

   public static Optional<MediaInfo> getCurrentMedia() {
      if (shutdownCalled.get()) {
         return Optional.empty();
      } else {
         ensureBuffersInitialized();
         mediaLock.lock();

         Optional var1;
         try {
            titleBuf.clear();
            artistBuf.clear();
            int var0 = NATIVE.MediaProvider_GetCurrentMedia(
               titleBuf, 512, artistBuf, 512, albumArtBuf, albumArtBuf.length, albumArtSize, isPlaying, durationMs, positionMs
            );
            if (var0 != 0) {
               String var10 = extractWideString(titleBuf, 512);
               String var2 = extractWideString(artistBuf, 512);
               int var3 = Math.max(0, albumArtSize.getValue());
               byte[] var4 = var3 > 0 ? Arrays.copyOf(albumArtBuf, var3) : new byte[0];
               boolean var5 = isPlaying.getValue() != 0;
               return Optional.of(new MediaInfo(var10, var2, var4, var5, durationMs.getValue(), positionMs.getValue()));
            }

            var1 = Optional.empty();
         } finally {
            mediaLock.unlock();
         }

         return var1;
      }
   }

   public static boolean play() {
      return shutdownCalled.get() ? false : NATIVE.MediaProvider_Play() != 0;
   }

   public static boolean pause() {
      return shutdownCalled.get() ? false : NATIVE.MediaProvider_Pause() != 0;
   }

   public static boolean playPause() {
      return shutdownCalled.get() ? false : NATIVE.MediaProvider_PlayPause() != 0;
   }

   public static boolean next() {
      return shutdownCalled.get() ? false : NATIVE.MediaProvider_Next() != 0;
   }

   public static boolean previous() {
      return shutdownCalled.get() ? false : NATIVE.MediaProvider_Previous() != 0;
   }

   public static Optional<AudioLevels> getAudioLevels() {
      if (shutdownCalled.get()) {
         return Optional.empty();
      } else {
         ensureBuffersInitialized();
         audioLock.lock();

         Optional var1;
         try {
            int var0 = NATIVE.MediaProvider_GetAudioLevels(masterPeak, leftPeak, rightPeak, channelPeaks, channelCount);
            if (var0 != 0) {
               return Optional.of(
                  new AudioLevels(masterPeak.getValue(), leftPeak.getValue(), rightPeak.getValue(), (float[])channelPeaks.clone(), channelCount.getValue())
               );
            }

            var1 = Optional.empty();
         } finally {
            audioLock.unlock();
         }

         return var1;
      }
   }

   public static boolean seek(long var0) {
      return shutdownCalled.get() ? false : NATIVE.MediaProvider_Seek(var0) != 0;
   }

   public static boolean isAvailable() {
      try {
         return NATIVE != null && !shutdownCalled.get();
      } catch (UnsatisfiedLinkError var1) {
         return false;
      }
   }

   public static void shutdown() {
      if (shutdownCalled.compareAndSet(false, true)) {
         try {
            NATIVE.MediaProvider_Shutdown();
         } catch (Throwable var5) {
         }

         mediaLock.lock();

         try {
            titleBuf = null;
            artistBuf = null;
            albumArtBuf = null;
         } finally {
            mediaLock.unlock();
         }

         buffersInitialized = false;
      }
   }

   private static String extractWideString(Memory var0, int var1) {
      StringBuilder var2 = new StringBuilder();

      for (int var3 = 0; var3 < var1; var3++) {
         char var4 = var0.getChar(var3 * 2L);
         if (var4 == 0) {
            break;
         }

         var2.append(var4);
      }

      return var2.toString();
   }
}
