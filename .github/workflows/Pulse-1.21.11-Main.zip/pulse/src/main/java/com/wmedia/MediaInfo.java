package com.wmedia;

import java.util.Arrays;
import java.util.Objects;

public final class MediaInfo {
   private final String title;
   private final String artist;
   private final byte[] albumArt;
   private final boolean playing;
   private final long durationMs;
   private final long positionMs;

   MediaInfo(String var1, String var2, byte[] var3, boolean var4, long var5, long var7) {
      this.title = var1 != null ? var1 : "";
      this.artist = var2 != null ? var2 : "";
      this.albumArt = var3 != null ? (byte[])var3.clone() : new byte[0];
      this.playing = var4;
      this.durationMs = var5;
      this.positionMs = var7;
   }

   public String getTitle() {
      return this.title;
   }

   public String getArtist() {
      return this.artist;
   }

   public byte[] getAlbumArt() {
      return (byte[])this.albumArt.clone();
   }

   public boolean isPlaying() {
      return this.playing;
   }

   public long getDurationMs() {
      return this.durationMs;
   }

   public long getPositionMs() {
      return this.positionMs;
   }

   public double getProgress() {
      return this.durationMs <= 0L ? 0.0 : (double)this.positionMs / this.durationMs;
   }

   public boolean hasAlbumArt() {
      return this.albumArt.length > 0;
   }

   public String getFormattedDuration() {
      return formatTime(this.durationMs);
   }

   public String getFormattedPosition() {
      return formatTime(this.positionMs);
   }

   private static String formatTime(long var0) {
      long var2 = var0 / 1000L;
      long var4 = var2 / 60L;
      long var6 = var2 % 60L;
      return String.format("%d:%02d", var4, var6);
   }

   @Override
   public String toString() {
      return "MediaInfo{title='"
         + this.title
         + '\''
         + ", artist='"
         + this.artist
         + '\''
         + ", playing="
         + this.playing
         + ", position="
         + this.getFormattedPosition()
         + "/"
         + this.getFormattedDuration()
         + ", albumArtSize="
         + this.albumArt.length
         + '}';
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         MediaInfo var2 = (MediaInfo)var1;
         return this.playing == var2.playing
            && this.durationMs == var2.durationMs
            && this.positionMs == var2.positionMs
            && Objects.equals(this.title, var2.title)
            && Objects.equals(this.artist, var2.artist)
            && Arrays.equals(this.albumArt, var2.albumArt);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      int var1 = Objects.hash(this.title, this.artist, this.playing, this.durationMs, this.positionMs);
      return 31 * var1 + Arrays.hashCode(this.albumArt);
   }
}
