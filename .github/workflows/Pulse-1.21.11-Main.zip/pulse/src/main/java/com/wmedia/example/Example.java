package com.wmedia.example;

import com.wmedia.AudioLevels;
import com.wmedia.MediaInfo;
import com.wmedia.MediaProvider;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

public class Example {
   public static void main(String[] var0) throws InterruptedException {
      System.out.println("WMedia Library Example");
      System.out.println("======================\n");
      if (!MediaProvider.isAvailable()) {
         System.err.println("WMedia library is not available!");
      } else {
         Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("\nShutting down WMedia...");
            MediaProvider.shutdown();
         }));
         System.out.println("Getting current media info...\n");
         Optional var1 = MediaProvider.getCurrentMedia();
         if (!var1.isPresent()) {
            System.out.println("No media is currently playing.");
            System.out.println("Start playing something in Spotify, YouTube, etc.");
         } else {
            MediaInfo var2 = (MediaInfo)var1.get();
            System.out.println("Now Playing:");
            System.out.println("  Title:    " + var2.getTitle());
            System.out.println("  Artist:   " + var2.getArtist());
            System.out.println("  Status:   " + (var2.isPlaying() ? "Playing" : "Paused"));
            System.out.println("  Progress: " + var2.getFormattedPosition() + " / " + var2.getFormattedDuration());
            System.out.println("  Position: " + String.format("%.1f%%", var2.getProgress() * 100.0));
            if (var2.hasAlbumArt()) {
               try {
                  Path var3 = Paths.get("album_art.jpg");
                  Files.write(var3, var2.getAlbumArt());
                  System.out.println("  Album Art: Saved to " + var3.toAbsolutePath());
               } catch (IOException var6) {
                  System.out.println("  Album Art: Available (" + var2.getAlbumArt().length + " bytes)");
               }
            }

            System.out.println();
            if (var0.length > 0) {
               String var7 = var0[0].toLowerCase();
               switch (var7) {
                  case "play":
                     System.out.println("Sending play command...");
                     MediaProvider.play();
                     break;
                  case "pause":
                     System.out.println("Sending pause command...");
                     MediaProvider.pause();
                     break;
                  case "toggle":
                     System.out.println("Toggling play/pause...");
                     MediaProvider.playPause();
                     break;
                  case "next":
                     System.out.println("Skipping to next track...");
                     MediaProvider.next();
                     break;
                  case "prev":
                     System.out.println("Going to previous track...");
                     MediaProvider.previous();
                     break;
                  default:
                     System.out.println("Unknown command: " + var7);
               }

               Thread.sleep(500L);
               MediaProvider.getCurrentMedia().ifPresent(var0x -> {
                  System.out.println("\nUpdated status: " + (var0x.isPlaying() ? "Playing" : "Paused"));
                  System.out.println("Now playing: " + var0x.getTitle());
               });
            } else {
               System.out.println("Tip: Run with argument 'play', 'pause', 'toggle', 'next', 'prev', or 'levels' to control playback.");
            }

            if (var0.length > 0 && var0[0].equalsIgnoreCase("levels")) {
               System.out.println("\nAudio Levels (updating for 5 seconds):\n");

               for (int var8 = 0; var8 < 50; var8++) {
                  MediaProvider.getAudioLevels().ifPresent(Example::printAudioLevels);
                  Thread.sleep(100L);
               }
            }
         }
      }
   }

   private static void printAudioLevels(AudioLevels var0) {
      byte var1 = 30;
      int var2 = (int)(var0.getMasterPeak() * var1);
      int var3 = (int)(var0.getLeftPeak() * var1);
      int var4 = (int)(var0.getRightPeak() * var1);
      System.out.print("\r");
      System.out.printf("Master: [%-" + var1 + "s] %.2f  ", repeat('=', var2), var0.getMasterPeak());
      System.out.printf("L: [%-" + var1 + "s] %.2f  ", repeat('=', var3), var0.getLeftPeak());
      System.out.printf("R: [%-" + var1 + "s] %.2f", repeat('=', var4), var0.getRightPeak());
      System.out.flush();
   }

   private static String repeat(char var0, int var1) {
      StringBuilder var2 = new StringBuilder(var1);

      for (int var3 = 0; var3 < var1; var3++) {
         var2.append(var0);
      }

      return var2.toString();
   }
}
