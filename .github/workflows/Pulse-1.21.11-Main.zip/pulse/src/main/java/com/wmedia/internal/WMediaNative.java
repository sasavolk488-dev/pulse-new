package com.wmedia.internal;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;

public interface WMediaNative extends Library {
   int TITLE_MAX_LEN = 512;
   int ARTIST_MAX_LEN = 512;
   int ALBUM_ART_MAX_LEN = 10485760;
   WMediaNative INSTANCE = WMediaNative.Loader.loadLibrary();

   int MediaProvider_GetCurrentMedia(
      Pointer var1,
      int var2,
      Pointer var3,
      int var4,
      byte[] var5,
      int var6,
      IntByReference var7,
      IntByReference var8,
      LongByReference var9,
      LongByReference var10
   );

   int MediaProvider_Play();

   int MediaProvider_Pause();

   int MediaProvider_PlayPause();

   int MediaProvider_Next();

   int MediaProvider_Previous();

   int MediaProvider_GetAudioLevels(FloatByReference var1, FloatByReference var2, FloatByReference var3, float[] var4, IntByReference var5);

   int MediaProvider_Seek(long var1);

   void MediaProvider_Shutdown();

   public static class Loader {
      static WMediaNative loadLibrary() {
         HashMap var0 = new HashMap();

         try {
            return Native.loadLibrary("MediaData", WMediaNative.class, var0);
         } catch (UnsatisfiedLinkError var21) {
            try {
               Path var2 = Files.createTempDirectory("wmedia");
               Path var3 = var2.resolve("MediaData.dll");

               WMediaNative var6;
               try (InputStream var4 = WMediaNative.class.getResourceAsStream("/native/MediaData.dll")) {
                  if (var4 == null) {
                     throw var21;
                  }

                  Files.copy(var4, var3, StandardCopyOption.REPLACE_EXISTING);
                  var3.toFile().deleteOnExit();
                  var2.toFile().deleteOnExit();
                  var6 = Native.loadLibrary(var3.toString(), WMediaNative.class, var0);
               }

               return var6;
            } catch (IOException var20) {
               throw var21;
            }
         }
      }
   }
}
