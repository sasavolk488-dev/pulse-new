package com.wmedia;

import java.util.Arrays;

public final class AudioLevels {
   private final float masterPeak;
   private final float leftPeak;
   private final float rightPeak;
   private final float[] channelPeaks;
   private final int channelCount;

   AudioLevels(float var1, float var2, float var3, float[] var4, int var5) {
      this.masterPeak = var1;
      this.leftPeak = var2;
      this.rightPeak = var3;
      this.channelPeaks = var4 != null ? (float[])var4.clone() : new float[8];
      this.channelCount = var5;
   }

   public float getMasterPeak() {
      return this.masterPeak;
   }

   public float getLeftPeak() {
      return this.leftPeak;
   }

   public float getRightPeak() {
      return this.rightPeak;
   }

   public float[] getChannelPeaks() {
      return (float[])this.channelPeaks.clone();
   }

   public int getChannelCount() {
      return this.channelCount;
   }

   public float getChannelPeak(int var1) {
      return var1 >= 0 && var1 < this.channelPeaks.length ? this.channelPeaks[var1] : 0.0F;
   }

   @Override
   public String toString() {
      return String.format("AudioLevels{master=%.2f, L=%.2f, R=%.2f, channels=%d}", this.masterPeak, this.leftPeak, this.rightPeak, this.channelCount);
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         AudioLevels var2 = (AudioLevels)var1;
         return Float.compare(var2.masterPeak, this.masterPeak) == 0
            && Float.compare(var2.leftPeak, this.leftPeak) == 0
            && Float.compare(var2.rightPeak, this.rightPeak) == 0
            && this.channelCount == var2.channelCount
            && Arrays.equals(this.channelPeaks, var2.channelPeaks);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      int var1 = Float.hashCode(this.masterPeak);
      var1 = 31 * var1 + Float.hashCode(this.leftPeak);
      var1 = 31 * var1 + Float.hashCode(this.rightPeak);
      var1 = 31 * var1 + Arrays.hashCode(this.channelPeaks);
      return 31 * var1 + this.channelCount;
   }
}
