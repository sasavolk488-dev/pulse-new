package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.EquipmentSlot;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Armor Notifier",
   b = "Уведомляет о низкой прочности брони",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ArmorNotifierModule extends Module {
   private final NumberSetting a = new NumberSetting("Порог (%)", 20.0F, 1.0F, 50.0F, 1.0F);
   private static final EquipmentSlot[] b = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   private static final String[] c = new String[]{"Шлем", "Нагрудник", "Поножи", "Ботинки"};
   private final boolean[] f = new boolean[4];
   private long g = 0L;

   @EventHandler
   @Compile
   private void a(UpdateEvent var1) {
      NumberSetting threshold = this.a;
      boolean[] warned = this.f;
      if (d.player == null) {
         return;
      }
      long now = System.currentTimeMillis();
      for (int index = 0; index < b.length; index++) {
         var stack = d.player.getEquippedStack(b[index]);
         if (stack.isEmpty() || stack.getMaxDamage() == 0) {
            warned[index] = false;
            continue;
         }
         float percent = (1.0F - (float)stack.getDamage() / (float)stack.getMaxDamage()) * 100.0F;
         if (percent <= threshold.b()) {
            if (!warned[index] && now - this.g > 2000L) {
               warned[index] = true;
               this.g = now;
               int rounded = Math.round(percent);
               String message = "Низкая прочность / " + c[index] + " - " + rounded + "%";
               pulse.features.modules.hud.components.WatermarkComponent.a(
                  pulse.features.modules.hud.island.NotificationIsland.a(message)
                     .a(pulse.features.modules.hud.island.NotificationIsland.NotificationType.b)
                     .a(3000L).b());
            }
         } else {
            warned[index] = false;
         }
      }
   }

   static {
      NativeMethodLookup.lookup(ArmorNotifierModule.class, 44);
   }
}
