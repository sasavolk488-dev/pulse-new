package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.InputSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Auto Eat",
   b = "Автоматически ест еду при указанном голоде",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoEatModule extends Module {
   private final ModeSetting a = new ModeSetting("Режим", new String[]{"Еда", "Команда"}, 0);
   private final InputSetting b = new InputSetting("Команда", InputSetting.InputType.b, "/feed", "/feed").c(() -> this.a.b("Команда"));
   private final NumberSetting c = new NumberSetting("Кушать, если голод меньше", 15.0F, 1.0F, 20.0F, 1.0F);
   private boolean f;
   private int g = -1;
   private boolean h = false;
   private boolean i = false;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      NumberSetting hunger = this.c;
      ModeSetting mode = this.a;
      InputSetting commandSetting = this.b;
      if (d.player == null || d.world == null) {
         return;
      }
      if (!this.f) {
         try {
            this.h = d.options.useKey.isPressed();
         } catch (RuntimeException | Error failure) {
            this.h = false;
            throw failure;
         }
      }
      boolean hungry = d.player.getHungerManager().getFoodLevel() < (Float)hunger.q()
         && d.player.getHungerManager().isNotFull();
      if (mode.b("Команда")) {
         if (hungry && !this.i) {
            String command = commandSetting.i();
            if (command != null && !command.isEmpty()) {
               pulse.utils.game.ChatUtils.a(command);
               this.i = true;
            }
         } else if (!hungry) {
            this.i = false;
         }
         return;
      }
      int slot = -1;
      if (hungry) {
         for (int index = 0; index < 9; index++) {
            ItemStack stack = d.player.getInventory().getStack(index);
            if (!stack.isEmpty() && this.a(stack)) {
               slot = index;
               break;
            }
         }
      }
      if (slot == -1) {
         if (this.f) {
            if (this.g != -1) {
               d.player.getInventory().setSelectedSlot(this.g);
               this.g = -1;
            }
            d.options.useKey.setPressed(this.h);
            this.f = false;
         }
      } else {
         if (!this.f) {
            try {
               this.g = d.player.getInventory().getSelectedSlot();
            } catch (RuntimeException | Error failure) {
               this.g = 0;
               throw failure;
            }
         }
         d.player.getInventory().setSelectedSlot(slot);
         d.options.useKey.setPressed(true);
         this.f = true;
      }
   }

   private boolean a(ItemStack var1) {
      return var1.getComponents().contains(DataComponentTypes.FOOD);
   }

   @Compile
   @Override
      public void f() {
      super.f();
      if (d.player == null || d.world == null) {
         return;
      }
      var client = net.minecraft.client.MinecraftClient.getInstance();
      if (this.f) {
         client.options.useKey.setPressed(this.h);
      }
      if (this.g != -1) {
         client.player.getInventory().setSelectedSlot(this.g);
      }
      this.f = false;
      this.g = -1;
      this.i = false;
   }

   static {
      NativeMethodLookup.lookup(AutoEatModule.class, 48);
   }
}
