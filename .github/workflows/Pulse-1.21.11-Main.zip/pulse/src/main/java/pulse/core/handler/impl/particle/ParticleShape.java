package pulse.core.handler.impl.particle;

import java.util.Arrays;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum ParticleShape {
   a(null),
   b("Куб"),
   c("Ромб");

   private final String e;
   public static final String[] d = c();

   private ParticleShape(String var3) {
      this.e = var3;
   }

   public String a() {
      return this.e;
   }

   public boolean b() {
      return this != a;
   }

   public static ParticleShape a(String var0) {
      for (ParticleShape var4 : values()) {
         if (var4.e != null && var4.e.equals(var0)) {
            return var4;
         }
      }

      return a;
   }

   private static String[] c() {
      ParticleShape[] var0 = Arrays.stream(values()).filter(ParticleShape::b).toArray(ParticleShape[]::new);
      String[] var1 = Arrays.copyOf(ParticleTextures.f, ParticleTextures.f.length + var0.length);

      for (int var2 = 0; var2 < var0.length; var2++) {
         var1[ParticleTextures.f.length + var2] = var0[var2].e;
      }

      return var1;
   }

   private static ParticleShape[] d() {
      return new ParticleShape[]{a, b, c};
   }
}
