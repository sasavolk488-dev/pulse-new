package pulse.features.modules.utilities.ft;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public record DetectedSound(Identifier soundId, SoundCategory category, float volume, float pitch, Vec3d pos, BlockPos blockPos, long timestampMs) {
}
