package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.LivingJumpEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.particle.ParticleTextures;
import pulse.core.handler.impl.particle.PhysicsMode;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.WorldRenderHelper;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.utils.render.world.JumpLayers;
import pulse.utils.render.world.JumpShockwave;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;

@ModuleInfo(
   a = "Jump Circles",
   b = "Отображает круги при прыжке игрока",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class JumpCirclesModule extends Module {
   private final ModeSetting a = new ModeSetting(
      "Режим прыжка", new String[]{"Только круг", "Только частицы", "Круг + частицы", "Блоковая волна", "Шейдер волна"}, "Только круг"
   );
   private final BooleanSetting b = new BooleanSetting("Показывать от первого лица", true);
   private final SeparatorSetting c = new SeparatorSetting("Шейдер волна").a(() -> this.a.b("Шейдер волна"));
   private final NumberSetting f = new NumberSetting("Скорость волны", 18.0F, 2.0F, 60.0F, 0.5F).a(() -> this.a.b("Шейдер волна"));
   private final NumberSetting g = new NumberSetting("Радиус", 24.0F, 4.0F, 128.0F, 1.0F).a(() -> this.a.b("Шейдер волна"));
   private final NumberSetting h = new NumberSetting("Амплитуда", 1.0F, 0.0F, 3.0F, 0.05F).a(() -> this.a.b("Шейдер волна"));
   private final NumberSetting i = new NumberSetting("Толщина", 2.5F, 0.3F, 10.0F, 0.1F).a(() -> this.a.b("Шейдер волна"));
   private final NumberSetting j = new NumberSetting("Время жизни", 1.4F, 0.3F, 4.0F, 0.05F).a(() -> this.a.b("Шейдер волна"));
   private final SeparatorSetting k = new SeparatorSetting("Круги").a(() -> this.a.b("Круг + частицы"));
   private final NumberSetting l = new NumberSetting("Радиус", 1.0F, 0.5F, 2.0F, 0.1F).a(() -> this.a.b("Только круг") || this.a.b("Круг + частицы"));
   private final NumberSetting m = new NumberSetting("Скорость", 2.0F, 0.5F, 5.0F, 0.1F).a(() -> this.a.b("Только круг") || this.a.b("Круг + частицы"));
   private final BooleanSetting n = new BooleanSetting("Цвет клиента", true).a(() -> this.a.b("Только круг") || this.a.b("Круг + частицы"));
   private final ColorSetting o = new ColorSetting("Кастомный цвет", Color.WHITE)
      .a(() -> (this.a.b("Только круг") || this.a.b("Круг + частицы")) && !this.n.a());
   private final SeparatorSetting p = new SeparatorSetting("Частицы").a(() -> this.a.b("Круг + частицы"));
   private final ModeSetting q = new ModeSetting("Тип частиц", ParticleTextures.f, "Звезда").a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final ModeSetting r = new ModeSetting("Режим физики", PhysicsMode.b(), "Реалистичная")
      .a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final NumberSetting s = new NumberSetting("Количество частиц", 4.0F, 1.0F, 10.0F, 1.0F)
      .a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final NumberSetting t = new NumberSetting("Размер частиц", 0.3F, 0.1F, 0.75F, 0.05F)
      .a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final NumberSetting u = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F)
      .a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final NumberSetting v = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F)
      .a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final BooleanSetting w = new BooleanSetting("Цвет клиента", true).a(() -> this.a.b("Только частицы") || this.a.b("Круг + частицы"));
   private final ColorSetting x = new ColorSetting("Кастомный цвет", Color.WHITE)
      .a(() -> (this.a.b("Только частицы") || this.a.b("Круг + частицы")) && !this.w.a());
   private final SeparatorSetting y = new SeparatorSetting("Блоковая волна").a(() -> this.a.b("Блоковая волна"));
   private final NumberSetting z = new NumberSetting("Радиус волны", 10.0F, 6.0F, 35.0F, 1.0F).a(() -> this.a.b("Блоковая волна"));
   private final NumberSetting A = new NumberSetting("Скорость волны", 8.0F, 1.0F, 25.0F, 0.5F).a(() -> this.a.b("Блоковая волна"));
   private final NumberSetting B = new NumberSetting("Толщина кольца", 1.5F, 0.5F, 3.0F, 0.1F).a(() -> this.a.b("Блоковая волна"));
   private final BooleanSetting C = new BooleanSetting("Обводка", true).a(() -> this.a.b("Блоковая волна"));
   private final NumberSetting D = new NumberSetting("Толщина линий", 2.0F, 1.0F, 5.0F, 0.5F).a(() -> this.a.b("Блоковая волна") && this.C.a());
   private final BooleanSetting E = new BooleanSetting("Заливка", true).a(() -> this.a.b("Блоковая волна"));
   private final NumberSetting F = new NumberSetting("Прозрачность заливки", 0.3F, 0.05F, 0.8F, 0.05F).a(() -> this.a.b("Блоковая волна") && this.E.a());
   private final BooleanSetting G = new BooleanSetting("Цвет клиента", true).a(() -> this.a.b("Блоковая волна"));
   private final ColorSetting H = new ColorSetting("Кастомный цвет", Color.CYAN).a(() -> this.a.b("Блоковая волна") && !this.G.a());
   private final Identifier I = Identifier.of("pulse", "textures/jump.png");
   private final Queue<JumpCirclesModule.Circle> J = new LinkedBlockingQueue<>();
   private final Queue<JumpCirclesModule.BlockWave> K = new LinkedBlockingQueue<>();

   @EventHandler
   @Compile
   public void a(LivingJumpEvent var1) {
      BooleanSetting showFirstPerson = this.b;
      ModeSetting effectSetting = this.a;
      Queue<Circle> circles = this.J;
      NumberSetting particleCount = this.s;
      ModeSetting physicsSetting = this.r;
      NumberSetting blockRadius = this.z;
      Queue<BlockWave> waves = this.K;
      NumberSetting blockSpeed = this.A;
      NumberSetting waveLifetime = this.j;
      NumberSetting waveRadius = this.g;
      NumberSetting waveThickness = this.i;
      NumberSetting waveSpeed = this.f;
      NumberSetting waveAmplitude = this.h;
      if (var1.a() != d.player) {
         return;
      }
      if (d.options.getPerspective().isFirstPerson() && !(Boolean)showFirstPerson.q()) {
         return;
      }
      String effect = effectSetting.e();
      if (effect.equals("Только круг") || effect.equals("Круг + частицы")) {
         circles.add(new Circle(d.player.getLerpedPos(1.0F).add(0.0, (double)0.01F, 0.0), System.currentTimeMillis()));
      }
      if (effect.equals("Только частицы") || effect.equals("Круг + частицы")) {
         double x = d.player.getX();
         double z = d.player.getZ();
         double y = d.player.getY();
         Vec3d position = new Vec3d(x, y + 0.1, z);
         int count = particleCount.c() * 2;
         int color = this.o().getRGB();
         Identifier texture = this.p();
         String physics = physicsSetting.e();
         for (int index = 0; index < count; index++) {
            this.a(position, 0.15, color, texture, physics);
         }
      }
      if (effect.equals("Блоковая волна")) {
         float radius = blockRadius.b();
         waves.add(new BlockWave(d.player.getLerpedPos(1.0F), radius, radius / blockSpeed.b()));
      }
      if (effect.equals("Шейдер волна")) {
         JumpShockwave.a(waveLifetime.b(), waveRadius.b(), waveThickness.b(), waveSpeed.b());
         JumpShockwave.a(d.player.getLerpedPos(1.0F), waveAmplitude.b());
      }
   }

   @EventHandler
   public void a(RenderEvent var1) {
      if (!d.options.getPerspective().isFirstPerson() || this.b.q()) {
         String var2 = this.a.e();
         if (var2.equals("Шейдер волна")) {
            JumpShockwave.a(this.j.b(), this.g.b(), this.i.b(), this.f.b());
         } else {
            if (var2.equals("Блоковая волна") && !this.K.isEmpty()) {
               this.b(var1);
            }

            if (var2.equals("Только круг") || var2.equals("Круг + частицы")) {
               if (!this.J.isEmpty()) {
                  var1.a().push();
                  Camera var3 = d.getEntityRenderDispatcher().camera;
                  Vec3d var4 = var3.getCameraPos();
                  ArrayList<JumpCirclesModule.Circle> var5 = new ArrayList<>(this.J);
                  var5.sort((var1x, var2x) -> {
                     double var3x = var1x.a.squaredDistanceTo(var4);
                     double var5x = var2x.a.squaredDistanceTo(var4);
                     return Double.compare(var5x, var3x);
                  });
                  long var6 = System.currentTimeMillis();
                  float var8 = 3000.0F / this.m.b();
                  float var9 = this.l.b() * 2.0F;
                  int var10 = this.n().getRGB();
                  Immediate var11 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
                  VertexConsumer var12 = var11.getBuffer(JumpLayers.c);

                  for (JumpCirclesModule.Circle var14 : var5) {
                     long var15 = var6 - var14.b;
                     float var17 = Math.min((float)var15 / var8, 1.0F);
                     if (var17 >= 1.0F) {
                        this.J.remove(var14);
                     } else {
                        float var18 = this.a(var17);
                        double var19 = var18 * var9;
                        Vec3d var21 = var14.a.subtract(var19 / 2.0, 0.0, var19 / 2.0);
                        int var22 = (int)(255.0F * (1.0F - var17));
                        int var23 = ColorUtils.a(var10, var22);
                        float var24 = (float)(var21.x - var4.x);
                        float var25 = (float)(var21.y - var4.y) + 0.001F;
                        float var26 = (float)(var21.z - var4.z);
                        float var27 = (float)var19;
                        float var28 = (var23 >> 16 & 0xFF) / 255.0F;
                        float var29 = (var23 >> 8 & 0xFF) / 255.0F;
                        float var30 = (var23 & 0xFF) / 255.0F;
                        float var31 = var22 / 255.0F;
                        Matrix4f var32 = var1.a().peek().getPositionMatrix();
                        var12.vertex(var32, var24, var25, var26).texture(0.0F, 0.0F).color(var28, var29, var30, var31);
                        var12.vertex(var32, var24 + var27, var25, var26).texture(1.0F, 0.0F).color(var28, var29, var30, var31);
                        var12.vertex(var32, var24 + var27, var25, var26 + var27).texture(1.0F, 1.0F).color(var28, var29, var30, var31);
                        var12.vertex(var32, var24, var25, var26 + var27).texture(0.0F, 1.0F).color(var28, var29, var30, var31);
                     }
                  }

                  var11.draw(JumpLayers.c);
                  var1.a().pop();
               }
            }
         }
      }
   }

   private void a(Vec3d var1, double var2, int var4, Identifier var5, String var6) {
      var4 = ColorUtils.a(var4);
      int var7 = this.s.c();
      int var8 = this.u.c();
      int var9 = var8 - 10;
      int var10 = var8 + 10;
      float var11 = this.t.b();
      float var12 = var11 - 0.05F;
      float var13 = var11 + 0.05F;
      double var14 = this.v.b();

      for (int var16 = 0; var16 < var7; var16++) {
         int var17 = ThreadLocalRandom.current().nextInt(var9, var10);
         float var18 = var12 + ThreadLocalRandom.current().nextFloat() * (var13 - var12);
         Vec3d var19 = new Vec3d(
            ThreadLocalRandom.current().nextDouble(-var2, var2),
            ThreadLocalRandom.current().nextDouble(0.0, var2),
            ThreadLocalRandom.current().nextDouble(-var2, var2)
         );
         if (var19.lengthSquared() > 0.0) {
            var19 = var19.normalize().multiply(ThreadLocalRandom.current().nextDouble(0.005000000011148443, var14));
         }

         HandlerRegistry.g.a(var1, var19, var17, var18, var5, var4, var6);
      }
   }

   private Color n() {
      if (this.n.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.o.a();
      }
   }

   private Color o() {
      if (this.w.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.x.a();
      }
   }

   private Identifier p() {
      return ParticleTextures.a(this.q.e());
   }

   private float a(float var1) {
      return var1 == 1.0F ? 1.0F : 1.0F - (float)Math.pow(2.0, -10.0F * var1);
   }

   private void b(RenderEvent var1) {
      if (d.world != null) {
         Camera var2 = d.getEntityRenderDispatcher().camera;
         Vec3d var3 = var2.getCameraPos();
         var1.a().push();
         Color var4 = this.q();
         float var5 = var4.getRed() / 255.0F;
         float var6 = var4.getGreen() / 255.0F;
         float var7 = var4.getBlue() / 255.0F;
         float var8 = this.B.b();
         float var9 = this.F.b();
         boolean var10 = this.E.a();
         boolean var11 = this.C.a();
         float var12 = this.D.b();
         double var13 = 0.005000000011148443;
         Immediate var15 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer var16 = var10 ? WorldRenderHelper.h() : null;
         VertexConsumer var17 = var11 ? var15.getBuffer(BlockOverlayLayers.h) : null;
         Mutable var18 = new Mutable();
         Mutable var19 = new Mutable();
         this.K
            .removeIf(
               var14 -> {
                  var14.a();
                  if (var14.b()) {
                     return true;
                  } else {
                     float var15x = var14.c();
                     if (var15x < 0.1F) {
                        return false;
                     } else {
                        float var16x = Math.max(0.0F, var15x - var8);
                        float var18x = var16x * var16x;
                        float var19x = var15x * var15x;
                        float var20 = var14.d();
                        BlockPos var21 = BlockPos.ofFloored(var14.a);
                        int var22 = (int)Math.ceil(var15x) + 1;

                        for (int var23 = -var22; var23 <= var22; var23++) {
                           for (int var24 = -var22; var24 <= var22; var24++) {
                              double var25 = var21.getX() + var23 + 0.5 - var14.a.x;
                              double var27 = var21.getZ() + var24 + 0.5 - var14.a.z;
                              double var29 = var25 * var25 + var27 * var27;
                              if (!(var29 > var19x)) {
                                 double var31 = Math.sqrt(Math.max(0.0, var19x - var29));
                                 int var33 = (int)Math.floor(-var31);
                                 int var34 = (int)Math.ceil(var31);

                                 for (int var35 = var33; var35 <= var34; var35++) {
                                    double var36 = var21.getY() + var35 + 0.5 - var14.a.y;
                                    double var38 = var29 + var36 * var36;
                                    if (!(var38 < var18x) && !(var38 > var19x)) {
                                       var18.set(var21.getX() + var23, var21.getY() + var35, var21.getZ() + var24);
                                       BlockState var40 = d.world.getBlockState(var18);
                                       if (!var40.isAir() && var40.isOpaqueFullCube()) {
                                          var19.set(var18.getX(), var18.getY() + 1, var18.getZ());
                                          BlockState var41 = d.world.getBlockState(var19);
                                          if (var41.isAir() || !var41.isOpaqueFullCube()) {
                                             try {
                                                VoxelShape var42 = var40.getOutlineShape(d.world, var18);
                                                if (!var42.isEmpty()) {
                                                   Box var43 = var42.getBoundingBox()
                                                      .expand(var13)
                                                      .offset(var18.getX() - var3.x, var18.getY() - var3.y, var18.getZ() - var3.z);
                                                   double var44 = Math.sqrt(var38);
                                                   float var46 = var8 > 0.0F ? (float)((var44 - var16x) / var8) : 0.5F;
                                                   float var47 = var20 * (1.0F - Math.abs(var46 - 0.5F) * 2.0F);
                                                   var47 = Math.max(0.1F, var47);
                                                   float var48 = (float)var43.minX;
                                                   float var49 = (float)var43.maxY;
                                                   float var50 = (float)var43.minZ;
                                                   float var51 = (float)var43.maxX;
                                                   float var52 = (float)var43.maxZ;
                                                   if (var16 != null) {
                                                      WorldRenderHelper.b(var1.a(), var48, var49, var50, var51, var52, var5, var6, var7, var9 * var47);
                                                   }

                                                   if (var17 != null) {
                                                      Entry var53 = var1.a().peek();
                                                      a(var17, var53, var48, var49, var50, var51, var52, var5, var6, var7, var47, var12);
                                                   }
                                                }
                                             } catch (Exception var54) {
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        return false;
                     }
                  }
               }
            );
         if (var16 != null) {
            var15.draw(WorldRenderHelper.d());
         }

         if (var17 != null) {
            var15.draw(BlockOverlayLayers.h);
         }

         var1.a().pop();
      }
   }

   private static void a(
      VertexConsumer var0, Entry var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11
   ) {
      a(var0, var1, var2, var3, var4, var5, var3, var4, var7, var8, var9, var10, var11);
      a(var0, var1, var5, var3, var4, var5, var3, var6, var7, var8, var9, var10, var11);
      a(var0, var1, var5, var3, var6, var2, var3, var6, var7, var8, var9, var10, var11);
      a(var0, var1, var2, var3, var6, var2, var3, var4, var7, var8, var9, var10, var11);
   }

   private static void a(
      VertexConsumer var0,
      Entry var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12
   ) {
      float var13 = var5 - var2;
      float var14 = var6 - var3;
      float var15 = var7 - var4;
      float var16 = (float)Math.sqrt(var13 * var13 + var14 * var14 + var15 * var15);
      if (!(var16 < 1.0E-6F)) {
         var13 /= var16;
         var14 /= var16;
         var15 /= var16;
         var0.vertex(var1, var2, var3, var4).color(var8, var9, var10, var11).normal(var1, var13, var14, var15).lineWidth(var12);
         var0.vertex(var1, var5, var6, var7).color(var8, var9, var10, var11).normal(var1, var13, var14, var15).lineWidth(var12);
      }
   }

   private Color q() {
      if (this.G.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.H.a();
      }
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.J.clear();
      this.K.clear();
      JumpShockwave.a();
   }

   static {
      NativeMethodLookup.lookup(JumpCirclesModule.class, 84);
   }

   @Environment(EnvType.CLIENT)
   private class BlockWave {
      final Vec3d a;
      final Animation b;
      final Animation c;

      BlockWave(Vec3d var2, float var3, float var4) {
         this.a = var2;
         this.b = new Animation();
         this.c = new Animation();
         this.b.d(0.0);
         this.b.a(var3, var4, Easings.f);
         this.c.d(1.0);
         this.c.a(0.0, var4, Easings.s);
      }

      boolean a() {
         this.b.a();
         this.c.a();
         return this.b.b() || this.c.b();
      }

      boolean b() {
         return this.b.d() && this.c.d();
      }

      float c() {
         return (float)this.b.j();
      }

      float d() {
         return (float)this.c.j();
      }
   }

   @Environment(EnvType.CLIENT)
   private static class Circle {
      final Vec3d a;
      final long b;

      Circle(Vec3d var1, long var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
