package pulse.core.handler.impl;

public final class ServerIntegrationHandler$$Lambda$16 implements Runnable {
   private final ServerIntegrationHandler c0;

   public ServerIntegrationHandler$$Lambda$16(ServerIntegrationHandler var1) {
      this.c0 = var1;
   }

   @Override
   public void run() {
      this.c0.l();
   }
}
