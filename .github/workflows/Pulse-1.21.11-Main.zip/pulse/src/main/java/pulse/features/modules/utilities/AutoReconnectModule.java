package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import pulse.core.event.impl.UpdateEvent;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.time.TimeUtils;

@ModuleInfo(
   a = "Auto Reconnect",
   b = "Автоматически перезаходит на последнюю известную анархию",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoReconnectModule extends Module {
   private TimeUtils a = new TimeUtils();
   private int b = -1;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      if (d.player == null || d.world == null) {
         return;
      }
      boolean update;
      try {
         update = (this.b != this.o() || this.b == -1) && this.n();
      } catch (RuntimeException | Error error) {
         this.o();
         throw error;
      }
      if (update) {
         try {
            this.b = this.o();
         } catch (RuntimeException | Error error) {
            this.b = 0;
            throw error;
         }
      }
      if (this.o() == -1 && this.b != -1 && d.player.age > 20 && this.a.a(30000L)) {
         pulse.utils.game.ChatUtils.a("an" + this.b);
         this.a.b();
      }
   }

   public boolean n() {
      if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
         PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
         Text var2 = var1.getHeader();
         return var2 != null && var2.getString().contains("Анархия");
      } else {
         return false;
      }
   }

   public int o() {
      try {
         if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
            PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
            Text var2 = var1.getHeader();
            if (var2 == null) {
               return -1;
            } else {
               String var3 = Formatting.strip(var2.getString());
               if (var3 != null && var3.contains("Анархия-")) {
                  String[] var4 = var3.split("Анархия-");
                  if (var4.length < 2) {
                     return -1;
                  } else {
                     String var5 = var4[1].trim();

                     try {
                        return Integer.parseInt(var5);
                     } catch (NumberFormatException var7) {
                        return -1;
                     }
                  }
               } else {
                  return -1;
               }
            }
         } else {
            return -1;
         }
      } catch (Exception var8) {
         return -1;
      }
   }

   static {
      NativeMethodLookup.lookup(AutoReconnectModule.class, 52);
   }
}
