package pulse.features.emote;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.sound.Channel;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.client.sound.Source;
import net.minecraft.client.sound.StaticSound;
import net.minecraft.client.sound.Channel.SourceManager;
import net.minecraft.client.sound.SoundEngine.RunMode;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.Vec3d;
import pulse.mixin.accessor.SoundManagerAccessor;
import pulse.mixin.accessor.SoundSystemAccessor;
import pulse.utils.audio.PulseSoundOptions;

@Environment(EnvType.CLIENT)
public final class EmoteMusicPlayer {
   private static final double a = 3.0;
   private static final double b = 5.0;
   private static final int c = 4;
   private static final EmoteMusicPlayer d = new EmoteMusicPlayer();
   private final Map<Integer, EmoteMusicPlayer.Voice> e = new ConcurrentHashMap<>();
   private boolean f;

   private EmoteMusicPlayer() {
   }

   public static EmoteMusicPlayer a() {
      return d;
   }

   public void b() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.world != null && var1.player != null) {
         var var2 = EmoteManager.a().m();
         if (!var2.isEmpty() || !this.e.isEmpty()) {
            for (Entry var4 : this.e.entrySet()) {
               EmoteManager.PlayingInfo var5 = (EmoteManager.PlayingInfo)var2.get(var4.getKey());
               if (var5 == null || !var5.equals(((EmoteMusicPlayer.Voice)var4.getValue()).a)) {
                  this.b((Integer)var4.getKey());
               }
            }

            boolean var17 = var1.isPaused();
            if (var17 != this.f) {
               this.f = var17;

               for (EmoteMusicPlayer.Voice var21 : this.e.values()) {
                  this.a(var21, var17);
               }
            }

            if (!var17) {
               for (EmoteMusicPlayer.Voice var22 : this.e.values()) {
                  SourceManager var6 = var22.b;
                  if (var6 != null && var6.isStopped()) {
                     var22.d = true;
                     var22.b = null;
                  }
               }

               Vec3d var20 = var1.player.getEyePos();
               ArrayList<EmoteMusicPlayer.Candidate> var23 = new ArrayList<>();

               for (Entry var7 : var2.entrySet()) {
                  int var8 = (Integer)var7.getKey();
                  EmoteManager.PlayingInfo var9 = (EmoteManager.PlayingInfo)var7.getValue();
                  if (EmoteAudio.a(var9.emoteId()) != null) {
                     EmoteMusicPlayer.Voice var10 = this.e.get(var8);
                     if ((var10 == null || !var10.d)
                        && var1.world.getEntityById(var8) instanceof AbstractClientPlayerEntity var12
                        && EmoteManager.a((LivingEntity)var12)) {
                        boolean var13 = var8 == var1.player.getId();
                        Vec3d var14 = new Vec3d(var12.getX(), var12.getY() + var12.getHeight() * 0.5, var12.getZ());
                        double var15 = var13 ? 0.0 : var20.distanceTo(var14);
                        if (var10 != null || !(var15 > 5.0)) {
                           var23.add(new EmoteMusicPlayer.Candidate(var8, var9, var14, var15, var13));
                        }
                     }
                  }
               }

               var23.sort(Comparator.comparingDouble(EmoteMusicPlayer.Candidate::distance));
               HashSet var25 = new HashSet<>();

               for (int var26 = 0; var26 < var23.size() && var26 < 4; var26++) {
                  EmoteMusicPlayer.Candidate var28 = (EmoteMusicPlayer.Candidate)var23.get(var26);
                  var25.add(var28.entityId());
                  this.a(var1, var28);
               }

               for (Entry var29 : this.e.entrySet()) {
                  if (!((EmoteMusicPlayer.Voice)var29.getValue()).d && !var25.contains(var29.getKey())) {
                     this.a((Integer)var29.getKey());
                  }
               }
            }
         }
      } else {
         this.c();
      }
   }

   public void c() {
      for (Integer var2 : this.e.keySet()) {
         this.b(var2);
      }
   }

   private void a(MinecraftClient var1, EmoteMusicPlayer.Candidate var2) {
      EmoteMusicPlayer.Voice var3 = this.e.get(var2.entityId());
      if (var3 == null) {
         var3 = new EmoteMusicPlayer.Voice(var2.playback());
         this.e.put(var2.entityId(), var3);
         this.a(var1, var3, var2);
      } else {
         SourceManager var4 = var3.b;
         if (var4 != null) {
            float var5 = this.b(var1, var2);
            Vec3d var6 = var2.position();
            boolean var7 = var2.self();
            var4.run(var3x -> {
               if (!var7) {
                  var3x.setPosition(var6);
               }

               var3x.setVolume(var5);
            });
         }
      }
   }

   private void a(MinecraftClient var1, EmoteMusicPlayer.Voice var2, EmoteMusicPlayer.Candidate var3) {
      Channel var4 = a(var1);
      StaticSound var5 = EmoteAudio.a(var3.playback().emoteId());
      if (var4 != null && var5 != null) {
         float var6 = this.b(var1, var3);
         Vec3d var7 = var3.position();
         boolean var8 = var3.self();
         var4.createSource(RunMode.STATIC).thenAccept(var5x -> {
            if (var5x != null) {
               synchronized (var2) {
                  if (var2.c || var2.d) {
                     var5x.run(Source::stop);
                     return;
                  }

                  var2.b = var5x;
               }

               var5x.run(var4xx -> {
                  var4xx.setBuffer(var5);
                  var4xx.setLooping(false);
                  var4xx.disableAttenuation();
                  var4xx.setRelative(var8);
                  var4xx.setPosition(var8 ? Vec3d.ZERO : var7);
                  var4xx.setPitch(1.0F);
                  var4xx.setVolume(var6);
                  var4xx.play();
               });
            }
         });
      } else {
         this.e.remove(var3.entityId(), var2);
      }
   }

   private void a(int var1) {
      EmoteMusicPlayer.Voice var2 = this.e.get(var1);
      if (var2 != null) {
         SourceManager var3;
         synchronized (var2) {
            var2.d = true;
            var3 = var2.b;
            var2.b = null;
         }

         if (var3 != null) {
            var3.run(Source::stop);
         }
      }
   }

   private void b(int var1) {
      EmoteMusicPlayer.Voice var2 = this.e.remove(var1);
      if (var2 != null) {
         SourceManager var3;
         synchronized (var2) {
            var2.c = true;
            var3 = var2.b;
            var2.b = null;
         }

         if (var3 != null) {
            var3.run(Source::stop);
         }
      }
   }

   private void a(EmoteMusicPlayer.Voice var1, boolean var2) {
      SourceManager var3 = var1.b;
      if (var3 != null) {
         var3.run(var2 ? Source::pause : Source::resume);
      }
   }

   private float b(MinecraftClient var1, EmoteMusicPlayer.Candidate var2) {
      double var3 = var2.distance();
      float var5;
      if (var2.self() || var3 <= 3.0) {
         var5 = 1.0F;
      } else if (var3 >= 5.0) {
         var5 = 0.0F;
      } else {
         var5 = (float)(1.0 - (var3 - 3.0) / 2.0);
      }

      float var6 = var1.options.getSoundVolume(SoundCategory.RECORDS) * (float)PulseSoundOptions.a();
      return Math.max(0.0F, Math.min(1.0F, var5 * var6));
   }

   private static Channel a(MinecraftClient var0) {
      try {
         SoundSystem var1 = ((SoundManagerAccessor)var0.getSoundManager()).pulse$getSoundSystem();
         return ((SoundSystemAccessor)var1).pulse$getChannel();
      } catch (Throwable var2) {
         return null;
      }
   }

   @Environment(EnvType.CLIENT)
   private record Candidate(int entityId, EmoteManager.PlayingInfo playback, Vec3d position, double distance, boolean self) {
   }

   @Environment(EnvType.CLIENT)
   private static final class Voice {
      final EmoteManager.PlayingInfo a;
      volatile SourceManager b;
      volatile boolean c;
      volatile boolean d;

      Voice(EmoteManager.PlayingInfo var1) {
         this.a = var1;
      }
   }
}
