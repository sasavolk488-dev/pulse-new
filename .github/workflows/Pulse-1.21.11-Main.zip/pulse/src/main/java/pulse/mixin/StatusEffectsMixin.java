package pulse.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntity.class})
public class StatusEffectsMixin {
   @ModifyReturnValue(
      method = {"hasStatusEffect"},
      at = {@At("RETURN")}
   )
   private boolean pulse$hideWitherHearts(boolean var1, RegistryEntry<StatusEffect> var2) {
      if (var1 && var2 == StatusEffects.WITHER && (Object)this instanceof ClientPlayerEntity) {
         RenderTweaksModule var3 = ModuleRegistry.h;
         if (var3 != null && var3.t()) {
            return false;
         }
      }

      return var1;
   }
}
