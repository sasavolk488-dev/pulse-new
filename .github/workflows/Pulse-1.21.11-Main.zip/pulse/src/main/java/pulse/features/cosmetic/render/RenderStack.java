package pulse.features.cosmetic.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;

@Environment(EnvType.CLIENT)
public class RenderStack {
   private MatrixStack a;

   public void a(MatrixStack var1) {
      this.a = var1;
   }

   public void a() {
      this.a.push();
   }

   public void b() {
      this.a.pop();
   }

   public MatrixStack c() {
      return this.a;
   }

   public void a(float var1, float var2, float var3) {
      this.a.translate(var1, var2, var3);
   }

   public void b(float var1, float var2, float var3) {
      this.a.scale(var1, var2, var3);
   }

   public void a(float var1) {
      this.a.multiply(new Quaternionf().rotationX((float)Math.toRadians(var1)));
   }

   public void b(float var1) {
      this.a.multiply(new Quaternionf().rotationY((float)Math.toRadians(var1)));
   }

   public void c(float var1) {
      this.a.multiply(new Quaternionf().rotationZ((float)Math.toRadians(var1)));
   }

   public void c(float var1, float var2, float var3) {
      if (var3 != 0.0F) {
         this.c(var3);
      }

      if (var2 != 0.0F) {
         this.b(var2);
      }

      if (var1 != 0.0F) {
         this.a(var1);
      }
   }

   public void d(float var1, float var2, float var3) {
      this.c(var1, var2, var3);
   }

   public void d(float var1) {
      this.a(var1);
   }

   public void e(float var1) {
      this.b(var1);
   }

   public void f(float var1) {
      this.c(var1);
   }
}
