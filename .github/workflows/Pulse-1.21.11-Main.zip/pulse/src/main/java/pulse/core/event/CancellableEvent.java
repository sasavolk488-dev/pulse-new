package pulse.core.event;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class CancellableEvent extends Event {
   private boolean a;

   public void a() {
      this.a = false;
   }

   public void b() {
      this.a = true;
   }

   @Generated
   public boolean c() {
      return this.a;
   }

   @Generated
   public void a(boolean var1) {
      this.a = var1;
   }
}
