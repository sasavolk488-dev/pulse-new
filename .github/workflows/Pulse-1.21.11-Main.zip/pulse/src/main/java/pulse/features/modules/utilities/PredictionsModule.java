package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerLikeState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import pulse.utils.animation.Animation;
import pulse.core.event.impl.RenderEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.ParticleHandler;
import pulse.core.handler.impl.particle.ParticleTextures;
import pulse.core.handler.impl.particle.PhysicsMode;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.WorldRenderHelper;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;
import pulse.utils.render.RenderUtils;

@ModuleInfo(
   a = "Predictions",
   b = "Предсказывает траекторию снарядов",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class PredictionsModule extends Module {
   private final SeparatorSetting a = new SeparatorSetting("Предметы");
   private final BooleanSetting b = new BooleanSetting("Стрелы", true);
   private final BooleanSetting c = new BooleanSetting("Эндер-перлы", true);
   private final BooleanSetting f = new BooleanSetting("Трезубцы", true);
   private final BooleanSetting g = new BooleanSetting("Зелья", true);
   private final SeparatorSetting h = new SeparatorSetting("Линия траектории");
   private final NumberSetting i = new NumberSetting("Толщина линии", 2.5F, 0.5F, 5.0F, 0.1F);
   private final BooleanSetting j = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting k = new ColorSetting("Цвет линии", new Color(100, 200, 255)).a(() -> !this.j.a());
   private final BooleanSetting l = new BooleanSetting("Градиент", true);
   private final ColorSetting m = new ColorSetting("Конечный цвет", new Color(255, 100, 100)).a(() -> this.l.a() && !this.j.a());
   private final BooleanSetting n = new BooleanSetting("Затухание", true);
   private final NumberSetting o = new NumberSetting("Начало затухания %", 30.0F, 0.0F, 80.0F, 5.0F).a(() -> this.n.a());
   private final BooleanSetting p = new BooleanSetting("Стабилизация у прицела", true);
   private final SeparatorSetting q = new SeparatorSetting("Точка приземления");
   private final BooleanSetting r = new BooleanSetting("Показывать", true);
   private final NumberSetting s = new NumberSetting("Размер", 0.6F, 0.2F, 1.5F, 0.05F).a(() -> this.r.a());
   private final BooleanSetting t = new BooleanSetting("Свечение", true).a(() -> this.r.a());
   private final NumberSetting u = new NumberSetting("Размер свечения", 1.2F, 0.5F, 2.5F, 0.1F).a(() -> this.r.a() && this.t.a());
   private final BooleanSetting v = new BooleanSetting("Пульсация", true).a(() -> this.r.a());
   private final NumberSetting w = new NumberSetting("Скорость пульсации", 2.0F, 0.5F, 5.0F, 0.1F).a(() -> this.r.a() && this.v.a());
   private final SeparatorSetting x = new SeparatorSetting("При попадании");
   private final ColorSetting y = new ColorSetting("Цвет при попадании", new Color(255, 80, 80));
   private final SeparatorSetting z = new SeparatorSetting("След снаряда (частицы)");
   private final BooleanSetting A = new BooleanSetting("Партикл-след", true);
   private final ModeSetting B = new ModeSetting("Тип частиц", ParticleTextures.f, "Лучи").a(() -> this.A.a());
   private final ModeSetting C = new ModeSetting("Режим физики", PhysicsMode.b(), "Без физики").a(() -> this.A.a());
   private final NumberSetting D = new NumberSetting("Частиц на тик", 4.0F, 1.0F, 16.0F, 1.0F).a(() -> this.A.a());
   private final NumberSetting E = new NumberSetting("Размер частиц", 0.2F, 0.05F, 0.75F, 0.05F).a(() -> this.A.a());
   private final NumberSetting F = new NumberSetting("Время жизни", 14.0F, 4.0F, 40.0F, 1.0F).a(() -> this.A.a());
   private final BooleanSetting G = new BooleanSetting("Цвет клиента", true).a(() -> this.A.a());
   private final ColorSetting H = new ColorSetting("Цвет частиц", new Color(100, 200, 255)).a(() -> this.A.a() && !this.G.a());
   private final BooleanSetting I = new BooleanSetting("Градиент", true).a(() -> this.A.a());
   private final ColorSetting J = new ColorSetting("Конечный цвет", new Color(255, 100, 100)).a(() -> this.A.a() && this.I.a() && !this.G.a());
   private long K = -1L;
   private final List<List<Vec3d>> L = new ArrayList<>();
   private final List<Vec3d> M = new ArrayList<>();
   private boolean N = false;
   private long O = 0L;
   private final Animation P = new Animation();
   private final Animation Q = new Animation();
   private final List<List<Vec3d>> R = new ArrayList<>();
   private final List<Vec3d> S = new ArrayList<>();
   private boolean T = false;
   private boolean U = false;
   private long V = Long.MIN_VALUE;
   private Item W = null;

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      var paths = this.L;
      Animation opacity = this.P;
      Animation landing = this.Q;
      var points = this.M;
      if (d.player == null || d.world == null) {
         return;
      }
      ItemStack stack = d.player.getMainHandStack();
      PredictableItem kind = PredictableItem.a(stack);
      boolean valid;
      try {
         valid = kind != null && this.a(kind) && this.a(stack);
      } catch (RuntimeException | Error failure) {
         this.U = false;
         throw failure;
      }
      boolean visible = false;
      if (valid) {
         Item item = stack.getItem();
         boolean rebuild = !this.U;
         if (!rebuild) {
            long worldTime;
            try {
               worldTime = d.world.getTime();
            } catch (RuntimeException | Error failure) {
               if (item == null) {
                  this.b(var1);
               }
               throw failure;
            }
            rebuild = worldTime != this.V || item != this.W;
         }
         if (rebuild) {
            this.a(var1, stack);
            try {
               this.V = d.world.getTime();
            } catch (RuntimeException | Error failure) {
               this.V = 0L;
               throw failure;
            }
            this.W = item;
            this.U = true;
         }
         this.b(var1);
         visible = !paths.isEmpty();
      } else {
         this.U = false;
      }
      if (visible) {
         opacity.a(1.0, 0.3, pulse.utils.animation.util.Easings.h, true);
         landing.a(1.0, 0.25, pulse.utils.animation.util.Easings.F, true);
      } else {
         opacity.a(0.0, 0.2, pulse.utils.animation.util.Easings.g, true);
         landing.a(0.0, 0.15, pulse.utils.animation.util.Easings.g, true);
      }
      opacity.a();
      landing.a();
      if (opacity.j() > 0.01 && !paths.isEmpty()) {
         this.c(var1);
      }
      if (!opacity.b() && opacity.j() <= 0.01) {
         paths.clear();
         points.clear();
         this.N = false;
      }
      this.n();
      try {
         this.O = System.currentTimeMillis();
      } catch (RuntimeException | Error failure) {
         this.O = 0L;
         throw failure;
      }
   }

   private void n() {
      if (this.A.a() && d.world != null && d.player != null) {
         if (this.b.a() || this.c.a() || this.f.a() || this.g.a()) {
            long var1 = d.world.getTime();
            if (var1 != this.K) {
               this.K = var1;
               PhysicsMode var3 = PhysicsMode.a(this.C.e());
               Identifier var4 = ParticleTextures.a(this.B.e());
               int var5 = this.D.c();
               int var6 = this.F.c();
               float var7 = this.E.b();
               boolean var8 = this.I.a();
               int var9 = this.o();
               int var10 = this.p();
               Box var11 = d.player.getBoundingBox().expand(128.0);

               for (ProjectileEntity var13 : d.world.getEntitiesByClass(ProjectileEntity.class, var11, this::a)) {
                  double var14 = var13.getHeight() * 0.5;
                  Vec3d var16 = var13.getLerpedPos(0.0F);
                  Vec3d var17 = var13.getLerpedPos(1.0F);
                  Vec3d var18 = new Vec3d(var17.x, var17.y + var14, var17.z);
                  Vec3d var19 = new Vec3d(var16.x, var16.y + var14, var16.z);
                  if (!(var19.squaredDistanceTo(var18) < 9.999995998224017E-5)) {
                     for (int var20 = 0; var20 < var5; var20++) {
                        double var21 = var5 <= 1 ? 1.0 : (double)var20 / (var5 - 1);
                        Vec3d var23 = var19.lerp(var18, var21);
                        Vec3d var24 = new Vec3d(
                           ThreadLocalRandom.current().nextDouble(-0.010000003845801917, 0.010000003758960761),
                           ThreadLocalRandom.current().nextDouble(-0.010000003845801917, 0.010000003758960761),
                           ThreadLocalRandom.current().nextDouble(-0.010000003845801917, 0.010000003758960761)
                        );
                        ParticleHandler.Builder var25 = HandlerRegistry.g.d().a(var23).b(var24).a(var6).a(var7).a(var4).a(0.0).a(0.2F, 1.0F, 0.0F).a(var3);
                        if (var8) {
                           var25.a(var9, var10);
                        } else {
                           var25.b(var9);
                        }

                        var25.a();
                     }
                  }
               }
            }
         }
      }
   }

   private boolean a(Entity var1) {
      if (var1 instanceof TridentEntity) {
         return this.f.a();
      } else if (var1 instanceof PersistentProjectileEntity) {
         return this.b.a();
      } else if (var1 instanceof EnderPearlEntity) {
         return this.c.a();
      } else {
         return var1 instanceof PotionEntity ? this.g.a() : false;
      }
   }

   private int o() {
      Color var1 = this.G.a() ? ModuleRegistry.aw.n() : this.H.a();
      return ColorUtils.a(var1.getRGB());
   }

   private int p() {
      Color var1 = this.G.a() ? this.a(ModuleRegistry.aw.n()) : this.J.a();
      return ColorUtils.a(var1.getRGB());
   }

   private boolean a(PredictionsModule.PredictableItem var1) {
      switch (var1) {
         case a:
            return this.c.a();
         case b:
            return this.f.a();
         case c:
            return this.b.a();
         case d:
            return this.g.a();
         default:
            return false;
      }
   }

   private void a(RenderEvent var1, ItemStack var2) {
      this.R.clear();
      this.S.clear();
      this.T = false;
      float var3 = var1.b();
      Vec3d var4 = this.a(var3);
      Vec3d var5 = this.s();
      boolean var6 = false;

      try {
         ItemEnchantmentsComponent var7 = EnchantmentHelper.getEnchantments(var2);

         for (RegistryEntry var9 : var7.getEnchantments()) {
            if (!var9.getKey().isEmpty() && var9.getKey().get() == Enchantments.MULTISHOT) {
               var6 = true;
               break;
            }
         }
      } catch (Exception var34) {
         var6 = false;
      }

      ArrayList<Vec3d> var35 = new ArrayList<>();
      if (var2.getItem() == Items.CROSSBOW && var6) {
         double var36 = 3.1500011518896067;
         Vec3d var10 = d.player.getRotationVec(var3);
         Vector3f var11 = new Vector3f((float)var10.x, (float)var10.y, (float)var10.z);
         Vector3f var12 = new Vector3f((float)var10.x, (float)var10.y, (float)var10.z);
         Vector3f var13 = new Vector3f((float)var10.x, (float)var10.y, (float)var10.z);
         var12.rotate(RotationAxis.POSITIVE_Y.rotationDegrees(-10.0F));
         var13.rotate(RotationAxis.POSITIVE_Y.rotationDegrees(10.0F));
         var35.add(new Vec3d(var11.x(), var11.y(), var11.z()).normalize().multiply(var36).add(var5));
         var35.add(new Vec3d(var12.x(), var12.y(), var12.z()).normalize().multiply(var36).add(var5));
         var35.add(new Vec3d(var13.x(), var13.y(), var13.z()).normalize().multiply(var36).add(var5));
      } else {
         var35.add(this.a(var2, var3));
      }

      PredictionsModule.PredictableItem var37 = PredictionsModule.PredictableItem.a(var2);
      ArrayList<PredictionsModule.BlockPath> var38 = new ArrayList<>();
      double var39 = Double.POSITIVE_INFINITY;
      double var40 = Double.POSITIVE_INFINITY;
      double var14 = Double.POSITIVE_INFINITY;
      double var16 = Double.NEGATIVE_INFINITY;
      double var18 = Double.NEGATIVE_INFINITY;
      double var20 = Double.NEGATIVE_INFINITY;

      for (Vec3d var23 : var35) {
         PredictionsModule.BlockPath var24 = this.a(var4, var23, var37);
         var38.add(var24);

         for (Vec3d var26 : var24.a) {
            if (var26.x < var39) {
               var39 = var26.x;
            }

            if (var26.y < var40) {
               var40 = var26.y;
            }

            if (var26.z < var14) {
               var14 = var26.z;
            }

            if (var26.x > var16) {
               var16 = var26.x;
            }

            if (var26.y > var18) {
               var18 = var26.y;
            }

            if (var26.z > var20) {
               var20 = var26.z;
            }
         }
      }

      Box var41 = var39 <= var16 ? new Box(var39, var40, var14, var16, var18, var20) : null;
      var var42 = this.a(var41);

      for (PredictionsModule.BlockPath var44 : var38) {
         var var45 = var44.a;
         ArrayList var27 = new ArrayList<>(var45.size());
         Vec3d var28 = null;
         boolean var29 = false;

         for (int var30 = 0; var30 < var45.size(); var30++) {
            Vec3d var31 = (Vec3d)var45.get(var30);
            if (var30 > 0) {
               EntityHitResult var32 = this.a((Vec3d)var45.get(var30 - 1), var31, var42);
               if (var32 != null) {
                  Vec3d var33 = var32.getPos();
                  var27.add(var33.subtract(var4));
                  var28 = var33.subtract(var4);
                  this.T = true;
                  var29 = true;
                  break;
               }
            }

            var27.add(var31.subtract(var4));
         }

         if (!var29 && var44.b && !var45.isEmpty()) {
            var28 = ((Vec3d)var45.get(var45.size() - 1)).subtract(var4);
         }

         this.R.add(var27);
         this.S.add(var28);
      }
   }

   private PredictionsModule.BlockPath a(Vec3d var1, Vec3d var2, PredictionsModule.PredictableItem var3) {
      ArrayList var4 = new ArrayList<>();
      Vec3d var5 = var1;
      Vec3d var6 = var2;
      short var7 = 200;
      var4.add(var1);

      for (int var8 = 0; var8 < var7; var8++) {
         Vec3d var9 = var5;
         var5 = var5.add(var6);
         RaycastContext var10 = new RaycastContext(var9, var5, ShapeType.COLLIDER, FluidHandling.NONE, d.player);
         BlockHitResult var11 = d.world.raycast(var10);
         if (var11.getType() != Type.MISS) {
            var4.add(var11.getPos());
            return new PredictionsModule.BlockPath(var4, true);
         }

         if (var5.y < -64.0) {
            var4.add(var5);
            return new PredictionsModule.BlockPath(var4, true);
         }

         var4.add(var5);
         var6 = this.a(var6, var3);
      }

      return new PredictionsModule.BlockPath(var4, false);
   }

   private List<LivingEntity> a(Box var1) {
      ArrayList<LivingEntity> var2 = new ArrayList<>();
      if (var1 != null && d.world != null && d.player != null) {
         Box var3 = var1.expand(1.0);

         for (Entity var5 : d.world.getOtherEntities(d.player, var3)) {
            if (var5 != d.player && var5.isAlive() && var5 instanceof LivingEntity var6) {
               var2.add(var6);
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private EntityHitResult a(Vec3d var1, Vec3d var2, List<LivingEntity> var3) {
      Entity var4 = null;
      Vec3d var5 = null;
      double var6 = 1.7976922776554308E308;

      for (Entity var9 : var3) {
         if (var9.isAlive()) {
            Box var10 = var9.getBoundingBox().expand(0.3000000317600329);
            Optional var11 = var10.raycast(var1, var2);
            if (var11.isPresent()) {
               Vec3d var12 = (Vec3d)var11.get();
               double var13 = var1.squaredDistanceTo(var12);
               if (var13 < var6) {
                  var6 = var13;
                  var4 = var9;
                  var5 = var12;
               }
            }
         }
      }

      return var4 != null && var5 != null ? new EntityHitResult(var4, var5) : null;
   }

   private void b(RenderEvent var1) {
      this.L.clear();
      this.M.clear();
      this.N = this.T;
      Vec3d var2 = this.a(var1.b());

      for (int var3 = 0; var3 < this.R.size(); var3++) {
         List<Vec3d> var4 = this.R.get(var3);
         ArrayList var5 = new ArrayList<>(var4.size());

         for (Vec3d var7 : var4) {
            var5.add(var2.add(var7));
         }

         this.L.add(var5);
         Vec3d var8 = this.S.get(var3);
         if (var8 != null) {
            this.M.add(var2.add(var8));
         }
      }
   }

   private void c(RenderEvent var1) {
      if (!this.L.isEmpty()) {
         MatrixStack var2 = var1.a();
         Vec3d var3 = d.gameRenderer.getCamera().getCameraPos();
         var2.push();
         if (this.p.a()) {
            this.a(var2, var1.b());
         }

         Entry var4 = var2.peek();
         Color var5 = this.N ? this.y.a() : this.q();
         Color var6 = this.N ? this.a(this.y.a()) : this.r();
         float var7 = this.o.b() / 100.0F;
         float var8 = this.i.b() * 0.0013F;
         VertexConsumer var9 = WorldRenderHelper.a().getBuffer(BlockOverlayLayers.f);

         for (List var11 : this.L) {
            if (var11.size() >= 2) {
               int var12 = var11.size();

               for (int var13 = 0; var13 + 1 < var12; var13++) {
                  this.a(var9, var4, (Vec3d)var11.get(var13), (Vec3d)var11.get(var13 + 1), var3, var13, var13 + 1, var12, var5, var6, var7, 1.0F, var8, true);
               }

               for (int var16 = 0; var16 + 1 < var12; var16++) {
                  this.a(
                     var9,
                     var4,
                     (Vec3d)var11.get(var16),
                     (Vec3d)var11.get(var16 + 1),
                     var3,
                     var16,
                     var16 + 1,
                     var12,
                     var5,
                     var6,
                     var7,
                     0.15F,
                     var8 * 3.0F,
                     false
                  );
               }
            }
         }

         WorldRenderHelper.a(BlockOverlayLayers.f);
         var2.pop();
         if (this.r.a()) {
            for (Vec3d var15 : this.M) {
               this.a(var1, var3, var15);
            }
         }
      }
   }

   private void a(
      VertexConsumer var1,
      Entry var2,
      Vec3d var3,
      Vec3d var4,
      Vec3d var5,
      int var6,
      int var7,
      int var8,
      Color var9,
      Color var10,
      float var11,
      float var12,
      float var13,
      boolean var14
   ) {
      float var15 = this.a(var6, var8, var11, var12, var14);
      float var16 = this.a(var7, var8, var11, var12, var14);
      float var17 = var8 <= 1 ? 0.0F : (float)var6 / (var8 - 1);
      float var18 = var8 <= 1 ? 0.0F : (float)var7 / (var8 - 1);
      int var19 = var9.getRed();
      int var20 = var9.getGreen();
      int var21 = var9.getBlue();
      int var22 = var10.getRed();
      int var23 = var10.getGreen();
      int var24 = var10.getBlue();
      float var25;
      float var26;
      float var27;
      float var28;
      float var29;
      float var30;
      if (this.l.a()) {
         var25 = (int)(var19 + (var22 - var19) * var17) / 255.0F;
         var26 = (int)(var20 + (var23 - var20) * var17) / 255.0F;
         var27 = (int)(var21 + (var24 - var21) * var17) / 255.0F;
         var28 = (int)(var19 + (var22 - var19) * var18) / 255.0F;
         var29 = (int)(var20 + (var23 - var20) * var18) / 255.0F;
         var30 = (int)(var21 + (var24 - var21) * var18) / 255.0F;
      } else {
         var25 = var28 = var19 / 255.0F;
         var26 = var29 = var20 / 255.0F;
         var27 = var30 = var21 / 255.0F;
      }

      float var31 = (float)(var3.x - var5.x);
      float var32 = (float)(var3.y - var5.y);
      float var33 = (float)(var3.z - var5.z);
      float var34 = (float)(var4.x - var5.x);
      float var35 = (float)(var4.y - var5.y);
      float var36 = (float)(var4.z - var5.z);
      float var37 = var34 - var31;
      float var38 = var35 - var32;
      float var39 = var36 - var33;
      float var40 = (float)Math.sqrt(var37 * var37 + var38 * var38 + var39 * var39);
      if (!(var40 < 1.0E-6F)) {
         var37 /= var40;
         var38 /= var40;
         var39 /= var40;
         float var41 = (var31 + var34) * 0.5F;
         float var42 = (var32 + var35) * 0.5F;
         float var43 = (var33 + var36) * 0.5F;
         float var44 = (float)Math.sqrt(var41 * var41 + var42 * var42 + var43 * var43);
         if (!(var44 < 0.6F)) {
            float var45 = -var41 / var44;
            float var46 = -var42 / var44;
            float var47 = -var43 / var44;
            float var48 = var13 * var44;
            float var49 = var38 * var47 - var39 * var46;
            float var50 = var39 * var45 - var37 * var47;
            float var51 = var37 * var46 - var38 * var45;
            float var52 = (float)Math.sqrt(var49 * var49 + var50 * var50 + var51 * var51);
            if (var52 < 1.0E-4F) {
               var49 = -var39;
               var50 = 0.0F;
               var51 = var37;
               var52 = (float)Math.sqrt(var49 * var49 + var50 * var50 + var37 * var37);
               if (var52 < 1.0E-4F) {
                  var49 = 1.0F;
                  var50 = 0.0F;
                  var51 = 0.0F;
                  var52 = 1.0F;
               }
            }

            var49 = var49 / var52 * var48;
            var50 = var50 / var52 * var48;
            var51 = var51 / var52 * var48;
            float var53 = var31 + var49;
            float var54 = var32 + var50;
            float var55 = var33 + var51;
            float var56 = var31 - var49;
            float var57 = var32 - var50;
            float var58 = var33 - var51;
            float var59 = var34 + var49;
            float var60 = var35 + var50;
            float var61 = var36 + var51;
            float var62 = var34 - var49;
            float var63 = var35 - var50;
            float var64 = var36 - var51;
            var1.vertex(var2, var53, var54, var55).color(var25, var26, var27, var15);
            var1.vertex(var2, var56, var57, var58).color(var25, var26, var27, var15);
            var1.vertex(var2, var62, var63, var64).color(var28, var29, var30, var16);
            var1.vertex(var2, var53, var54, var55).color(var25, var26, var27, var15);
            var1.vertex(var2, var62, var63, var64).color(var28, var29, var30, var16);
            var1.vertex(var2, var59, var60, var61).color(var28, var29, var30, var16);
         }
      }
   }

   private float a(int var1, int var2, float var3, float var4, boolean var5) {
      float var6 = var2 <= 1 ? 0.0F : (float)var1 / (var2 - 1);
      float var7 = var4;
      if (this.n.a() && var6 > var3) {
         var7 = var4 * (1.0F - (var6 - var3) / (1.0F - var3));
      }

      if (var5) {
         var7 *= 1.0F + 0.05F * (float)Math.sin(this.O * 0.010000003758960761 + var1 * 0.3000000317600329);
      }

      var7 = Math.max(0.0F, Math.min(1.0F, var7));
      return var7 * (float)this.P.j();
   }

   private void a(MatrixStack var1, float var2) {
      ClientPlayerEntity var4 = d.player;
      if (var4 instanceof AbstractClientPlayerEntity) {
         if (d.options.getBobView().getValue()) {
            ClientPlayerLikeState var9 = var4.getState();
            float var5 = var9.getReverseLerpedDistanceMoved(var2);
            float var6 = var9.lerpMovement(var2);
            if (var6 != 0.0F) {
               float var7 = (float) Math.PI;
               Matrix4f var8 = new Matrix4f();
               var8.translate(MathHelper.sin(var5 * var7) * var6 * 0.5F, -Math.abs(MathHelper.cos(var5 * var7) * var6), 0.0F);
               var8.rotate(RotationAxis.POSITIVE_Z.rotationDegrees(MathHelper.sin(var5 * var7) * var6 * 3.0F));
               var8.rotate(RotationAxis.POSITIVE_X.rotationDegrees(Math.abs(MathHelper.cos(var5 * var7 - 0.2F) * var6) * 5.0F));
               var8.invert();
               var1.peek().getPositionMatrix().mulLocal(var8);
            }
         }
      }
   }

   private void a(RenderEvent var1, Vec3d var2, Vec3d var3) {
      MatrixStack var4 = var1.a();
      Color var5 = this.N ? this.y.a() : this.q();
      float var6 = 1.0F;
      if (this.v.a()) {
         float var7 = (float)this.O * this.w.b() * 0.003F % (float) (Math.PI * 2);
         var6 = 1.0F + 0.2F * (float)Math.sin(var7);
      }

      float var41 = (float)this.Q.j();
      float var8 = this.s.b() * var6 * var41;
      if (this.t.a()) {
         float var9 = this.u.b() * var6 * var41;
         int var10 = (int)(100.0F * (0.5F + 0.3F * (float)Math.sin(this.O * 0.005000001864940435)));
         int var11 = ColorUtils.a(ColorUtils.a(var5.getRGB()), var10);
         RenderUtils.a(var4, var3, var9, var11);
      }

      var4.push();
      float var42 = (float)(var3.x - var2.x);
      float var43 = (float)(var3.y - var2.y);
      float var44 = (float)(var3.z - var2.z);
      float var12 = var5.getRed() / 255.0F;
      float var13 = var5.getGreen() / 255.0F;
      float var14 = var5.getBlue() / 255.0F;
      float var15 = var8 * 0.3F;
      byte var16 = 16;
      byte var17 = 12;
      Immediate var18 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
      VertexConsumer var19 = var18.getBuffer(BlockOverlayLayers.f);
      Entry var20 = var4.peek();

      for (int var21 = 0; var21 < var17; var21++) {
         float var22 = (float) Math.PI * (-0.5F + (float)var21 / var17);
         float var23 = (float) Math.PI * (-0.5F + (float)(var21 + 1) / var17);
         float var24 = (float)Math.sin(var22);
         float var25 = (float)Math.sin(var23);
         float var26 = (float)Math.cos(var22);
         float var27 = (float)Math.cos(var23);

         for (int var28 = 0; var28 < var16; var28++) {
            float var29 = (float) (Math.PI * 2) * var28 / var16;
            float var30 = (float) (Math.PI * 2) * (var28 + 1) / var16;
            float var31 = var26 * (float)Math.cos(var29);
            float var32 = var26 * (float)Math.sin(var29);
            float var33 = var26 * (float)Math.cos(var30);
            float var34 = var26 * (float)Math.sin(var30);
            float var35 = var27 * (float)Math.cos(var29);
            float var36 = var27 * (float)Math.sin(var29);
            float var37 = var27 * (float)Math.cos(var30);
            float var38 = var27 * (float)Math.sin(var30);
            float var39 = 0.5F + 0.4F * (var24 + 1.0F) / 2.0F;
            float var40 = 0.5F + 0.4F * (var25 + 1.0F) / 2.0F;
            var19.vertex(var20, var42 + var31 * var15, var43 + var24 * var15, var44 + var32 * var15)
               .color(var12, var13, var14, var39)
               .normal(var20, 0.0F, 1.0F, 0.0F);
            var19.vertex(var20, var42 + var35 * var15, var43 + var25 * var15, var44 + var36 * var15)
               .color(var12, var13, var14, var40)
               .normal(var20, 0.0F, 1.0F, 0.0F);
            var19.vertex(var20, var42 + var33 * var15, var43 + var24 * var15, var44 + var34 * var15)
               .color(var12, var13, var14, var39)
               .normal(var20, 0.0F, 1.0F, 0.0F);
            var19.vertex(var20, var42 + var33 * var15, var43 + var24 * var15, var44 + var34 * var15)
               .color(var12, var13, var14, var39)
               .normal(var20, 0.0F, 1.0F, 0.0F);
            var19.vertex(var20, var42 + var35 * var15, var43 + var25 * var15, var44 + var36 * var15)
               .color(var12, var13, var14, var40)
               .normal(var20, 0.0F, 1.0F, 0.0F);
            var19.vertex(var20, var42 + var37 * var15, var43 + var25 * var15, var44 + var38 * var15)
               .color(var12, var13, var14, var40)
               .normal(var20, 0.0F, 1.0F, 0.0F);
         }
      }

      VertexConsumer var45 = WorldRenderHelper.g();
      float var46 = this.i.b();

      for (int var47 = 0; var47 < var16; var47++) {
         float var49 = (float) (Math.PI * 2) * var47 / var16;
         float var51 = (float) (Math.PI * 2) * (var47 + 1) / var16;
         float var53 = (float)Math.cos(var49);
         float var55 = (float)Math.sin(var49);
         float var57 = (float)Math.cos(var51);
         float var59 = (float)Math.sin(var51);
         float var61 = var57 - var53;
         float var63 = var59 - var55;
         float var65 = (float)Math.sqrt(var61 * var61 + var63 * var63);
         if (var65 < 1.0E-6F) {
            var65 = 1.0F;
         }

         float var67 = var61 / var65;
         float var69 = var63 / var65;
         var45.vertex(var20, var42 + var53 * var15, var43, var44 + var55 * var15)
            .color(var12, var13, var14, 0.9F)
            .normal(var20, var67, 0.0F, var69)
            .lineWidth(var46);
         var45.vertex(var20, var42 + var57 * var15, var43, var44 + var59 * var15)
            .color(var12, var13, var14, 0.9F)
            .normal(var20, -var67, 0.0F, -var69)
            .lineWidth(var46);
      }

      for (int var48 = 0; var48 < var16; var48++) {
         float var50 = (float) (Math.PI * 2) * var48 / var16;
         float var52 = (float) (Math.PI * 2) * (var48 + 1) / var16;
         float var54 = (float)Math.sin(var50);
         float var56 = (float)Math.cos(var50);
         float var58 = (float)Math.sin(var52);
         float var60 = (float)Math.cos(var52);
         float var62 = var58 - var54;
         float var64 = var60 - var56;
         float var66 = (float)Math.sqrt(var62 * var62 + var64 * var64);
         if (var66 < 1.0E-6F) {
            var66 = 1.0F;
         }

         float var68 = var62 / var66;
         float var70 = var64 / var66;
         var45.vertex(var20, var42 + var56 * var15, var43 + var54 * var15, var44)
            .color(var12, var13, var14, 0.8F)
            .normal(var20, var70, var68, 0.0F)
            .lineWidth(var46);
         var45.vertex(var20, var42 + var60 * var15, var43 + var58 * var15, var44)
            .color(var12, var13, var14, 0.8F)
            .normal(var20, -var70, -var68, 0.0F)
            .lineWidth(var46);
         var45.vertex(var20, var42, var43 + var54 * var15, var44 + var56 * var15)
            .color(var12, var13, var14, 0.8F)
            .normal(var20, 0.0F, var68, var70)
            .lineWidth(var46);
         var45.vertex(var20, var42, var43 + var58 * var15, var44 + var60 * var15)
            .color(var12, var13, var14, 0.8F)
            .normal(var20, 0.0F, -var68, -var70)
            .lineWidth(var46);
      }

      WorldRenderHelper.e();
      var18.draw(BlockOverlayLayers.f);
      var4.pop();
   }

   private Color q() {
      return this.j.a() ? ModuleRegistry.aw.n() : this.k.a();
   }

   private Color r() {
      return this.j.a() ? this.a(ModuleRegistry.aw.n()) : this.m.a();
   }

   private Color a(Color var1) {
      return new Color(Math.max(0, var1.getRed() - 80), Math.max(0, var1.getGreen() - 40), Math.min(255, var1.getBlue() + 30));
   }

   private Vec3d a(Vec3d var1, PredictionsModule.PredictableItem var2) {
      return var2 == null ? var1 : var1.multiply(var2.e).subtract(0.0, var2.f, 0.0);
   }

   private Vec3d s() {
      double var1 = d.player.getVelocity().y;
      return new Vec3d(0.0, var1 * 0.5, 0.0);
   }

   private Vec3d a(ItemStack var1, float var2) {
      Item var3 = var1.getItem();
      Vec3d var4 = this.s();
      if (var3 == Items.BOW) {
         int var11 = var1.getMaxUseTime(d.player);
         float var13 = var11 - d.player.getItemUseTimeLeft();
         if (var13 < 0.0F) {
            var13 = 0.0F;
         }

         float var14 = var13 / 20.0F;
         var14 = (var14 * var14 + var14 * 2.0F) / 3.0F;
         if (var14 > 1.0F) {
            var14 = 1.0F;
         }

         if (var14 < 0.05F) {
            var14 = 0.05F;
         }

         Vec3d var8 = this.a(d.player.getYaw(), d.player.getPitch());
         return var8.multiply(3.0 * var14).add(var4);
      } else if (var3 == Items.CROSSBOW) {
         Vec3d var10 = this.a(d.player.getYaw(), d.player.getPitch());
         return var10.multiply(3.1500011518896067).add(var4);
      } else if (var3 == Items.TRIDENT) {
         float var9 = d.player.getItemUseTimeLeft();
         if (var9 < 0.0F) {
            var9 = 0.0F;
         }

         float var12 = var9 / 10.0F;
         if (var12 > 1.0F) {
            var12 = 1.0F;
         }

         if (var12 < 0.1F) {
            var12 = 0.1F;
         }

         Vec3d var7 = this.a(d.player.getYaw(), d.player.getPitch());
         return var7.multiply(2.5 * var12).add(var4);
      } else {
         Vec3d var5 = this.a(d.player.getYaw(), d.player.getPitch());
         double var6 = 1.5;
         if (var3 == Items.SPLASH_POTION || var3 == Items.LINGERING_POTION) {
            var6 = 0.5;
         }

         return var5.multiply(var6).add(var4);
      }
   }

   private boolean a(ItemStack var1) {
      Item var2 = var1.getItem();
      if (var2 == Items.BOW) {
         return d.player.getItemUseTimeLeft() > 0;
      } else if (var2 != Items.CROSSBOW) {
         return var2 == Items.TRIDENT ? d.player.getItemUseTimeLeft() > 0 : true;
      } else {
         ChargedProjectilesComponent var3 = var1.get(DataComponentTypes.CHARGED_PROJECTILES);
         return var3 != null && !var3.isEmpty();
      }
   }

   private Vec3d a(float var1) {
      return d.gameRenderer.getCamera().getCameraPos();
   }

   private Vec3d a(float var1, float var2) {
      float var3 = MathHelper.cos(var2 * (float) (Math.PI / 180.0));
      float var4 = MathHelper.sin(var2 * (float) (Math.PI / 180.0));
      float var5 = MathHelper.cos(var1 * (float) (Math.PI / 180.0));
      float var6 = MathHelper.sin(var1 * (float) (Math.PI / 180.0));
      float var7 = -var6 * var3;
      float var8 = -var4;
      float var9 = var5 * var3;
      return new Vec3d(var7, var8, var9).normalize();
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.L.clear();
      this.M.clear();
      this.R.clear();
      this.S.clear();
      this.T = false;
      this.U = false;
      this.W = null;
      this.P.d(0.0);
      this.Q.d(0.0);
   }

   static {
      NativeMethodLookup.lookup(PredictionsModule.class, 70);
   }

   @Environment(EnvType.CLIENT)
   private static final class BlockPath {
      final List<Vec3d> a;
      final boolean b;

      BlockPath(List<Vec3d> var1, boolean var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   @Environment(EnvType.CLIENT)
   private static enum PredictableItem {
      a(0.9900001196755193, 0.029999989348058503),
      b(0.9900001196755193, 0.0500000018708313),
      c(0.9900001196755193, 0.0500000018708313),
      d(0.9900001196755193, 0.0500000018708313);

      final double e;
      final double f;

      private PredictableItem(double var3, double var5) {
         this.e = var3;
         this.f = var5;
      }

      public static PredictionsModule.PredictableItem a(ItemStack var0) {
         if (var0 != null && !var0.isEmpty()) {
            Item var1 = var0.getItem();
            if (var1 == Items.ENDER_PEARL) {
               return a;
            } else if (var1 == Items.TRIDENT) {
               return b;
            } else if (var1 == Items.BOW || var1 == Items.CROSSBOW) {
               return c;
            } else {
               return var1 != Items.SPLASH_POTION && var1 != Items.LINGERING_POTION ? null : d;
            }
         } else {
            return null;
         }
      }

      private static PredictionsModule.PredictableItem[] a() {
         return new PredictionsModule.PredictableItem[]{a, b, c, d};
      }
   }
}
