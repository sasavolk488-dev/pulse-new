package pulse.features.modules.hud;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Low HP",
   b = "Пульсирующее сердце с остатком здоровья и подсветка краёв экрана на критическом хп",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class LowHpModule extends Module {
   private final NumberSetting a = new NumberSetting("Порог, %", 35.0F, 10.0F, 75.0F, 5.0F);
   private final SeparatorSetting b = new SeparatorSetting("Отображение");
   private final ModeSetting c = new ModeSetting("Позиция", new String[]{"Над хотбаром", "Под прицелом", "Справа снизу"}, "Над хотбаром");
   private final BooleanSetting f = new BooleanSetting("Сердце", true);
   private final BooleanSetting g = new BooleanSetting("Подсветка краёв", true);
   private final NumberSetting h = new NumberSetting("Сила подсветки", 0.6F, 0.1F, 1.0F, 0.05F).a(this.g::a);
   private final SeparatorSetting i = new SeparatorSetting("Звук");
   private final BooleanSetting j = new BooleanSetting("Сердцебиение", false);
   private final NumberSetting k = new NumberSetting("Громкость", 0.5F, 0.1F, 1.0F, 0.05F).a(this.j::a);
   private static final Identifier l = Identifier.of("minecraft", "textures/gui/sprites/hud/heart/full.png");
   private static final float m = 14.0F;
   private static final float n = 6.0F;
   private static final Color o = new Color(255, 176, 64);
   private static final Color p = new Color(255, 56, 56);
   private final Animation q = new Animation();
   private double r;
   private long s;
   private float t;
   private int u;
   private static final FontRenderContext v = new FontRenderContext(new AffineTransform(), true, true);
   private static final Map<FontRenderer, float[]> w = new HashMap<>();

   @Override
   public void e() {
      super.e();
      this.q.d(0.0);
      this.r = 0.0;
      this.s = 0L;
      this.t = 0.0F;
      this.u = 0;
   }

   @EventHandler
   private void a(RenderHudPostEvent var1) {
      ClientPlayerEntity var2 = d.player;
      if (var2 != null && d.world != null && !d.options.hudHidden) {
         Render var3 = Pulse.l().p();
         if (var3 != null) {
            float var4 = Math.max(1.0F, var2.getMaxHealth());
            float var5 = Math.max(0.0F, var2.getHealth()) + var2.getAbsorptionAmount();
            float var6 = MathHelper.clamp(var5 / var4, 0.0F, 1.0F);
            float var7 = this.a.b() / 100.0F;
            boolean var8 = var2.isAlive() && !var2.isSpectator() && !var2.isCreative() && var6 <= var7;
            float var9 = var7 <= 0.0F ? 1.0F : MathHelper.clamp(1.0F - var6 / var7, 0.0F, 1.0F);
            this.a(var2, var8, var9);
            float var10 = (float)this.q.j();
            if (!(var10 < 0.01F)) {
               float var11 = MathHelper.clamp(a(this.r) + this.t, 0.0F, 1.0F);
               Color var12 = a(o, p, var9);
               float var13 = d.getWindow().getFramebufferWidth() / 2.0F;
               float var14 = d.getWindow().getFramebufferHeight() / 2.0F;
               if (this.g.a()) {
                  this.a(var3, var1.a(), var13, var14, var12, var10, var11, var9);
               }

               if (this.f.a()) {
                  this.a(var3, var1.a(), var2, var13, var14, var12, var10, var11, var5);
               }
            }
         }
      }
   }

   private void a(ClientPlayerEntity var1, boolean var2, float var3) {
      long var4 = System.nanoTime();
      float var6 = this.s == 0L ? 0.0F : (float)((var4 - this.s) / 1.0E9);
      this.s = var4;
      var6 = MathHelper.clamp(var6, 0.0F, 0.1F);
      if (var2 && this.q.i() < 1.0) {
         this.q.a(1.0, 0.18000001541162985, Easings.h);
      } else if (!var2 && this.q.i() > 0.0) {
         this.q.a(0.0, 0.30000017882169366, Easings.h);
      }

      this.q.a();
      double var7 = 1.0 + 1.4000003111083674 * var3;
      this.r += var6 * var7;
      boolean var9 = this.r >= 1.0;
      this.r %= 1.0;
      if (var9 && var2 && this.j.a()) {
         d.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 1.2F + 0.4F * var3, this.k.b()));
      }

      if (var1.hurtTime > this.u) {
         this.t = 1.0F;
      }

      this.u = var1.hurtTime;
      this.t = Math.max(0.0F, this.t - var6 * 3.5F);
   }

   private static float a(double var0) {
      return (float)Math.min(1.0, a(var0, 0.0, 0.055000001397681623) + 0.5500000392320226 * a(var0, 0.2399999478496062, 0.05999998557541947));
   }

   private static double a(double var0, double var2, double var4) {
      double var6 = var0 - var2;
      var6 -= Math.floor(var6 + 0.5);
      return Math.exp(-(var6 * var6) / (2.0 * var4 * var4));
   }

   private void a(Render var1, MatrixStack var2, float var3, float var4, Color var5, float var6, float var7, float var8) {
      float var9 = var6 * this.h.b() * (0.35F + 0.65F * var7) * (0.55F + 0.45F * var8);
      int var10 = (int)(MathHelper.clamp(var9, 0.0F, 1.0F) * 90.0F);
      if (var10 > 1) {
         Color var11 = new Color(var5.getRed(), var5.getGreen() / 3, var5.getBlue() / 3, var10);
         Color var12 = new Color(var11.getRed(), var11.getGreen(), var11.getBlue(), 0);
         float var13 = var4 * 0.3F;
         float var14 = var3 * 0.2F;
         var1.a(0.0F, 0.0F, var3, var13, 0.0F, var11, var11, var12, var12, var2);
         var1.a(0.0F, var4 - var13, var3, var13, 0.0F, var12, var12, var11, var11, var2);
         var1.a(0.0F, 0.0F, var14, var4, 0.0F, var11, var12, var11, var12, var2);
         var1.a(var3 - var14, 0.0F, var14, var4, 0.0F, var12, var11, var12, var11, var2);
      }
   }

   private void a(Render var1, MatrixStack var2, ClientPlayerEntity var3, float var4, float var5, Color var6, float var7, float var8, float var9) {
      FontRenderer var10 = Fonts.b[28];
      String var11 = a(var9);
      float var12 = var10.a(var11);
      float var13 = 20.0F + var12;
      float[] var14 = this.a(var3, var4, var5, var13);
      float var15 = var14[0];
      float var16 = var14[1];
      float var17 = 14.0F * (1.0F + 0.18F * var8);
      var1.a(l, var15 + (14.0F - var17) / 2.0F, var16 - var17 / 2.0F, var17, var17, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, a(Color.WHITE, var7), var2);
      float[] var18 = a(var10);
      float var19 = var15 + 14.0F + 6.0F;
      float var20 = var16 - var18[1] / 2.0F - var18[0];
      var10.a(var11, var19 + 1.0F, var20 + 1.0F, a(new Color(0, 0, 0), var7 * 0.65F), var2);
      var10.a(var11, var19, var20, a(var6, var7), var2);
   }

   private float[] a(ClientPlayerEntity var1, float var2, float var3, float var4) {
      if (this.c.b("Под прицелом")) {
         return new float[]{(var2 - var4) / 2.0F, var3 / 2.0F + 34.0F};
      } else if (this.c.b("Справа снизу")) {
         return new float[]{var2 - var4 - 14.0F, var3 - 14.0F - 7.0F};
      } else {
         float var5 = d.getWindow().getScaleFactor() / 2.0F;
         int var6 = MathHelper.clamp(MathHelper.ceil((var1.getMaxHealth() + var1.getAbsorptionAmount()) / 20.0F) - 1, 0, 4);
         float var7 = (55.0F + var6 * 10.0F) * var5;
         return new float[]{(var2 - var4) / 2.0F, var3 - var7 - 7.0F};
      }
   }

   private static float[] a(FontRenderer var0) {
      return w.computeIfAbsent(var0, var0x -> {
         Rectangle2D var1 = var0x.b().createGlyphVector(v, "0").getVisualBounds();
         Graphics2D var2 = new BufferedImage(1, 1, 2).createGraphics();
         var2.setFont(var0x.b());
         float var3 = var2.getFontMetrics().getAscent();
         var2.dispose();
         return new float[]{(var3 + (float)var1.getY()) / 2.0F, (float)var1.getHeight() / 2.0F};
      });
   }

   private static String a(float var0) {
      float var1 = Math.round(var0 * 10.0F) / 10.0F;
      return Math.abs(var1 - Math.round(var1)) < 0.05F ? String.valueOf(Math.round(var1)) : String.format(Locale.ROOT, "%.1f", var1);
   }

   private static Color a(Color var0, float var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), MathHelper.clamp((int)(var0.getAlpha() * var1), 0, 255));
   }

   private static Color a(Color var0, Color var1, float var2) {
      var2 = MathHelper.clamp(var2, 0.0F, 1.0F);
      return new Color(
         (int)(var0.getRed() + (var1.getRed() - var0.getRed()) * var2),
         (int)(var0.getGreen() + (var1.getGreen() - var0.getGreen()) * var2),
         (int)(var0.getBlue() + (var1.getBlue() - var0.getBlue()) * var2)
      );
   }
}
