package pulse.features.modules.visuals;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.visuals.animations.ChatAnimator;
import pulse.features.modules.visuals.animations.HotbarAnimator;
import pulse.features.modules.visuals.animations.PerspectiveAnimator;
import pulse.features.modules.visuals.animations.PlayerListAnimator;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Animations",
   b = "Анимации интерфейса",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class AnimationsModule extends Module {
   private final SeparatorSetting k = new SeparatorSetting("Таб");
   public final BooleanSetting a = new BooleanSetting("Анимация таба", true);
   public final NumberSetting b = new NumberSetting("Длительность таба", 200.0F, 50.0F, 500.0F, 10.0F).a(this.a::a);
   private final SeparatorSetting l = new SeparatorSetting("Чат");
   public final BooleanSetting c = new BooleanSetting("Анимация чата", true);
   public final NumberSetting f = new NumberSetting("Длительность чата", 200.0F, 50.0F, 500.0F, 10.0F).a(this.c::a);
   private final SeparatorSetting m = new SeparatorSetting("Хотбар");
   public final BooleanSetting g = new BooleanSetting("Анимация хотбара", true);
   public final NumberSetting h = new NumberSetting("Длительность хотбара", 100.0F, 50.0F, 500.0F, 10.0F).a(this.g::a);
   private final SeparatorSetting n = new SeparatorSetting("Смена перспективы");
   public final BooleanSetting i = new BooleanSetting("Анимация перспективы", true);
   public final NumberSetting j = new NumberSetting("Длительность перспективы", 300.0F, 50.0F, 1000.0F, 10.0F).a(this.i::a);
   private static PlayerListAnimator o;
   private static ChatAnimator p;
   private static HotbarAnimator q;
   private static PerspectiveAnimator r;

   public static PlayerListAnimator n() {
      if (o == null) {
         o = new PlayerListAnimator();
      }

      return o;
   }

   public static ChatAnimator o() {
      if (p == null) {
         p = new ChatAnimator();
      }

      return p;
   }

   public static HotbarAnimator p() {
      if (q == null) {
         q = new HotbarAnimator();
      }

      return q;
   }

   public static PerspectiveAnimator q() {
      if (r == null) {
         r = new PerspectiveAnimator();
      }

      return r;
   }
}
