package pulse.core.handler.impl.autoevent;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import pulse.ui.clickgui.menu.markers.MarkerEntry;
import pulse.ui.clickgui.menu.markers.MarkerManager;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.handler.impl.autoevent.parser.FillCubeEventParser;
import pulse.core.handler.impl.autoevent.parser.FunTimeEventParser;
import pulse.core.handler.impl.autoevent.parser.HolyWorldEventParser;
import pulse.features.modules.hud.components.WatermarkComponent;
import pulse.core.api.IMinecraft;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.FTHelperModule;
import pulse.utils.game.ChatUtils;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class AutoEventHandler extends Handler implements IMinecraft {
   private static final long a = 600000L;
   private static final Set<Integer> b = Set.of(106, 107, 212, 213, 214, 308, 309);
   private static final long c = 5000L;
   private static final long f = 2000L;
   private static final Pattern g = Pattern.compile("(СолоЛайт|ДуоЛайт|ТриоЛайт|КланЛайт)\\s*#(\\d{1,2})");
   private final List<ServerEventParser> h = new ArrayList<>();
   private ServerEventParser i;
   private boolean j = false;
   private boolean k = false;
   private boolean l = false;
   private long m = 0L;
   private String[] n = null;
   private long o = 0L;
   private String p = null;
   private int q = -1;
   private static final String[] r = new String[]{"Загадочный маяк", "Мистический сундук", "Метеоритный дождь", "Маяк убийца", "Алтарь", "Вулкан", "Аирдроп"};

   public AutoEventHandler() {
      this.h.add(new FunTimeEventParser());
      this.h.add(new FillCubeEventParser());
      this.h.add(new HolyWorldEventParser());
   }

   @EventHandler
   @Compile
   private void a(PacketEvent var1) {
      if (!pulse.ui.clickgui.menu.markers.MarkerSettings.h() || d.player == null) {
         return;
      }
      if (!(var1.d() instanceof net.minecraft.network.packet.s2c.play.GameMessageS2CPacket)) {
         return;
      }
      net.minecraft.network.packet.Packet<?> packet = var1.d();
      this.v();
      if (this.i == null) {
         return;
      }
      String message = ((net.minecraft.network.packet.s2c.play.GameMessageS2CPacket)packet).content().getString();
      String normalized = Formatting.strip(message).toLowerCase(java.util.Locale.ROOT);
      boolean pending = this.k;
      if (this.i.a(normalized, message, this) && pending) {
         var1.b();
      }
   }

   @EventHandler
   @Compile
   private void a(UpdateEvent var1) {
      if (d.player == null) {
         return;
      }
      this.y();
      if (!pulse.ui.clickgui.menu.markers.MarkerSettings.h() || !this.j()) {
         return;
      }
      this.v();
      this.w();
      MarkerManager.e();
      if (this.i != null) {
         this.i.a(this);
      }
   }

   @EventHandler
   @Compile
   private void a(WorldChangeEvent var1) {
      if (pulse.ui.clickgui.menu.markers.MarkerSettings.h()) {
         this.j = true;
      }
   }

   private void v() {
      String var1 = this.z();
      if (var1 == null) {
         this.i = null;
      } else if (this.i == null || !this.i.a(var1)) {
         for (ServerEventParser var3 : this.h) {
            if (var3.a(var1)) {
               this.i = var3;
               return;
            }
         }

         this.i = null;
      }
   }

   private void w() {
      if (this.j && d.player.age > 6) {
         if (this.x()) {
            int var1 = this.h();
            if (var1 == -1) {
               return;
            }

            this.d(var1);
            ChatUtils.a("event delay");
            this.k = true;
         } else if (this.A()) {
            ChatUtils.a("events");
            this.k = true;
         } else if (this.B()) {
            ChatUtils.a("event active");
            this.k = true;
         }

         this.j = false;
      }
   }

   private boolean x() {
      String var1 = this.z();
      return var1 != null && var1.toLowerCase().contains("funtime");
   }

   public void d() {
      MarkerManager.c();
      this.p = null;
   }

   public void a(int var1) {
      if (d.player != null) {
         Random var2 = new Random();
         int var3 = this.h();
         String var4 = this.i();
         int var5 = (int)Math.floor(d.player.getX());
         int var6 = (int)Math.floor(d.player.getY());
         int var7 = (int)Math.floor(d.player.getZ());

         for (int var8 = 0; var8 < var1; var8++) {
            String var9 = r[var2.nextInt(r.length)];
            EventConfig var10 = this.a(var9.toLowerCase());
            int var11 = var5 + var2.nextInt(121) - 60;
            int var12 = var6 + var2.nextInt(21) - 10;
            int var13 = var7 + var2.nextInt(121) - 60;
            long var14 = (30 + var2.nextInt(571)) * 1000L;
            MarkerEntry var16 = MarkerEntry.a(var9, var11, var12, var13, var10.a, var10.b, var3, var4, var14, true);
            MarkerManager.a(var16);
         }

         ChatUtils.a("&aЗаспавнено &f" + var1 + "&a фейковых меток. Всего авто-меток: &f" + MarkerManager.f().size() + "&a. Очистить: &f.clearmarkers");
      }
   }

   public void a(String var1, String var2) {
      if (var1 != null && this.k) {
         String var3 = var2 != null ? var2 : "Неизвестно";
         this.a("Текущий ивент", var1, var3);
         this.k = false;
      }
   }

   public void a(String var1, int var2) {
      if (this.k) {
         String var3 = this.e(var2);
         this.a("Скоро ивент", this.b(var1), var3);
         this.k = false;
      }
   }

   public void b(int var1) {
      if (this.k) {
         String var2 = this.e(var1);
         this.a("Следующий ивент", "Начнется через", var2);
         this.k = false;
      }
   }

   public void e() {
      if (this.k) {
         this.a("Ивенты", "Идёт голосование", "/event vote");
         this.k = false;
      }
   }

   private void d(int var1) {
      this.l = false;
      if (b.contains(var1)) {
         FTHelperModule var2 = ModuleRegistry.C;
         if (var2 != null && var2.n()) {
            WatermarkComponent.a("Внимание", "На этой анархии не работают спец. предметы");
            ChatUtils.a("На этой анархии &cне работают&7 спец. предметы!");
            this.l = true;
            this.m = System.currentTimeMillis();
         }
      }
   }

   private void a(String var1, String var2, String var3) {
      if (this.l) {
         this.n = new String[]{var1, var2, var3};
         this.o = this.m + 5000L + 2000L;
         this.l = false;
      } else {
         WatermarkComponent.a(var1, var2, var3);
      }
   }

   private void y() {
      if (this.n != null) {
         if (System.currentTimeMillis() >= this.o) {
            WatermarkComponent.a(this.n[0], this.n[1], this.n[2]);
            this.n = null;
         }
      }
   }

   private String e(int var1) {
      if (var1 < 60) {
         return var1 + " сек";
      } else {
         int var2 = var1 / 60;
         int var3 = var1 % 60;
         return var3 > 0 ? var2 + " мин " + var3 + " сек" : var2 + " мин";
      }
   }

   public boolean f() {
      return this.k;
   }

   public void g() {
      this.k = false;
   }

   public void a(String var1, int[] var2, int var3) {
      int var4 = this.h();
      String var5 = this.i();
      MarkerEntry var6 = MarkerManager.a(var2[0], var2[1], var2[2]);
      if (var6 != null) {
         var6.a(this.b(var1));
         if (var3 > 0) {
            var6.a(System.currentTimeMillis() + var3 * 1000L);
            var6.a(true);
         }
      } else {
         EventConfig var7 = this.a(var1.toLowerCase());
         long var8 = var3 > 0 ? var3 * 1000L : 600000L;
         boolean var10 = var3 > 0;
         MarkerEntry var11 = MarkerEntry.a(this.b(var1), var2[0], var2[1], var2[2], var7.a, var7.b, var4, var5, var8, var10);
         MarkerManager.a(var11);
      }
   }

   public void b(String var1, int var2) {
      this.p = var1;
      this.q = var2;
   }

   public void a(int[] var1) {
      if (this.p != null && var1 != null) {
         this.a(this.p, var1, 0);
      }
   }

   public void c(int var1) {
      if (this.p != null) {
         for (MarkerEntry var3 : MarkerManager.f()) {
            if (var3.a().equalsIgnoreCase(this.b(this.p))) {
               var3.a(System.currentTimeMillis() + var1 * 1000L);
               break;
            }
         }
      }
   }

   public int h() {
      try {
         if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
            PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
            Text var2 = var1.getHeader();
            if (var2 == null) {
               return -1;
            } else {
               String var3 = Formatting.strip(var2.getString());
               if (var3 == null) {
                  return -1;
               } else if (this.B()) {
                  Matcher var9 = g.matcher(var3);
                  return var9.find() ? Integer.parseInt(var9.group(2)) : -1;
               } else if (!var3.contains("Анархия-")) {
                  return -1;
               } else {
                  int var4 = var3.indexOf("Анархия-") + "Анархия-".length();
                  StringBuilder var5 = new StringBuilder();

                  for (int var6 = var4; var6 < var3.length(); var6++) {
                     char var7 = var3.charAt(var6);
                     if (Character.isDigit(var7)) {
                        var5.append(var7);
                     } else if (var5.length() > 0) {
                        break;
                     }
                  }

                  return var5.length() == 0 ? -1 : Integer.parseInt(var5.toString());
               }
            }
         } else {
            return -1;
         }
      } catch (Exception var8) {
         return -1;
      }
   }

   public String i() {
      if (this.B() && d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
         PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
         Text var2 = var1.getHeader();
         if (var2 == null) {
            return null;
         } else {
            String var3 = Formatting.strip(var2.getString());
            Matcher var4 = g.matcher(var3);
            return var4.find() ? var4.group(1) : null;
         }
      } else {
         return null;
      }
   }

   public boolean j() {
      if (d.player == null) {
         return false;
      } else {
         String var1 = d.player.getDisplayName().getString();
         String var2 = Formatting.strip(var1);
         return !var1.equals(var2);
      }
   }

   public boolean k() {
      return d.world != null && d.world.getRegistryKey() == World.OVERWORLD && !d.isInSingleplayer();
   }

   private String z() {
      return d.getCurrentServerEntry() != null ? d.getCurrentServerEntry().address : null;
   }

   private boolean A() {
      String var1 = this.z();
      return var1 != null && var1.toLowerCase().contains("fillcube");
   }

   private boolean B() {
      String var1 = this.z();
      return var1 != null && var1.toLowerCase().contains("holyworld");
   }

   public EventConfig a(String var1) {
      if (this.i != null) {
         var var2 = this.i.b();
         if (var2.containsKey(var1)) {
            return (EventConfig)var2.get(var1);
         }
      }

      for (ServerEventParser var3 : this.h) {
         var var4 = var3.b();
         if (var4.containsKey(var1)) {
            return (EventConfig)var4.get(var1);
         }
      }

      return new EventConfig(new Color(255, 165, 0));
   }

   private String b(String var1) {
      return var1 != null && !var1.isEmpty() ? var1.substring(0, 1).toUpperCase() + var1.substring(1) : var1;
   }

   @Generated
   public List<ServerEventParser> l() {
      return this.h;
   }

   @Generated
   public ServerEventParser m() {
      return this.i;
   }

   @Generated
   public boolean n() {
      return this.j;
   }

   @Generated
   public boolean o() {
      return this.l;
   }

   @Generated
   public long p() {
      return this.m;
   }

   @Generated
   public String[] q() {
      return this.n;
   }

   @Generated
   public long r() {
      return this.o;
   }

   @Generated
   public String s() {
      return this.p;
   }

   @Generated
   public int t() {
      return this.q;
   }

   static {
      NativeMethodLookup.lookup(AutoEventHandler.class, 33);
   }
}
