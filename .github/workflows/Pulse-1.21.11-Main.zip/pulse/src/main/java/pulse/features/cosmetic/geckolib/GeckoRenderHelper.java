package pulse.features.cosmetic.geckolib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import pulse.features.cosmetic.geo.GeoBone;
import pulse.features.cosmetic.geo.GeoCube;

@Environment(EnvType.CLIENT)
public class GeckoRenderHelper {
   private static final ThreadLocal<Quaternionf> a = ThreadLocal.withInitial(Quaternionf::new);

   public static void a(GeoBone var0, MatrixStack var1) {
      var1.translate(-var0.d() / 16.0F, var0.e() / 16.0F, var0.f() / 16.0F);
   }

   public static void b(GeoBone var0, MatrixStack var1) {
      var1.translate(var0.j() / 16.0F, var0.k() / 16.0F, var0.l() / 16.0F);
   }

   public static void c(GeoBone var0, MatrixStack var1) {
      var1.translate(-var0.j() / 16.0F, -var0.k() / 16.0F, -var0.l() / 16.0F);
   }

   public static void d(GeoBone var0, MatrixStack var1) {
      if (var0.c() != 0.0F) {
         var1.multiply(a.get().rotationZ(var0.c()));
      }

      if (var0.b() != 0.0F) {
         var1.multiply(a.get().rotationY(var0.b()));
      }

      if (var0.a() != 0.0F) {
         var1.multiply(a.get().rotationX(var0.a()));
      }
   }

   public static void e(GeoBone var0, MatrixStack var1) {
      var1.scale(var0.g(), var0.h(), var0.i());
   }

   public static void a(GeoCube var0, MatrixStack var1) {
      var1.translate(var0.c.a() / 16.0F, var0.c.b() / 16.0F, var0.c.c() / 16.0F);
   }

   public static void b(GeoCube var0, MatrixStack var1) {
      var1.translate(-var0.c.a() / 16.0F, -var0.c.b() / 16.0F, -var0.c.c() / 16.0F);
   }

   public static void c(GeoCube var0, MatrixStack var1) {
      if (var0.d.c() != 0.0F) {
         var1.multiply(a.get().rotationZ(var0.d.c()));
      }

      if (var0.d.b() != 0.0F) {
         var1.multiply(a.get().rotationY(var0.d.b()));
      }

      if (var0.d.a() != 0.0F) {
         var1.multiply(a.get().rotationX(var0.d.a()));
      }
   }
}
