package pulse.services.tracker.v2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket.Action;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket.Entry;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public class TabSyncManager implements ThreadFactory {
   private static long a = 150L;
   private static int b = 20;
   private static long c = 500L;
   private static double d = 0.3000001430838915;
   private static int e = 30;
   private final Set<String> f = ConcurrentHashMap.newKeySet();
   private final AtomicInteger g = new AtomicInteger(0);
   private volatile long h = XxHashUtil.a(Collections.emptySet());
   private final Set<String> i = ConcurrentHashMap.newKeySet();
   private final Set<String> j = ConcurrentHashMap.newKeySet();
   private final ScheduledExecutorService k;
   private ScheduledFuture<?> l;
   private ScheduledFuture<?> m;
   private final AtomicBoolean n = new AtomicBoolean(false);
   private SyncCallback o;
   private final Map<UUID, String> p = new ConcurrentHashMap<>();
   private final EpochCheckTask q;
   private final DeltaFlushTask r;
   private static final Pattern s = Pattern.compile("^[a-zA-Z0-9_]{3,16}$");

   public TabSyncManager() {
      this.k = Executors.newSingleThreadScheduledExecutor(this);
      this.q = new EpochCheckTask(this);
      this.r = new DeltaFlushTask(this);
   }

   @Override
   public Thread newThread(Runnable var1) {
      Thread var2 = new Thread(var1, "TabSyncManager-Scheduler");
      var2.setDaemon(true);
      return var2;
   }

   public void a(SyncCallback var1) {
      this.o = var1;
   }

   public void a(PlayerListS2CPacket var1) {
      EnumSet var2 = var1.getActions();
      boolean var3 = var2.contains(Action.ADD_PLAYER) || var2.contains(Action.UPDATE_LISTED);
      if (var3 || !this.i.isEmpty() || !this.j.isEmpty()) {
         if (Pulse.m().isDebugEnabled()) {
            Pulse.m().debug("TabSyncManager: Received packet actions={}, entries={}", var2, var1.getEntries().size());
         }

         if (var2.contains(Action.ADD_PLAYER)) {
            for (Entry var5 : var1.getEntries()) {
               if (var5.profile() != null) {
                  String var6 = var5.profile().name();
                  UUID var7 = var5.profileId();
                  if (a(var6)) {
                     if (var7 != null) {
                        this.p.put(var7, var6);
                     }

                     this.i.add(var6);
                     this.j.remove(var6);
                     if (Pulse.m().isDebugEnabled()) {
                        Pulse.m().debug("TabSyncManager: ADD_PLAYER {}", var6);
                     }
                  }
               }
            }
         }

         if (var2.contains(Action.UPDATE_LISTED)) {
            for (Entry var9 : var1.getEntries()) {
               if (!var9.listed()) {
                  UUID var10 = var9.profileId();
                  String var11 = null;
                  if (var9.profile() != null) {
                     var11 = var9.profile().name();
                  }

                  if (!a(var11) && var10 != null) {
                     var11 = this.p.remove(var10);
                     if (Pulse.m().isDebugEnabled()) {
                        Pulse.m().debug("TabSyncManager: REMOVE_PLAYER resolved from UUID: {} -> {}", var10, var11);
                     }
                  } else if (var10 != null) {
                     this.p.remove(var10);
                  }

                  if (a(var11)) {
                     this.j.add(var11);
                     this.i.remove(var11);
                     if (Pulse.m().isDebugEnabled()) {
                        Pulse.m().debug("TabSyncManager: REMOVE_PLAYER {}", var11);
                     }
                  } else {
                     Pulse.m().warn("TabSyncManager: REMOVE_PLAYER with no valid name, uuid={}", var10);
                  }
               }
            }
         }

         this.j();
         this.l();
      }
   }

   public void a() {
      this.o();
      this.i.clear();
      this.j.clear();
      int var1 = this.g.incrementAndGet();
      this.h = XxHashUtil.a(this.f);
      Pulse.m().info("TabSyncManager: Forcing full sync, epoch={}, players={}", var1, this.f.size());
      if (this.o != null) {
         this.o.a(var1, new HashSet<>(this.f));
      }
   }

   public void a(Collection<PlayerListEntry> var1) {
      this.f.clear();
      this.p.clear();

      for (PlayerListEntry var3 : var1) {
         String var4 = var3.getProfile().name();
         UUID var5 = var3.getProfile().id();
         if (a(var4)) {
            this.f.add(var4);
            if (var5 != null) {
               this.p.put(var5, var4);
            }
         }
      }

      this.h = XxHashUtil.a(this.f);
      Pulse.m().info("TabSyncManager: Initialized with {} players, {} UUID mappings", this.f.size(), this.p.size());
   }

   public void b(Collection<String> var1) {
      this.f.clear();

      for (String var3 : var1) {
         if (a(var3)) {
            this.f.add(var3);
         }
      }

      this.h = XxHashUtil.a(this.f);
      Pulse.m().debug("TabSyncManager: Initialized with {} players", this.f.size());
   }

   public void b() {
      this.o();
      this.f.clear();
      this.i.clear();
      this.j.clear();
      this.p.clear();
      this.h = XxHashUtil.a(Collections.emptySet());
      Pulse.m().debug("TabSyncManager: Tab cleared");
   }

   public void a(int var1, long var2) {
      if (var1 == this.g.get()) {
         this.h = var2;
         Pulse.m().debug("TabSyncManager: Full sync confirmed, hash={}", var2);
      }
   }

   public void a(long var1, boolean var3) {
      if (var3) {
         Pulse.m().info("TabSyncManager: Server requested resync");
         this.a();
      } else {
         this.h = var1;
         Pulse.m().debug("TabSyncManager: Delta confirmed, hash={}", var1);
      }
   }

   public void a(boolean var1, boolean var2) {
      if (var2) {
         Pulse.m().info("TabSyncManager: Heartbeat mismatch, resync needed");
         this.a();
      }
   }

   public void c() {
      Pulse.m().info("TabSyncManager: Received NEED_RESYNC from server");
      this.a();
   }

   public int d() {
      return this.g.get();
   }

   public long e() {
      return this.h;
   }

   public Set<String> f() {
      return new HashSet<>(this.f);
   }

   public void g() {
      this.o();
      this.k.shutdown();

      try {
         if (!this.k.awaitTermination(2L, TimeUnit.SECONDS)) {
            this.k.shutdownNow();
         }
      } catch (InterruptedException var2) {
         this.k.shutdownNow();
      }
   }

   private void j() {
      if (this.n.compareAndSet(false, true)) {
         this.m = this.k.schedule(this.q, c, TimeUnit.MILLISECONDS);
      }
   }

   void h() {
      try {
         this.k();
      } finally {
         this.n.set(false);
      }

      if (!this.i.isEmpty() || !this.j.isEmpty()) {
         this.m();
      }
   }

   private void k() {
      int var1 = this.i.size() + this.j.size();
      int var2 = Math.max(this.f.size(), 1);
      boolean var3 = var1 >= 5 && var1 > var2 * d;
      boolean var4 = var1 > e;
      boolean var5 = var3 || var4;
      if (var5) {
         Pulse.m().info("TabSyncManager: Mass change detected ({} changes, {} tab size), bumping epoch", var1, var2);
         this.n();
         this.a();
      }
   }

   private void l() {
      if (this.l == null || this.l.isDone()) {
         if (this.i.size() + this.j.size() >= b) {
            this.m();
         } else {
            this.l = this.k.schedule(this.r, a, TimeUnit.MILLISECONDS);
         }
      }
   }

   void i() {
      this.m();
   }

   private void m() {
      if (!this.i.isEmpty() || !this.j.isEmpty()) {
         if (!this.n.get()) {
            HashSet<String> var1 = new HashSet<>(this.i);
            HashSet<String> var2 = new HashSet<>(this.j);
            this.i.clear();
            this.j.clear();
            this.f.removeAll(var2);
            this.f.addAll(var1);
            long var3 = this.h;
            this.h = XxHashUtil.a(this.f);
            ArrayList var5 = new ArrayList<>();

            for (String var7 : var1) {
               var5.add(new DeltaOp("add", var7));
            }

            for (String var9 : var2) {
               var5.add(new DeltaOp("rem", var9));
            }

            Pulse.m().debug("TabSyncManager: Flushing delta, adds={}, removes={}", var1.size(), var2.size());
            if (this.o != null && !var5.isEmpty()) {
               this.o.a(this.g.get(), var3, var5);
            }
         }
      }
   }

   private void n() {
      this.f.removeAll(this.j);
      this.f.addAll(this.i);
      this.i.clear();
      this.j.clear();
      this.h = XxHashUtil.a(this.f);
   }

   private void o() {
      if (this.l != null) {
         this.l.cancel(false);
         this.l = null;
      }

      if (this.m != null) {
         this.m.cancel(false);
         this.m = null;
      }

      this.n.set(false);
   }

   private static boolean a(String var0) {
      return var0 != null && s.matcher(var0).matches();
   }
}
