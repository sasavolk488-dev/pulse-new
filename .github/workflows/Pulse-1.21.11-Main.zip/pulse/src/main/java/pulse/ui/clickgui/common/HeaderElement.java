package pulse.ui.clickgui.common;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.utils.render.Render;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class HeaderElement implements GuiElement {
   private static final float a = 12.0F;

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      float var7 = ClickGuiScreen.e();
      TextureRegistry.TextureEntry var8 = TextureRegistry.b("water");
      if (var8 != null) {
         Identifier var9 = var8.a();
         float var10 = var8.b() / 2.0F;
         float var11 = var8.c() / 2.0F;
         float var12 = var3 + (var7 - var10) / 2.0F;
         float var13 = var4 - var11 - 12.0F;
         var2.a(var9, var12, var13, var10, var11, Color.WHITE, var1);
      }
   }

   @Override
   public void a(float var1, float var2, int var3, int var4) {
   }
}
