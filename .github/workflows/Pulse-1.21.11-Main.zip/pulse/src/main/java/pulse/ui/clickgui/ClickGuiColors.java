package pulse.ui.clickgui;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ClickGuiColors {
   public static final Color a = new Color(223, 223, 243);
   public static final Color b = new Color(49, 49, 69);
   public static final Color c = new Color(115, 83, 255);
   public static final Color d = new Color(80, 80, 110);
   public static final Color e = new Color(17, 17, 23);
   public static final Color f = new Color(13, 13, 17);
   public static final Color g = new Color(22, 22, 30);
   public static final Color h = new Color(18, 18, 24);
   public static final Color i = new Color(25, 25, 45);
   public static final Color j = new Color(19, 19, 35);
   public static final Color k = new Color(20, 20, 32);
   public static final Color l = new Color(16, 16, 26);
   public static final Color m = new Color(24, 24, 31);
   public static final Color n = new Color(19, 19, 25);
   public static final Color o = new Color(21, 21, 28);
   public static final Color p = new Color(30, 30, 40);
   public static final Color q = new Color(21, 21, 23);
   public static final Color r = new Color(26, 26, 35);
   public static final Color s = new Color(37, 37, 67);
   public static final Color t = new Color(21, 21, 38);
   public static final Color u = new Color(30, 30, 50);
   public static final Color v = new Color(18, 18, 32);
   public static final Color w = new Color(255, 255, 255, 10);
   public static final Color x = new Color(18, 18, 24);
   public static final Color y = new Color(115, 83, 255);
   public static final Color z = new Color(70, 46, 174);
   public static final Color A = new Color(115, 83, 255, 100);
   public static final Color B = new Color(140, 110, 255);
   public static final Color C = new Color(126, 90, 254);
   public static final Color D = new Color(106, 70, 215);
   public static final Color E = new Color(33, 21, 87);
   public static final Color F = new Color(14, 14, 19);
   public static final Color G = new Color(37, 37, 52);
   public static final Color H = new Color(0, 0, 0, 55);
   public static final Color I = new Color(25, 25, 33);
   public static final Color J = new Color(22, 22, 28);
   public static final Color K = new Color(20, 20, 26);
   public static final Color L = new Color(40, 20, 20);
   public static final Color M = new Color(30, 15, 15);
   public static final Color N = new Color(100, 100, 130);
   public static final Color O = new Color(96, 96, 96);
   public static final Color P = new Color(60, 60, 85);
   public static final Color Q = new Color(140, 110, 255);
   public static final Color R = new Color(95, 65, 200);
   public static final Color S = new Color(15, 15, 21);
   public static final Color T = new Color(18, 18, 25);
   public static final Color U = new Color(140, 140, 170);
   public static final Color V = new Color(24, 24, 32);
   public static final Color W = new Color(220, 53, 69);
   public static final Color X = new Color(40, 167, 69);
   public static final Color Y = new Color(255, 180, 50);
   public static final Color Z = new Color(255, 80, 80);
   public static final Color aa = new Color(255, 255, 255);
   public static final Color ab = new Color(0, 0, 0);
   public static final Color ac = new Color(30, 30, 40);
   public static final Color ad = new Color(0, 0, 0, 125);

   private ClickGuiColors() {
   }

   public static Color a(Color var0, int var1) {
      int var2 = Math.max(0, Math.min(255, var1));
      return var0.getAlpha() == var2 ? var0 : new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var2);
   }

   public static Color a(Color var0, float var1) {
      return a(var0, (int)(255.0F * var1));
   }

   public static Color b(Color var0, float var1) {
      return var1 == 1.0F ? var0 : new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), Math.max(0, Math.min(255, (int)(var0.getAlpha() * var1))));
   }

   public static Color b(Color var0, int var1) {
      return var1 == 0
         ? var0
         : new Color(Math.min(255, var0.getRed() + var1), Math.min(255, var0.getGreen() + var1), Math.min(255, var0.getBlue() + var1), var0.getAlpha());
   }

   public static Color c(Color var0, int var1) {
      return var1 == 0
         ? var0
         : new Color(Math.max(0, var0.getRed() - var1), Math.max(0, var0.getGreen() - var1), Math.max(0, var0.getBlue() - var1), var0.getAlpha());
   }
}
