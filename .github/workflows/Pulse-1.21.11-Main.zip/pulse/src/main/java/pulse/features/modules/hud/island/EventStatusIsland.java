package pulse.features.modules.hud.island;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@Environment(EnvType.CLIENT)
public class EventStatusIsland extends Island {
   private static final Color k = new Color(87, 215, 106);
   private static final Color l = new Color(255, 255, 255);
   private static final Color m = new Color(223, 223, 243);
   private static final Color n = new Color(255, 255, 255, 77);
   private static final float o = 12.0F;
   private static final float p = 3.0F;
   private static final float q = 3.0F;
   private final String r;
   private final String s;
   private final String t;

   public EventStatusIsland(String var1, String var2, String var3) {
      this.r = var1;
      this.s = var2;
      this.t = var3;
      this.e = 8.0F;
      this.f = 4.5F;
      this.h = 3000L;
   }

   @Override
   public float a() {
      FontRenderer var1 = Fonts.b[15];
      FontRenderer var2 = Fonts.a[15];
      float var3 = 15.0F + var2.a(this.r);
      float var4 = var1.a("/");
      float var5 = var1.a(this.s) + 3.0F + var4 + 3.0F + var1.a(this.t);
      return var3 + 15.0F + var5 + 20.0F;
   }

   @Override
   public float b() {
      return 13.0F;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      FontRenderer var8 = Fonts.b[15];
      FontRenderer var9 = Fonts.a[15];
      float var10 = var4 + var6 / 2.0F;
      int var11 = (int)(var7 * 255.0F);
      Color var12 = new Color(223, 223, 255, var11);
      Color var13 = new Color(255, 255, 255, var11);
      Color var14 = new Color(n.getRed(), n.getGreen(), n.getBlue(), (int)(n.getAlpha() * var7));
      float var15 = var10 - var9.b(this.r) / 4.0F;
      float var17 = var10 - 6.0F;
      Color var18 = new Color(k.getRed(), k.getGreen(), k.getBlue(), var11);
      FontRenderer var19 = Fonts.d[22];
      var19.a("\ue90a", var3, var17 + 0.5F, var18, var1);
      float var16 = var3 + 15.0F;
      var9.a(this.r, var16, var15, var12, var1);
      float var20 = var8.a("/");
      float var21 = var8.a(this.s);
      float var22 = var8.a(this.t);
      float var23 = var21 + 3.0F + var20 + 3.0F + var22;
      float var24 = var3 + var5 - var23;
      var8.a(this.s, var24, var15, var13, var1);
      var24 += var21 + 3.0F;
      var8.a("/", var24, var15, var14, var1);
      var24 += var20 + 3.0F;
      var8.a(this.t, var24, var15, var13, var1);
   }
}
