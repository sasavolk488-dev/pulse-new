package pulse.features.modules.visuals;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Hitbox Customizer",
   b = "Настраивает отображение хитбоксов сущностей",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class HitboxCustomizerModule extends Module {
   public final ModeSetting a = new ModeSetting("Режим обводки", new String[]{"Обычный", "Углы"}, "Обычный");
   public final NumberSetting b = new NumberSetting("Длина углов", 0.5F, 0.1F, 1.0F, 0.05F).a(() -> this.a.b("Углы"));
   private final BooleanSetting c = new BooleanSetting("Линии взгляда", false);
   private final BooleanSetting f = new BooleanSetting("Заполнять", true);
   private final SeparatorSetting g = new SeparatorSetting("Цвет");
   private final BooleanSetting h = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting i = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.h.a());
   private static final float j = 2.0F;
   private static final int k = 64;

   public boolean n() {
      return this.k() && this.c.a();
   }

   public boolean o() {
      return this.k() && this.f.a();
   }

   public Color p() {
      if (this.h.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.i.a();
      }
   }

   public boolean q() {
      return this.a.b("Углы");
   }

   public float r() {
      return this.b.b() / 4.0F;
   }

   public void a(Entity var1, float var2) {
      if (!var1.isInvisible()) {
         if (d.player == null || !d.player.hasStatusEffect(StatusEffects.BLINDNESS)) {
            Color var3 = this.p();
            int var4 = var3.getRGB() & 16777215;
            int var5 = 0xFF000000 | var4;
            int var6 = this.o() ? 1073741824 | var4 : 0;
            Vec3d var7 = var1.getLerpedPos(var2);
            Box var8 = var1.getBoundingBox().offset(var7.subtract(var1.getEntityPos()));
            if (this.q()) {
               if (var6 != 0) {
                  GizmoDrawing.box(var8, DrawStyle.filled(var6));
               }

               a(var8, var5, this.r());
            } else if (var6 != 0) {
               GizmoDrawing.box(var8, DrawStyle.filledAndStroked(var5, 2.0F, var6));
            } else {
               GizmoDrawing.box(var8, DrawStyle.stroked(var5, 2.0F));
            }

            if (this.n()) {
               Vec3d var9 = var7.add(0.0, var1.getStandingEyeHeight(), 0.0);
               Vec3d var10 = var1.getRotationVec(var2);
               GizmoDrawing.arrow(var9, var9.add(var10.multiply(2.0)), var5, 2.0F);
            }
         }
      }
   }

   private static void a(Box var0, int var1, float var2) {
      double var3 = var0.minX;
      double var5 = var0.minY;
      double var7 = var0.minZ;
      double var9 = var0.maxX;
      double var11 = var0.maxY;
      double var13 = var0.maxZ;
      a(var3, var5, var7, var2, var2, var2, var1);
      a(var9, var5, var7, -var2, var2, var2, var1);
      a(var3, var11, var7, var2, -var2, var2, var1);
      a(var9, var11, var7, -var2, -var2, var2, var1);
      a(var3, var5, var13, var2, var2, -var2, var1);
      a(var9, var5, var13, -var2, var2, -var2, var1);
      a(var3, var11, var13, var2, -var2, -var2, var1);
      a(var9, var11, var13, -var2, -var2, -var2, var1);
   }

   private static void a(double var0, double var2, double var4, float var6, float var7, float var8, int var9) {
      Vec3d var10 = new Vec3d(var0, var2, var4);
      GizmoDrawing.line(var10, new Vec3d(var0 + var6, var2, var4), var9, 2.0F);
      GizmoDrawing.line(var10, new Vec3d(var0, var2 + var7, var4), var9, 2.0F);
      GizmoDrawing.line(var10, new Vec3d(var0, var2, var4 + var8), var9, 2.0F);
   }
}
