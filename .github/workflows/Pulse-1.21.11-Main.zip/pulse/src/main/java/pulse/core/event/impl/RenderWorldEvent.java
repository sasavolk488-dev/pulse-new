package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class RenderWorldEvent extends Event {
   private final MatrixStack a;
   private final float b;
   private final Camera c;

   @Generated
   public MatrixStack a() {
      return this.a;
   }

   @Generated
   public float b() {
      return this.b;
   }

   @Generated
   public Camera c() {
      return this.c;
   }

   @Generated
   public RenderWorldEvent(MatrixStack var1, float var2, Camera var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
