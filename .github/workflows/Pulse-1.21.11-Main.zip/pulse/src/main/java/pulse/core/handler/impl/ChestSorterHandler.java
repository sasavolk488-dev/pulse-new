package pulse.core.handler.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class ChestSorterHandler extends Handler implements IMinecraft {
   private static final int a = 250;
   private static final Comparator<ItemStack> b = Comparator.<ItemStack>comparingInt(var0 -> Registries.ITEM.getRawId(var0.getItem()))
      .thenComparingInt(var0 -> ItemGroupKey.a(var0).hashCode())
      .thenComparingInt(var0 -> -var0.getCount());
   private boolean c;
   private int f;
   private int g;
   private int h = -1;
   private int i = -1;
   private ItemStack j = ItemStack.EMPTY;
   private final List<ItemStack> k = new ArrayList<>();

   public boolean d() {
      return this.c;
   }

   public boolean e() {
      if (this.c) {
         return true;
      } else if (d.player != null && d.interactionManager != null) {
         ScreenHandler var1 = d.player.currentScreenHandler;
         if (var1 == null) {
            return false;
         } else {
            List<Slot> var2 = this.b(var1);
            if (var2.isEmpty()) {
               return false;
            } else {
               ArrayList var3 = new ArrayList<>();

               for (Slot var5 : var2) {
                  if (!var5.getStack().isEmpty()) {
                     var3.add(var5.getStack().copy());
                  }
               }

               if (var3.isEmpty()) {
                  return false;
               } else {
                  var3.sort(b);
                  this.k.clear();

                  for (int var6 = 0; var6 < var2.size(); var6++) {
                     this.k.add(var6 < var3.size() ? (ItemStack)var3.get(var6) : ItemStack.EMPTY);
                  }

                  this.i = this.g();
                  this.j = d.player.getInventory().getStack(this.i).copy();
                  this.h = var1.syncId;
                  this.c = true;
                  this.g = 0;
                  this.f = 0;
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private int g() {
      for (int var1 = 0; var1 <= 8; var1++) {
         if (d.player.getInventory().getStack(var1).isEmpty()) {
            return var1;
         }
      }

      if (d.player.getInventory().getStack(40).isEmpty()) {
         return 40;
      } else {
         return d.player.getInventory().getSelectedSlot() == 0 ? 1 : 0;
      }
   }

   public void f() {
      this.c = false;
      this.k.clear();
      this.h = -1;
      this.j = ItemStack.EMPTY;
   }

   @EventHandler
   public void a(UpdateEvent var1) {
      if (this.c) {
         ScreenHandler var2 = d.player != null ? d.player.currentScreenHandler : null;
         if (d.interactionManager == null || var2 == null || var2.syncId != this.h || !(d.currentScreen instanceof HandledScreen)) {
            this.f();
         } else if (this.f > 0) {
            this.f--;
         } else {
            int var3 = this.a(var2);
            if (var3 < 0) {
               this.f();
            } else {
               d.interactionManager.clickSlot(this.h, var3, this.i, SlotActionType.SWAP, d.player);
               this.f = Math.random() < 0.25 ? 1 : 0;
            }
         }
      }
   }

   private int a(ScreenHandler var1) {
      if (++this.g > 250) {
         return -1;
      } else {
         var var2 = this.b(var1);
         if (var2.size() != this.k.size()) {
            return -1;
         } else {
            ItemStack var3 = d.player.getInventory().getStack(this.i);
            if (!var3.isEmpty()) {
               for (int var4 = 0; var4 < var2.size(); var4++) {
                  if (!this.a(var2, var4) && a(var3, this.k.get(var4))) {
                     return ((Slot)var2.get(var4)).id;
                  }
               }
            }

            if (a(var3, this.j)) {
               for (int var7 = 0; var7 < var2.size(); var7++) {
                  if (!this.a(var2, var7) && !this.k.get(var7).isEmpty()) {
                     int var5 = this.a(var2, this.k.get(var7));
                     if (var5 >= 0) {
                        return ((Slot)var2.get(var5)).id;
                     }
                  }
               }

               return -1;
            } else {
               if (var3.isEmpty()) {
                  for (int var6 = 0; var6 < var2.size(); var6++) {
                     if (!this.a(var2, var6) && a(((Slot)var2.get(var6)).getStack(), this.j)) {
                        return ((Slot)var2.get(var6)).id;
                     }
                  }
               }

               return -1;
            }
         }
      }
   }

   private int a(List<Slot> var1, ItemStack var2) {
      for (int var3 = 0; var3 < var1.size(); var3++) {
         if (!this.a(var1, var3) && a(((Slot)var1.get(var3)).getStack(), var2)) {
            return var3;
         }
      }

      return -1;
   }

   private boolean a(List<Slot> var1, int var2) {
      return a(((Slot)var1.get(var2)).getStack(), this.k.get(var2));
   }

   private static boolean a(ItemStack var0, ItemStack var1) {
      return !var0.isEmpty() && !var1.isEmpty()
         ? var0.getCount() == var1.getCount() && ItemGroupKey.a(var0).equals(ItemGroupKey.a(var1))
         : var0.isEmpty() && var1.isEmpty();
   }

   private List<Slot> b(ScreenHandler var1) {
      ArrayList<Slot> var2 = new ArrayList<>();

      for (Slot var4 : var1.slots) {
         if (var4.inventory != d.player.getInventory()) {
            var2.add(var4);
         }
      }

      return var2;
   }
}
