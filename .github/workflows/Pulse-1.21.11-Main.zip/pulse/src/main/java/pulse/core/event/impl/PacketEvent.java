package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.packet.Packet;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class PacketEvent extends CancellableEvent {
   private final Packet<?> a;
   private final PacketEvent.EventType b;

   public PacketEvent(Packet<?> var1, PacketEvent.EventType var2) {
      this.a = var1;
      this.b = var2;
   }

   @Generated
   public Packet<?> d() {
      return this.a;
   }

   @Generated
   public PacketEvent.EventType e() {
      return this.b;
   }

   @Environment(EnvType.CLIENT)
   public static enum EventType {
      a,
      b;

      private static PacketEvent.EventType[] a() {
         return new PacketEvent.EventType[]{a, b};
      }
   }
}
