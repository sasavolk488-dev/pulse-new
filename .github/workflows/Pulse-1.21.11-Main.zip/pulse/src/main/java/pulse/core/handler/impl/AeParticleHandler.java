package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class AeParticleHandler extends Handler implements IMinecraft {
   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      pulse.utils.render.particle.AeParticleSystem.d();
   }

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      pulse.utils.render.particle.AeParticleSystem.a(var1.a());
   }

   static {
      NativeMethodLookup.lookup(AeParticleHandler.class, 21);
   }
}
