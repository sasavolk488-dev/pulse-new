package pulse.services.tracker.v2;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.imageio.ImageIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public class RemoteTextureLoader {
   private static final ConcurrentHashMap<String, Identifier> a = new ConcurrentHashMap<>();
   private static final Set<String> b = ConcurrentHashMap.newKeySet();
   private static final Set<String> c = ConcurrentHashMap.newKeySet();
   private static final ExecutorService d = Executors.newFixedThreadPool(2, var0 -> {
      Thread var1 = new Thread(var0, "PulseRemoteTextureLoader");
      var1.setDaemon(true);
      return var1;
   });

   public static Identifier a(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         Identifier var1 = a.get(var0);
         if (var1 != null) {
            return var1;
         } else if (c.contains(var0)) {
            return null;
         } else {
            if (b.add(var0)) {
               d.submit(() -> b(var0));
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private static void b(String var0) {
      try {
         HttpURLConnection var1 = (HttpURLConnection)new URL(var0).openConnection();
         var1.setRequestMethod("GET");
         var1.setConnectTimeout(8000);
         var1.setReadTimeout(8000);
         var1.setRequestProperty("User-Agent", "PulseMod");
         int var2 = var1.getResponseCode();
         if (var2 != 200) {
            Pulse.m().warn("[RemoteTexture] " + var0 + " returned " + var2);
            c.add(var0);
            b.remove(var0);
            return;
         }

         byte[] var3;
         try (InputStream var4 = var1.getInputStream()) {
            ByteArrayOutputStream var5 = new ByteArrayOutputStream();
            byte[] var6 = new byte[4096];

            int var7;
            while ((var7 = var4.read(var6)) > 0) {
               var5.write(var6, 0, var7);
            }

            var3 = var5.toByteArray();
         }

         String var12 = c(var0);
         Identifier var13 = Identifier.of("pulse", "remote/" + var12);
         BufferedImage var14 = ImageIO.read(new ByteArrayInputStream(var3));
         if (var14 == null) {
            Pulse.m().warn("[RemoteTexture] unsupported format: " + var0);
            c.add(var0);
            b.remove(var0);
            return;
         }

         ByteArrayOutputStream var15 = new ByteArrayOutputStream();
         ImageIO.write(var14, "PNG", var15);
         byte[] var8 = var15.toByteArray();
         MinecraftClient.getInstance().execute(() -> {
            try {
               NativeImage var3x = NativeImage.read(new ByteArrayInputStream(var8));
               NativeImageBackedTexture var4x = new NativeImageBackedTexture(var13::toString, var3x);
               MinecraftClient.getInstance().getTextureManager().registerTexture(var13, var4x);
               a.put(var0, var13);
            } catch (Exception var8x) {
               Pulse.m().warn("[RemoteTexture] decode failed " + var0 + ": " + var8x.getMessage());
               c.add(var0);
            } finally {
               b.remove(var0);
            }
         });
      } catch (Exception var11) {
         Pulse.m().warn("[RemoteTexture] download failed " + var0 + ": " + var11.getMessage());
         c.add(var0);
         b.remove(var0);
      }
   }

   private static String c(String var0) {
      try {
         MessageDigest var1 = MessageDigest.getInstance("SHA-1");
         byte[] var2 = var1.digest(var0.getBytes());
         StringBuilder var3 = new StringBuilder();

         for (byte var7 : var2) {
            var3.append(String.format("%02x", var7));
         }

         return var3.toString().substring(0, 16);
      } catch (Exception var8) {
         return Integer.toHexString(var0.hashCode());
      }
   }
}
