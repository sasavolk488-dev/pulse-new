package pulse.features.modules.visuals;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Hit Color",
   b = "Изменяет цвет сущностей при получении урона",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class HitColorModule extends Module {
   private final ModeSetting a = new ModeSetting("Режим", new String[]{"Полностью", "Скин"}, "Полностью");
   private final BooleanSetting b = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting c = new ColorSetting("Кастомный цвет", Color.RED).a(() -> !this.b.q());

   public Color n() {
      if (this.b.q()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.c.q();
      }
   }

   public boolean o() {
      return this.k();
   }

   public boolean p() {
      return this.a.c("Полностью");
   }
}
