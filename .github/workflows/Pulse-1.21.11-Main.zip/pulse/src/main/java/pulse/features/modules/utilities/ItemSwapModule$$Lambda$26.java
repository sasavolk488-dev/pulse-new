package pulse.features.modules.utilities;

import java.util.function.Predicate;
import net.minecraft.item.ItemStack;

public final class ItemSwapModule$$Lambda$26 implements Predicate {
   private final ItemSwapModule c0;

   public ItemSwapModule$$Lambda$26(ItemSwapModule var1) {
      this.c0 = var1;
   }

   @Override
   public boolean test(Object var1) {
      return this.c0.c((ItemStack)var1);
   }
}
