package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;
import pulse.core.event.impl.ClientPlayerTickEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.ParticleHandler;
import pulse.core.handler.impl.particle.ParticleTextures;
import pulse.core.handler.impl.particle.PhysicsMode;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.world.TrailHistory;
import pulse.utils.render.world.TrailLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;

@ModuleInfo(
   a = "Trails",
   b = "Отображает след игроков",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class TrailsModule extends Module {
   private final ModeSetting a = new ModeSetting("Режим ходьбы", new String[]{"Только след", "Только частицы", "След + частицы"}, "Только след");
   private final BooleanSetting b = new BooleanSetting("Показывать от первого лица", false);
   private final SeparatorSetting c = new SeparatorSetting("След").a(this::n);
   private final ModeSetting f = new ModeSetting("Тип следа", new String[]{"Сплошной", "Ленты"}, "Сплошной").a(this::n);
   private final NumberSetting g = new NumberSetting("Длина", 8.0F, 2.0F, 16.0F, 1.0F).a(() -> this.n() && !this.f.b("Ленты"));
   private final NumberSetting h = new NumberSetting("Длительность лент", 0.7F, 0.3F, 1.5F, 0.05F).a(() -> this.n() && this.f.b("Ленты"));
   private final NumberSetting i = new NumberSetting("Размер лент", 0.35F, 0.1F, 1.2F, 0.05F).a(() -> this.n() && this.f.b("Ленты"));
   private final NumberSetting j = new NumberSetting("Свечение лент", 40.0F, 0.0F, 100.0F, 5.0F).a(() -> this.n() && this.f.b("Ленты"));
   private final BooleanSetting k = new BooleanSetting("Цвет клиента", true).a(this::n);
   private final ColorSetting l = new ColorSetting("Кастомный цвет", new Color(0, 255, 136)).a(() -> this.n() && !this.k.a());
   private final SeparatorSetting m = new SeparatorSetting("Частицы").a(this::o);
   private final ModeSetting n = new ModeSetting("Режим частиц", new String[]{"Под ногами", "По телу"}, "Под ногами").a(this::o);
   private final ModeSetting o = new ModeSetting("Тип частиц", ParticleTextures.f, "Лучи").a(this::o);
   private final ModeSetting p = new ModeSetting("Режим физики", PhysicsMode.b(), "Без коллизий").a(this::o);
   private final BooleanSetting q = new BooleanSetting("Градиент частиц", true).a(this::o);
   private final ColorSetting r = new ColorSetting("Конечный цвет частиц", new Color(255, 0, 136)).a(() -> this.o() && this.q.a());
   private final NumberSetting s = new NumberSetting("Количество частиц", 4.0F, 1.0F, 20.0F, 1.0F).a(this::o);
   private final NumberSetting t = new NumberSetting("Размер частиц", 0.3F, 0.1F, 0.75F, 0.05F).a(this::o);
   private final NumberSetting u = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F).a(this::o);
   private final NumberSetting v = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F).a(this::o);
   private final BooleanSetting w = new BooleanSetting("Цвет клиента частиц", true).a(this::o);
   private final ColorSetting x = new ColorSetting("Кастомный цвет частиц", new Color(0, 255, 136)).a(() -> this.o() && !this.w.a());
   private final Map<UUID, Deque<TrailsModule.TrailPoint>> y = new HashMap<>();
   private double z;
   private double A;
   private double B;
   private boolean C = false;
   private final TrailHistory D = new TrailHistory();
   private PlayerEntity E;
   private float F;
   private double G;
   private final double[] H = new double[44];
   private final double[] I = new double[44];
   private final double[] J = new double[44];
   private final float[] K = new float[44];
   private final float[] L = new float[44];
   private final float[] M = new float[44];
   private final float[] N = new float[44];
   private final float[] O = new float[44];
   private final float[] P = new float[176];
   private final float[] Q = new float[176];
   private final float[] R = new float[176];
   private final float[] S = new float[176];
   private final float[] T = new float[176];
   private final float[] U = new float[176];
   private final int[] V = new int[176];
   private final float[] W = new float[12];
   private final float[] X = new float[12];
   private final float[] Y = new float[12];
   private final float[] Z = new float[12];
   private final int[] aa = new int[12];
   private float ab;
   private float ac;
   private float ad;
   private float ae;
   private float af;
   private float ag;

   private boolean n() {
      return this.a.b("Только след") || this.a.b("След + частицы");
   }

   private boolean o() {
      return this.a.b("Только частицы") || this.a.b("След + частицы");
   }

   @EventHandler
   @Compile
   public void a(ClientPlayerTickEvent var1) {
      ModeSetting style = this.f;
      Map<UUID, Deque<TrailsModule.TrailPoint>> history = this.y;
      NumberSetting length = this.g;
      if (var1.a() != ClientPlayerTickEvent.State.a || !this.n() || d.world == null || d.player == null) {
         return;
      }
      if (style.b("Ленты")) {
         if (!history.isEmpty()) {
            history.clear();
         }
         return;
      }
      if (!this.a(d.player)) {
         history.clear();
         return;
      }
      UUID uuid = d.player.getUuid();
      if (history.size() > 1 || (!history.isEmpty() && !history.containsKey(uuid))) {
         history.keySet().retainAll(java.util.Collections.singleton(uuid));
      }
      int limit = length.c();
      Object queue = history.computeIfAbsent(uuid, TrailsModule::a);
      TrailsModule.TrailPoint point = new TrailsModule.TrailPoint(d.player.getEntityPos(), d.player.getHeight());
      Deque<TrailsModule.TrailPoint> points = (Deque<TrailsModule.TrailPoint>)queue;
      points.addLast(point);
      while (points.size() > limit) {
         points.pollFirst();
      }
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      BooleanSetting firstPerson = this.b;
      ModeSetting particleMode = this.n;
      if (!this.o() || d.player == null) {
         return;
      }
      if (d.options.getPerspective().isFirstPerson() && !firstPerson.a()) {
         return;
      }
      double x = d.player.getX();
      double y = d.player.getY();
      double z = d.player.getZ();
      if (!this.C) {
         this.z = x;
         this.A = y;
         this.B = z;
         this.C = true;
         return;
      }
      double dx = x - this.z;
      double dy = y - this.A;
      double dz = z - this.B;
      double distance = Math.sqrt(dy * dy + dx * dx + dz * dz);
      this.z = x;
      this.A = y;
      this.B = z;
      if (!(distance > 0.01)) {
         return;
      }
      String mode = particleMode.e();
      if (mode.equals("Под ногами")) {
         this.a(d.player.getLerpedPos(1.0F), 0.1, this.q().getRGB());
      } else if (mode.equals("По телу")) {
         float height = d.player.getHeight();
         for (int index = 0; index < 4; index++) {
            Vec3d position = d.player.getLerpedPos(1.0F).add(0.0, (double)index * (double)height * 0.25, 0.0);
            this.a(position, 0.08, this.q().getRGB());
         }
      }
   }

   @EventHandler
   public void a(RenderEvent var1) {
      if (this.n()) {
         if (d.world != null && d.player != null) {
            if (this.f.b("Ленты")) {
               if (this.a(d.player)) {
                  this.b(var1);
               }
            } else if (!this.y.isEmpty()) {
               if (this.a(d.player)) {
                  ClientPlayerEntity var2 = d.player;
                  Deque<TrailsModule.TrailPoint> var3 = this.y.get(var2.getUuid());
                  if (var3 != null && !var3.isEmpty()) {
                     float var4 = var1.b();
                     Vec3d var5 = d.gameRenderer.getCamera().getCameraPos();
                     int var6 = this.p().getRGB();
                     int var7 = var6 >>> 24 & 0xFF;
                     Entry var8 = var1.a().peek();
                     Immediate var9 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
                     ArrayList var10 = new ArrayList<>(var3.size() + 1);
                     ArrayList var11 = new ArrayList<>(var3.size() + 1);

                     for (TrailsModule.TrailPoint var13 : var3) {
                        var10.add(var13.pos.subtract(var5));
                        var11.add(new Vec3d(var13.pos.x, var13.pos.y + var13.height, var13.pos.z).subtract(var5));
                     }

                     Vec3d var21 = var2.getLerpedPos(var4);
                     double var22 = var2.getHeight();
                     var10.add(var21.subtract(var5));
                     var11.add(new Vec3d(var21.x, var21.y + var22, var21.z).subtract(var5));
                     if (var10.size() >= 2) {
                        int var15 = var10.size() - 1;
                        float var16 = Math.max(1, var15 - 1);
                        int[] var17 = new int[var10.size()];

                        for (int var18 = 0; var18 < var10.size(); var18++) {
                           int var19;
                           if (var18 == var15) {
                              var19 = var7;
                           } else {
                              float var20 = MathHelper.clamp((var18 - var4) / var16, 0.0F, 1.0F);
                              var19 = (int)(var7 * var20);
                           }

                           var17[var18] = a(var6, var19);
                        }

                        this.a(var8, var9, TrailLayers.b, var10, 2.0F, var17);
                        this.a(var8, var9, TrailLayers.b, var11, 2.0F, var17);
                        this.a(var8, var9.getBuffer(TrailLayers.d), var10, var11, var17);
                        var9.draw(TrailLayers.b);
                        var9.draw(TrailLayers.d);
                     }
                  }
               }
            }
         }
      }
   }

   private void a(Vec3d var1, double var2, int var4) {
      var4 = ColorUtils.a(var4);
      int var5 = this.s.c();
      int var6 = this.u.c();
      int var7 = var6 - 10;
      int var8 = var6 + 10;
      float var9 = this.t.b();
      float var10 = var9 - 0.05F;
      float var11 = var9 + 0.05F;
      double var12 = this.v.b();
      PhysicsMode var14 = PhysicsMode.a(this.p.e());
      Identifier var15 = this.r();
      boolean var16 = this.q.a();
      int var17 = ColorUtils.a(this.r.a().getRGB());

      for (int var18 = 0; var18 < var5; var18++) {
         int var19 = ThreadLocalRandom.current().nextInt(var7, var8);
         float var20 = var10 + ThreadLocalRandom.current().nextFloat() * (var11 - var10);
         Vec3d var21 = new Vec3d(
            ThreadLocalRandom.current().nextDouble(-var2, var2),
            ThreadLocalRandom.current().nextDouble(0.0, var2),
            ThreadLocalRandom.current().nextDouble(-var2, var2)
         );
         if (var21.lengthSquared() > 0.0) {
            var21 = var21.normalize().multiply(ThreadLocalRandom.current().nextDouble(0.005000000708043431, var12));
         }

         ParticleHandler.Builder var22 = HandlerRegistry.g.d().a(var1).b(var21).a(var19).a(var20).a(var15).a(var14);
         if (var16) {
            var22.a(var4, var17);
         } else {
            var22.b(var4);
         }

         var22.a();
      }
   }

   private void a(Entry var1, VertexConsumerProvider var2, RenderLayer var3, List<Vec3d> var4, float var5, int[] var6) {
      if (var4.size() >= 2) {
         VertexConsumer var7 = var2.getBuffer(var3);

         for (int var8 = 0; var8 + 1 < var4.size(); var8++) {
            Vec3d var9 = (Vec3d)var4.get(var8);
            Vec3d var10 = (Vec3d)var4.get(var8 + 1);
            float var11 = (float)(var10.x - var9.x);
            float var12 = (float)(var10.y - var9.y);
            float var13 = (float)(var10.z - var9.z);
            float var14 = (float)Math.sqrt(var11 * var11 + var12 * var12 + var13 * var13);
            if (var14 < 1.0E-6F) {
               var14 = 1.0F;
            }

            float var15 = var11 / var14;
            float var16 = var12 / var14;
            float var17 = var13 / var14;
            var7.vertex(var1, (float)var9.x, (float)var9.y, (float)var9.z).color(var6[var8]).normal(var1, var15, var16, var17).lineWidth(var5);
            var7.vertex(var1, (float)var10.x, (float)var10.y, (float)var10.z).color(var6[var8 + 1]).normal(var1, var15, var16, var17).lineWidth(var5);
         }
      }
   }

   private void a(Entry var1, VertexConsumer var2, List<Vec3d> var3, List<Vec3d> var4, int[] var5) {
      if (var3.size() >= 2) {
         int var6 = var3.size() - 1;

         for (int var7 = 0; var7 < var6; var7++) {
            int var8 = var5[var7];
            int var9 = var5[var7 + 1];
            Vec3d var10 = (Vec3d)var3.get(var7);
            Vec3d var11 = (Vec3d)var4.get(var7);
            Vec3d var12 = (Vec3d)var3.get(var7 + 1);
            Vec3d var13 = (Vec3d)var4.get(var7 + 1);
            var2.vertex(var1, (float)var10.x, (float)var10.y, (float)var10.z).color(var8);
            var2.vertex(var1, (float)var11.x, (float)var11.y, (float)var11.z).color(var8);
            var2.vertex(var1, (float)var13.x, (float)var13.y, (float)var13.z).color(var9);
            var2.vertex(var1, (float)var12.x, (float)var12.y, (float)var12.z).color(var9);
         }
      }
   }

   private void b(RenderEvent var1) {
      Vec3d var2 = d.gameRenderer.getCamera().getCameraPos();
      if (this.a(var1.b(), var2)) {
         Entry var3 = var1.a().peek();
         Immediate var4 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer var5 = var4.getBuffer(TrailLayers.d);
         float var6 = this.j.b();
         if (var6 >= 1.0F) {
            float var7 = var6 / 100.0F;
            this.a(var5, var3, 1.0F + 5.0F * var7, 0.09F * var7);
            this.a(var5, var3, 1.0F + 2.5F * var7, 0.14F * var7);
         }

         this.a(var5, var3, 1.5F, 0.2F);
         this.a(var5, var3, 1.0F, 0.75F);
         this.a(var5, var3);
         var4.draw(TrailLayers.d);
      }
   }

   private boolean a(float var1, Vec3d var2) {
      ClientPlayerEntity var3 = d.player;
      if (var3 == null) {
         return false;
      } else {
         if (var3 != this.E) {
            this.D.a();
            this.E = var3;
            this.F = 0.0F;
         }

         double var4 = System.currentTimeMillis() % 86400000L * 9.999995716466507E-4;
         Vec3d var6 = var3.getLerpedPos(var1);
         this.D.a(var4, var6.x, var6.y, var6.z);
         float var7 = (float)MathHelper.clamp(var4 - this.G, 0.0, 0.09999998815956226);
         this.G = var4;
         double var8 = this.D.b();
         double var10 = this.D.c();
         double var12 = this.D.d();
         this.D.a(var4 - 0.1199999573999807);
         double var14 = var8 - this.D.a;
         double var16 = var10 - this.D.b;
         double var18 = var12 - this.D.c;
         double var20 = (Math.sqrt(var14 * var14 + var18 * var18) + 0.3500000610314743 * Math.abs(var16)) / 0.1199999573999807;
         this.F = var20 > 0.7000000155505413 ? Math.min(1.0F, this.F + var7 / 0.18F) : Math.max(0.0F, this.F - var7 / 0.45F);
         if (this.F <= 0.0F) {
            return false;
         } else {
            float var22 = this.F * this.F * (3.0F - 2.0F * this.F);
            double var23 = this.h.b();
            double var25 = var3.getHeight() * 0.42000003352778675;

            for (int var27 = 0; var27 < 44; var27++) {
               this.D.b(var4 - var23 * var27 / 43.0);
               this.H[var27] = this.D.a;
               this.I[var27] = this.D.b + var25;
               this.J[var27] = this.D.c;
            }

            for (int var58 = 0; var58 < 44; var58++) {
               int var28 = Math.max(var58 - 1, 0);
               int var29 = Math.min(var58 + 1, 43);
               float var30 = (float)(this.H[var28] - this.H[var29]);
               float var31 = (float)(this.I[var28] - this.I[var29]);
               float var32 = (float)(this.J[var28] - this.J[var29]);
               float var33 = (float)Math.sqrt(var30 * var30 + var31 * var31 + var32 * var32);
               if (var33 < 1.0E-4F) {
                  var30 = 0.0F;
                  var31 = 0.0F;
                  var32 = 1.0F;
               } else {
                  var30 /= var33;
                  var31 /= var33;
                  var32 /= var33;
               }

               float var34 = -var32;
               float var36 = (float)Math.sqrt(var34 * var34 + var30 * var30);
               float var35;
               if (var36 < 0.2F) {
                  var34 = 1.0F;
                  var35 = 0.0F;
               } else {
                  var34 /= var36;
                  var35 = var30 / var36;
               }

               this.K[var58] = var34;
               this.L[var58] = var35;
               float var37 = -var35 * var31;
               float var38 = var35 * var30 - var34 * var32;
               float var39 = var34 * var31;
               float var40 = (float)Math.sqrt(var37 * var37 + var38 * var38 + var39 * var39);
               if (var40 < 1.0E-4F) {
                  var37 = 0.0F;
                  var38 = 1.0F;
                  var39 = 0.0F;
               } else {
                  var37 /= var40;
                  var38 /= var40;
                  var39 /= var40;
               }

               this.M[var58] = var37;
               this.N[var58] = var38;
               this.O[var58] = var39;
            }

            Color var59 = this.p();
            float[] var60 = Color.RGBtoHSB(var59.getRed(), var59.getGreen(), var59.getBlue(), null);
            float var61 = var60[0] * 360.0F;
            float var63 = var60[1];
            float var65 = var60[2];
            int var67 = var59.getAlpha();
            float var68 = this.i.b() * 0.5F * var22;
            float var70 = this.i.b() * 0.42F * var22;
            float var71 = Math.min((float)(var23 / 0.7000000155505413), 1.0F);

            for (int var72 = 0; var72 < 4; var72++) {
               int var75 = var72 * 44;
               double var78 = var72 * 0.5499999405468146;
               float var82 = 1.0F + 0.15F * b(var72 * 7 + 1);
               float var41 = 0.7F + 0.45F * b(var72 * 13 + 5);
               float var42 = 0.85F + 0.25F * b(var72 * 5 + 2);
               float var43 = (var72 - 1.5F) * 0.04F;

               for (int var44 = 0; var44 < 44; var44++) {
                  float var45 = var44 / 43.0F;
                  float var46 = 0.1F + 0.9F * a(var45 / 0.55F);
                  float var47 = var70 * var46 * var42;
                  float var48 = (float)(
                     0.7200000602472614 * Math.sin(var45 * 10.5 * var82 * var71 - var4 * 6.8000000247964865 + var78)
                        + 0.28000018166651564 * Math.sin(var45 * 23.0 * var71 - var4 * 11.0 + var78 * 3.09999906422466)
                  );
                  float var49 = (float)Math.sin(
                     var45 * 6.400000489083693 * var82 * var71 - var4 * 5.199997771354265 + var78 * 1.7000000359985183 + 1.2999995544931247
                  );
                  float var50 = 0.08F * a((var45 - 0.35F) / 0.65F) * var22;
                  float var51 = var48 * 0.8F * var47 + var50;
                  float var52 = var49 * 0.35F * var47 + var43 * var46;
                  int var53 = var75 + var44;
                  this.P[var53] = (float)(this.H[var44] + this.M[var44] * var51 + this.K[var44] * var52 - var2.x);
                  this.Q[var53] = (float)(this.I[var44] + this.N[var44] * var51 - var2.y);
                  this.R[var53] = (float)(this.J[var44] + this.O[var44] * var51 + this.L[var44] * var52 - var2.z);
                  float var54 = a((var45 - 0.45F) / 0.55F);
                  float var55 = (float)(0.5 + 0.5 * Math.sin(var45 * 47.0 - var4 * 8.300000517939065 + var78 * 2.4000002533674887));
                  float var56 = Math.min(1.0F, var45 * 14.0F) * (0.9F - 0.45F * var45) * (1.0F - var54 * (0.55F + 0.45F * var55));
                  float var57 = var63 * (0.35F + 0.65F * Math.min(1.0F, var45 * 9.0F));
                  this.V[var53] = ColorUtils.a(a(var61 + 10.0F * var45, var57, var65), (int)(var67 * var22 * var56));
               }

               for (int var85 = 0; var85 < 44; var85++) {
                  int var86 = var75 + var85;
                  float var88 = var85 / 43.0F;
                  float var90 = (0.45F + 0.55F * Math.min(1.0F, var88 * 4.0F)) * (1.0F - a((var88 - 0.5F) / 0.5F) * 0.95F);
                  float var93 = (float)(0.6000000048430639 * Math.sin(var88 * 7.300002885332444 * var71 - var4 * 5.400001226442692 + var78));
                  float var94 = (float)Math.cos(var93);
                  float var95 = (float)Math.sin(var93);
                  float var96 = var68 * var90 * var41;
                  this.S[var86] = (this.M[var85] * var94 + this.K[var85] * var95) * var96;
                  this.T[var86] = this.N[var85] * var94 * var96;
                  this.U[var86] = (this.O[var85] * var94 + this.L[var85] * var95) * var96;
               }
            }

            Vector3f var73 = new Vector3f(0.0F, 1.0F, 0.0F).rotate(d.gameRenderer.getCamera().getRotation());
            Vector3f var76 = new Vector3f(1.0F, 0.0F, 0.0F).rotate(d.gameRenderer.getCamera().getRotation());
            this.ab = var73.x;
            this.ac = var73.y;
            this.ad = var73.z;
            this.ae = var76.x;
            this.af = var76.y;
            this.ag = var76.z;

            for (int var79 = 0; var79 < 12; var79++) {
               double var81 = 0.5499999405468146 + b(var79 * 47 + 9) * 0.5;
               double var83 = var4 / var81 + b(var79 * 31 + 4) * 32.0;
               double var84 = Math.floor(var83);
               float var87 = (float)(var83 - var84);
               int var89 = var79 * 389 + (int)var84 * 613;
               this.D.b(var4 - var87 * var81 - (0.09999998815956226 + 0.5 * b(var89 + 11)) * var23);
               float var91 = Math.min(Math.min(var87 / 0.18F, (1.0F - var87) / 0.4F), 1.0F);
               var91 = var91 * var91 * (3.0F - 2.0F * var91);
               this.W[var79] = (float)(this.D.a + (b(var89 + 2) - 0.5F) * 0.45F * var87 - var2.x);
               this.X[var79] = (float)(this.D.b + var25 * (0.7000000155505413 + 0.5 * b(var89 + 8)) + 0.35F * var87 - 0.15F * var87 * var87 - var2.y);
               this.Y[var79] = (float)(this.D.c + (b(var89 + 3) - 0.5F) * 0.45F * var87 - var2.z);
               this.Z[var79] = 0.024F * (0.6F + 0.8F * b(var89 + 4)) * (1.0F - 0.4F * var87) * var22;
               this.aa[var79] = ColorUtils.a(a(var61 + 8.0F * var87, var63 * 0.5F, var65), (int)(var67 * var22 * var91 * 0.6F));
            }

            return true;
         }
      }
   }

   private void a(VertexConsumer var1, Entry var2, float var3, float var4) {
      for (int var5 = 0; var5 < 4; var5++) {
         int var6 = var5 * 44;

         for (int var7 = 0; var7 < 43; var7++) {
            int var8 = var6 + var7;
            int var9 = var8 + 1;
            int var10 = a(this.V[var8], var4);
            int var11 = a(this.V[var9], var4);
            int var12 = a(var10, 0.45F);
            int var13 = a(var11, 0.45F);
            var1.vertex(var2, this.P[var8] - this.S[var8] * var3, this.Q[var8] - this.T[var8] * var3, this.R[var8] - this.U[var8] * var3).color(var10);
            var1.vertex(var2, this.P[var8] + this.S[var8] * var3, this.Q[var8] + this.T[var8] * var3, this.R[var8] + this.U[var8] * var3).color(var12);
            var1.vertex(var2, this.P[var9] + this.S[var9] * var3, this.Q[var9] + this.T[var9] * var3, this.R[var9] + this.U[var9] * var3).color(var13);
            var1.vertex(var2, this.P[var9] - this.S[var9] * var3, this.Q[var9] - this.T[var9] * var3, this.R[var9] - this.U[var9] * var3).color(var11);
         }
      }
   }

   private void a(VertexConsumer var1, Entry var2) {
      for (int var3 = 0; var3 < 12; var3++) {
         float var4 = this.Z[var3];
         float var5 = this.ab * var4;
         float var6 = this.ac * var4;
         float var7 = this.ad * var4;
         float var8 = this.ae * var4;
         float var9 = this.af * var4;
         float var10 = this.ag * var4;
         int var11 = this.aa[var3];
         var1.vertex(var2, this.W[var3] + var5, this.X[var3] + var6, this.Y[var3] + var7).color(var11);
         var1.vertex(var2, this.W[var3] + var8, this.X[var3] + var9, this.Y[var3] + var10).color(var11);
         var1.vertex(var2, this.W[var3] - var5, this.X[var3] - var6, this.Y[var3] - var7).color(var11);
         var1.vertex(var2, this.W[var3] - var8, this.X[var3] - var9, this.Y[var3] - var10).color(var11);
      }
   }

   private static float b(int var0) {
      float var1 = (float)(Math.sin(var0 * 12.9898F + 1.7F) * 43758.55F);
      return var1 - (float)Math.floor(var1);
   }

   private static float a(float var0) {
      float var1 = Math.max(0.0F, Math.min(1.0F, var0));
      return var1 * var1 * (3.0F - 2.0F * var1);
   }

   private static int a(float var0, float var1, float var2) {
      return Color.HSBtoRGB(var0 / 360.0F, Math.max(0.0F, Math.min(1.0F, var1)), Math.max(0.0F, Math.min(1.0F, var2)));
   }

   private static int a(int var0, float var1) {
      return ColorUtils.a(var0, (int)((var0 >>> 24) * var1));
   }

   private boolean a(PlayerEntity var1) {
      return var1 != d.player ? false : var1 != d.player || !d.options.getPerspective().isFirstPerson() || this.b.a();
   }

   private static int a(int var0, int var1) {
      return Math.max(0, Math.min(255, var1)) << 24 | var0 & 16777215;
   }

   private Color p() {
      if (this.k.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.l.a();
      }
   }

   private Color q() {
      if (this.w.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.x.a();
      }
   }

   private Identifier r() {
      return ParticleTextures.a(this.o.e());
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.y.clear();
      this.C = false;
      this.D.a();
      this.E = null;
      this.F = 0.0F;
   }

   public static Deque a(UUID var0) {
      return new ArrayDeque<>();
   }

   static {
      NativeMethodLookup.lookup(TrailsModule.class, 88);
   }

   @Environment(EnvType.CLIENT)
   private record TrailPoint(Vec3d pos, float height) {
   }
}
