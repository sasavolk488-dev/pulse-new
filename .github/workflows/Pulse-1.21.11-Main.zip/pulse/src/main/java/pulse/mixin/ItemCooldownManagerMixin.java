package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.utils.game.CooldownUtil;

@Environment(EnvType.CLIENT)
@Mixin({ItemCooldownManager.class})
public abstract class ItemCooldownManagerMixin {
   @Inject(
      method = {"set(Lnet/minecraft/util/Identifier;I)V"},
      at = {@At("HEAD")}
   )
   private void pulse$captureDuration(Identifier var1, int var2, CallbackInfo var3) {
      CooldownUtil.a(var1, var2);
   }
}
