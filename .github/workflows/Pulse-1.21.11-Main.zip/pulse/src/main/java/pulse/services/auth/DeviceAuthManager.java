package pulse.services.auth;

import java.awt.Desktop;
import java.awt.Desktop.Action;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.json.JSONObject;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public class DeviceAuthManager {
   private static final String a = "/auth/device/init";
   private static final String b = "/auth/device/poll";
   private static final int c = 1000;
   private static final int d = 300;
   private volatile boolean e = false;

   public String a() {
      try {
         String var1 = UUID.randomUUID().toString();
         Pulse.m().info("Запуск авторизации...");
         if (!this.a(var1)) {
            Pulse.m().error("Ошибка инициализации запроса авторизации");
            return null;
         } else {
            this.b(var1);
            String var2 = this.c(var1);
            if (var2 != null) {
               Pulse.m().info("Токен успешно получен!");
            } else {
               Pulse.a("Не удалось получить токен");
            }

            return var2;
         }
      } catch (Exception var3) {
         Pulse.m().error("Ошибка Device Auth Flow", (Throwable)var3);
         return null;
      }
   }

   private boolean a(String var1) {
      try {
         String var2 = Pulse.i() + "/auth/device/init?state=" + URLEncoder.encode(var1, "UTF-8");
         JSONObject var3 = this.d(var2);
         if (var3 != null && var3.getBoolean("success")) {
            int var4 = var3.getInt("expiresIn");
            Pulse.m().info("Запрос авторизации создан");
            Pulse.m().info("Истекает через " + var4 / 60 + " минут");
            return true;
         } else {
            return false;
         }
      } catch (Exception var5) {
         Pulse.m().error("Ошибка init request", (Throwable)var5);
         return false;
      }
   }

   private void b(String var1) {
      String var2 = Pulse.g() + "/auth/device?state=" + var1;

      try {
         if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Action.BROWSE)) {
            Desktop.getDesktop().browse(new URI(var2));
         } else {
            String var3 = System.getProperty("os.name").toLowerCase();
            if (var3.contains("win")) {
               Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + var2);
            } else if (var3.contains("mac")) {
               Runtime.getRuntime().exec("open " + var2);
            } else {
               Runtime.getRuntime().exec("xdg-open " + var2);
            }
         }
      } catch (Exception var4) {
         Pulse.a("Не удалось открыть браузер автоматически. Откройте ссылку вручную: " + var2);
         Pulse.m().error("Не удалось открыть браузер автоматически");
         Pulse.m().error("Откройте ссылку вручную: " + var2);
      }
   }

   private String c(String var1) {
      int var2 = 0;
      boolean var3 = false;
      String var4 = Pulse.g() + "/auth/device?state=" + var1;
      Pulse.m().info("Ожидание подтверждения в браузере...");

      while (var2 < 300 && !this.e) {
         try {
            if (++var2 >= 150 && !var3) {
               var3 = true;
               String var5 = "Вам необходимо пройти авторизацию в браузере!\nЕсли ссылка не открылась автоматически, откройте её вручную:\n" + var4;
               new Thread(() -> Pulse.a(var5)).start();
            }

            if (var2 % 30 == 0) {
               int var10 = 300 - var2;
               int var6 = var10 * 1;
               int var7 = var6 / 60;
               Pulse.m().info("Все еще ожидаем подтверждения... (" + var7 + " мин " + var6 % 60 + " сек до таймаута)");
            }

            String var11 = Pulse.i() + "/auth/device/poll?state=" + URLEncoder.encode(var1, "UTF-8");
            JSONObject var12 = this.d(var11);
            if (var12 == null) {
               Thread.sleep(1000L);
            } else if (!var12.getBoolean("success")) {
               Thread.sleep(1000L);
            } else {
               String var13 = var12.getString("status");
               if ("confirmed".equals(var13)) {
                  return var12.getString("token");
               }

               if ("expired".equals(var13)) {
                  Pulse.a("Запрос авторизации истек (прошло более 15 минут)");
                  return null;
               }

               if ("not_found".equals(var13)) {
                  Pulse.a("Запрос авторизации не найден");
                  return null;
               }

               if ("cancelled".equals(var13)) {
                  Pulse.a("Авторизация отменена пользователем");
                  return null;
               }

               Thread.sleep(1000L);
            }
         } catch (InterruptedException var8) {
            Thread.currentThread().interrupt();
            return null;
         } catch (Exception var9) {
            Pulse.m().error("Ошибка polling: " + var9.getMessage());
         }
      }

      if (this.e) {
         Pulse.a("Авторизация отменена пользователем");
      } else {
         Pulse.a("Время ожидания авторизации истекло! Перезапустите клиент и попробуйте снова");
      }

      return null;
   }

   private JSONObject d(String var1) {
      try {
         URL var2 = new URL(var1);
         HttpURLConnection var3 = (HttpURLConnection)var2.openConnection();
         var3.setRequestMethod("GET");
         var3.setConnectTimeout(5000);
         var3.setReadTimeout(5000);
         int var4 = var3.getResponseCode();
         if (var4 != 200) {
            return null;
         } else {
            InputStream var5 = var3.getInputStream();
            ByteArrayOutputStream var6 = new ByteArrayOutputStream();
            byte[] var7 = new byte[1024];

            int var8;
            while ((var8 = var5.read(var7)) != -1) {
               var6.write(var7, 0, var8);
            }

            String var9 = new String(var6.toByteArray(), StandardCharsets.UTF_8);
            return new JSONObject(var9);
         }
      } catch (Exception var10) {
         return null;
      }
   }

   public void b() {
      this.e = true;
   }
}
