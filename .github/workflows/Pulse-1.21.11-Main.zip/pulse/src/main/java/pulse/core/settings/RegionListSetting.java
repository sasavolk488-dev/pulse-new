package pulse.core.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class RegionListSetting extends InputSetting {
   private final List<RegionListSetting.Entry> a = new ArrayList<>();

   public RegionListSetting(String var1) {
      super(var1, InputSetting.InputType.a, "", "");
   }

   @Override
   public void a(String var1) {
      super.a(var1);
      this.c(var1);
   }

   public List<RegionListSetting.Entry> b() {
      return this.a;
   }

   @Override
   public boolean c() {
      return this.a.isEmpty();
   }

   public void a(int var1, int var2, int var3, int var4) {
      this.a.add(new RegionListSetting.Entry(var1, var2, var3, var4));
      this.d();
   }

   public void a(int var1) {
      if (var1 >= 0 && var1 < this.a.size()) {
         this.a.remove(var1);
         this.d();
      }
   }

   public void d() {
      super.a(this.s());
   }

   private String s() {
      StringBuilder var1 = new StringBuilder();

      for (RegionListSetting.Entry var3 : this.a) {
         if (var1.length() > 0) {
            var1.append(';');
         }

         var1.append(var3.a).append(',').append(var3.b).append(',').append(var3.c).append(',').append(var3.d);
      }

      return var1.toString();
   }

   private void c(String var1) {
      this.a.clear();
      if (var1 != null && !var1.isEmpty()) {
         for (String var5 : var1.split(";")) {
            String[] var6 = var5.split(",");
            if (var6.length == 4) {
               try {
                  this.a
                     .add(
                        new RegionListSetting.Entry(
                           Integer.parseInt(var6[0].trim()),
                           Integer.parseInt(var6[1].trim()),
                           Integer.parseInt(var6[2].trim()),
                           Integer.parseInt(var6[3].trim())
                        )
                     );
               } catch (NumberFormatException var8) {
               }
            }
         }
      }
   }

   public RegionListSetting a(Supplier<Boolean> var1) {
      super.c(var1);
      return this;
   }

   @Override
   public InputSetting c(Supplier var1) {
      return this.a(var1);
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }

   @Environment(EnvType.CLIENT)
   public static final class Entry {
      private int a;
      private int b;
      private int c;
      private int d;

      public Entry(int var1, int var2, int var3, int var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }

      public int a() {
         return this.a;
      }

      public int b() {
         return this.b;
      }

      public int c() {
         return this.c;
      }

      public int d() {
         return this.d;
      }

      public void a(int var1) {
         this.a = var1;
      }

      public void b(int var1) {
         this.b = var1;
      }

      public void c(int var1) {
         this.c = var1;
      }

      public void d(int var1) {
         this.d = var1;
      }
   }
}
