package pulse.features.modules.visuals;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import pulse.Pulse;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.core.Renderer2D;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Crosshair",
   b = "Настраивает отображение прицела",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class CrosshairModule extends Module {
   private final NumberSetting a = new NumberSetting("Длина", 3.0F, 1.0F, 15.0F, 1.0F);
   private final NumberSetting b = new NumberSetting("Толщина", 1.0F, 1.0F, 10.0F, 1.0F);
   private final NumberSetting c = new NumberSetting("Отступ", 0.0F, 0.0F, 10.0F, 1.0F);
   private final SeparatorSetting f = new SeparatorSetting("Поведение");
   private final BooleanSetting g = new BooleanSetting("Обводка", true);
   private final BooleanSetting h = new BooleanSetting("Точка", false);
   private final BooleanSetting i = new BooleanSetting("Менять цвет при наводке", true);
   private final BooleanSetting j = new BooleanSetting("Динамический", false);
   private final SeparatorSetting k = new SeparatorSetting("Цвет");
   private final BooleanSetting l = new BooleanSetting("Цвет клиента", false);
   private final ColorSetting m = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.l.a());

   @EventHandler(
      priority = -200
   )
   private void a(RenderHudPostEvent var1) {
      if (d.options.getPerspective() == Perspective.FIRST_PERSON) {
         if (d.player != null) {
            Renderer2D var2 = Pulse.l().o();
            if (var2 != null) {
               float var3 = d.getWindow().getFramebufferWidth() / 4.0F;
               float var4 = d.getWindow().getFramebufferHeight() / 4.0F;
               float var5 = 1.0F - d.player.getAttackCooldownProgress(var1.d());
               Color var6 = this.o();
               if (this.i.a() && this.n()) {
                  var6 = new Color(255, 64, 64);
               }

               this.a(var2, var3, var4, var5, var6);
            }
         }
      }
   }

   private void a(Renderer2D var1, float var2, float var3, float var4, Color var5) {
      float var6 = this.j.a() ? this.c.b() + 8.0F * var4 : this.c.b();
      float var7 = this.b.b();
      float var8 = this.a.b();
      float var9 = 0.5F;
      if (this.g.a()) {
         int var10 = Color.BLACK.getRGB();
         var1.a(var2 + var6 - var9, var3 - var7 / 2.0F - var9, var8 + var9 * 2.0F, var7 + var9 * 2.0F, var10);
         var1.a(var2 - var6 - var8 - var9, var3 - var7 / 2.0F - var9, var8 + var9 * 2.0F, var7 + var9 * 2.0F, var10);
         var1.a(var2 - var7 / 2.0F - var9, var3 - var6 - var8 - var9, var7 + var9 * 2.0F, var8 + var9 * 2.0F, var10);
         var1.a(var2 - var7 / 2.0F - var9, var3 + var6 - var9, var7 + var9 * 2.0F, var8 + var9 * 2.0F, var10);
         if (this.h.a()) {
            float var11 = 2.0F;
            var1.a(var2 - var11 / 2.0F - var9, var3 - var11 / 2.0F - var9, var11 + var9 * 2.0F, var11 + var9 * 2.0F, var10);
         }
      }

      int var12 = var5.getRGB();
      var1.a(var2 + var6, var3 - var7 / 2.0F, var8, var7, var12);
      var1.a(var2 - var6 - var8, var3 - var7 / 2.0F, var8, var7, var12);
      var1.a(var2 - var7 / 2.0F, var3 - var6 - var8, var7, var8, var12);
      var1.a(var2 - var7 / 2.0F, var3 + var6, var7, var8, var12);
      if (this.h.a()) {
         float var13 = 2.0F;
         var1.a(var2 - var13 / 2.0F, var3 - var13 / 2.0F, var13, var13, var12);
      }
   }

   private boolean n() {
      if (d.crosshairTarget != null && d.crosshairTarget.getType() == Type.ENTITY) {
         Entity var1 = ((EntityHitResult)d.crosshairTarget).getEntity();
         return var1 instanceof LivingEntity;
      } else {
         return false;
      }
   }

   private Color o() {
      if (this.l.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.m.a();
      }
   }
}
