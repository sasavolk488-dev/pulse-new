package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.PacketEvent;

@Environment(EnvType.CLIENT)
@Mixin({ClientConnection.class})
public class ClientConnectionMixin {
   @Inject(
      method = {"handlePacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static <T extends PacketListener> void onHandlePacket(Packet<T> var0, PacketListener var1, CallbackInfo var2) {
      if (EventHandler.a.isListening(PacketEvent.class)) {
         PacketEvent var3 = new PacketEvent(var0, PacketEvent.EventType.b);
         EventHandler.a.post(var3);
         if (var3.c()) {
            var2.cancel();
         }
      }
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendPacket(Packet<?> var1, CallbackInfo var2) {
      if (EventHandler.a.isListening(PacketEvent.class)) {
         PacketEvent var3 = new PacketEvent(var1, PacketEvent.EventType.a);
         EventHandler.a.post(var3);
         if (var3.c()) {
            var2.cancel();
         }
      }
   }
}
