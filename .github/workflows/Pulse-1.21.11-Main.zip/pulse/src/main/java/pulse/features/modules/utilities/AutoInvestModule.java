package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.scoreboard.Team;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.InputSetting;

@ModuleInfo(
   a = "Auto Invest",
   b = "Автоматически инвестирует деньги в клан при превышении порога",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoInvestModule extends Module {
   private final InputSetting a = new InputSetting(
      "Порог суммы", "Сумма при которой деньги будут вложены в клан", InputSetting.InputType.e, "50000000", "Введите сумму"
   );
   private final Pattern b = Pattern.compile("[\\d,]+");
   private long c = -1L;
   private int f = 0;

   @EventHandler
   @Compile
      private void a(UpdateEvent var1) {
      if (pulse.utils.game.PVPUtils.a().a() || d.player == null || d.world == null) {
         return;
      }
      if (++this.f < 20) {
         return;
      }
      this.f = 0;
      long balance = this.o();
      long threshold = this.n();
      if (balance > threshold && threshold > 0L && balance != this.c) {
         pulse.utils.game.ChatUtils.a("clan invest " + threshold);
         this.c = balance;
      }
   }

   private long n() {
      try {
         return Long.parseLong(this.a.q().replace(",", ""));
      } catch (NumberFormatException var2) {
         return 0L;
      }
   }

   private long o() {
      for (Team var2 : d.world.getScoreboard().getTeams()) {
         String var3 = var2.getPrefix().getString().toLowerCase(Locale.ROOT);
         if (var3.contains("монет")) {
            Matcher var4 = this.b.matcher(var3);

            while (var4.find()) {
               try {
                  String var5 = var4.group().replace(",", "");
                  return Long.parseLong(var5);
               } catch (NumberFormatException var6) {
               }
            }
         }
      }

      return -1L;
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.c = -1L;
      this.f = 0;
   }

   static {
      NativeMethodLookup.lookup(AutoInvestModule.class, 49);
   }
}
