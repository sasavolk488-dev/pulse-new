package pulse.features.modules.utilities;

import java.util.function.Predicate;

public final class OptimizationModule$$Lambda$29 implements Predicate {
   private final long c0;

   public OptimizationModule$$Lambda$29(long var1) {
      this.c0 = var1;
   }

   @Override
   public boolean test(Object var1) {
      return OptimizationModule.a(this.c0, (OptimizationModule.CullEntry)var1);
   }
}
