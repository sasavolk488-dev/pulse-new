package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.SkyboxRenderEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "World Customizer",
   b = "Настройка мира",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class WorldCustomizerModule extends Module {
   private final SeparatorSetting a = new SeparatorSetting("Туман");
   private final BooleanSetting b = new BooleanSetting("Настроить туман", true);
   private final BooleanSetting c = new BooleanSetting("Убрать туман", "Полностью вырезает весь туман (включая туман Нижнего мира и слепоты)", false);
   private final BooleanSetting f = new BooleanSetting("Кастомная дальность", false).a(() -> this.b.a() && !this.c.a());
   private final NumberSetting g = new NumberSetting("Дальность тумана", 0.3F, 0.1F, 1.0F, 0.01F).a(() -> this.b.a() && this.f.a() && !this.c.a());
   private final SeparatorSetting h = new SeparatorSetting("Небо");
   private final BooleanSetting i = new BooleanSetting("Настроить небо", true);
   private final SeparatorSetting j = new SeparatorSetting("Цвет");
   private final BooleanSetting k = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting l = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.k.a());
   private static final String[] m = new String[]{"Nebula", "Aurora", "Galaxy", "Sunset", "Lava", "Cosmos", "BlackHole"};
   private final SeparatorSetting n = new SeparatorSetting("Шейдер неба");
   private final BooleanSetting o = new BooleanSetting("Включить шейдер", false);
   private final ModeSetting p = new ModeSetting("Режим", m, "Nebula").a(this.o::a);
   private final NumberSetting q = new NumberSetting("Скорость", 1.0F, 0.0F, 5.0F, 0.05F).a(this.o::a);
   private final SeparatorSetting r = new SeparatorSetting("Цветокоррекция");
   private final BooleanSetting s = new BooleanSetting("Включить цветокоррекцию", false);
   private final ColorSetting t = new ColorSetting("Оттенок", Color.WHITE).a(this.s::a);
   private final NumberSetting u = new NumberSetting("Vibrance", 0.0F, -1.0F, 1.0F, 0.01F).a(this.s::a);
   private final NumberSetting v = new NumberSetting("Exposure", 0.0F, -2.0F, 2.0F, 0.05F).a(this.s::a);
   private float w = 0.0F;
   private long x = 0L;

   public boolean n() {
      return this.k() && this.b.a();
   }

   public boolean o() {
      return this.k() && this.b.a() && this.f.a() && !this.c.a();
   }

   public boolean p() {
      return this.k() && this.c.a();
   }

   public float q() {
      return 0.0F;
   }

   public float r() {
      return this.g.b() * 250.0F;
   }

   public boolean s() {
      return this.k() && this.i.a();
   }

   public int t() {
      return this.A().getRGB();
   }

   public int v() {
      return this.A().getRGB();
   }

   private Color A() {
      if (this.k.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return var1.n();
      } else {
         return this.l.a();
      }
   }

   public boolean w() {
      return this.k() && this.s.a();
   }

   public int x() {
      return this.t.a().getRGB();
   }

   public float y() {
      return this.u.b();
   }

   public float z() {
      return this.v.b();
   }

   @EventHandler
   @Compile
   public void a(SkyboxRenderEvent var1) {
      BooleanSetting shader = this.o;
      ModeSetting mode = this.p;
      if (this.k() && shader.a()) {
         float time = this.B();
         int selection = (Integer)mode.q();
         if (pulse.utils.render.world.Skybox.a(selection, time)) {
            pulse.utils.render.world.BlackHoleBloom.a();
         }
      }
   }

   private float B() {
      long var1 = System.currentTimeMillis();
      if (this.x != 0L) {
         float var3 = (float)(var1 - this.x) / 1000.0F;
         if (var3 < 0.0F) {
            var3 = 0.0F;
         }

         if (var3 > 0.1F) {
            var3 = 0.1F;
         }

         this.w = (this.w + var3 * this.q.b()) % 100000.0F;
      }

      this.x = var1;
      return this.w;
   }

   @Compile
   @Override
   public void e() {
      super.e();
      this.x = 0L;
   }

   @Compile
   @Override
   public void f() {
      super.f();
      if (d.worldRenderer != null) {
         d.worldRenderer.reload();
      }
   }

   static {
      NativeMethodLookup.lookup(WorldCustomizerModule.class, 89);
   }
}
