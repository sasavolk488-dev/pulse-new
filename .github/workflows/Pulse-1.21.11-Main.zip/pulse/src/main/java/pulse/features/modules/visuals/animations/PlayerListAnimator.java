package pulse.features.modules.visuals.animations;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.utils.animation.util.Easing;
import pulse.utils.animation.util.Easings;

@Environment(EnvType.CLIENT)
public class PlayerListAnimator {
   private float a = 0.0F;
   private float b = 0.0F;
   private float c = 1.0F;
   private long d = 0L;
   private long e = 200L;
   private final Easing f = Easings.h;
   private boolean g = false;
   private boolean h = false;

   public void a(long var1) {
      this.e = var1;
      this.b = this.a;
      this.c = 1.0F;
      this.d = System.currentTimeMillis();
      this.g = false;
      this.h = true;
   }

   public void b(long var1) {
      this.e = var1;
      this.b = this.a;
      this.c = 0.0F;
      this.d = System.currentTimeMillis();
      this.g = true;
      this.h = true;
   }

   public void a() {
      if (this.d != 0L) {
         long var1 = System.currentTimeMillis();
         double var3 = var1 - this.d;
         double var5 = this.e;
         if (var3 >= var5) {
            this.a = this.c;
            this.d = 0L;
            if (this.g) {
               this.h = false;
               this.g = false;
            }
         } else {
            double var7 = var3 / var5;
            double var9 = this.f.ease(var7);
            this.a = (float)(this.b + (this.c - this.b) * var9);
         }
      }
   }

   public float b() {
      return this.a;
   }

   public boolean c() {
      return this.g;
   }

   public boolean d() {
      return this.h;
   }

   public boolean e() {
      return this.d != 0L;
   }

   public void f() {
      this.a = 1.0F;
      this.d = 0L;
      this.g = false;
      this.h = false;
   }
}
