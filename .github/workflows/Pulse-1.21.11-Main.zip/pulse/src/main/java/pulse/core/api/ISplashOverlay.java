package pulse.core.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface ISplashOverlay {
   long pulse$reloadStartTime();

   long pulse$reloadCompleteTime();
}
