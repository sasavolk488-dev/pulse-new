package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;
import pulse.core.event.impl.PlaySoundEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Sound Controller",
   b = "Контроль громкости определённых звуков",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class SoundControllerModule extends Module {
   private final SeparatorSetting a = new SeparatorSetting("Фейерверк");
   private final BooleanSetting b = new BooleanSetting("Включить", false);
   private final NumberSetting c = new NumberSetting("Громкость", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.b.a());
   private final SeparatorSetting f = new SeparatorSetting("Пузырёк опыта");
   private final BooleanSetting g = new BooleanSetting("Бросок", false);
   private final NumberSetting h = new NumberSetting("Громкость броска", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.g.a());
   private final BooleanSetting i = new BooleanSetting("Разбивание", false);
   private final NumberSetting j = new NumberSetting("Громкость разбивания", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.i.a());
   private final BooleanSetting k = new BooleanSetting("Подбор опыта", false);
   private final NumberSetting l = new NumberSetting("Громкость подбора", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.k.a());
   private final SeparatorSetting m = new SeparatorSetting("Оружие");
   private final BooleanSetting n = new BooleanSetting("Трезубец", false);
   private final NumberSetting o = new NumberSetting("Громкость трезубца", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.n.a());
   private final BooleanSetting p = new BooleanSetting("Удочка", false);
   private final NumberSetting q = new NumberSetting("Громкость удочки", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.p.a());
   private final SeparatorSetting r = new SeparatorSetting("Козий рог");
   private final BooleanSetting s = new BooleanSetting("Козий рог", false);
   private final NumberSetting t = new NumberSetting("Громкость рога", 0.0F, 0.0F, 100.0F, 1.0F).a(() -> this.s.a());
   private final SeparatorSetting u = new SeparatorSetting("Атака");
   private final BooleanSetting v = new BooleanSetting("Звук удара", false);
   private final NumberSetting w = new NumberSetting("Громкость удара", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.v.a());
   private final BooleanSetting x = new BooleanSetting("Звук крита", false);
   private final NumberSetting y = new NumberSetting("Громкость крита", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.x.a());
   private final SeparatorSetting z = new SeparatorSetting("Прочее");
   private final BooleanSetting A = new BooleanSetting("Сплеш", false);
   private final NumberSetting B = new NumberSetting("Громкость сплеша", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.A.a());
   private final BooleanSetting C = new BooleanSetting("Крит FunTime", false);
   private final NumberSetting D = new NumberSetting("Громкость FunTime", 50.0F, 0.0F, 100.0F, 1.0F).a(() -> this.C.a());
   private final Map<Identifier, SoundControllerModule.SoundControl> E = new HashMap<>();

   public SoundControllerModule() {
      this.E.put(Identifier.of("minecraft:entity.firework_rocket.launch"), new SoundControllerModule.SoundControl(this.b, this.c));
      this.E.put(Identifier.of("minecraft:entity.experience_bottle.throw"), new SoundControllerModule.SoundControl(this.g, this.h));
      this.E.put(Identifier.of("minecraft:entity.splash_potion.break"), new SoundControllerModule.SoundControl(this.i, this.j));
      this.E.put(Identifier.of("minecraft:entity.experience_orb.pickup"), new SoundControllerModule.SoundControl(this.k, this.l));
      this.E.put(Identifier.of("minecraft:item.trident.return"), new SoundControllerModule.SoundControl(this.n, this.o));
      this.E.put(Identifier.of("minecraft:item.trident.hit_ground"), new SoundControllerModule.SoundControl(this.n, this.o));
      this.E.put(Identifier.of("minecraft:block.beacon.deactivate"), new SoundControllerModule.SoundControl(this.n, this.o));
      this.E.put(Identifier.of("minecraft:entity.fishing_bobber.retrieve"), new SoundControllerModule.SoundControl(this.p, this.q));
      this.E.put(Identifier.of("minecraft:entity.player.attack.sweep"), new SoundControllerModule.SoundControl(this.v, this.w));
      this.E.put(Identifier.of("minecraft:entity.player.attack.strong"), new SoundControllerModule.SoundControl(this.v, this.w));
      this.E.put(Identifier.of("minecraft:entity.player.attack.weak"), new SoundControllerModule.SoundControl(this.v, this.w));
      this.E.put(Identifier.of("minecraft:entity.generic.splash"), new SoundControllerModule.SoundControl(this.A, this.B));
      this.E.put(Identifier.of("minecraft:entity.player.splash"), new SoundControllerModule.SoundControl(this.A, this.B));
      this.E.put(Identifier.of("minecraft:entity.player.attack.crit"), new SoundControllerModule.SoundControl(this.x, this.y));
      this.E.put(Identifier.of("minecraft:entity.player.levelup"), new SoundControllerModule.SoundControl(this.C, this.D));

      for (int var1 = 0; var1 < 8; var1++) {
         this.E.put(Identifier.of("minecraft:item.goat_horn.sound." + var1), new SoundControllerModule.SoundControl(this.s, this.t));
      }
   }

   @EventHandler
   @Compile
   public void a(PlaySoundEvent var1) {
      Identifier var2 = var1.d().getId();
      SoundControl var3 = this.E.get(var2);
      if (var3 != null && var3.a.a()) {
         var1.a(var3.b.b() / 100.0F);
      }
   }

   static {
      NativeMethodLookup.lookup(SoundControllerModule.class, 74);
   }

   @Environment(EnvType.CLIENT)
   private static class SoundControl {
      private final BooleanSetting a;
      private final NumberSetting b;

      public SoundControl(BooleanSetting var1, NumberSetting var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
