package pulse.mixin;

import java.util.Arrays;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import pulse.features.resourcepack.PulsePackProvider;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public class MinecraftClientPackMixin {
   @ModifyArg(
      method = {"<init>"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/resource/ResourcePackManager;<init>([Lnet/minecraft/resource/ResourcePackProvider;)V"
      ),
      index = 0
   )
   private ResourcePackProvider[] pulse$addResourcePackProvider(ResourcePackProvider[] var1) {
      ResourcePackProvider[] var2 = Arrays.copyOf(var1, var1.length + 1);
      var2[var1.length] = new PulsePackProvider();
      return var2;
   }
}
