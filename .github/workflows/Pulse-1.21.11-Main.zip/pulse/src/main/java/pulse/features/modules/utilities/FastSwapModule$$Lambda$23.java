package pulse.features.modules.utilities;

import java.util.function.Predicate;

public final class FastSwapModule$$Lambda$23 implements Predicate {
   private final int c0;

   public FastSwapModule$$Lambda$23(int var1) {
      this.c0 = var1;
   }

   @Override
   public boolean test(Object var1) {
      return FastSwapModule.a(this.c0, (FastSwapModule.Action)var1);
   }
}
