package pulse.features.modules.utilities.ft;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public final class FunTimeItemDetector {
   private static final String a = "нерушимая клетка";
   private static final String b = "нерушимая стена";

   private FunTimeItemDetector() {
   }

   public static FunTimeItemType a(ItemStack var0) {
      if (var0.isEmpty()) {
         return FunTimeItemType.c;
      } else {
         FunTimeItemType var1 = b(var0);
         if (var1 != FunTimeItemType.c) {
            return var1;
         } else {
            FunTimeItemType var2 = a(var0.getName());
            return var2 != FunTimeItemType.c ? var2 : c(var0);
         }
      }
   }

   private static FunTimeItemType b(ItemStack var0) {
      NbtComponent var1 = var0.get(DataComponentTypes.CUSTOM_DATA);
      if (var1 == null) {
         return FunTimeItemType.c;
      } else {
         NbtCompound var2 = var1.copyNbt();
         NbtCompound var3 = var2.getCompound("PublicBukkitValues").orElse(null);
         if (var3 != null && !var3.isEmpty()) {
            FunTimeItemType var4 = a(a(var3, "minecraft:ftid"));
            if (var4 != FunTimeItemType.c) {
               return var4;
            } else {
               FunTimeItemType var5 = a(a(var3, "minecraft:don-item"));
               if (var5 != FunTimeItemType.c) {
                  return var5;
               } else if (var3.getInt("minecraft:trap").orElse(0) == 1) {
                  return FunTimeItemType.a;
               } else {
                  return var3.getInt("minecraft:stratum").orElse(0) == 1 ? FunTimeItemType.b : FunTimeItemType.c;
               }
            }
         } else {
            return FunTimeItemType.c;
         }
      }
   }

   private static FunTimeItemType a(String var0) {
      if ("trap".equals(var0)) {
         return FunTimeItemType.a;
      } else {
         return "stratum".equals(var0) ? FunTimeItemType.b : FunTimeItemType.c;
      }
   }

   private static FunTimeItemType a(Text var0) {
      String var1 = b(var0.getString());
      if (var1.contains("трапка")) {
         return FunTimeItemType.a;
      } else {
         return var1.contains("пласт") ? FunTimeItemType.b : FunTimeItemType.c;
      }
   }

   private static FunTimeItemType c(ItemStack var0) {
      LoreComponent var1 = var0.get(DataComponentTypes.LORE);
      if (var1 == null) {
         return FunTimeItemType.c;
      } else {
         boolean var2 = false;
         boolean var3 = false;

         for (Text var5 : var1.lines()) {
            String var6 = b(var5.getString());
            if (var6.contains("нерушимая клетка")) {
               var2 = true;
            }

            if (var6.contains("нерушимая стена")) {
               var3 = true;
            }
         }

         if (var2 && !var3) {
            return FunTimeItemType.a;
         } else {
            return var3 && !var2 ? FunTimeItemType.b : FunTimeItemType.c;
         }
      }
   }

   private static String a(NbtCompound var0, String var1) {
      return var0.getString(var1).orElse(null);
   }

   private static String b(String var0) {
      return var0.toLowerCase().replace('ё', 'е').trim();
   }
}
