package pulse.features.modules.hud.components;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.DebuffTimeHandler;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.hud.HudItemDrawer;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.PotionsModule;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class PotionsComponent extends DraggableComponent {
   private static final Color m = new Color(13, 13, 17);
   private static final Color n = new Color(17, 17, 23);
   private static final Color o = new Color(255, 255, 255);
   private static final Color p = new Color(223, 223, 243);
   private static final Color q = new Color(20, 20, 28);
   private static final Color r = new Color(16, 16, 21);
   private static final Color s = new Color(17, 17, 23);
   private static final Color t = new Color(23, 23, 30);
   private static final Color u = new Color(18, 18, 24);
   private static final Color v = new Color(255, 100, 100);
   private static final Color w = new Color(115, 83, 255);
   private static final Color x = new Color(70, 46, 174);
   private static final float y = 8.5F;
   private static final float z = 8.0F;
   private static final float A = 24.0F;
   private static final float B = 16.0F;
   private static final float C = 5.0F;
   private static final float D = 8.0F;
   private static final float E = 2.5F;
   private static final float F = 12.0F;
   private static final float G = 2.0F;
   private static final float H = 12.0F;
   private static final float I = 6.0F;
   private static final float J = 6.5F;
   private static final float K = 0.5F;
   private static final float L = 112.0F;
   private static final int M = 200;
   private static final double N = 0.20000000236176813;
   private static final long O = 1000L;
   private static final float P = 6.0F;
   private static final float Q = 1.0F;
   private final Map<RegistryEntry<StatusEffect>, PotionsComponent.AnimatedEffectData> R = new LinkedHashMap<>();
   private final List<PotionsComponent.DemoEffectData> S = new ArrayList<>();
   private final Animation T = new Animation();
   private final Animation U = new Animation();
   private final Animation V = new Animation();
   private final Map<String, PotionsComponent.AnimatedDebuffData> W = new LinkedHashMap<>();
   private final Animation X = new Animation();
   private long Y = 0L;
   private int Z = 0;
   private boolean aa = false;
   private boolean ab = false;
   private boolean ac = false;
   private boolean ad = false;
   private final Map<String, String> ae = new HashMap<>();

   public PotionsComponent(float var1, float var2) {
      super(var1, var2);
      this.V.d(0.0);
      this.w();
      this.a();
   }

   private void v() {
      if (!this.ac) {
         PotionsModule var1 = ModuleRegistry.at;
         if (var1 != null) {
            this.f().a(var1);
            this.ac = true;
         }
      }
   }

   private void w() {
      this.S.add(new PotionsComponent.DemoEffectData(StatusEffects.SPEED, "Speed I", "0:00"));
      this.S.add(new PotionsComponent.DemoEffectData(StatusEffects.STRENGTH, "Strength I", "0:00"));
      this.S.add(new PotionsComponent.DemoEffectData(StatusEffects.FIRE_RESISTANCE, "Fire Resistance I", "0:00"));
   }

   private boolean a(List<PotionsComponent.EffectData> var1) {
      return this.a.currentScreen instanceof ChatScreen && var1.isEmpty();
   }

   @Override
   protected void a() {
      this.v();
      List<PotionsComponent.EffectData> var1 = this.y();
      boolean var2 = this.a(var1);
      this.ad = var2;
      float var3 = this.g();
      float var4 = 8.5F * var3;
      float var5 = 24.0F * var3;
      float var6 = 5.0F * var3;
      float var7 = 8.0F * var3;
      float var8 = 2.5F * var3;
      float var9 = 12.0F * var3;
      float var10 = 2.0F * var3;
      float var11 = 6.5F * var3;
      float var12 = 0.5F * var3;
      float var13 = 112.0F * var3;
      int var14 = Math.round(15.0F * var3);
      int var15 = Math.round(14.0F * var3);
      FontRenderer var16 = Fonts.a[Math.max(10, Math.min(48, var14))];
      FontRenderer var17 = Fonts.a[Math.max(10, Math.min(48, var15))];
      if (var2) {
         long var18 = System.currentTimeMillis();
         if (var18 - this.Y >= 1000L) {
            this.Z = (this.Z + 1) % this.S.size();
            this.Y = var18;
         }
      }

      HashSet var37 = new HashSet<>();

      for (PotionsComponent.EffectData var20 : var1) {
         var37.add(var20.a);
      }

      for (PotionsComponent.AnimatedEffectData var40 : this.R.values()) {
         if (!var37.contains(var40.a) && !var40.g) {
            var40.g = true;
            var40.e.a(0.0, 0.20000000236176813, Easings.h);
         }
      }

      int var39 = 0;

      for (PotionsComponent.EffectData var21 : var1) {
         PotionsComponent.AnimatedEffectData var22 = this.R.get(var21.a);
         if (var22 == null) {
            var22 = new PotionsComponent.AnimatedEffectData(var21.a, var21.b, var21.c, var21.d);
            var22.e.d(0.0);
            var22.e.a(1.0, 0.20000000236176813, Easings.h);
            var22.f.d(var39);
            this.R.put(var21.a, var22);
         } else {
            var22.b = var21.b;
            var22.c = var21.c;
            var22.d = var21.d;
            var22.g = false;
            if (var22.e.i() < 1.0) {
               var22.e.a(1.0, 0.20000000236176813, Easings.h);
            }

            if (Math.abs(var22.f.i() - var39) > 0.010000004227345613) {
               var22.f.a(var39, 0.20000000236176813, Easings.h);
            }
         }

         var39++;
      }

      this.R.entrySet().removeIf(var0 -> var0.getValue().g && var0.getValue().e.j() < 0.010000004227345613);

      for (PotionsComponent.AnimatedEffectData var44 : this.R.values()) {
         var44.e.a();
         var44.f.a();
      }

      boolean var43 = ModuleRegistry.at != null && ModuleRegistry.at.n().q();
      List<PotionsComponent.DebuffData> var45 = var43 ? this.x() : Collections.emptyList();
      HashSet var47 = new HashSet<>();

      for (PotionsComponent.DebuffData var24 : var45) {
         var47.add(var24.a);
      }

      for (PotionsComponent.AnimatedDebuffData var50 : this.W.values()) {
         if (!var47.contains(var50.a) && !var50.j) {
            var50.j = true;
            var50.h.a(0.0, 0.20000000236176813, Easings.h);
         }
      }

      int var49 = 0;

      for (PotionsComponent.DebuffData var25 : var45) {
         PotionsComponent.AnimatedDebuffData var26 = this.W.get(var25.a);
         if (var26 == null) {
            var26 = new PotionsComponent.AnimatedDebuffData(var25.a, var25.b, var25.c, var25.d, var25.e, var25.f, var25.g);
            var26.h.d(0.0);
            var26.h.a(1.0, 0.20000000236176813, Easings.h);
            var26.i.d(var49);
            this.W.put(var25.a, var26);
         } else {
            var26.b = var25.b;
            var26.c = var25.c;
            var26.d = var25.d;
            var26.e = var25.e;
            var26.f = var25.f;
            var26.g = var25.g;
            var26.j = false;
            if (var26.h.i() < 1.0) {
               var26.h.a(1.0, 0.20000000236176813, Easings.h);
            }

            if (Math.abs(var26.i.i() - var49) > 0.010000004227345613) {
               var26.i.a(var49, 0.20000000236176813, Easings.h);
            }
         }

         var49++;
      }

      this.W.entrySet().removeIf(var0 -> var0.getValue().j && var0.getValue().h.j() < 0.010000004227345613);

      for (PotionsComponent.AnimatedDebuffData var54 : this.W.values()) {
         var54.h.a();
         var54.i.a();
      }

      int var53 = 0;

      for (PotionsComponent.AnimatedDebuffData var58 : this.W.values()) {
         if (!var58.j) {
            var53++;
         }
      }

      boolean var56 = var53 > 0;
      if (var56 && this.X.i() < 1.0) {
         this.X.a(1.0, 0.20000000236176813, Easings.h);
      } else if (!var56 && this.X.i() > 0.0) {
         this.X.a(0.0, 0.20000000236176813, Easings.h);
      }

      this.X.a();
      boolean var59 = this.ab;
      this.ab = false;
      int var27 = 0;
      if (var2) {
         this.ab = true;
         var27 = 1;
      } else {
         for (PotionsComponent.AnimatedEffectData var29 : this.R.values()) {
            if (!var29.g) {
               this.ab = true;
               var27++;
            }
         }
      }

      if (this.ab && !var59) {
         this.V.a(1.0, 0.20000000236176813, Easings.h);
      } else if (!this.ab && var59) {
         this.V.a(0.0, 0.20000000236176813, Easings.h);
      } else if (this.ab && this.V.i() < 1.0) {
         this.V.a(1.0, 0.20000000236176813, Easings.h);
      }

      this.V.a();
      float var60 = 0.0F;
      if (var2) {
         PotionsComponent.DemoEffectData var61 = this.S.get(this.Z);
         float var30 = var16.a(var61.b);
         float var31 = var17.a(var61.c) + var11 * 2.0F + var12 * 2.0F;
         var60 = var7 + var8 + var30 + var8 * 2.0F + var31;
      } else {
         for (PotionsComponent.AnimatedEffectData var65 : this.R.values()) {
            if (!var65.g) {
               float var68 = var16.a(var65.b);
               float var32 = var17.a(var65.c) + var11 * 2.0F + var12 * 2.0F;
               float var33 = var7 + var8 + var68 + var8 * 2.0F + var32;
               var60 = Math.max(var60, var33);
            }
         }
      }

      for (PotionsComponent.AnimatedDebuffData var66 : this.W.values()) {
         if (!var66.j) {
            float var69 = var16.a(var66.a);
            float var71 = var17.a(var66.b) + var11 * 2.0F + var12 * 2.0F;
            float var73 = var7 + var8 + var69 + var8 * 2.0F + var71;
            var60 = Math.max(var60, var73);
         }
      }

      float var64 = Math.max(var13, var60);
      float var67 = var4 * 2.0F + var64;
      float var70 = 1.0F * var3;
      float var72 = var27 == 0 ? 0.0F : var27 * var9 + (var27 - 1) * var10;
      float var74 = 0.0F;
      if (var53 > 0) {
         float var34 = 6.0F * var3;
         float var35 = 1.0F * var3;
         float var36 = var53 * var9 + (var53 - 1) * var10;
         var74 = var34 + var35 + var34 + var36;
      }

      float var75 = var5 + var70 + var6 + var72 + var74 + var6 + 2.0F * var3;
      if (!this.aa) {
         this.U.d(var67);
         this.T.d(var75);
         this.aa = true;
      } else {
         if (Math.abs(this.U.i() - var67) > 0.5) {
            this.U.a(var67, 0.20000000236176813, Easings.h);
         }

         if (Math.abs(this.T.i() - var75) > 0.5) {
            this.T.a(var75, 0.20000000236176813, Easings.h);
         }
      }

      this.U.a();
      this.T.a();
      this.d = (float)this.U.j();
      this.e = (float)this.T.j();
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (this.a.player != null) {
         this.a();
         float var5 = (float)this.V.j();
         if (!(var5 < 0.01F)) {
            boolean var6 = this.ad;
            float var7 = this.g();
            float var8 = 8.5F * var7;
            float var9 = 8.0F * var7;
            float var10 = 24.0F * var7;
            float var11 = 16.0F * var7;
            float var12 = 5.0F * var7;
            float var13 = 12.0F * var7;
            float var14 = 2.0F * var7;
            int var15 = Math.round(16.0F * var7);
            int var16 = Math.round(15.0F * var7);
            int var17 = Math.round(14.0F * var7);
            boolean var18 = var5 < 0.99F;
            if (var18) {
               var2.c(this.b, this.c, this.d, this.e, var1);
            }

            float var19 = var18 ? 1.0F : var5;
            FontRenderer var20 = Fonts.b[Math.max(10, Math.min(48, var15))];
            FontRenderer var21 = Fonts.a[Math.max(10, Math.min(48, var16))];
            FontRenderer var22 = Fonts.a[Math.max(10, Math.min(48, var17))];
            Color var23 = this.a(m, var19);
            Color var24 = this.a(n, var19);
            var2.a(this.b, this.c, this.d, this.e, var9, var23, var23, var24, var24, var1);
            float var25 = this.b + var8;
            float var26 = this.c + var10 / 2.0F;
            int var27 = Math.round(22.0F * var7);
            FontRenderer var28 = Fonts.d[Math.max(12, Math.min(48, var27))];
            float var29 = var28.a("\ue91d");
            float var30 = var28.b("\ue91d");
            float var31 = var25 + (var11 - var29) / 2.0F - 4.0F;
            float var32 = var26 - var30 / 4.0F + 0.5F;
            var28.a("\ue91d", var31, var32, this.a(w, var19), this.a(x, var19), var1);
            float var33 = var26 - var20.b("Potions") / 4.0F + 1.0F * var7;
            var20.a("Potions", var25 + var11 - 2.0F * var7, var33, this.a(o, var19), var1);
            float var34 = this.c + var10;
            var2.a(this.b, var34, this.d, 1.0F * var7, 0.0F, this.a(q, var19), var1);
            float var35 = var34 + 1.0F * var7;
            float var36 = this.e - var10 - 1.0F * var7;
            var2.a().a(this.b, var35, this.d, var36, 0.0F, var1);
            float var37 = var34 + 1.0F * var7 + var12;
            int var38 = 0;
            if (var6) {
               var38 = 1;
            } else {
               for (PotionsComponent.AnimatedEffectData var40 : this.R.values()) {
                  if (!var40.g) {
                     var38++;
                  }
               }
            }

            if (var6) {
               PotionsComponent.DemoEffectData var53 = this.S.get(this.Z);
               this.a(var1, var2, var21, var22, var25, var37, var53, var19, var7);
            } else {
               for (PotionsComponent.AnimatedEffectData var56 : this.R.values()) {
                  float var41 = (float)var56.e.j();
                  float var42 = var18 ? var41 : var41 * var5;
                  if (!(var42 < 0.01F)) {
                     float var43 = (float)var56.f.j();
                     float var44 = var37 + var43 * (var13 + var14);
                     this.a(var1, var2, var21, var22, var25, var44, var56, var42, var7);
                  }
               }
            }

            float var55 = (float)this.X.j();
            if (var55 > 0.01F && !var6) {
               float var57 = 6.0F * var7;
               float var58 = 1.0F * var7;
               float var59 = var37 + var38 * (var13 + var14);
               if (var38 > 0) {
                  var59 -= var14;
               }

               float var60 = var59 + var57;
               float var61 = var55 * (var18 ? 1.0F : var5);
               Color var45 = this.a(q, var61);
               var2.a(this.b, var60, this.d, var58, 0.0F, var45, var1);
               float var46 = var60 + var58 + var57;

               for (PotionsComponent.AnimatedDebuffData var48 : this.W.values()) {
                  float var49 = (float)var48.h.j();
                  float var50 = var49 * var55 * (var18 ? 1.0F : var5);
                  if (!(var50 < 0.01F)) {
                     float var51 = (float)var48.i.j();
                     float var52 = var46 + var51 * (var13 + var14);
                     this.a(var1, var2, var21, var22, var25, var52, var48, var50, var7);
                  }
               }
            }

            var2.a().a(var1);
            if (var18) {
               var2.a(var5, var1);
            }
         }
      }
   }

   private void a(
      MatrixStack var1, Render var2, FontRenderer var3, FontRenderer var4, float var5, float var6, PotionsComponent.DemoEffectData var7, float var8, float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 8.0F * var9;
      float var12 = 2.5F * var9;
      float var13 = 8.5F * var9;
      float var14 = 6.5F * var9;
      float var15 = 0.5F * var9;
      float var16 = 12.0F * var9;
      float var17 = 6.0F * var9;
      float var18 = var6 + var10 / 2.0F;
      Color var19 = this.a(p, var8);
      Color var20 = this.a(Color.WHITE, var8);
      Identifier var21 = this.b(var7.a);
      float var22 = var18 - var11 / 2.0F;
      if (var21 != null) {
         var2.a(var21, var5, var22, var11, var11, var20, var1);
      } else {
         var2.a(var5, var22, var11, var11, 2.0F * var9, var19, var1);
      }

      float var24 = var18 - var3.b(var7.b) / 4.0F;
      var3.a(var7.b, var5 + var11 + var12, var24, var19, var1);
      float var25 = var4.a(var7.c) + var14 * 2.0F + var15 * 2.0F - 2.0F * var9;
      float var26 = this.b + this.d - var13 - var25;
      float var27 = var18 - var16 / 2.0F - var15;
      float var28 = var16 + var15 * 2.0F;
      Color var29 = this.a(t, var8);
      Color var30 = this.a(u, var8);
      Color var31 = this.a(r, var8);
      Color var32 = this.a(s, var8);
      var2.a(var26, var27, var25, var28, var17, var29, var29, var30, var30, var1);
      var2.a(var26 + var15, var27 + var15, var25 - var15 * 2.0F, var16, var17 - var15, var31, var31, var32, var32, var1);
      float var33 = var18 - var4.b(var7.c) / 4.0F;
      float var34 = var26 + (var25 - var4.a(var7.c)) / 2.0F;
      var4.a(var7.c, var34, var33, var19, var1);
      float var35 = var5 + var11 + var12 + var3.a(var7.b) + var12;
      float var36 = var26 - var12;
      if (var36 > var35 + 5.0F * var9) {
         float var37 = var18 - 0.5F * var9;
         Color var38 = this.a(q, var8);
         var2.a(var35, var37, var36 - var35, 1.0F * var9, 0.0F, var38, var1);
      }
   }

   private void a(
      MatrixStack var1,
      Render var2,
      FontRenderer var3,
      FontRenderer var4,
      float var5,
      float var6,
      PotionsComponent.AnimatedEffectData var7,
      float var8,
      float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 8.0F * var9;
      float var12 = 2.5F * var9;
      float var13 = 8.5F * var9;
      float var14 = 6.5F * var9;
      float var15 = 0.5F * var9;
      float var16 = 12.0F * var9;
      float var17 = 6.0F * var9;
      float var18 = var6 + var10 / 2.0F;
      Color var19 = this.a(p, var8);
      Color var20 = this.a(Color.WHITE, var8);
      Identifier var21 = this.b(var7.a);
      float var22 = var18 - var11 / 2.0F;
      if (var21 != null) {
         var2.a(var21, var5, var22, var11, var11, var20, var1);
      } else {
         var2.a(var5, var22, var11, var11, 2.0F * var9, var19, var1);
      }

      float var24 = var18 - var3.b(var7.b) / 4.0F;
      var3.a(var7.b, var5 + var11 + var12, var24, var19, var1);
      float var25 = var4.a(var7.c) + var14 * 2.0F + var15 * 2.0F - 2.0F * var9;
      float var26 = this.b + this.d - var13 - var25;
      float var27 = var18 - var16 / 2.0F - var15;
      float var28 = var16 + var15 * 2.0F;
      Color var29 = this.a(t, var8);
      Color var30 = this.a(u, var8);
      Color var31 = this.a(r, var8);
      Color var32 = this.a(s, var8);
      var2.a(var26, var27, var25, var28, var17, var29, var29, var30, var30, var1);
      var2.a(var26 + var15, var27 + var15, var25 - var15 * 2.0F, var16, var17 - var15, var31, var31, var32, var32, var1);
      Color var33;
      if (var7.d > 0 && var7.d <= 200) {
         float var34 = (float)(Math.sin(System.currentTimeMillis() / 150.0) * 0.5 + 0.5);
         var33 = this.a(p, v, var34);
         var33 = this.a(var33, var8);
      } else {
         var33 = var19;
      }

      float var41 = var18 - var4.b(var7.c) / 4.0F;
      float var35 = var26 + (var25 - var4.a(var7.c)) / 2.0F;
      var4.a(var7.c, var35, var41, var33, var1);
      float var36 = var5 + var11 + var12 + var3.a(var7.b) + var12;
      float var37 = var26 - var12;
      if (var37 > var36 + 5.0F * var9) {
         float var38 = var18 - 0.5F * var9;
         Color var39 = this.a(q, var8);
         var2.a(var36, var38, var37 - var36, 1.0F * var9, 0.0F, var39, var1);
      }
   }

   private void a(
      MatrixStack var1,
      Render var2,
      FontRenderer var3,
      FontRenderer var4,
      float var5,
      float var6,
      PotionsComponent.AnimatedDebuffData var7,
      float var8,
      float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 8.0F * var9;
      float var12 = 2.5F * var9;
      float var13 = 8.5F * var9;
      float var14 = 6.5F * var9;
      float var15 = 0.5F * var9;
      float var16 = 12.0F * var9;
      float var17 = 6.0F * var9;
      float var18 = var6 + var10 / 2.0F;
      Color var19 = this.a(p, var8);
      Color var20 = this.a(Color.WHITE, var8);
      float var21 = var18 - var11 / 2.0F;
      if (var7.f && var7.d != null) {
         Identifier var22 = this.b(var7.d);
         if (var22 != null) {
            var2.a(var22, var5, var21, var11, var11, var20, var1);
         } else {
            var2.a(var5, var21, var11, var11, 2.0F * var9, var19, var1);
         }
      } else if (var7.e != null) {
         this.a(var1, new ItemStack(var7.e), var5, var21, var11, var8);
      } else {
         var2.a(var5, var21, var11, var11, 2.0F * var9, var19, var1);
      }

      float var23 = var18 - var3.b(var7.a) / 4.0F;
      var3.a(var7.a, var5 + var11 + var12, var23, var19, var1);
      float var24 = var4.a(var7.b) + var14 * 2.0F + var15 * 2.0F - 2.0F * var9;
      float var25 = this.b + this.d - var13 - var24;
      float var26 = var18 - var16 / 2.0F - var15;
      float var27 = var16 + var15 * 2.0F;
      Color var28 = this.a(t, var8);
      Color var29 = this.a(u, var8);
      Color var30 = this.a(r, var8);
      Color var31 = this.a(s, var8);
      var2.a(var25, var26, var24, var27, var17, var28, var28, var29, var29, var1);
      var2.a(var25 + var15, var26 + var15, var24 - var15 * 2.0F, var16, var17 - var15, var30, var30, var31, var31, var1);
      Color var32;
      if (var7.c > 0 && var7.c <= 200) {
         float var33 = (float)(Math.sin(System.currentTimeMillis() / 150.0) * 0.5 + 0.5);
         var32 = this.a(p, v, var33);
         var32 = this.a(var32, var8);
      } else {
         var32 = var19;
      }

      float var40 = var18 - var4.b(var7.b) / 4.0F;
      float var34 = var25 + (var24 - var4.a(var7.b)) / 2.0F;
      var4.a(var7.b, var34, var40, var32, var1);
      float var35 = var5 + var11 + var12 + var3.a(var7.a) + var12;
      float var36 = var25 - var12;
      if (var36 > var35 + 5.0F * var9) {
         float var37 = var18 - 0.5F * var9;
         Color var38 = this.a(q, var8);
         var2.a(var35, var37, var36 - var35, 1.0F * var9, 0.0F, var38, var1);
      }
   }

   private void a(MatrixStack var1, ItemStack var2, float var3, float var4, float var5, float var6) {
      if (!(var6 < 0.01F)) {
         HudItemDrawer.b(var2, var3, var4, var5);
      }
   }

   private Color a(Color var1, float var2) {
      int var3 = Math.max(0, Math.min(255, (int)(var1.getAlpha() * var2)));
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var3);
   }

   private Color a(Color var1, Color var2, float var3) {
      var3 = Math.max(0.0F, Math.min(1.0F, var3));
      int var4 = (int)(var1.getRed() + (var2.getRed() - var1.getRed()) * var3);
      int var5 = (int)(var1.getGreen() + (var2.getGreen() - var1.getGreen()) * var3);
      int var6 = (int)(var1.getBlue() + (var2.getBlue() - var1.getBlue()) * var3);
      int var7 = (int)(var1.getAlpha() + (var2.getAlpha() - var1.getAlpha()) * var3);
      return new Color(var4, var5, var6, var7);
   }

   private List<PotionsComponent.DebuffData> x() {
      ArrayList<PotionsComponent.DebuffData> var1 = new ArrayList<>();
      DebuffTimeHandler var2 = HandlerRegistry.h;
      if (var2 == null) {
         return var1;
      } else {
         for (DebuffTimeHandler.ActiveDebuff var4 : var2.g()) {
            String var5 = this.c(var4.e());
            var1.add(new PotionsComponent.DebuffData(var4.a(), var5, var4.e(), var4.c(), var4.b(), var4.d(), var4.h()));
         }

         return var1;
      }
   }

   private List<PotionsComponent.EffectData> y() {
      ArrayList<PotionsComponent.EffectData> var1 = new ArrayList<>();
      if (this.a.player == null) {
         return var1;
      } else {
         var var2 = this.a.player.getActiveStatusEffects();

         for (Entry var4 : var2.entrySet()) {
            RegistryEntry var5 = (RegistryEntry)var4.getKey();
            StatusEffectInstance var6 = (StatusEffectInstance)var4.getValue();
            int var7 = var6.getAmplifier();
            String var8 = this.a(var5, var7);
            int var9 = var6.getDuration();
            String var10 = this.c(var9);
            var1.add(new PotionsComponent.EffectData(var5, var8, var10, var9));
         }

         var1.sort(Comparator.comparingInt(var0 -> var0.d));
         return var1;
      }
   }

   private String a(RegistryEntry<StatusEffect> var1, int var2) {
      String var3 = ((StatusEffect)var1.value()).getTranslationKey();
      String var4 = var3 + " " + var2;
      String var5 = this.ae.get(var4);
      if (var5 != null) {
         return var5;
      } else {
         String var6 = this.a(var1) + " " + this.b(var2 + 1);
         this.ae.put(var4, var6);
         return var6;
      }
   }

   private String a(RegistryEntry<StatusEffect> var1) {
      String var2 = ((StatusEffect)var1.value()).getTranslationKey();
      String[] var3 = var2.split("\\.");
      if (var3.length > 0) {
         String var4 = var3[var3.length - 1];
         return this.a(var4);
      } else {
         return "Unknown";
      }
   }

   private String a(String var1) {
      StringBuilder var2 = new StringBuilder();
      String[] var3 = var1.split("_");

      for (String var7 : var3) {
         if (!var7.isEmpty()) {
            var2.append(Character.toUpperCase(var7.charAt(0))).append(var7.substring(1).toLowerCase()).append(" ");
         }
      }

      return var2.toString().trim();
   }

   private String b(int var1) {
      if (var1 > 0 && var1 <= 10) {
         String[] var2 = new String[]{"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
         return var2[var1 - 1];
      } else {
         return String.valueOf(var1);
      }
   }

   private String c(int var1) {
      if (var1 != -1 && var1 <= 12000) {
         int var2 = var1 / 20;
         int var3 = var2 / 60;
         var2 %= 60;
         return String.format("%d:%02d", var3, var2);
      } else {
         return "   ∞   ";
      }
   }

   private Identifier b(RegistryEntry<StatusEffect> var1) {
      String var2 = this.c(var1);
      return var2 != null ? TextureRegistry.a(var2) : null;
   }

   private String c(RegistryEntry<StatusEffect> var1) {
      if (var1.equals(StatusEffects.ABSORPTION)) {
         return "absorption";
      } else if (var1.equals(StatusEffects.BAD_OMEN)) {
         return "bad_omen";
      } else if (var1.equals(StatusEffects.BLINDNESS)) {
         return "blindness";
      } else if (var1.equals(StatusEffects.CONDUIT_POWER)) {
         return "conduit_power";
      } else if (var1.equals(StatusEffects.DOLPHINS_GRACE)) {
         return "dolphins_grace";
      } else if (var1.equals(StatusEffects.FIRE_RESISTANCE)) {
         return "fire_resistance";
      } else if (var1.equals(StatusEffects.GLOWING)) {
         return "glowing";
      } else if (var1.equals(StatusEffects.HASTE)) {
         return "haste";
      } else if (var1.equals(StatusEffects.HEALTH_BOOST)) {
         return "health_boost";
      } else if (var1.equals(StatusEffects.HERO_OF_THE_VILLAGE)) {
         return "hero_of_the_village";
      } else if (var1.equals(StatusEffects.HUNGER)) {
         return "hunger";
      } else if (var1.equals(StatusEffects.INSTANT_DAMAGE)) {
         return "instant_damage";
      } else if (var1.equals(StatusEffects.INSTANT_HEALTH)) {
         return "instant_health";
      } else if (var1.equals(StatusEffects.INVISIBILITY)) {
         return "invisibility";
      } else if (var1.equals(StatusEffects.JUMP_BOOST)) {
         return "jump_boost";
      } else if (var1.equals(StatusEffects.LEVITATION)) {
         return "levitation";
      } else if (var1.equals(StatusEffects.LUCK)) {
         return "luck";
      } else if (var1.equals(StatusEffects.MINING_FATIGUE)) {
         return "mining_fatigue";
      } else if (var1.equals(StatusEffects.NAUSEA)) {
         return "nausea";
      } else if (var1.equals(StatusEffects.NIGHT_VISION)) {
         return "night_vision";
      } else if (var1.equals(StatusEffects.POISON)) {
         return "poison";
      } else if (var1.equals(StatusEffects.REGENERATION)) {
         return "regeneration";
      } else if (var1.equals(StatusEffects.RESISTANCE)) {
         return "resistance";
      } else if (var1.equals(StatusEffects.SATURATION)) {
         return "saturation";
      } else if (var1.equals(StatusEffects.SLOW_FALLING)) {
         return "slow_falling";
      } else if (var1.equals(StatusEffects.SLOWNESS)) {
         return "slowness";
      } else if (var1.equals(StatusEffects.SPEED)) {
         return "speed";
      } else if (var1.equals(StatusEffects.STRENGTH)) {
         return "strength";
      } else if (var1.equals(StatusEffects.UNLUCK)) {
         return "unluck";
      } else if (var1.equals(StatusEffects.WATER_BREATHING)) {
         return "water_breathing";
      } else if (var1.equals(StatusEffects.WEAKNESS)) {
         return "weakness";
      } else {
         return var1.equals(StatusEffects.WITHER) ? "wither" : null;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class AnimatedDebuffData {
      final String a;
      String b;
      int c;
      RegistryEntry<StatusEffect> d;
      Item e;
      boolean f;
      boolean g;
      final Animation h = new Animation();
      final Animation i = new Animation();
      boolean j = false;

      AnimatedDebuffData(String var1, String var2, int var3, RegistryEntry<StatusEffect> var4, Item var5, boolean var6, boolean var7) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
         this.f = var6;
         this.g = var7;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class AnimatedEffectData {
      final RegistryEntry<StatusEffect> a;
      String b;
      String c;
      int d;
      final Animation e = new Animation();
      final Animation f = new Animation();
      boolean g = false;

      AnimatedEffectData(RegistryEntry<StatusEffect> var1, String var2, String var3, int var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class DebuffData {
      final String a;
      final String b;
      final int c;
      final RegistryEntry<StatusEffect> d;
      final Item e;
      final boolean f;
      final boolean g;

      DebuffData(String var1, String var2, int var3, RegistryEntry<StatusEffect> var4, Item var5, boolean var6, boolean var7) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
         this.f = var6;
         this.g = var7;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class DemoEffectData {
      final RegistryEntry<StatusEffect> a;
      final String b;
      final String c;

      DemoEffectData(RegistryEntry<StatusEffect> var1, String var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class EffectData {
      final RegistryEntry<StatusEffect> a;
      final String b;
      final String c;
      final int d;

      EffectData(RegistryEntry<StatusEffect> var1, String var2, String var3, int var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }
}
