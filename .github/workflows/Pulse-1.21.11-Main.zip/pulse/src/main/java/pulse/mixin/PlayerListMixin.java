package pulse.mixin;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket.Action;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket.Entry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.PlayerJoinEvent;
import pulse.core.event.impl.PlayerLeaveEvent;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayNetworkHandler.class})
public class PlayerListMixin {
   @Unique
   private static final ConcurrentHashMap<UUID, String> uuidToNameCache = new ConcurrentHashMap<>();

   @Inject(
      method = {"onPlayerList"},
      at = {@At("HEAD")}
   )
   private void onPlayerListUpdate(PlayerListS2CPacket var1, CallbackInfo var2) {
      for (Entry var4 : var1.getEntries()) {
         UUID var5 = var4.profileId();
         if (var1.getActions().contains(Action.ADD_PLAYER) && var4.profile() != null && var4.profile().name() != null) {
            String var6 = var4.profile().name();
            if (!uuidToNameCache.containsKey(var5)) {
               uuidToNameCache.put(var5, var6);
               EventHandler.a.post(new PlayerJoinEvent(var6, var5));
            }
         }

         if (var1.getActions().contains(Action.UPDATE_LISTED) && !var4.listed()) {
            String var7 = uuidToNameCache.get(var5);
            if (var7 != null) {
               EventHandler.a.post(new PlayerLeaveEvent(var7, var5));
               uuidToNameCache.remove(var5);
            } else {
               EventHandler.a.post(new PlayerLeaveEvent("", var5));
            }
         }
      }
   }

   @Inject(
      method = {"onGameJoin"},
      at = {@At("HEAD")}
   )
   private void onGameJoinClear(CallbackInfo var1) {
      uuidToNameCache.clear();
   }
}
