package pulse.features.modules.utilities;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import org.lwjgl.glfw.GLFW;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Shulker Preview",
   b = "Показывает содержимое шалкер-бокса при наведении",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ShulkerPreviewModule extends Module {
   private static final int a = 3;
   private static final int b = 9;
   private static final int c = 18;
   private final BooleanSetting f = new BooleanSetting("Только с Shift", true);
   private final BooleanSetting g = new BooleanSetting("Показывать название", true);
   private final NumberSetting h = new NumberSetting("Смещение X", 12.0F, -120.0F, 120.0F, 1.0F);
   private final NumberSetting i = new NumberSetting("Смещение Y", -12.0F, -120.0F, 120.0F, 1.0F);
   private final BooleanSetting j = new BooleanSetting("Показывать в мире", true);

   public static boolean a(ItemStack var0) {
      return !var0.isEmpty() && var0.getItem() instanceof BlockItem && ((BlockItem)var0.getItem()).getBlock() instanceof ShulkerBoxBlock;
   }

   public static DefaultedList<ItemStack> b(ItemStack var0) {
      DefaultedList var1 = DefaultedList.ofSize(27, ItemStack.EMPTY);
      ContainerComponent var2 = var0.get(DataComponentTypes.CONTAINER);
      if (var2 != null) {
         var2.copyTo(var1);
      }

      return var1;
   }

   public static boolean c(ItemStack var0) {
      for (ItemStack var3 : b(var0)) {
         if (!var3.isEmpty()) {
            return true;
         }
      }

      return false;
   }

   public boolean n() {
      return this.j.a();
   }

   public boolean d(ItemStack var1) {
      return this.k() && a(var1) && (!this.f.a() || o());
   }

   private static boolean o() {
      long var0 = MinecraftClient.getInstance().getWindow().getHandle();
      return GLFW.glfwGetKey(var0, 340) == 1 || GLFW.glfwGetKey(var0, 344) == 1;
   }

   public void a(DrawContext var1, ItemStack var2, int var3, int var4) {
      if (this.d(var2)) {
         DefaultedList var5 = b(var2);
         byte var6 = 7;
         int var7 = this.g.a() ? 11 : 0;
         int var8 = var6 * 2 + 162;
         int var9 = var6 + var7 + 54 + var6;
         Screen var10 = d.currentScreen;
         if (var10 != null) {
            int var11 = var10.width;
            int var12 = var10.height;
            int var13 = var3 + this.h.c();
            int var14 = var4 + this.i.c();
            if (var13 + var8 > var11) {
               var13 = var3 - var8 - 4;
            }

            if (var13 < 0) {
               var13 = 0;
            }

            if (var14 + var9 > var12) {
               var14 = var12 - var9;
            }

            if (var14 < 0) {
               var14 = 0;
            }

            var1.fill(var13, var14, var13 + var8, var14 + var9, -267386864);
            if (this.g.a()) {
               String var15 = var2.getName().getString();
               var1.drawText(d.textRenderer, var15, var13 + var6, var14 + var6 - 2, -1, true);
            }

            int var23 = var13 + var6;
            int var16 = var14 + var6 + var7;

            for (int var17 = 0; var17 < 3; var17++) {
               for (int var18 = 0; var18 < 9; var18++) {
                  int var19 = var17 * 9 + var18;
                  int var20 = var23 + var18 * 18;
                  int var21 = var16 + var17 * 18;
                  var1.fill(var20, var21, var20 + 18, var21 + 18, -7631989);
                  var1.fill(var20 + 1, var21 + 1, var20 + 18 - 1, var21 + 18 - 1, -13158601);
                  var1.fill(var20 + 2, var21 + 2, var20 + 18 - 2, var21 + 18 - 2, -7631989);
                  ItemStack var22 = (ItemStack)var5.get(var19);
                  if (!var22.isEmpty()) {
                     var1.drawItem(var22, var20 + 1, var21 + 1);
                     var1.drawStackOverlay(d.textRenderer, var22, var20 + 1, var21 + 1);
                  }
               }
            }
         }
      }
   }
}
