package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.HashMap;
import java.util.Map;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import pulse.core.event.impl.ItemUsedEvent;
import pulse.core.event.impl.RightClickEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Cooldowns",
   b = "Добавляет кастомный кулдаун на зелья исцеления",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class CooldownsModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Преобразовывать задержки", true);
   private final BooleanSetting b = new BooleanSetting("Только в Пвп (Исцеление)", true);
   private final NumberSetting c = new NumberSetting("Размер шрифта таймеров", 1.0F, 0.5F, 2.0F, 0.1F);
   private final Map<Item, Long> f = new HashMap<>();

   @Compile
   @Override
      public void f() {
      this.f.clear();
      super.f();
   }

   @EventHandler
   @Compile
      public void a(ItemUsedEvent var1) {
      if (this.b.q() && !pulse.utils.game.PVPUtils.a().a()) {
         return;
      }
      var stack = var1.d();
      if (a(stack)) {
         var item = stack.getItem();
         long time = System.currentTimeMillis();
         this.f.put(item, time);
      }
   }

   @EventHandler
   @Compile
      public void a(RightClickEvent var1) {
      if (d.player == null) {
         return;
      }
      var stack = var1.d().getStackInHand(var1.f());
      if (a(stack)) {
         var item = stack.getItem();
         long now = System.currentTimeMillis();
         long previous = this.f.getOrDefault(item, 0L);
         if ((double)(now - previous) < 18500.0) {
            var1.b();
         }
      }
   }

   @EventHandler
   @Compile
      public void a(UpdateEvent var1) {
      if (this.b.q() && !pulse.utils.game.PVPUtils.a().a()) {
         this.f.clear();
      }
   }

   public static boolean a(ItemStack var0) {
      if (!(var0.getItem() instanceof PotionItem)) {
         return false;
      } else if (!var0.contains(DataComponentTypes.POTION_CONTENTS)) {
         return false;
      } else {
         PotionContentsComponent var1 = var0.get(DataComponentTypes.POTION_CONTENTS);
         if (var1 == null) {
            return false;
         } else {
            return var1.potion().isPresent()
                  && var1.potion().get().value().getEffects().stream().anyMatch(var0x -> var0x.getEffectType() == StatusEffects.INSTANT_HEALTH)
               ? true
               : var1.customEffects().stream().anyMatch(var0x -> var0x.getEffectType() == StatusEffects.INSTANT_HEALTH);
         }
      }
   }

   private float c(Item var1) {
      long var2 = this.f.getOrDefault(var1, 0L);
      double var4 = 18500.0;
      long var6 = System.currentTimeMillis() - var2;
      if (var6 >= var4) {
         this.f.remove(var1);
         return 0.0F;
      } else {
         return 1.0F - (float)(var6 / var4);
      }
   }

   public float a(Item var1) {
      return this.c(var1);
   }

   public boolean b(Item var1) {
      return this.f.containsKey(var1) && this.a(var1) > 0.0F;
   }

   public boolean n() {
      return this.a.q();
   }

   @Generated
   public BooleanSetting o() {
      return this.a;
   }

   @Generated
   public BooleanSetting p() {
      return this.b;
   }

   @Generated
   public NumberSetting q() {
      return this.c;
   }

   @Generated
   public Map<Item, Long> r() {
      return this.f;
   }

   static {
      NativeMethodLookup.lookup(CooldownsModule.class, 55);
   }
}
