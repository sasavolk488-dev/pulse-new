package pulse.features.resourcepack;

import java.util.Optional;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourcePackPosition;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.resource.ResourcePackProvider;
import net.minecraft.resource.ResourcePackSource;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.ResourcePackProfile.InsertionPosition;
import net.minecraft.resource.ResourcePackProfile.Metadata;
import net.minecraft.resource.ResourcePackProfile.PackFactory;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class PulsePackProvider implements ResourcePackProvider {
   public static final String a = "pulse_rp/";

   @Override
   public void register(Consumer<ResourcePackProfile> profileAdder) {
      for (ResourcePackService.ReadyPack var3 : ResourcePackService.a().b()) {
         try {
            final PpackContainer var4 = var3.container();
            String var5 = "pulse_rp/" + var3.id();
            ResourcePackInfo var6 = new ResourcePackInfo(var5, Text.literal(var3.name()), ResourcePackSource.NONE, Optional.empty());
            ResourcePackPosition var7 = new ResourcePackPosition(false, InsertionPosition.TOP, false);
            PackFactory var8 = new PackFactory() {
               @Override
               public ResourcePack open(ResourcePackInfo info) {
                  return new PulseInMemoryResourcePack(info, var4);
               }

               @Override
               public ResourcePack openWithOverlays(ResourcePackInfo info, Metadata metadata) {
                  return new PulseInMemoryResourcePack(info, var4);
               }
            };
            ResourcePackProfile var9 = ResourcePackProfile.create(var6, var8, ResourceType.CLIENT_RESOURCES, var7);
            if (var9 != null) {
               profileAdder.accept(var9);
            }
         } catch (Exception var10) {
         }
      }
   }
}
