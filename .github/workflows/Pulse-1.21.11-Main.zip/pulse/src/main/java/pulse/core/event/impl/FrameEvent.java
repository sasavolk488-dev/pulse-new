package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class FrameEvent extends Event {
   private final float a;

   public FrameEvent(float var1) {
      this.a = var1;
   }

   @Generated
   public float a() {
      return this.a;
   }
}
