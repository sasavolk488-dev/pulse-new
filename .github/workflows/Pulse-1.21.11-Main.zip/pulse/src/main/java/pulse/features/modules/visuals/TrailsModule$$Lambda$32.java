package pulse.features.modules.visuals;

import java.util.UUID;
import java.util.function.Function;

public final class TrailsModule$$Lambda$32 implements Function {
   @Override
   public Object apply(Object var1) {
      return TrailsModule.a((UUID)var1);
   }
}
