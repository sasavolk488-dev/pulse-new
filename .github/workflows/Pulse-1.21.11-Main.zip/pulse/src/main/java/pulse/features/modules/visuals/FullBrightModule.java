package pulse.features.modules.visuals;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Full Bright",
   b = "Увеличивает яркость",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class FullBrightModule extends Module {
}
