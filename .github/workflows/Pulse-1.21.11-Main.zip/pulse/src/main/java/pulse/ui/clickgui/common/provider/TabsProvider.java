package pulse.ui.clickgui.common.provider;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface TabsProvider {
   String[] c();

   int d();

   void a(int var1);
}
