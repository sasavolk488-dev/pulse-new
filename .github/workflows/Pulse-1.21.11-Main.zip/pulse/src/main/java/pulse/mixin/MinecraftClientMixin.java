package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.NarratorMode;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.CriticalHitEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.core.api.IMinecraft;
import pulse.utils.game.TotemCache;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public abstract class MinecraftClientMixin implements IMinecraft {
   @Unique
   private int pulse$narratorCheck;

   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void onTick(CallbackInfo var1) {
      TotemCache.a();
      if ((++this.pulse$narratorCheck & 63) == 0) {
         this.pulse$forceNarratorOff();
      }
   }

   @Unique
   private void pulse$forceNarratorOff() {
      MinecraftClient var1 = (MinecraftClient)(Object)this;
      if (var1.options != null) {
         boolean var2 = false;
         if (var1.options.getNarrator().getValue() != NarratorMode.OFF) {
            var1.options.getNarrator().setValue(NarratorMode.OFF);
            var2 = true;
         }

         if (var1.options.getNarratorHotkey().getValue()) {
            var1.options.getNarratorHotkey().setValue(false);
            var2 = true;
         }

         if (var2) {
            var1.options.write();
         }
      }
   }

   @Inject(
      method = {"joinWorld"},
      at = {@At("HEAD")}
   )
   private void onJoinWorld(ClientWorld var1, CallbackInfo var2) {
      EventHandler.a.post(new WorldChangeEvent());
   }

   @Inject(
      method = {"doAttack"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V"
      )}
   )
   private void onAttack(CallbackInfoReturnable<Boolean> var1) {
      if (d.targetedEntity != null) {
         EventHandler.a.post(new AttackEvent(d.targetedEntity));
         if (d.targetedEntity instanceof LivingEntity && d.player != null) {
            ClientPlayerEntity var2 = d.player;
            float var3 = var2.getAttackCooldownProgress(0.5F);
            boolean var4 = var3 > 0.9F;
            boolean var5 = var2.getVelocity().y < 0.0;
            boolean var6 = var4
               && var5
               && !var2.isOnGround()
               && !var2.isClimbing()
               && !var2.isTouchingWater()
               && !var2.hasStatusEffect(StatusEffects.BLINDNESS)
               && !var2.hasVehicle()
               && !var2.isSprinting();
            if (var6) {
               EventHandler.a.post(new CriticalHitEvent(d.targetedEntity));
            }
         }
      }
   }
}
