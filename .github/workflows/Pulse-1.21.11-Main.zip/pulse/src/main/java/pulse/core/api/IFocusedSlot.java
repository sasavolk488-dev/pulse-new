package pulse.core.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.screen.slot.Slot;

@Environment(EnvType.CLIENT)
public interface IFocusedSlot {
   Slot pulse$getFocusedSlot();
}
