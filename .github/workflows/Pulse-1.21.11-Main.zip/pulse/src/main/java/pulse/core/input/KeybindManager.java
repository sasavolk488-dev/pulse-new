package pulse.core.input;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;
import pulse.config.cloud.CloudConfigManager;
import pulse.core.api.IMinecraft;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleRegistry;

@Environment(EnvType.CLIENT)
public final class KeybindManager implements IMinecraft {
   private static final KeybindManager a = new KeybindManager();
   private final Map<Integer, String> b = new LinkedHashMap<>();
   private boolean c;
   private static final int f = 4;
   private final List<Integer> g = new ArrayList<>();
   private boolean h;
   private final Map<Integer, Keybind> i = new HashMap<>();
   private final List<Keybind> j = new ArrayList<>();

   public static KeybindManager a() {
      return a;
   }

   private void e() {
      this.h = false;
   }

   @Compile
   private void f() {
      if (this.h) {
         return;
      }
      this.h();
      this.i.clear();
      this.j.clear();
      for (Map.Entry<Integer, String> entry : this.b.entrySet()) {
         Keybind bind = Keybind.b(entry.getKey().intValue(), entry.getValue());
         this.i.put(entry.getKey(), bind);
         this.j.add(bind);
      }
      for (Module module : ModuleRegistry.b()) {
         int key = module.j();
         if (key != -1 && key != 0 && !this.b.containsKey(Integer.valueOf(key))) {
            Keybind bind = Keybind.a(key, module.g());
            this.i.putIfAbsent(Integer.valueOf(key), bind);
            this.j.add(bind);
         }
      }
      this.h = true;
   }

   private KeybindManager() {
   }

   public Keybind a(int var1) {
      if (var1 != 0 && var1 != -1) {
         this.f();
         return this.i.get(var1);
      } else {
         return null;
      }
   }

   public boolean b(int var1) {
      return this.a(var1) != null;
   }

   public List<Keybind> b() {
      this.f();
      return new ArrayList<>(this.j);
   }

   public List<Keybind> c() {
      ArrayList var1 = new ArrayList();

      for (Integer var3 : this.g) {
         Keybind var4 = this.a(var3);
         if (var4 != null) {
            var1.add(var4);
         }

         if (var1.size() >= 4) {
            break;
         }
      }

      return var1;
   }

   public void a(int var1, String var2) {
      if (var1 != 0 && var1 != -1 && var2 != null && !var2.isEmpty()) {
         this.h();
         this.e(var1);
         this.b.put(var1, var2);
         this.f(var1);
         this.e();
         this.i();
         this.j();
      }
   }

   public void b(int var1, String var2) {
      if (var1 != 0 && var1 != -1) {
         Module var3 = ModuleRegistry.a(var2);
         if (var3 != null) {
            this.h();
            this.e(var1);
            var3.a(var1);
            this.f(var1);
            this.e();
            this.i();
         }
      }
   }

   public void c(int var1) {
      this.h();
      this.e(var1);
      this.g.remove(Integer.valueOf(var1));
      this.e();
      this.i();
      this.j();
   }

   public void d() {
      this.h();
      this.b.clear();

      for (Module var2 : ModuleRegistry.b()) {
         if (var2.j() != 0) {
            var2.a(0);
         }
      }

      this.g.clear();
      this.e();
      this.i();
      this.j();
   }

   @Compile
   private void e(int var1) {
      this.b.remove(Integer.valueOf(var1));
      for (Module module : ModuleRegistry.b()) {
         if (module.j() == var1) {
            module.a(0);
         }
      }
   }

   private void f(int var1) {
      this.g.remove(Integer.valueOf(var1));
      this.g.add(0, var1);

      while (this.g.size() > 4) {
         this.g.remove(this.g.size() - 1);
      }
   }

   @Compile
   public void d(int var1) {
      this.h();
      String command = this.b.get(Integer.valueOf(var1));
      if (command == null || command.isEmpty()) return;
      if (d.player == null || d.world == null || d.currentScreen != null) return;
      pulse.core.event.impl.ChatEvent event = new pulse.core.event.impl.ChatEvent("/" + command);
      pulse.core.event.EventHandler.a.post((Object) event);
      if (!event.c()) pulse.utils.game.ChatUtils.a(command);
   }

   private Path g() {
      return d.runDirectory.toPath().resolve("pulse_cache").resolve("keybind_commands.json");
   }

   private void h() {
      if (!this.c) {
         this.c = true;

         try {
            Path var1 = this.g();
            if (Files.exists(var1)) {
               String var2 = new String(Files.readAllBytes(var1), StandardCharsets.UTF_8);
               JsonObject var3 = new JsonParser().parse(var2).getAsJsonObject();
               this.b.clear();

               for (Entry var5 : var3.entrySet()) {
                  try {
                     int var6 = Integer.parseInt((String)var5.getKey());
                     String var7 = ((JsonElement)var5.getValue()).getAsString();
                     if (var7 != null && !var7.isEmpty()) {
                        this.b.put(var6, var7);
                     }
                  } catch (NumberFormatException var8) {
                  }
               }
            }
         } catch (Exception var9) {
            Pulse.m().error("Не удалось прочитать pulse_cache/keybind_commands.json", (Throwable)var9);
         }
      }
   }

   private void i() {
      try {
         Path var1 = this.g();
         Files.createDirectories(var1.getParent());
         JsonObject var2 = new JsonObject();

         for (Entry var4 : this.b.entrySet()) {
            var2.addProperty(String.valueOf(var4.getKey()), (String)var4.getValue());
         }

         Files.write(var1, var2.toString().getBytes(StandardCharsets.UTF_8));
      } catch (Exception var5) {
         Pulse.m().error("Не удалось сохранить pulse_cache/keybind_commands.json", (Throwable)var5);
      }
   }

   private void j() {
      CloudConfigManager.a().h();
   }

   static {
      NativeMethodLookup.lookup(KeybindManager.class, 37);
   }
}
