package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.features.cosmetic.render.CosmeticRenderer;
import pulse.core.event.impl.GameJoinEvent;
import pulse.core.event.impl.GameLeaveEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleRegistry;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class ServerIntegrationHandler extends Handler implements IMinecraft {
   private static final Identifier b = Identifier.of("pulse", "hello");
   private static final Identifier c = Identifier.of("pulse", "policy");
   private static final Identifier f = Identifier.of("pulse", "request");
   private static final Identifier g = Identifier.of("pulse", "ack");
   private static final Pattern h = Pattern.compile("[^a-z0-9_]");
   public static volatile long a = 0L;
   private Set<String> i = new HashSet<>();
   private boolean j = false;
   private final Map<String, Boolean> k = new ConcurrentHashMap<>();
   private final Map<String, String> l = new ConcurrentHashMap<>();
   private volatile long m = 0L;

   @Override
   public void a() {
      super.a();
      Pulse.m().info("Инициализация ServerIntegrationHandler...");

      try {
         PayloadTypeRegistry.playC2S().register(ServerIntegrationHandler.HelloPayload.a, ServerIntegrationHandler.HelloPayload.b);
         PayloadTypeRegistry.playS2C().register(ServerIntegrationHandler.PolicyPayload.a, ServerIntegrationHandler.PolicyPayload.b);
         PayloadTypeRegistry.playS2C().register(ServerIntegrationHandler.RequestPayload.a, ServerIntegrationHandler.RequestPayload.b);
         PayloadTypeRegistry.playC2S().register(ServerIntegrationHandler.AckPayload.a, ServerIntegrationHandler.AckPayload.b);
         ClientPlayNetworking.registerGlobalReceiver(ServerIntegrationHandler.PolicyPayload.a, (var1, var2x) -> {
            String var3 = var1.a();
            Pulse.m().info("Получен POLICY пакет: " + var3);
            var2x.client().execute(() -> {
               try {
                  this.a(new JSONObject(var3));
                  this.f();
               } catch (Exception var3x) {
                  Pulse.m().warn("Ошибка обработки POLICY", (Throwable)var3x);
               }
            });
         });
         ClientPlayNetworking.registerGlobalReceiver(ServerIntegrationHandler.RequestPayload.a, (var1, var2x) -> {
            String var3 = var1.a();
            Pulse.m().info("Получен REQUEST пакет: " + var3);
            var2x.client().execute(() -> {
               try {
                  this.b(new JSONObject(var3));
                  this.f();
               } catch (Exception var3x) {
                  Pulse.m().warn("Ошибка обработки REQUEST", (Throwable)var3x);
               }
            });
         });
         ClientPlayConnectionEvents.DISCONNECT.register((var1, var2x) -> {
            Pulse.m().info("ClientPlayConnectionEvents.DISCONNECT");
            this.h();
            this.i();
            CosmeticRenderer.a().b();
         });
         Pulse.m().info("ServerIntegrationHandler инициализирован успешно");
      } catch (Exception var2) {
         Pulse.m().error("Ошибка инициализации ServerIntegrationHandler", (Throwable)var2);
      }
   }

   @EventHandler
   @Compile
   public void a(GameJoinEvent var1) {
      Pulse.m().info("GameJoinEvent");
      d.execute(this::d);
      new Thread(this::l).start();
   }

   public void d() {
      this.j();
      String var1 = this.k();
      if (var1 != null) {
         RealtimeSyncServiceV2 var2 = RealtimeSyncServiceV2.L();
         Pulse.m().info("Применение ограничений из БД для сервера: {}", var1);

         for (Module var4 : ModuleRegistry.b()) {
            if (!var2.a(var4.g(), var1) && var4.l()) {
               var4.c(false);
               Pulse.m().info("Модуль {} запрещен на сервере {} (БД)", var4.g(), var1);
            }
         }
      }
   }

   @EventHandler
   @Compile
   public void a(GameLeaveEvent var1) {
      Pulse.m().info("GameLeaveEvent");
      this.h();
      this.i();
   }

   private void e() {
      try {
         Pulse.m().info("Попытка отправить HELLO...");
         if (d == null || d.player == null || d.getNetworkHandler() == null) {
            Pulse.m().warn("mc.player == null, отмена отправки HELLO");
            return;
         }

         boolean var1 = ClientPlayNetworking.canSend(ServerIntegrationHandler.HelloPayload.a);
         Pulse.m().info("ClientPlayNetworking.canSend(CH_HELLO): " + var1);
         if (!var1) {
            Pulse.m().warn("Не можем отправить HELLO - канал недоступен");
            return;
         }

         JsonObject var2 = new JsonObject();
         var2.addProperty("mod", "Pulse");
         var2.addProperty("mod_version", "2.0.4");
         var2.addProperty("protocol", 1);
         List<Module> var3 = ModuleRegistry.b();
         JsonArray var4 = new JsonArray();

         for (Module var6 : var3) {
            JsonObject var7 = new JsonObject();
            var7.addProperty("key", this.b(var6.g()));
            var7.addProperty("name", var6.g());
            var7.addProperty("category", var6.i().name().toLowerCase());
            var4.add(var7);
         }

         JsonObject var12 = new JsonObject();
         var12.addProperty("key", "invisibility");
         var12.addProperty("name", "Invisibility");
         var12.addProperty("category", "server");
         var4.add(var12);
         var2.add("features", var4);
         JsonArray var13 = new JsonArray();
         JsonArray var14 = new JsonArray();

         for (Module var9 : var3) {
            String var10 = this.b(var9.g());
            if (var9.k()) {
               var13.add(var10);
            }

            if (var9.a()) {
               var14.add(var10);
            }
         }

         var13.add("invisibility");
         var14.add("invisibility");
         var2.add("enabled", var13);
         var2.add("desired", var14);
         String var15 = var2.toString();
         Pulse.m().info("HELLO JSON: " + var15.substring(0, Math.min(200, var15.length())) + "...");
         a(new ServerIntegrationHandler.HelloPayload(var15));
         Pulse.m().info("HELLO отправлен на сервер с " + var3.size() + " модулями");
      } catch (Exception var11) {
         Pulse.m().error("Ошибка отправки HELLO", (Throwable)var11);
      }
   }

   private void a(JSONObject var1) {
      Pulse.m().info("Получена политика сервера: " + var1.toString());
      this.j();
      this.j = true;
      this.i.clear();
      if (var1.has("deny_list")) {
         JSONArray var2 = var1.getJSONArray("deny_list");

         for (int var3 = 0; var3 < var2.length(); var3++) {
            String var4 = var2.getString(var3);
            this.i.add(var4);
            Pulse.m().info("Функция запрещена сервером: " + var4);
         }
      }

      if (var1.has("allow_list")) {
         JSONArray var7 = var1.getJSONArray("allow_list");
         HashSet var8 = new HashSet<>();

         for (int var9 = 0; var9 < var7.length(); var9++) {
            var8.add(var7.getString(var9));
         }

         for (Module var5 : ModuleRegistry.b()) {
            String var6 = this.b(var5.g());
            if (!var8.contains(var6)) {
               this.i.add(var6);
            }
         }

         if (!var8.contains("invisibility")) {
            this.i.add("invisibility");
         }
      }

      this.g();
   }

   private void b(JSONObject var1) {
      Pulse.m().info("Получен запрос сервера: " + var1.toString());
      this.j();
      if (var1.has("disable")) {
         JSONArray var2 = var1.getJSONArray("disable");

         for (int var3 = 0; var3 < var2.length(); var3++) {
            String var4 = var2.getString(var3);
            this.i.add(var4);
            Pulse.m().info("Отключение по запросу сервера: " + var4);
         }
      }

      if (var1.has("enable")) {
         JSONArray var5 = var1.getJSONArray("enable");

         for (int var6 = 0; var6 < var5.length(); var6++) {
            String var7 = var5.getString(var6);
            this.i.remove(var7);
            Pulse.m().info("Включение по запросу сервера: " + var7);
         }
      }

      this.g();
   }

   private void f() {
      try {
         var var1 = ModuleRegistry.b();
         var var2 = var1.stream().filter(Module::k).map(var1x -> this.b(var1x.g())).collect(Collectors.toList());
         var var3 = var1.stream().filter(var0 -> !var0.k()).map(var1x -> this.b(var1x.g())).collect(Collectors.toList());
         if (!this.i.contains("invisibility")) {
            var2.add("invisibility");
         } else {
            var3.add("invisibility");
         }

         JSONObject var4 = new JSONObject();
         JSONObject var5 = new JSONObject();
         var5.put("enabled", var2);
         var5.put("disabled", var3);
         var4.put("applied", var5);
         a(new ServerIntegrationHandler.AckPayload(var4.toString()));
         Pulse.m().info("ACK отправлен на сервер");
      } catch (Exception var6) {
         Pulse.m().error("Ошибка отправки ACK", (Throwable)var6);
      }
   }

   private void g() {
      Pulse.m().info("Применение серверных ограничений. Запрещено плагином: " + this.i.size());
      this.j();
      String var1 = this.k();
      RealtimeSyncServiceV2 var2 = RealtimeSyncServiceV2.L();

      for (Module var4 : ModuleRegistry.b()) {
         String var5 = this.b(var4.g());
         boolean var6 = var1 != null && var2.a(var4.g(), var1);
         boolean var7 = !this.i.contains(var5);
         if (var6 && var7) {
            if (var4.a() && !var4.l()) {
               var4.c(true);
            }
         } else if (var4.l()) {
            var4.c(false);
            Pulse.m().info("Модуль {} отключен (backend={}, plugin={})", var4.g(), var6, var7);
         }
      }
   }

   private void h() {
      this.j();
      this.i.clear();
      this.j = false;
      Pulse.m().info("Серверный контроль отключен");
   }

   private void i() {
      for (Module var2 : ModuleRegistry.b()) {
         var2.c();
      }
   }

   private String b(String var1) {
      String var2 = this.l.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         String var3 = h.matcher(var1.toLowerCase().replace(" ", "_").replace("-", "_")).replaceAll("");
         this.l.put(var1, var3);
         return var3;
      }
   }

   public boolean a(String var1) {
      long var2 = System.currentTimeMillis();
      if (var2 - this.m > 1000L) {
         this.k.clear();
         this.m = var2;
      }

      Boolean var4 = this.k.get(var1);
      if (var4 != null) {
         return var4;
      } else {
         String var5 = this.k();
         boolean var6 = this.a(var1, var5);
         if (var5 != null) {
            this.k.put(var1, var6);
         }

         return var6;
      }
   }

   private boolean a(String var1, String var2) {
      if (!RealtimeSyncServiceV2.L().a(var1, var2)) {
         return false;
      } else if (!this.j) {
         return true;
      } else {
         String var3 = this.b(var1);
         return !this.i.contains(var3);
      }
   }

   private void j() {
      this.k.clear();
      this.m = System.currentTimeMillis();
      a++;
   }

   private String k() {
      return d != null && d.getCurrentServerEntry() != null ? d.getCurrentServerEntry().address : null;
   }

   private static void a(CustomPayload var0) {
      try {
         ClientPlayNetworking.send(var0);
      } catch (Exception var2) {
         Pulse.m().error("Ошибка отправки пакета", (Throwable)var2);
      }
   }

   public void l() {
      try {
         Thread.sleep(3000L);
      } catch (InterruptedException var2) {
      }

      d.execute(this::e);
   }

   static {
      NativeMethodLookup.lookup(ServerIntegrationHandler.class, 31);
   }

   @Environment(EnvType.CLIENT)
   public static class AckPayload implements CustomPayload {
      public static final Id<ServerIntegrationHandler.AckPayload> a = new Id<>(ServerIntegrationHandler.g);
      public static final PacketCodec<RegistryByteBuf, ServerIntegrationHandler.AckPayload> b = PacketCodec.of((var0, var1) -> {
         byte[] var2 = var0.c.getBytes(StandardCharsets.UTF_8);
         var1.writeBytes(var2);
      }, var0 -> {
         byte[] var1 = new byte[var0.readableBytes()];
         var0.readBytes(var1);
         return new ServerIntegrationHandler.AckPayload(new String(var1, StandardCharsets.UTF_8));
      });
      private final String c;

      public AckPayload(String var1) {
         this.c = var1;
      }

      public String a() {
         return this.c;
      }

      @Override
      public Id<? extends CustomPayload> getId() {
         return a;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class HelloPayload implements CustomPayload {
      public static final Id<ServerIntegrationHandler.HelloPayload> a = new Id<>(ServerIntegrationHandler.b);
      public static final PacketCodec<RegistryByteBuf, ServerIntegrationHandler.HelloPayload> b = PacketCodec.of((var0, var1) -> {
         byte[] var2 = var0.c.getBytes(StandardCharsets.UTF_8);
         var1.writeBytes(var2);
      }, var0 -> {
         byte[] var1 = new byte[var0.readableBytes()];
         var0.readBytes(var1);
         return new ServerIntegrationHandler.HelloPayload(new String(var1, StandardCharsets.UTF_8));
      });
      private final String c;

      public HelloPayload(String var1) {
         this.c = var1;
      }

      public String a() {
         return this.c;
      }

      @Override
      public Id<? extends CustomPayload> getId() {
         return a;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class PolicyPayload implements CustomPayload {
      public static final Id<ServerIntegrationHandler.PolicyPayload> a = new Id<>(ServerIntegrationHandler.c);
      public static final PacketCodec<RegistryByteBuf, ServerIntegrationHandler.PolicyPayload> b = PacketCodec.of((var0, var1) -> {
         byte[] var2 = var0.c.getBytes(StandardCharsets.UTF_8);
         var1.writeBytes(var2);
      }, var0 -> {
         byte[] var1 = new byte[var0.readableBytes()];
         var0.readBytes(var1);
         return new ServerIntegrationHandler.PolicyPayload(new String(var1, StandardCharsets.UTF_8));
      });
      private final String c;

      public PolicyPayload(String var1) {
         this.c = var1;
      }

      public String a() {
         return this.c;
      }

      @Override
      public Id<? extends CustomPayload> getId() {
         return a;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class RequestPayload implements CustomPayload {
      public static final Id<ServerIntegrationHandler.RequestPayload> a = new Id<>(ServerIntegrationHandler.f);
      public static final PacketCodec<RegistryByteBuf, ServerIntegrationHandler.RequestPayload> b = PacketCodec.of((var0, var1) -> {
         byte[] var2 = var0.c.getBytes(StandardCharsets.UTF_8);
         var1.writeBytes(var2);
      }, var0 -> {
         byte[] var1 = new byte[var0.readableBytes()];
         var0.readBytes(var1);
         return new ServerIntegrationHandler.RequestPayload(new String(var1, StandardCharsets.UTF_8));
      });
      private final String c;

      public RequestPayload(String var1) {
         this.c = var1;
      }

      public String a() {
         return this.c;
      }

      @Override
      public Id<? extends CustomPayload> getId() {
         return a;
      }
   }
}
