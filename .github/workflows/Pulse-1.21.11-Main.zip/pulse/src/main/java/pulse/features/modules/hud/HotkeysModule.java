package pulse.features.modules.hud;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Hotkeys",
   b = "Display hotkey bindings",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class HotkeysModule extends Module {
   private final NumberSetting a = new NumberSetting("Масштаб", 1.0F, 0.8F, 2.0F, 0.1F);

   public HotkeysModule() {
      this.d();
   }

   @Generated
   public NumberSetting n() {
      return this.a;
   }
}
