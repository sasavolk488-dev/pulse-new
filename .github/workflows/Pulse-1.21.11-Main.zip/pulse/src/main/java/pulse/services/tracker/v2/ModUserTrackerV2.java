package pulse.services.tracker.v2;

import java.util.Collection;
import java.util.Collections;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import pulse.Pulse;
import pulse.core.handler.HandlerRegistry;

@Environment(EnvType.CLIENT)
public class ModUserTrackerV2 {
   private final RealtimeSyncServiceV2 a;
   private volatile int b = 0;
   private volatile String c;
   private volatile String d;
   private volatile String e = "";
   private volatile boolean f = false;
   private static volatile ModUserTrackerV2 g;

   private ModUserTrackerV2() {
      this.a = RealtimeSyncServiceV2.L();
   }

   public void a() {
      this.a.I();
      MinecraftClient var1 = MinecraftClient.getInstance();
      String var2 = var1.getSession().getUsername();
      this.c = var2;
      if (var2 != null && !var2.isEmpty()) {
         Pulse.m().info("Current minecraft nick: {}", var2);
         this.a.b(var2);
      }

      String var3 = this.f();
      this.d = var3;
      if (var3 != null && !var3.isEmpty()) {
         Pulse.m().info("Server address: {}", var3);
         this.a.c(var3);
      }

      this.a.F();
      this.e = "";
      this.f = true;
      this.a.a("join", var3, "", this.c);
      int var4 = ++this.b;
      new Thread(() -> {
         try {
            Thread.sleep(1500L);
         } catch (InterruptedException var3x) {
            return;
         }

         if (this.b == var4) {
            MinecraftClient var2x = MinecraftClient.getInstance();
            var2x.execute(() -> {
               if (var2x.player != null && this.b == var4) {
                  Collection var3xx = this.e();
                  this.a.k().a(var3xx);
                  this.a.k().a();
                  String var4x = this.g();
                  if (var4x != null && !var4x.isEmpty()) {
                     this.e = var4x;
                     this.a.a("world", this.d, var4x, this.c);
                  }
               }
            });
         }
      }).start();
   }

   public void b() {
      if (this.f) {
         this.f = false;

         try {
            this.a.a("leave", this.d, this.e, this.c);
         } catch (Throwable var2) {
         }
      }

      this.a.G();
   }

   public void a(PlayerListS2CPacket var1) {
      this.a.k().a(var1);
   }

   public boolean a(String var1) {
      return this.a.d(var1);
   }

   public boolean c() {
      return this.a.H();
   }

   public Integer b(String var1) {
      return this.a.d(var1, "cape");
   }

   public Integer a(String var1, String var2) {
      return this.a.d(var1, var2);
   }

   public int c(String var1) {
      return this.a.e(var1);
   }

   private Collection<PlayerListEntry> e() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.player != null) {
         ClientPlayNetworkHandler var2 = var1.player.networkHandler;
         if (var2 != null) {
            return var2.getPlayerList();
         }
      }

      return Collections.emptyList();
   }

   private String f() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      return var1.getCurrentServerEntry() != null ? var1.getCurrentServerEntry().address : null;
   }

   private String g() {
      try {
         int var1 = HandlerRegistry.c.h();
         return var1 > 0 ? String.valueOf(var1) : "";
      } catch (Throwable var2) {
         return "";
      }
   }

   public static ModUserTrackerV2 d() {
      if (g == null) {
         synchronized (ModUserTrackerV2.class) {
            if (g == null) {
               g = new ModUserTrackerV2();
            }
         }
      }

      return g;
   }
}
