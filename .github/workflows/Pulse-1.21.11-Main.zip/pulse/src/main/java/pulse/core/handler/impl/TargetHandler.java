package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.time.TimeUtils;

@HandlerInfo
@Environment(EnvType.CLIENT)
public class TargetHandler extends Handler implements IMinecraft {
   private LivingEntity a;
   private final Map<LivingEntity, TimeUtils> b = new HashMap<>();
   private final TimeUtils c = new TimeUtils();
   private boolean f = false;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      TimeUtils timer = this.c;
      var history = this.b;
      if (d.player == null || d.world == null) {
         return;
      }
      net.minecraft.util.hit.HitResult hit = d.crosshairTarget;
      float lifetime = pulse.features.modules.ModuleRegistry.au.o().b() * 1000.0F;
      if (hit != null && hit.getType() == net.minecraft.util.hit.HitResult.Type.ENTITY) {
         net.minecraft.entity.Entity entity = ((net.minecraft.util.hit.EntityHitResult)hit).getEntity();
         if (entity instanceof LivingEntity living && entity != d.player) {
            boolean ignored;
            try {
               if (living.isInvisible()) {
                  return;
               }
               ignored = pulse.utils.game.EntityUtils.a(living);
            } catch (RuntimeException | Error failure) {
               this.a = living;
               throw failure;
            }
            if (!ignored) {
               this.a = living;
               history.put(living, new TimeUtils());
               timer.b();
               this.f = true;
            }
         }
      } else if (this.f && timer.a((long)(int)lifetime)) {
         this.a = null;
         this.f = false;
      }
      int timeout = (int)lifetime;
      history.entrySet().removeIf(entry -> this.a(timeout, entry));
   }

   public boolean d() {
      return this.a != null;
   }

   public List<LivingEntity> e() {
      return new ArrayList<>(this.b.keySet());
   }

   public void f() {
      this.a = null;
      this.f = false;
      this.c.b();
   }

   public void g() {
      this.f();
      this.b.clear();
   }

   @Generated
   public LivingEntity h() {
      return this.a;
   }

   public boolean a(int var1, Entry var2) {
      LivingEntity var3 = (LivingEntity)var2.getKey();
      if (((TimeUtils)var2.getValue()).a(var1)) {
         return true;
      } else if (var3 instanceof PlayerEntity && var3.isInvisible()) {
         if (this.a == var3) {
            this.a = null;
            this.f = false;
         }

         return true;
      } else {
         return false;
      }
   }

   static {
      NativeMethodLookup.lookup(TargetHandler.class, 32);
   }
}
