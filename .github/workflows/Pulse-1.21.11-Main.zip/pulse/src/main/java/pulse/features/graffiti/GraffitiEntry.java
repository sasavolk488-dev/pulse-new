package pulse.features.graffiti;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class GraffitiEntry {
   private final String a;
   private final String b;
   private final Identifier[] c;
   private final int[] d;
   private final int e;
   private final float f;
   private final int g;

   public GraffitiEntry(String var1, Identifier[] var2, int[] var3, float var4) {
      this(var1, a(var1), var2, var3, var4, -1);
   }

   public GraffitiEntry(String var1, String var2, Identifier[] var3, int[] var4, float var5, int var6) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      int var7 = 0;
      if (var3.length > 1) {
         for (int var11 : var4) {
            var7 += var11;
         }
      }

      this.e = Math.max(1, var7);
      this.f = var5;
      this.g = var6;
   }

   private static String a(String var0) {
      int var1 = var0.lastIndexOf(46);
      return var1 > 0 ? var0.substring(0, var1) : var0;
   }

   public int a() {
      return this.g;
   }

   public String b() {
      return this.a;
   }

   public String c() {
      return this.b;
   }

   public Identifier d() {
      if (this.c.length == 1) {
         return this.c[0];
      } else {
         int var1 = (int)(System.currentTimeMillis() % this.e);
         int var2 = 0;

         for (int var3 = 0; var3 < this.c.length; var3++) {
            var2 += this.d[var3];
            if (var1 < var2) {
               return this.c[var3];
            }
         }

         return this.c[this.c.length - 1];
      }
   }

   public Identifier[] e() {
      return this.c;
   }

   public boolean f() {
      return this.c.length > 1;
   }

   public float g() {
      return this.f;
   }
}
