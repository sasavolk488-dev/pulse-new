package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.hud.components.BossBarComponent;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({BossBarHud.class})
public class BossBarHudMixin {
   @Unique
   private boolean pulseBossBarMatrixPushed = false;

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRender(DrawContext var1, CallbackInfo var2) {
      RenderTweaksModule var3 = ModuleRegistry.h;
      if (var3 != null && var3.s()) {
         var2.cancel();
      } else {
         BossBarComponent var4 = BossBarComponent.v();
         if (var4 != null && var4.w()) {
            var1.getMatrices().pushMatrix();
            var4.a(var1.getMatrices());
            this.pulseBossBarMatrixPushed = true;
         }
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("RETURN")}
   )
   private void afterRender(DrawContext var1, CallbackInfo var2) {
      if (this.pulseBossBarMatrixPushed) {
         var1.getMatrices().popMatrix();
         this.pulseBossBarMatrixPushed = false;
      }
   }
}
