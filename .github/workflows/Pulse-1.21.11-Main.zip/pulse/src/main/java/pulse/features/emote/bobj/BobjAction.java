package pulse.features.emote.bobj;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class BobjAction {
   final Map<String, List<BobjAction.Channel>> a = new LinkedHashMap<>();
   private final String b;
   private float c;

   BobjAction(String var1) {
      this.b = var1;
   }

   public String a() {
      return this.b;
   }

   public float b() {
      return this.c;
   }

   List<BobjAction.Channel> a(String var1) {
      return this.a.computeIfAbsent(var1, var0 -> new ArrayList<>());
   }

   void a(float var1) {
      this.c = Math.max(this.c, var1);
   }

   float a(String var1, String var2, int var3, float var4, float var5) {
      List<BobjAction.Channel> var6 = this.a.get(var1);
      if (var6 == null) {
         return var5;
      } else {
         for (BobjAction.Channel var8 : var6) {
            if (var8.b == var3 && var8.a.equals(var2)) {
               return var8.a(var4, var5);
            }
         }

         return var5;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class Channel {
      final String a;
      final int b;
      final List<BobjAction.Keyframe> c = new ArrayList<>();

      Channel(String var1, int var2) {
         this.a = var1;
         this.b = var2;
      }

      float a(float var1, float var2) {
         if (this.c.isEmpty()) {
            return var2;
         } else if (var1 <= this.c.getFirst().a) {
            return this.c.getFirst().b;
         } else if (var1 >= this.c.getLast().a) {
            return this.c.getLast().b;
         } else {
            BobjAction.Keyframe var3 = this.c.getFirst();
            BobjAction.Keyframe var4 = this.c.getLast();

            for (int var5 = 0; var5 < this.c.size() - 1; var5++) {
               BobjAction.Keyframe var6 = this.c.get(var5);
               BobjAction.Keyframe var7 = this.c.get(var5 + 1);
               if (var1 >= var6.a && var1 <= var7.a) {
                  var3 = var6;
                  var4 = var7;
                  break;
               }
            }

            if ("CONSTANT".equals(var3.c)) {
               return var3.b;
            } else {
               float var11 = (var1 - var3.a) / (var4.a - var3.a);
               if ("BEZIER".equals(var3.c) && var3.d && var4.d) {
                  float var12 = 0.0F;
                  float var13 = 1.0F;

                  for (int var8 = 0; var8 < 24; var8++) {
                     float var9 = (var12 + var13) * 0.5F;
                     float var10 = a(var3.a, var3.g, var4.e, var4.a, var9);
                     if (var10 < var1) {
                        var12 = var9;
                     } else {
                        var13 = var9;
                     }
                  }

                  float var14 = (var12 + var13) * 0.5F;
                  return a(var3.b, var3.h, var4.f, var4.b, var14);
               } else {
                  return var3.b + (var4.b - var3.b) * var11;
               }
            }
         }
      }

      private static float a(float var0, float var1, float var2, float var3, float var4) {
         float var5 = 1.0F - var4;
         return var5 * var5 * var5 * var0 + 3.0F * var5 * var5 * var4 * var1 + 3.0F * var5 * var4 * var4 * var2 + var4 * var4 * var4 * var3;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class Keyframe {
      final float a;
      final float b;
      final String c;
      final boolean d;
      final float e;
      final float f;
      final float g;
      final float h;

      Keyframe(String[] var1) {
         this.a = Float.parseFloat(var1[1]);
         this.b = Float.parseFloat(var1[2]);
         this.c = var1.length >= 4 ? var1[3] : "LINEAR";
         this.d = var1.length >= 8;
         this.e = this.d ? Float.parseFloat(var1[4]) : this.a;
         this.f = this.d ? Float.parseFloat(var1[5]) : this.b;
         this.g = this.d ? Float.parseFloat(var1[6]) : this.a;
         this.h = this.d ? Float.parseFloat(var1[7]) : this.b;
      }
   }
}
