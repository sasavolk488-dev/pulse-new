package pulse.mixin;

import java.util.List;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

@Environment(EnvType.CLIENT)
public class PulseMixinPlugin implements IMixinConfigPlugin {
   private static final boolean IMMEDIATELYFAST_LOADED = FabricLoader.getInstance().isModLoaded("immediatelyfast");

   @Override
   public boolean shouldApplyMixin(String var1, String var2) {
      if (var2.endsWith(".GlyphAtlasTextureMixin")) {
         return !IMMEDIATELYFAST_LOADED;
      } else {
         return var2.endsWith(".TextRendererGlyphDrawerMixin") ? !IMMEDIATELYFAST_LOADED : true;
      }
   }

   @Override
   public void onLoad(String var1) {
   }

   @Override
   public String getRefMapperConfig() {
      return null;
   }

   @Override
   public void acceptTargets(Set<String> var1, Set<String> var2) {
   }

   @Override
   public List<String> getMixins() {
      return null;
   }

   @Override
   public void preApply(String var1, ClassNode var2, String var3, IMixinInfo var4) {
   }

   @Override
   public void postApply(String var1, ClassNode var2, String var3, IMixinInfo var4) {
   }
}
