package pulse.core.handler.impl.autoevent;

import java.awt.Color;
import java.util.Map;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface ServerEventParser {
   boolean a(String var1);

   boolean a(String var1, String var2, AutoEventHandler var3);

   Set<String> a();

   Map<String, EventConfig> b();

   String c();

   default EventConfig d() {
      return new EventConfig(new Color(255, 165, 0));
   }

   default void a(AutoEventHandler var1) {
   }
}
