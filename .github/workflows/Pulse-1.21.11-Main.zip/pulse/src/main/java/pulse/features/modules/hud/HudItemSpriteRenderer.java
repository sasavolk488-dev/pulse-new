package pulse.features.modules.hud;

import java.awt.Color;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import pulse.mixin.accessor.ItemRenderStateAccessor;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public final class HudItemSpriteRenderer {
   private static final ItemRenderState a = new ItemRenderState();

   private HudItemSpriteRenderer() {
   }

   public static void a(Render var0, MatrixStack var1, ItemStack var2, float var3, float var4, float var5, float var6) {
      if (var2 != null && !var2.isEmpty() && !(var6 < 0.01F)) {
         MinecraftClient var7 = MinecraftClient.getInstance();
         if (var7.player != null && var7.world != null) {
            ItemModelManager var8 = var7.getItemModelManager();
            if (var8 != null) {
               var8.clearAndUpdate(a, var2, ItemDisplayContext.GUI, var7.world, var7.player, 0);
               ItemRenderStateAccessor var9 = (ItemRenderStateAccessor)a;
               LayerRenderState[] var10 = var9.pulse$getLayers();
               int var11 = var9.pulse$getLayerCount();
               int var12 = Math.max(0, Math.min(255, Math.round(var6 * 255.0F)));
               Color var13 = new Color(255, 255, 255, var12);

               for (int var14 = 0; var14 < var11; var14++) {
                  LayerRenderState var15 = var10[var14];
                  if (var15 != null) {
                     List var16 = var15.getQuads();
                     if (!var16.isEmpty()) {
                        BakedQuad var17 = (BakedQuad)var16.get(0);
                        Sprite var18 = var17.sprite();
                        if (var18 != null) {
                           Identifier var19 = var18.getAtlasId();
                           float var20 = var18.getMinU();
                           float var21 = var18.getMinV();
                           float var22 = var18.getMaxU() - var20;
                           float var23 = var18.getMaxV() - var21;
                           var0.b(var19, var3, var4, var5, var5, 0.0F, var20, var21, var22, var23, var13, var1);
                        }
                     }
                  }
               }
            }
         }
      }
   }
}
