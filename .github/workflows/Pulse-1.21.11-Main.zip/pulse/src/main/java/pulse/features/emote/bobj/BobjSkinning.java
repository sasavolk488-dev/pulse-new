package pulse.features.emote.bobj;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class BobjSkinning {
   private BobjSkinning() {
   }

   public static void a(float[] var0, float var1, float var2, float var3, float[] var4) {
      BobjMath.a(var0, var1, var2, var3, var4);
   }

   public static void b(float[] var0, float var1, float var2, float var3, float[] var4) {
      BobjMath.b(var0, var1, var2, var3, var4);
   }
}
