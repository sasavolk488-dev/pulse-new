package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.KeyEvent;
import pulse.core.event.impl.MouseScrollEvent;
import pulse.core.event.impl.RenderWorldEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.KeySetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Zoom",
   b = "Плавный зум с регулировкой колесиком мыши",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ZoomModule extends Module {
   private final KeySetting c = new KeySetting("Кнопка зума", 67);
   private final NumberSetting f = new NumberSetting("Стартовый FOV", 50.0F, 5.0F, 120.0F, 1.0F);
   private double g = 70.0;
   private double h = 70.0;
   private double i = 70.0;
   private double j = 0.5;
   private double k = -1.0;
   private boolean l = false;
   private boolean m = false;
   private int n = 0;
   private int o = 60;
   private long p = 0L;
   private static final double q = 0.02000000283128815;
   public static volatile boolean a = false;
   public static volatile double b = 70.0;
   private long r = 0L;

   @Compile
   @Override
   public void e() {
      super.e();
      if (d.options != null) {
         this.g = d.options.getFov().getValue().intValue();
         this.h = this.g;
         this.i = this.g;
         this.j = d.options.getMouseSensitivity().getValue();
      }
   }

   @Compile
   @Override
   public void f() {
      this.p();
      super.f();
   }

   private void n() {
      if (d.options != null && d.player != null && d.world != null) {
         if (!this.m) {
            this.g = d.options.getFov().getValue().intValue();
            this.j = d.options.getMouseSensitivity().getValue();
            this.m = true;
         }

         this.h = Math.min(this.g, Math.max(5.0, (double)this.f.b()));
         this.i = d.options.getFov().getValue().intValue();
         this.n = d.player.getInventory().getSelectedSlot();
         this.l = true;
      }
   }

   private void o() {
      if (d.options != null) {
         this.l = false;
         this.h = this.g;
         d.options.getMouseSensitivity().setValue(this.j);
         d.options.smoothCameraEnabled = false;
      }
   }

   private void p() {
      if (d.options != null) {
         d.options.getMouseSensitivity().setValue(this.j);
         d.options.smoothCameraEnabled = false;
      }

      this.l = false;
      this.m = false;
      a = false;
      this.h = this.g;
      this.i = this.g;
      this.p = 0L;
   }

   @EventHandler
   @Compile
   public void a(RenderWorldEvent var1) {
      if (d.options == null) {
         return;
      }
      if (this.l && d.currentScreen != null) {
         this.o();
         return;
      }
      if (!this.l) {
         boolean settled;
         try {
            settled = this.b(this.i, this.h, 0.2);
         } catch (RuntimeException | Error failure) {
            System.nanoTime();
            throw failure;
         }
         if (settled) {
            int fov = d.options.getFov().getValue().intValue();
            this.g = fov;
            this.h = fov;
            this.i = fov;
            try {
               this.j = d.options.getMouseSensitivity().getValue();
            } catch (RuntimeException | Error failure) {
               this.j = 0.0;
               throw failure;
            }
            this.m = false;
         }
      }
      long now = System.nanoTime();
      double elapsed = this.p == 0L ? 1.0 / 60.0 : (double)(now - this.p) / 1_000_000_000.0;
      this.p = now;
      if (elapsed > 0.25) {
         elapsed = 1.0 / 60.0;
      }
      boolean close;
      try {
         close = this.b(this.i, this.h, 0.1);
      } catch (RuntimeException | Error failure) {
         Math.pow(0.5, elapsed / 0.02);
         throw failure;
      }
      if (close) {
         this.i = this.h;
      } else {
         double factor = 1.0 - Math.pow(0.5, elapsed / 0.02);
         if (factor < 0.0) {
            factor = 0.0;
         } else if (factor > 1.0) {
            factor = 1.0;
         }
         this.i = (this.h - this.i) * factor + this.i;
         try {
            close = this.b(this.i, this.h, 0.2);
         } catch (RuntimeException | Error failure) {
            a = this.m;
            throw failure;
         }
         if (close) {
            this.i = this.h;
         }
      }
      a = this.m;
      b = this.i;
      if (this.l) {
         if (d.player != null) {
            d.player.getInventory().setSelectedSlot(this.n);
         }
         double ratio = this.g <= 5.0 ? 1.0 : this.h / this.g;
         double sensitivity = Math.min(this.j, Math.max(this.j * ratio, 0.0));
         if (Math.abs(sensitivity - this.k) > 0.0001) {
            d.options.getMouseSensitivity().setValue(sensitivity);
            this.k = sensitivity;
         }
      }
   }

   @EventHandler
   @Compile
   public void a(KeyEvent var1) {
      KeySetting binding = this.c;
      if (this.k() && binding.c() && var1.a() == binding.b() && d.currentScreen == null) {
         if (var1.c() == 1) {
            this.n();
         } else if (var1.c() == 0) {
            this.o();
         }
      }
   }

   @EventHandler
   @Compile
   public void a(MouseScrollEvent var1) {
      if (this.k() && this.l && d.currentScreen == null) {
         var1.a(true);
         double delta = -var1.e() * 20.0;
         if (this.g > 5.0) {
            delta *= (this.h - 5.0) / (this.g - 5.0);
         }
         this.h = this.a(this.h + delta, 5.0, this.g);
      }
   }

   private int q() {
      long var1 = System.currentTimeMillis();
      if (var1 - this.r < 500L) {
         return this.o;
      } else {
         this.r = var1;
         this.o = d.getCurrentFps();
         if (this.o <= 0) {
            this.o = 60;
         }

         return this.o;
      }
   }

   private double a(double var1, double var3, double var5) {
      if (var1 < var3) {
         return var3;
      } else {
         return var1 > var5 ? var5 : var1;
      }
   }

   private boolean b(double var1, double var3, double var5) {
      return Math.abs(var1 - var3) <= var5;
   }

   static {
      NativeMethodLookup.lookup(ZoomModule.class, 78);
   }
}
