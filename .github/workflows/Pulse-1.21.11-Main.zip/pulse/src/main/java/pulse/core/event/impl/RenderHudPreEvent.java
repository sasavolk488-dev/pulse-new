package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class RenderHudPreEvent extends Event {
   private final MatrixStack a;
   private final int b;
   private final int c;
   private final float d;

   public RenderHudPreEvent(MatrixStack var1, int var2, int var3, float var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   @Generated
   public MatrixStack a() {
      return this.a;
   }

   @Generated
   public int b() {
      return this.b;
   }

   @Generated
   public int c() {
      return this.c;
   }

   @Generated
   public float d() {
      return this.d;
   }
}
