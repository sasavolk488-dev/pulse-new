package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.ProjectileEntityRenderer;
import net.minecraft.client.render.entity.state.ProjectileEntityRenderState;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.mixin.accessor.PersistentProjectileEntityInvoker;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.ArrowNametagModule;

@Environment(EnvType.CLIENT)
@Mixin({ProjectileEntityRenderer.class})
public class ProjectileEntityRendererMixin {
   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/projectile/PersistentProjectileEntity;Lnet/minecraft/client/render/entity/state/ProjectileEntityRenderState;F)V"},
      at = {@At("TAIL")}
   )
   private void pulse$applyArrowNametag(PersistentProjectileEntity var1, ProjectileEntityRenderState var2, float var3, CallbackInfo var4) {
      ArrowNametagModule var5 = ModuleRegistry.Z;
      if (var5.k() && ((PersistentProjectileEntityInvoker)var1).pulse$isInGround() && var1.hasCustomName()) {
         var2.displayName = var1.getCustomName();
         var2.nameLabelPos = new Vec3d(0.0, var1.getHeight() - 0.5, 0.0);
      }
   }
}
