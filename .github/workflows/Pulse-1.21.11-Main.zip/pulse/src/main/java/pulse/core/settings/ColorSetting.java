package pulse.core.settings;

import java.awt.Color;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ColorSetting extends Setting<Color> {
   private float a;
   private float b;
   private float c;
   private Color d;
   private int e;

   public ColorSetting(String var1, String var2, Color var3) {
      super(var1, var2, var3);
      float[] var4 = Color.RGBtoHSB(var3.getRed(), var3.getGreen(), var3.getBlue(), null);
      this.a = var4[0];
      this.b = var4[1];
      this.c = var4[2];
      this.f();
   }

   public ColorSetting(String var1, Color var2) {
      this(var1, "", var2);
   }

   public ColorSetting(String var1, int var2, int var3, int var4) {
      this(var1, "", new Color(var2, var3, var4));
   }

   private void f() {
      this.d = Color.getHSBColor(this.a, this.b, this.c);
      this.e = this.d.getRGB();
   }

   public Color a() {
      return this.d;
   }

   public void a(Color var1) {
      this.a((Color)var1);
      float[] var2 = Color.RGBtoHSB(var1.getRed(), var1.getGreen(), var1.getBlue(), null);
      this.a = var2[0];
      this.b = var2[1];
      this.c = var2[2];
      this.f();
   }

   public int b() {
      return this.e;
   }

   public float c() {
      return this.a;
   }

   public void a(float var1) {
      this.a = var1;
      this.a((Color)Color.getHSBColor(var1, this.b, this.c));
      this.f();
   }

   public float d() {
      return this.b;
   }

   public void b(float var1) {
      this.b = var1;
      this.a((Color)Color.getHSBColor(this.a, var1, this.c));
      this.f();
   }

   public float e() {
      return this.c;
   }

   public void c(float var1) {
      this.c = var1;
      this.a((Color)Color.getHSBColor(this.a, this.b, var1));
      this.f();
   }

   public void a(float var1, float var2, float var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.a((Color)Color.getHSBColor(var1, var2, var3));
      this.f();
   }

   public ColorSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
