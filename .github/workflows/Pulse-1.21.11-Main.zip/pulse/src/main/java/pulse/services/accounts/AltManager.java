package pulse.services.accounts;

import com.google.gson.JsonObject;
import com.mojang.authlib.yggdrasil.ProfileResult;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import net.minecraft.util.Util;
import pulse.Pulse;
import pulse.mixin.accessor.MinecraftClientAccessor;

@Environment(EnvType.CLIENT)
public final class AltManager {
   private static final List<AltAccount> a = new ArrayList<>();
   private static boolean b;
   private static Session c;
   private static CompletableFuture<ProfileResult> d;

   private AltManager() {
   }

   public static List<AltAccount> a() {
      d();
      return Collections.unmodifiableList(a);
   }

   public static void b() {
      b = false;
      d();
   }

   public static boolean a(AltAccount.Type var0, String var1) {
      d();

      for (AltAccount var3 : a) {
         if (var3.a() == var0 && var3.b().equalsIgnoreCase(var1)) {
            return true;
         }
      }

      return false;
   }

   public static void a(AltAccount var0) {
      d();
      a.add(var0);
      e();
   }

   public static void b(AltAccount var0) {
      d();
      boolean var1 = e(var0);
      a.remove(var0);
      e();
      if (var1) {
         c();
      }
   }

   public static void a(AltAccount var0, String var1) {
      d();
      boolean var2 = e(var0);
      var0.a(var1);
      e();
      if (var2 && var0.a() == AltAccount.Type.a) {
         c(var0);
      }
   }

   public static String c(AltAccount var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      a(var1);
      if (c != null && var0.b().equalsIgnoreCase(c.getUsername()) && var0.f() == null) {
         c();
         f(var0);
         return null;
      } else if (var0.a() == AltAccount.Type.b) {
         if (var0.f() == null) {
            return "Сессия Microsoft неактивна — войдите в аккаунт заново";
         } else {
            UUID var5 = c(var0.c());
            UUID var3 = var5 != null ? var5 : a(var0.b());
            Session var4 = new Session(var0.b(), var3, var0.f(), Optional.empty(), Optional.empty());
            a(var1, var4, CompletableFuture.supplyAsync(() -> var1.getApiServices().sessionService().fetchProfile(var3, true), Util.getMainWorkerExecutor()));
            f(var0);
            Pulse.m().info("AltManager: вход в Microsoft-аккаунт {}", var0.b());
            return null;
         }
      } else {
         Session var2 = new Session(var0.b(), a(var0.b()), "0", Optional.empty(), Optional.empty());
         a(var1, var2, CompletableFuture.completedFuture(null));
         f(var0);
         Pulse.m().info("AltManager: вход в оффлайн-аккаунт {}", var0.b());
         return null;
      }
   }

   public static void c() {
      if (c != null) {
         MinecraftClient var0 = MinecraftClient.getInstance();
         a(var0, c, d);
         Pulse.m().info("AltManager: возврат на исходный аккаунт {}", c.getUsername());
      }
   }

   private static void a(MinecraftClient var0, Session var1, CompletableFuture<ProfileResult> var2) {
      MinecraftClientAccessor var3 = (MinecraftClientAccessor)var0;
      var3.setSession(var1);
      var3.setGameProfileFuture(var2 != null ? var2 : CompletableFuture.completedFuture(null));
   }

   public static void a(MinecraftClient var0) {
      if (c == null) {
         c = var0.getSession();
         d = ((MinecraftClientAccessor)var0).getGameProfileFuture();
      }
   }

   private static void f(AltAccount var0) {
      if (var0.e()) {
         LauncherConfig.a(a, -1);
      } else {
         int var1 = 0;

         for (AltAccount var3 : a) {
            if (var3 == var0) {
               LauncherConfig.a(a, var1);
               return;
            }

            if (!var3.e()) {
               var1++;
            }
         }
      }
   }

   public static AltAccount a(MicrosoftAuth.Result var0) {
      d();
      AltAccount var1 = null;

      for (AltAccount var3 : a) {
         if (var3.a() == AltAccount.Type.b && (var3.c() != null && var3.c().equalsIgnoreCase(var0.b.toString()) || var3.b().equalsIgnoreCase(var0.a))) {
            var1 = var3;
            break;
         }
      }

      if (var1 == null) {
         var1 = new AltAccount(AltAccount.Type.b, var0.a);
         a.add(var1);
      }

      var1.a(var0.a);
      var1.b(var0.b.toString());
      var1.c(var0.c);
      if (var0.d != null) {
         var1.a(var0.d, var0.e);
      }

      e();
      return var1;
   }

   public static boolean d(AltAccount var0) {
      Session var1 = c != null ? c : MinecraftClient.getInstance().getSession();
      return var1 != null && var1.getUsername().equalsIgnoreCase(var0.b());
   }

   public static boolean e(AltAccount var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      return var1.getSession() == null ? false : var1.getSession().getUsername().equalsIgnoreCase(var0.b());
   }

   public static UUID a(String var0) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + var0).getBytes(StandardCharsets.UTF_8));
   }

   private static UUID c(String var0) {
      if (var0 == null) {
         return null;
      } else {
         try {
            return UUID.fromString(var0);
         } catch (IllegalArgumentException var2) {
            return null;
         }
      }
   }

   public static boolean b(String var0) {
      if (var0 != null && var0.length() >= 3 && var0.length() <= 16) {
         for (int var1 = 0; var1 < var0.length(); var1++) {
            char var2 = var0.charAt(var1);
            boolean var3 = var2 >= 'a' && var2 <= 'z' || var2 >= 'A' && var2 <= 'Z' || var2 >= '0' && var2 <= '9' || var2 == '_';
            if (!var3) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static void d() {
      if (!b) {
         b = true;
         HashMap var0 = new HashMap();

         for (AltAccount var2 : a) {
            if (var2.a() == AltAccount.Type.b) {
               var0.put(var2.k(), new String[]{var2.f(), var2.i()});
            }
         }

         a.clear();
         JsonObject var7 = LauncherConfig.b();
         a.addAll(LauncherConfig.a(var7));

         for (AltAccount var3 : a) {
            String[] var4 = (String[])var0.get(var3.k());
            if (var4 != null) {
               var3.c(var4[0]);
               var3.e(var4[1]);
            }
         }

         MinecraftClient var9 = MinecraftClient.getInstance();
         if (var9.getSession() != null) {
            String var10 = var9.getSession().getUsername();
            if (var10 != null && !var10.isEmpty() && d(var10) == null) {
               boolean var11 = var9.getSession().getXuid().isPresent();
               UUID var5 = var9.getSession().getUuidOrNull();
               AltAccount var6 = new AltAccount(var11 ? AltAccount.Type.b : AltAccount.Type.a, var10, var5 != null ? var5.toString() : null, null);
               var6.a(true);
               a.add(var6);
            }
         }
      }
   }

   private static AltAccount d(String var0) {
      for (AltAccount var2 : a) {
         if (var2.b().toLowerCase(Locale.ROOT).equals(var0.toLowerCase(Locale.ROOT))) {
            return var2;
         }
      }

      return null;
   }

   private static void e() {
      LauncherConfig.a(a, -1);
   }
}
