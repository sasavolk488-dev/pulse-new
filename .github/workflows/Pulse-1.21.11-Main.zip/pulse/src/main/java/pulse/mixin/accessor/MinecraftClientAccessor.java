package pulse.mixin.accessor;

import com.mojang.authlib.yggdrasil.ProfileResult;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public interface MinecraftClientAccessor {
   @Accessor("session")
   Session getSession();

   @Mutable
   @Accessor("session")
   void setSession(Session var1);

   @Accessor("gameProfileFuture")
   CompletableFuture<ProfileResult> getGameProfileFuture();

   @Mutable
   @Accessor("gameProfileFuture")
   void setGameProfileFuture(CompletableFuture<ProfileResult> var1);

   @Invoker("doItemUse")
   void invokeDoItemUse();

   @Invoker("doAttack")
   boolean invokeDoAttack();
}
