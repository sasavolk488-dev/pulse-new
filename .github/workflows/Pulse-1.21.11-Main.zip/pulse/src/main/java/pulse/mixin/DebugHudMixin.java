package pulse.mixin;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.DebugHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.StreamerModeModule;

@Environment(EnvType.CLIENT)
@Mixin({DebugHud.class})
public class DebugHudMixin {
   @Inject(
      method = {"drawText"},
      at = {@At("HEAD")}
   )
   private void pulse$filterStreamerCoords(DrawContext var1, List<String> var2, boolean var3, CallbackInfo var4) {
      StreamerModeModule var5 = ModuleRegistry.T;
      if (var5 != null && var5.k() && var5.c.a()) {
         if (var3) {
            var2.removeIf(var0 -> var0.contains("XYZ:") || var0.contains("Block:") || var0.contains("Chunk:") || var0.contains("Facing:"));
         } else {
            var2.removeIf(var0 -> var0.contains("Targeted Block:") || var0.contains("Targeted Fluid:") || var0.contains("Targeted Entity"));
         }
      }
   }
}
