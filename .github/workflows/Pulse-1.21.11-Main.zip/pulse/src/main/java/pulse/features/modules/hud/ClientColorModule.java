package pulse.features.modules.hud;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Client Color",
   b = "Настройка основного цвета клиента",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class ClientColorModule extends Module {
   public final ModeSetting a = new ModeSetting("Режим", new String[]{"Статичный", "Градиент", "Астольфо", "Радуга"}, "Статичный");
   public final ColorSetting b = new ColorSetting("Цвет", new Color(138, 43, 226)).a(() -> this.a.b("Статичный"));
   public final ColorSetting c = new ColorSetting("Цвет #1", new Color(255, 255, 255)).a(() -> this.a.b("Градиент"));
   public final ColorSetting f = new ColorSetting("Цвет #2", new Color(0, 125, 245)).a(() -> this.a.b("Градиент"));
   private static final Color[] g = new Color[]{new Color(255, 121, 198), new Color(170, 70, 255), new Color(80, 181, 255)};
   private static final int h = 4000;
   private static final int i = 6000;
   private static final int j = 6000;

   public Color n() {
      String var1 = this.a.e();
      if ("Статичный".equals(var1)) {
         return this.b.a();
      } else if ("Градиент".equals(var1)) {
         return this.a(this.c.a(), this.f.a(), 4000L);
      } else if ("Астольфо".equals(var1)) {
         return this.a(g, 6000L);
      } else {
         return "Радуга".equals(var1) ? this.a(6000L) : this.b.a();
      }
   }

   public int o() {
      return this.n().getRGB();
   }

   private Color a(Color var1, Color var2, long var3) {
      float var5 = this.b(var3);
      return this.a(var1, var2, var5);
   }

   private Color a(Color[] var1, long var2) {
      float var4 = this.c(var2);
      float var5 = var4 * var1.length;
      int var6 = (int)Math.floor(var5) % var1.length;
      int var7 = (var6 + 1) % var1.length;
      float var8 = var5 - (int)var5;
      return this.a(var1[var6], var1[var7], var8);
   }

   private Color a(long var1) {
      float var3 = this.c(var1);
      return Color.getHSBColor(var3, 1.0F, 1.0F);
   }

   private float b(long var1) {
      return (float)(0.5 * (1.0 + Math.sin(System.currentTimeMillis() % var1 * (6.283185895785003 / var1))));
   }

   private float c(long var1) {
      return (float)(System.currentTimeMillis() % var1) / (float)var1;
   }

   private Color a(Color var1, Color var2, float var3) {
      var3 = Math.max(0.0F, Math.min(1.0F, var3));
      int var4 = (int)(var1.getRed() + (var2.getRed() - var1.getRed()) * var3);
      int var5 = (int)(var1.getGreen() + (var2.getGreen() - var1.getGreen()) * var3);
      int var6 = (int)(var1.getBlue() + (var2.getBlue() - var1.getBlue()) * var3);
      int var7 = (int)(var1.getAlpha() + (var2.getAlpha() - var1.getAlpha()) * var3);
      return new Color(var4, var5, var6, var7);
   }
}
