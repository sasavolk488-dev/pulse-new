package pulse.features.emote.bobj;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class BobjProp {
   private final List<BobjModel.Vertex> a;
   private final Identifier b;

   public BobjProp(List<BobjModel.Vertex> var1, Identifier var2) {
      this.a = List.copyOf(var1);
      this.b = var2;
   }

   public List<BobjModel.Vertex> a() {
      return this.a;
   }

   public Identifier b() {
      return this.b;
   }
}
