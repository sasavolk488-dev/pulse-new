package pulse.ui.clickgui.common;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.utils.render.Render;
import pulse.utils.render.ColorUtils;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class ScrollElement {
   private static final float a = 2.0F;
   private static final float b = 10.0F;
   private static final float c = 15.0F;
   private static final float d = 25.0F;
   private float e = 0.0F;
   private float f = 0.0F;
   private final Animation g = new Animation();
   private boolean h = false;
   private float i = 0.0F;
   private float j = 0.0F;
   private final Animation k = new Animation();
   private boolean l = false;
   private float m = 2.0F;
   private float n = 10.0F;
   private float o = 15.0F;
   private float p = 25.0F;
   private Color q = ClickGuiColors.b;
   private Color r = ClickGuiColors.d;
   private float s;
   private float t;
   private float u;
   private float v;
   private float w;

   public ScrollElement() {
   }

   public ScrollElement(float var1, float var2) {
      this.m = var1;
      this.p = var2;
   }

   public void a(float var1) {
      this.m = var1;
   }

   public void b(float var1) {
      this.n = var1;
   }

   public void c(float var1) {
      this.o = var1;
   }

   public void d(float var1) {
      this.p = var1;
   }

   public void a(Color var1) {
      this.q = var1;
   }

   public void b(Color var1) {
      this.r = var1;
   }

   public void a() {
      if (!this.h) {
         this.g.a();
         this.e = (float)this.g.j();
      }
   }

   public boolean a(float var1, float var2) {
      return var1 > var2;
   }

   public float b() {
      return this.e;
   }

   public void e(float var1) {
      this.e = var1;
      this.f = var1;
      this.g.d(var1);
   }

   public boolean c() {
      return this.h;
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7, int var8, int var9, boolean var10) {
      if (!(var6 <= var7)) {
         this.s = var3;
         this.t = var4;
         this.u = var5;
         this.v = var6;
         this.w = var7;
         float var11 = var6 - var7;
         float var12 = this.e / var11;
         float var13 = var7 / var6;
         float var14 = Math.max(this.o, var5 * var13);
         float var15 = var4 + (var5 - var14) * var12;
         boolean var16 = OverlayElement.a().b();
         boolean var17 = !var10 && !var16 && MouseUtil.a(var3 - this.n / 2.0F, var4, this.m + this.n, var5, (double)var8, (double)var9);
         boolean var18 = this.h || var17;
         if (var16 && this.l) {
            this.k.a(0.0, 0.1500000300871834, Easings.h);
            this.l = false;
         } else if (!var16 && var18 != this.l) {
            this.k.a(var18 ? 1.0 : 0.0, 0.1500000300871834, Easings.h);
            this.l = var18;
         }

         this.k.a();
         float var19 = (float)this.k.j();
         Color var20 = ColorUtils.a(this.q, this.r, var19);
         var2.a(var3, var15, this.m, var14, this.m / 2.0F, var20, var1);
      }
   }

   public boolean a(float var1, float var2, float var3, float var4, float var5, int var6, int var7) {
      if (var4 <= var5) {
         return false;
      } else if (MouseUtil.a(var1 - this.n / 2.0F, var2, this.m + this.n, var3, (double)var6, (double)var7)) {
         this.h = true;
         this.i = var7;
         this.j = this.e;
         return true;
      } else {
         return false;
      }
   }

   public void d() {
      if (this.h) {
         this.h = false;
         this.f = this.e;
         this.g.d(this.e);
      }
   }

   @Compile
   public void a(int var1, float var2, float var3) {
      if (!this.h || var2 <= var3) {
         return;
      }
      float trackHeight = this.u;
      float initialScroll = this.j;
      float initialMouse = this.i;
      float thumbHeight = Math.max(this.o, (var3 / var2) * this.u);
      this.e = (((float)var1 - initialMouse) / (trackHeight - thumbHeight)) * (var2 - var3) + initialScroll;
      this.e = Math.max(0.0F, Math.min(this.e, var2 - var3));
      this.f = this.e;
      this.g.d((double)this.e);
   }

   public void a(float var1, float var2, float var3) {
      if (!this.h && !(var2 <= var3)) {
         float var4 = Math.max(0.0F, var2 - var3);
         this.f = this.f - var1 * this.p;
         this.f = Math.max(0.0F, Math.min(this.f, var4));
         this.g.a(this.f, 0.1500000300871834, Easings.h);
      }
   }

   public void e() {
      this.e = 0.0F;
      this.f = 0.0F;
      this.g.d(0.0);
      this.h = false;
   }

   public void b(float var1, float var2) {
      if (var1 <= var2) {
         if (this.e > 0.0F || this.f > 0.0F) {
            this.f = 0.0F;
            this.g.a(0.0, 0.1500000300871834, Easings.h);
         }
      } else {
         float var3 = var1 - var2;
         if (this.e > var3 || this.f > var3) {
            this.f = var3;
            this.g.a(var3, 0.1500000300871834, Easings.h);
         }
      }
   }

   static {
      NativeMethodLookup.lookup(ScrollElement.class, 4);
   }
}
