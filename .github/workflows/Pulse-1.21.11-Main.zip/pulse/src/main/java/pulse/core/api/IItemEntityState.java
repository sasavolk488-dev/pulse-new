package pulse.core.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface IItemEntityState {
   boolean pulse$isOnGround();

   void pulse$setOnGround(boolean var1);

   boolean pulse$isShouldScale();

   void pulse$setShouldScale(boolean var1);
}
