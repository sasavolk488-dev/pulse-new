package pulse.core.event;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import meteordevelopment.orbit.EventBus;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class EventHandler {
   public static final EventBus a = new EventBus();

   static {
      a.registerLambdaFactory("", (var0, var1) -> (Lookup)var0.invoke(null, var1, MethodHandles.lookup()));
   }
}
