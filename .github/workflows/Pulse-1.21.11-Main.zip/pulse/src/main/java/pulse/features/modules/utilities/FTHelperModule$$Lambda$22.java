package pulse.features.modules.utilities;

import java.util.function.Predicate;

public final class FTHelperModule$$Lambda$22 implements Predicate {
   @Override
   public boolean test(Object var1) {
      return ((FTHelperModule.ActiveTimer)var1).a();
   }
}
