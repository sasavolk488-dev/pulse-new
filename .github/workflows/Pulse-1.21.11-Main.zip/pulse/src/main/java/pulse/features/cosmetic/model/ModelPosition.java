package pulse.features.cosmetic.model;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum ModelPosition {
   a(-1),
   b(1),
   c(3),
   d(-1),
   e(-1),
   f(-1),
   g(2),
   h(0);

   private final int i;

   private ModelPosition(int var3) {
      this.i = var3;
   }

   public int a() {
      return this.ordinal();
   }

   public int b() {
      return this.i;
   }

   public static ModelPosition a(int var0) {
      return var0 >= 0 && var0 < values().length ? values()[var0] : b;
   }

   private static ModelPosition[] c() {
      return new ModelPosition[]{a, b, c, d, e, f, g, h};
   }
}
