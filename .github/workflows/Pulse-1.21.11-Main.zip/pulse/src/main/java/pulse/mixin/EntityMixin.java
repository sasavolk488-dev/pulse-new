package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.core.handler.impl.EmoteHandler;
import pulse.core.handler.impl.PhraseHandler;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.FreeLookModule;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({Entity.class})
public abstract class EntityMixin {
   @Shadow
   private boolean glowing;

   @Inject(
      method = {"changeLookDirection"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void changeLookDirection(double var1, double var3, CallbackInfo var5) {
      if (PhraseHandler.a && (Object)this instanceof ClientPlayerEntity) {
         PhraseHandler.b += var1;
         PhraseHandler.c += var3;
         var5.cancel();
      } else if (EmoteHandler.a && (Object)this instanceof ClientPlayerEntity) {
         EmoteHandler.b += var1;
         EmoteHandler.c += var3;
         var5.cancel();
      } else {
         if (FreeLookModule.c && (Object)this instanceof ClientPlayerEntity) {
            float var6 = (float)(var1 * 0.15);
            float var7 = (float)(var3 * 0.15);
            FreeLookModule.f += var6;
            FreeLookModule.g = MathHelper.clamp(FreeLookModule.g + var7, -90.0F, 90.0F);
            var5.cancel();
         }
      }
   }

   @Shadow
   public abstract boolean isGlowing();

   @Inject(
      method = {"isGlowing"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsGlowing(CallbackInfoReturnable<Boolean> var1) {
      if (ModuleRegistry.i != null && ModuleRegistry.i.a((Entity)(Object)this)) {
         var1.setReturnValue(true);
      } else {
         RenderTweaksModule var2 = ModuleRegistry.h;
         if (var2 != null && var2.w()) {
            var1.setReturnValue(false);
         }
      }
   }
}
