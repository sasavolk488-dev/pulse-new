package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Formatting;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.utils.game.ChatUtils;
import pulse.utils.render.ColorUtils;

@HandlerInfo(
   a = false
)
@Environment(EnvType.CLIENT)
public class AnarchyFinderHandler extends Handler implements IMinecraft {
   private AnarchyFinderHandler.Stage a;
   private AnarchyFinderHandler.AnarchyVersion b;
   private final List<AnarchyFinderHandler.AnarchyInfo> c;
   private String f;
   private AnarchyFinderHandler.AnarchyInfo g;
   private int h;
   private final Set<String> i;
   private boolean j;
   private static final Pattern k = Pattern.compile("Онлайн режима:?\\s*(\\d+)/?\\d*");
   private static final Pattern l = Pattern.compile("(\\d+)/(\\d+)");
   private static final Pattern m = Pattern.compile("Анархия[\\s\\-#]*(\\d+)");

   public AnarchyFinderHandler() {
      this.a = AnarchyFinderHandler.Stage.a;
      this.b = null;
      this.c = new CopyOnWriteArrayList<>();
      this.f = "";
      this.g = null;
      this.h = -1;
      this.i = new HashSet<>();
      this.j = false;
      this.f();
   }

   public boolean d() {
      return this.c() && this.a == AnarchyFinderHandler.Stage.a;
   }

   public void e() {
      this.f();
      this.a = AnarchyFinderHandler.Stage.a;
      this.a(true);
   }

   private void f() {
      this.a = AnarchyFinderHandler.Stage.a;
      this.b = null;
      this.c.clear();
      this.f = "";
      this.g = null;
      this.h = -1;
      this.i.clear();
      this.j = false;
   }

   @EventHandler
   @Compile
   public void a(WorldChangeEvent var1) {
      if (this.a != AnarchyFinderHandler.Stage.m) {
         this.f();
         this.a(false);
      }
   }

   @EventHandler
   @Compile
   private void a(UpdateEvent var1) {
      if (!this.c()) {
         return;
      }
      pulse.features.modules.utilities.StreamerModeModule.o();
      try {
         if (this.a == AnarchyFinderHandler.Stage.m) {
            this.g();
         } else if (d.currentScreen instanceof HandledScreen<?>) {
            HandledScreen<?> screen = (HandledScreen<?>)d.currentScreen;
            if (this.a == AnarchyFinderHandler.Stage.a) {
               this.a(screen);
            } else {
               this.b(screen);
            }
         }
      } finally {
         pulse.features.modules.utilities.StreamerModeModule.p();
      }
   }

   private void a(HandledScreen<?> var1) {
      for (AnarchyFinderHandler.AnarchyVersion var5 : AnarchyFinderHandler.AnarchyVersion.values()) {
         if (this.a(var1, var5.a())) {
            this.b = var5;
            this.a = AnarchyFinderHandler.Stage.b;
            return;
         }
      }
   }

   private boolean a(HandledScreen<?> var1, Item var2) {
      for (int var3 = 0; var3 < var1.getScreenHandler().slots.size(); var3++) {
         Slot var4 = var1.getScreenHandler().slots.get(var3);
         if (var4 != null && var4.hasStack()) {
            ItemStack var5 = var4.getStack();
            if (var5.getItem() == var2 && var5.hasGlint()) {
               return true;
            }
         }
      }

      return false;
   }

   private void g() {
      int var1 = this.h();
      if (var1 == this.h && this.g != null) {
         MutableText var2 = Text.literal("")
            .append(this.a("✔ Успешно подключился", new Color(144, 238, 144), new Color(102, 205, 170)))
            .append(this.a(" к "))
            .append(ChatUtils.b("Анархии #" + this.h))
            .append(this.a(" с самым маленьким онлайном: "))
            .append(this.a(this.g.b()));
         MutableText var3 = ChatUtils.b("Минимальный онлайн по командам:");
         StringBuilder var4 = new StringBuilder();
         var var5 = this.c
            .stream()
            .collect(Collectors.groupingBy(AnarchyFinderHandler.AnarchyInfo::c, Collectors.minBy(Comparator.comparingInt(AnarchyFinderHandler.AnarchyInfo::b))));
         String[] var6 = new String[]{"х1", "х2", "х3", "х5", "х10"};

         for (String var10 : var6) {
            Optional var11 = var5.getOrDefault(var10, Optional.empty());
            if (var11.isPresent()) {
               AnarchyFinderHandler.AnarchyInfo var12 = (AnarchyFinderHandler.AnarchyInfo)var11.get();
               var4.append(Formatting.GRAY)
                  .append("• ")
                  .append(var10)
                  .append(": ")
                  .append(Formatting.WHITE)
                  .append(var12.a())
                  .append(Formatting.GRAY)
                  .append(" - ")
                  .append(Formatting.WHITE)
                  .append(var12.b())
                  .append(" игроков")
                  .append("\n");
            }
         }

         MutableText var13 = Text.literal("").append(var3).append(Text.literal("\n" + var4.toString().trim()));
         Style var14 = Style.EMPTY.withColor(TextColor.fromRgb(16733525)).withHoverEvent(new ShowText(var13));
         MutableText var15 = Text.literal(" [")
            .setStyle(var14)
            .append(Text.literal("Подробнее").setStyle(var14.withFormatting(Formatting.UNDERLINE)))
            .append(Text.literal("]").setStyle(var14));
         var2.append(var15);
         ChatUtils.b(var2);
         this.a(false);
      }
   }

   private MutableText a(String var1, Color var2, Color var3) {
      MutableText var4 = Text.literal("");
      int var5 = var1.length();

      for (int var6 = 0; var6 < var5; var6++) {
         float var7 = var5 > 1 ? (float)var6 / (var5 - 1) : 0.0F;
         Color var8 = ColorUtils.a(var2, var3, var7);
         var4.append(Text.literal(String.valueOf(var1.charAt(var6))).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(var8.getRGB() & 16777215))));
      }

      return var4;
   }

   private MutableText a(int var1) {
      String var2 = String.valueOf(var1);
      if (var2.length() >= 3) {
         return ChatUtils.b(var2);
      } else {
         MutableText var3 = ChatUtils.b("x");
         TextColor var4 = var3.getStyle().getColor();
         int var5 = var4 != null ? var4.getRgb() : 16777215;
         return Text.literal(var2).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(var5)));
      }
   }

   private MutableText a(String var1) {
      return Text.literal(var1).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(11184810)));
   }

   private int h() {
      try {
         if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
            PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
            Text var2 = var1.getHeader();
            if (var2 == null) {
               return -1;
            } else {
               String var3 = Formatting.strip(var2.getString());
               if (var3 != null && var3.contains("Анархия-")) {
                  String[] var4 = var3.split("Анархия-");
                  if (var4.length < 2) {
                     return -1;
                  } else {
                     StringBuilder var5 = new StringBuilder();

                     for (char var9 : var4[1].trim().toCharArray()) {
                        if (Character.isDigit(var9)) {
                           var5.append(var9);
                        } else if (var5.length() > 0) {
                           break;
                        }
                     }

                     return var5.length() == 0 ? -1 : Integer.parseInt(var5.toString());
                  }
               } else {
                  return -1;
               }
            }
         } else {
            return -1;
         }
      } catch (Exception var10) {
         return -1;
      }
   }

   private void b(HandledScreen<?> var1) {
      switch (this.a) {
         case b:
            if (this.a(var1, Items.TOTEM_OF_UNDYING, false, "Команды х1")) {
               this.f = "х1";
               this.a = AnarchyFinderHandler.Stage.c;
            }
            break;
         case c:
            if (!this.a(var1, "Команды х1")) {
               return;
            }

            if (this.b(var1, "х1")) {
               this.i.clear();
               this.j = false;
               this.a = AnarchyFinderHandler.Stage.d;
            }
            break;
         case d:
            if (this.a(var1, Items.TOTEM_OF_UNDYING, false, "Команды х2")) {
               this.f = "х2";
               this.a = AnarchyFinderHandler.Stage.e;
            }
            break;
         case e:
            if (!this.a(var1, "Команды х2")) {
               return;
            }

            if (this.b(var1, "х2")) {
               this.i.clear();
               this.j = false;
               this.a = AnarchyFinderHandler.Stage.f;
            }
            break;
         case f:
            if (this.a(var1, Items.TOTEM_OF_UNDYING, false, "Команды х3")) {
               this.f = "х3";
               this.a = AnarchyFinderHandler.Stage.g;
            }
            break;
         case g:
            if (!this.a(var1, "Команды х3")) {
               return;
            }

            if (this.b(var1, "х3")) {
               this.i.clear();
               this.j = false;
               this.a = AnarchyFinderHandler.Stage.h;
            }
            break;
         case h:
            if (this.a(var1, Items.TOTEM_OF_UNDYING, false, "Команды х5")) {
               this.f = "х5";
               this.a = AnarchyFinderHandler.Stage.i;
            }
            break;
         case i:
            if (!this.a(var1, "Команды х5")) {
               return;
            }

            if (this.b(var1, "х5")) {
               this.i.clear();
               this.j = false;
               this.a = AnarchyFinderHandler.Stage.j;
            }
            break;
         case j:
            if (this.a(var1, Items.TOTEM_OF_UNDYING, false, "Команды х10")) {
               this.f = "х10";
               this.a = AnarchyFinderHandler.Stage.k;
            }
            break;
         case k:
            if (!this.a(var1, "Команды х10")) {
               return;
            }

            if (this.b(var1, "х10")) {
               this.i.clear();
               this.j = false;
               this.a = AnarchyFinderHandler.Stage.l;
            }
            break;
         case l:
            this.i();
      }
   }

   private void i() {
      if (this.c.isEmpty()) {
         this.a(false);
      } else {
         this.g = this.c.stream().min(Comparator.comparingInt(AnarchyFinderHandler.AnarchyInfo::b)).orElse(null);
         if (this.g != null) {
            String var1 = this.g.a();
            Matcher var2 = m.matcher(var1);
            if (var2.find()) {
               String var3 = var2.group(1);
               this.h = Integer.parseInt(var3);
               ChatUtils.a("an" + var3);
               this.a = AnarchyFinderHandler.Stage.m;
            } else {
               this.a(false);
            }
         } else {
            this.a(false);
         }
      }
   }

   private boolean a(HandledScreen<?> var1, String var2) {
      for (int var3 = 0; var3 < var1.getScreenHandler().slots.size(); var3++) {
         Slot var4 = var1.getScreenHandler().slots.get(var3);
         if (var4 != null && var4.hasStack()) {
            ItemStack var5 = var4.getStack();
            if (var5.getItem() == Items.TOTEM_OF_UNDYING && var5.hasGlint()) {
               String var6 = Formatting.strip(var5.getName().getString());
               if (var6 != null && var6.contains(var2)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean a(Item var1) {
      return var1 == Items.CHEST_MINECART || var1 == Items.TNT_MINECART;
   }

   private boolean a(HandledScreen<?> var1, Item var2, boolean var3, String var4) {
      for (int var5 = 0; var5 < var1.getScreenHandler().slots.size(); var5++) {
         Slot var6 = var1.getScreenHandler().slots.get(var5);
         if (var6 != null && var6.hasStack()) {
            ItemStack var7 = var6.getStack();
            if (var7.getItem() == var2) {
               boolean var8 = var7.hasGlint();
               String var9 = Formatting.strip(var7.getName().getString());
               boolean var10 = var3 || !var8;
               boolean var11 = var4.isEmpty() || var9 != null && var9.contains(var4);
               if (var10 && var11) {
                  this.a(var1, var5);
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean b(HandledScreen<?> var1, String var2) {
      boolean var3 = false;

      for (int var4 = 0; var4 < var1.getScreenHandler().slots.size(); var4++) {
         Slot var5 = var1.getScreenHandler().slots.get(var4);
         if (var5 != null && var5.hasStack()) {
            ItemStack var6 = var5.getStack();
            if (this.a(var6.getItem())) {
               String var7 = Formatting.strip(var6.getName().getString());
               if (var7 != null && var7.contains("Анархия") && !this.i.contains(var7)) {
                  var var8 = this.a(var6);
                  boolean var9 = var8.stream().anyMatch(var0 -> var0.contains("Премиум Анархия"));
                  boolean var10 = var8.stream().anyMatch(var0 -> var0.contains("Данная анархия будет запущена при необходимости"));
                  if (!var9 && !var10) {
                     Optional var11 = this.a(var8);
                     if (var11.isPresent()) {
                        int var12 = (Integer)var11.get();
                        String var13 = var7.trim();
                        var13 = var13.replaceAll("»\\s+", "").trim();
                        this.c.add(new AnarchyFinderHandler.AnarchyInfo(var13, var12, var2));
                     }

                     this.i.add(var7);
                     var3 = true;
                  } else {
                     this.i.add(var7);
                  }
               }
            }
         }
      }

      if (this.j && !var3) {
         return false;
      } else {
         for (int var14 = 0; var14 < var1.getScreenHandler().slots.size(); var14++) {
            Slot var15 = var1.getScreenHandler().slots.get(var14);
            if (var15 != null && var15.hasStack()) {
               ItemStack var16 = var15.getStack();
               if (var16.getItem() == Items.ARROW) {
                  String var17 = Formatting.strip(var16.getName().getString());
                  if (var17 != null && var17.contains("Следующая страница")) {
                     this.a(var1, var14);
                     this.j = true;
                     return false;
                  }
               }
            }
         }

         this.j = false;
         return true;
      }
   }

   private Optional<Integer> a(List<String> var1) {
      for (String var3 : var1) {
         Matcher var4 = k.matcher(var3);
         if (var4.find()) {
            try {
               int var9 = Integer.parseInt(var4.group(1));
               return Optional.of(var9);
            } catch (NumberFormatException var7) {
            }
         }

         var4 = l.matcher(var3);
         if (var4.find()) {
            try {
               int var5 = Integer.parseInt(var4.group(1));
               return Optional.of(var5);
            } catch (NumberFormatException var6) {
            }
         }
      }

      return Optional.empty();
   }

   private List<String> a(ItemStack var1) {
      ArrayList<String> var2 = new ArrayList<>();
      LoreComponent var3 = var1.get(DataComponentTypes.LORE);
      if (var3 != null) {
         for (Text var5 : var3.lines()) {
            String var6 = Formatting.strip(var5.getString());
            if (var6 != null) {
               var2.add(var6);
            }
         }
      }

      return var2;
   }

   private void a(HandledScreen<?> var1, int var2) {
      if (d.interactionManager != null) {
         d.interactionManager.clickSlot(var1.getScreenHandler().syncId, var2, 0, SlotActionType.PICKUP, d.player);
      }
   }

   static {
      NativeMethodLookup.lookup(AnarchyFinderHandler.class, 22);
   }

   @Environment(EnvType.CLIENT)
   private static class AnarchyInfo {
      private String a;
      private int b;
      private String c;

      @Generated
      public String a() {
         return this.a;
      }

      @Generated
      public int b() {
         return this.b;
      }

      @Generated
      public String c() {
         return this.c;
      }

      @Generated
      public AnarchyInfo(String var1, int var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   @Environment(EnvType.CLIENT)
   private static enum AnarchyVersion {
      a(Items.TNT),
      b(Items.RESPAWN_ANCHOR);

      private final Item c;

      private AnarchyVersion(Item var3) {
         this.c = var3;
      }

      @Generated
      public Item a() {
         return this.c;
      }

      private static AnarchyFinderHandler.AnarchyVersion[] b() {
         return new AnarchyFinderHandler.AnarchyVersion[]{a, b};
      }
   }

   @Environment(EnvType.CLIENT)
   private static enum Stage {
      a,
      b,
      c,
      d,
      e,
      f,
      g,
      h,
      i,
      j,
      k,
      l,
      m;

      private static AnarchyFinderHandler.Stage[] a() {
         return new AnarchyFinderHandler.Stage[]{a, b, c, d, e, f, g, h, i, j, k, l, m};
      }
   }
}
