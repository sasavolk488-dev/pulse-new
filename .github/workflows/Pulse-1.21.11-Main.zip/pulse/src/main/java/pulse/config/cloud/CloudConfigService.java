package pulse.config.cloud;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.config.ConfigData;
import pulse.config.ConfigSerializer;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@Environment(EnvType.CLIENT)
public class CloudConfigService {
   private static int a = 22;
   private static int b = 23;
   private static int c = 24;
   private static int d = 25;
   private static int e = 26;
   private static int f = 27;
   private static int g = 28;
   private final RealtimeSyncServiceV2 h;
   private final Map<String, CloudConfigService.ConfigMeta> i = new ConcurrentHashMap<>();
   private final List<CloudConfigService.PremiumConfigMeta> j = new ArrayList<>();
   private volatile ConfigData k;
   private volatile String l;
   private volatile int m;
   private volatile boolean n;
   private volatile boolean o;
   private volatile Runnable p;

   public CloudConfigService(RealtimeSyncServiceV2 var1) {
      this.h = var1;
   }

   public void a(JSONObject var1) {
      try {
         this.i.clear();
         this.k = null;
         this.l = null;
         this.m = 0;
         this.n = false;
         if (var1.has("configsMeta") && !var1.isNull("configsMeta")) {
            JSONArray var2 = var1.getJSONArray("configsMeta");

            for (int var3 = 0; var3 < var2.length(); var3++) {
               JSONObject var4 = var2.getJSONObject(var3);
               CloudConfigService.ConfigMeta var5 = CloudConfigService.ConfigMeta.a(var4);
               this.i.put(var5.b, var5);
               if (var5.d) {
                  this.l = var5.b;
                  this.m = var5.e;
               }
            }
         }

         if (var1.has("activeConfig") && !var1.isNull("activeConfig")) {
            JSONObject var7 = var1.getJSONObject("activeConfig");
            if (var7.has("data") && !var7.isNull("data")) {
               JSONObject var9 = var7.getJSONObject("data");
               this.k = ConfigSerializer.a(var9.toString());
               if (var7.has("name")) {
                  this.l = var7.getString("name");
               }

               if (var7.has("version")) {
                  this.m = var7.getInt("version");
               }
            }
         }

         this.j.clear();
         if (var1.has("premiumConfigs") && !var1.isNull("premiumConfigs")) {
            JSONArray var8 = var1.getJSONArray("premiumConfigs");

            for (int var10 = 0; var10 < var8.length(); var10++) {
               JSONObject var11 = var8.getJSONObject(var10);
               CloudConfigService.PremiumConfigMeta var12 = CloudConfigService.PremiumConfigMeta.a(var11);
               this.j.add(var12);
            }
         }

         this.o = true;
      } catch (Exception var6) {
         Pulse.m().error("Config init failed", (Throwable)var6);
         this.o = true;
      }
   }

   public void a(ConfigData var1, Runnable var2, Consumer<String> var3) {
      if (!this.j()) {
         if (var3 != null) {
            this.b(() -> var3.accept("Not connected"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               String var4 = this.l != null ? this.l : "Default";
               JSONObject var5 = new JSONObject();
               var5.put("name", var4);
               var5.put("baseVersion", this.m);
               var5.put("data", new JSONObject(ConfigSerializer.a(var1)));
               JSONObject var6 = this.h.a(a, 0, var5);
               if (var6 != null && var6.optBoolean("ok", false)) {
                  JSONObject var9 = var6.optJSONObject("data");
                  if (var9 != null && var9.has("newVersion")) {
                     this.m = var9.getInt("newVersion");
                  }

                  this.n = false;
                  if (var2 != null) {
                     this.b(var2);
                  }
               } else {
                  String var7 = var6 != null ? var6.optString("error", "Unknown error") : "No response";
                  if (var3 != null) {
                     this.b(() -> var3.accept(var7));
                  }
               }
            } catch (Exception var8) {
               if (var3 != null) {
                  this.b(() -> var3.accept(var8.getMessage()));
               }
            }
         });
      }
   }

   public void a(String var1, Runnable var2, Consumer<String> var3) {
      if (!this.j()) {
         if (var3 != null) {
            this.b(() -> var3.accept("Not connected"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var4 = new JSONObject();
               var4.put("name", var1);
               JSONObject var5 = this.h.a(b, 0, var4);
               if (var5 != null && var5.optBoolean("ok", false)) {
                  JSONObject var11 = var5.optJSONObject("data");
                  if (var11 != null && var11.has("configData") && !var11.isNull("configData")) {
                     JSONObject var7 = var11.getJSONObject("configData");
                     this.k = ConfigSerializer.a(var7.toString());
                     this.l = var1;
                     if (var11.has("version")) {
                        this.m = var11.getInt("version");
                     }

                     for (CloudConfigService.ConfigMeta var9 : this.i.values()) {
                        var9.d = var9.b.equals(var1);
                     }

                     this.n = false;
                     if (var2 != null) {
                        this.b(var2);
                     }
                  }
               } else {
                  String var6 = var5 != null ? var5.optString("error", "Unknown error") : "No response";
                  if (var3 != null) {
                     this.b(() -> var3.accept(var6));
                  }
               }
            } catch (Exception var10) {
               Pulse.m().error("CloudConfigService: Failed to switch config", (Throwable)var10);
               if (var3 != null) {
                  this.b(() -> var3.accept(var10.getMessage()));
               }
            }
         });
      }
   }

   public void a(ConfigData var1, String var2, Runnable var3, Consumer<String> var4) {
      if (!this.j()) {
         if (var4 != null) {
            this.b(() -> var4.accept("Not connected"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               String var5 = this.l != null ? this.l : "Default";
               JSONObject var6 = new JSONObject();
               var6.put("name", var5);
               var6.put("baseVersion", this.m);
               var6.put("data", new JSONObject(ConfigSerializer.a(var1)));
               JSONObject var7 = this.h.a(a, 0, var6);
               if (var7 != null && var7.optBoolean("ok", false)) {
                  JSONObject var8 = var7.optJSONObject("data");
                  if (var8 != null && var8.has("newVersion")) {
                     this.m = var8.getInt("newVersion");
                  }

                  this.n = false;
               }

               JSONObject var15 = new JSONObject();
               var15.put("name", var2);
               JSONObject var9 = this.h.a(b, 0, var15);
               if (var9 != null && var9.optBoolean("ok", false)) {
                  JSONObject var16 = var9.optJSONObject("data");
                  if (var16 != null && var16.has("configData") && !var16.isNull("configData")) {
                     JSONObject var11 = var16.getJSONObject("configData");
                     this.k = ConfigSerializer.a(var11.toString());
                     this.l = var2;
                     if (var16.has("version")) {
                        this.m = var16.getInt("version");
                     }

                     for (CloudConfigService.ConfigMeta var13 : this.i.values()) {
                        var13.d = var13.b.equals(var2);
                     }

                     this.n = false;
                     if (var3 != null) {
                        this.b(var3);
                     }
                  }
               } else {
                  String var10 = var9 != null ? var9.optString("error", "Unknown error") : "No response";
                  if (var4 != null) {
                     this.b(() -> var4.accept(var10));
                  }
               }
            } catch (Exception var14) {
               Pulse.m().error("CloudConfigService: Failed to save and switch config", (Throwable)var14);
               if (var4 != null) {
                  this.b(() -> var4.accept(var14.getMessage()));
               }
            }
         });
      }
   }

   public void b(String var1, Runnable var2, Consumer<String> var3) {
      if (!this.j()) {
         if (var3 != null) {
            this.b(() -> var3.accept("Not connected"));
         }
      } else if (var1.equals(this.l)) {
         if (var3 != null) {
            this.b(() -> var3.accept("Cannot delete active config"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var4 = new JSONObject();
               var4.put("name", var1);
               JSONObject var5 = this.h.a(c, 0, var4);
               if (var5 != null && var5.optBoolean("ok", false)) {
                  this.i.remove(var1);
                  if (var2 != null) {
                     this.b(var2);
                  }
               } else {
                  String var6 = var5 != null ? var5.optString("error", "Unknown error") : "No response";
                  if (var3 != null) {
                     this.b(() -> var3.accept(var6));
                  }
               }
            } catch (Exception var7) {
               Pulse.m().error("CloudConfigService: Failed to delete config", (Throwable)var7);
               if (var3 != null) {
                  this.b(() -> var3.accept(var7.getMessage()));
               }
            }
         });
      }
   }

   public void a(String var1, String var2, Runnable var3, Consumer<String> var4) {
      if (!this.j()) {
         if (var4 != null) {
            this.b(() -> var4.accept("Not connected"));
         }
      } else if (var1.equals(this.l)) {
         if (var4 != null) {
            this.b(() -> var4.accept("Cannot rename active config"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var5 = new JSONObject();
               var5.put("oldName", var1);
               var5.put("newName", var2);
               JSONObject var6 = this.h.a(d, 0, var5);
               if (var6 != null && var6.optBoolean("ok", false)) {
                  CloudConfigService.ConfigMeta var9 = this.i.remove(var1);
                  if (var9 != null) {
                     var9.b = var2;
                     this.i.put(var2, var9);
                  }

                  if (var3 != null) {
                     this.b(var3);
                  }
               } else {
                  String var7 = var6 != null ? var6.optString("error", "Unknown error") : "No response";
                  if (var4 != null) {
                     this.b(() -> var4.accept(var7));
                  }
               }
            } catch (Exception var8) {
               Pulse.m().error("CloudConfigService: Failed to rename config", (Throwable)var8);
               if (var4 != null) {
                  this.b(() -> var4.accept(var8.getMessage()));
               }
            }
         });
      }
   }

   public void c(String var1, Runnable var2, Consumer<String> var3) {
      if (!this.j()) {
         if (var3 != null) {
            this.b(() -> var3.accept("Not connected"));
         }
      } else if (this.i.containsKey(var1)) {
         if (var3 != null) {
            this.b(() -> var3.accept("Config already exists"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var4 = new JSONObject();
               var4.put("name", var1);
               var4.put("baseVersion", 0);
               var4.put("data", new JSONObject());
               var4.put("createNew", true);
               JSONObject var5 = this.h.a(a, 0, var4);
               if (var5 != null && var5.optBoolean("ok", false)) {
                  JSONObject var9 = var5.optJSONObject("data");
                  if (var9 != null) {
                     CloudConfigService.ConfigMeta var7 = new CloudConfigService.ConfigMeta();
                     var7.b = var1;
                     var7.e = var9.optInt("newVersion", 1);
                     var7.d = false;
                     var7.g = System.currentTimeMillis();
                     var7.f = System.currentTimeMillis();
                     this.i.put(var1, var7);
                     if (var2 != null) {
                        this.b(var2);
                     }
                  }
               } else {
                  String var6 = var5 != null ? var5.optString("error", "Unknown error") : "No response";
                  if (var3 != null) {
                     this.b(() -> var3.accept(var6));
                  }
               }
            } catch (Exception var8) {
               if (var3 != null) {
                  this.b(() -> var3.accept(var8.getMessage()));
               }
            }
         });
      }
   }

   public void a(String var1, int var2, Integer var3, Integer var4, Consumer<String> var5, Consumer<String> var6) {
      if (!this.j()) {
         if (var6 != null) {
            this.b(() -> var6.accept("Not connected"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var7 = new JSONObject();
               var7.put("configName", var1);
               var7.put("maxUsages", var2);
               if (var3 != null) {
                  var7.put("expiresInHours", var3);
               }

               if (var4 != null && var4 > 1) {
                  var7.put("count", var4);
               }

               JSONObject var8 = this.h.a(e, 0, var7);
               if (var8 != null && var8.optBoolean("ok", false)) {
                  JSONObject var14 = var8.optJSONObject("data");
                  if (var14 != null) {
                     if (var14.has("key")) {
                        String var10 = var14.getString("key");
                        if (var5 != null) {
                           this.b(() -> var5.accept(var10));
                        }
                     } else if (var14.has("keys")) {
                        JSONArray var15 = var14.getJSONArray("keys");
                        StringBuilder var11 = new StringBuilder();

                        for (int var12 = 0; var12 < var15.length(); var12++) {
                           if (var12 > 0) {
                              var11.append("\n");
                           }

                           var11.append(var15.getJSONObject(var12).getString("key"));
                        }

                        String var16 = var11.toString();
                        if (var5 != null) {
                           this.b(() -> var5.accept(var16));
                        }
                     } else if (var6 != null) {
                        this.b(() -> var6.accept("No key in response"));
                     }
                  } else if (var6 != null) {
                     this.b(() -> var6.accept("No data in response"));
                  }
               } else {
                  String var9 = var8 != null ? var8.optString("error", "Unknown error") : "No response";
                  if (var6 != null) {
                     this.b(() -> var6.accept(var9));
                  }
               }
            } catch (Exception var13) {
               Pulse.m().error("CloudConfigService: Failed to create share key", (Throwable)var13);
               if (var6 != null) {
                  this.b(() -> var6.accept(var13.getMessage()));
               }
            }
         });
      }
   }

   public void d(String var1, Runnable var2, Consumer<String> var3) {
      if (!this.j()) {
         if (var3 != null) {
            this.b(() -> var3.accept("Not connected"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var4 = new JSONObject();
               var4.put("key", var1);
               JSONObject var5 = this.h.a(f, 0, var4);
               if (var5 != null && var5.optBoolean("ok", false)) {
                  JSONObject var12 = var5.optJSONObject("data");
                  if (var12 != null) {
                     String var7 = var12.optString("configName", "Imported");
                     String var8 = "Unknown";
                     JSONObject var9 = var12.optJSONObject("configData");
                     if (var9 != null) {
                        JSONObject var10 = var9.optJSONObject("metadata");
                        if (var10 != null) {
                           var8 = var10.optString("author", "Unknown");
                        }
                     }

                     CloudConfigService.ConfigMeta var13 = new CloudConfigService.ConfigMeta();
                     var13.b = var7;
                     var13.c = var8;
                     var13.e = 1;
                     var13.d = false;
                     var13.g = System.currentTimeMillis();
                     var13.f = System.currentTimeMillis();
                     this.i.put(var7, var13);
                     if (var2 != null) {
                        this.b(var2);
                     }
                  }
               } else {
                  String var6 = var5 != null ? var5.optString("error", "Unknown error") : "No response";
                  if (var3 != null) {
                     this.b(() -> var3.accept(var6));
                  }
               }
            } catch (Exception var11) {
               Pulse.m().error("CloudConfigService: Failed to activate share key", (Throwable)var11);
               if (var3 != null) {
                  this.b(() -> var3.accept(var11.getMessage()));
               }
            }
         });
      }
   }

   public List<CloudConfigService.PremiumConfigMeta> a() {
      return new ArrayList<>(this.j);
   }

   public void a(int var1, Consumer<ConfigData> var2, Consumer<String> var3) {
      if (!this.j()) {
         if (var3 != null) {
            this.b(() -> var3.accept("Not connected"));
         }
      } else {
         this.h.f.execute(() -> {
            try {
               JSONObject var4 = new JSONObject();
               var4.put("configId", var1);
               JSONObject var5 = this.h.a(g, 0, var4);
               if (var5 != null && var5.optBoolean("ok", false)) {
                  JSONObject var10 = var5.optJSONObject("data");
                  if (var10 != null && var10.has("configData")) {
                     JSONObject var7 = var10.getJSONObject("configData");
                     ConfigData var8 = ConfigSerializer.a(var7.toString());
                     if (var2 != null) {
                        this.b(() -> var2.accept(var8));
                     }
                  } else if (var3 != null) {
                     this.b(() -> var3.accept("No config data in response"));
                  }
               } else {
                  String var6 = var5 != null ? var5.optString("error", "Unknown error") : "No response";
                  if (var3 != null) {
                     this.b(() -> var3.accept(var6));
                  }
               }
            } catch (Exception var9) {
               Pulse.m().error("CloudConfigService: Failed to apply premium config", (Throwable)var9);
               if (var3 != null) {
                  this.b(() -> var3.accept(var9.getMessage()));
               }
            }
         });
      }
   }

   public void a(Runnable var1) {
      this.p = var1;
   }

   public void a(JSONArray var1) {
      this.j.clear();

      for (int var2 = 0; var2 < var1.length(); var2++) {
         JSONObject var3 = var1.getJSONObject(var2);
         CloudConfigService.PremiumConfigMeta var4 = CloudConfigService.PremiumConfigMeta.a(var3);
         this.j.add(var4);
      }

      if (this.p != null) {
         this.b(this.p);
      }
   }

   public ConfigData b() {
      return this.k;
   }

   public String c() {
      return this.l;
   }

   public int d() {
      return this.m;
   }

   public List<String> e() {
      return new ArrayList<>(this.i.keySet());
   }

   public CloudConfigService.ConfigMeta a(String var1) {
      return this.i.get(var1);
   }

   public Collection<CloudConfigService.ConfigMeta> f() {
      return this.i.values();
   }

   public boolean g() {
      return this.o;
   }

   public void h() {
      this.n = true;
   }

   public boolean i() {
      return this.n;
   }

   public void a(ConfigData var1) {
      this.k = var1;
   }

   public boolean b(ConfigData var1) {
      if (!this.j()) {
         return false;
      } else {
         try {
            String var2 = this.l != null ? this.l : "Default";
            JSONObject var3 = new JSONObject();
            var3.put("name", var2);
            var3.put("baseVersion", this.m);
            var3.put("data", new JSONObject(ConfigSerializer.a(var1)));
            JSONObject var4 = this.h.a(a, 0, var3);
            if (var4 != null && var4.optBoolean("ok", false)) {
               JSONObject var5 = var4.optJSONObject("data");
               if (var5 != null && var5.has("newVersion")) {
                  this.m = var5.getInt("newVersion");
               }

               this.n = false;
               return true;
            } else {
               return false;
            }
         } catch (Exception var6) {
            return false;
         }
      }
   }

   public void a(int var1) {
      this.m = var1;
   }

   private boolean j() {
      return this.h.a() && this.h.w() != null && this.h.u() != null;
   }

   private void b(Runnable var1) {
      MinecraftClient.getInstance().execute(var1);
   }

   @Environment(EnvType.CLIENT)
   public static class ConfigMeta {
      public int a;
      public String b;
      public String c;
      public boolean d;
      public int e;
      public long f;
      public long g;

      public static CloudConfigService.ConfigMeta a(JSONObject var0) {
         CloudConfigService.ConfigMeta var1 = new CloudConfigService.ConfigMeta();
         var1.a = var0.optInt("id", 0);
         var1.b = var0.optString("name", "");
         var1.c = var0.optString("author", "Unknown");
         var1.d = var0.optBoolean("isActive", false);
         var1.e = var0.optInt("version", 1);
         var1.f = var0.optLong("updatedAt", System.currentTimeMillis());
         var1.g = var0.optLong("createdAt", System.currentTimeMillis());
         return var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class PremiumConfigMeta {
      public int a;
      public String b;
      public String c;
      public String d;
      public String e;
      public int f;
      public long g;

      public static CloudConfigService.PremiumConfigMeta a(JSONObject var0) {
         CloudConfigService.PremiumConfigMeta var1 = new CloudConfigService.PremiumConfigMeta();
         var1.a = var0.optInt("id", 0);
         var1.b = var0.optString("creatorName", "Unknown");
         var1.c = var0.optString("name", "");
         var1.d = var0.optString("description", "");
         var1.e = var0.optString("previewImageUrl", null);
         var1.f = var0.optInt("downloadsCount", 0);
         var1.g = var0.optLong("purchasedAt", System.currentTimeMillis());
         return var1;
      }
   }
}
