package pulse.features.modules.hud.components;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.hud.HudItemSpriteRenderer;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.game.CooldownUtil;

@Environment(EnvType.CLIENT)
public class CooldownsComponent extends DraggableComponent {
   private static final Color m = new Color(13, 13, 17);
   private static final Color n = new Color(17, 17, 23);
   private static final Color o = new Color(255, 255, 255);
   private static final Color p = new Color(223, 223, 243);
   private static final Color q = new Color(20, 20, 28);
   private static final Color r = new Color(16, 16, 21);
   private static final Color s = new Color(17, 17, 23);
   private static final Color t = new Color(23, 23, 30);
   private static final Color u = new Color(18, 18, 24);
   private static final Color v = new Color(115, 83, 255);
   private static final Color w = new Color(70, 46, 174);
   private static final float x = 8.5F;
   private static final float y = 8.0F;
   private static final float z = 24.0F;
   private static final float A = 16.0F;
   private static final float B = 5.0F;
   private static final float C = 10.0F;
   private static final float D = 2.5F;
   private static final float E = 12.0F;
   private static final float F = 2.0F;
   private static final float G = 12.0F;
   private static final float H = 6.0F;
   private static final float I = 6.5F;
   private static final float J = 0.5F;
   private static final float K = 100.0F;
   private static final double L = 0.20000000782532884;
   private static final long M = 1000L;
   private final Map<Item, CooldownsComponent.AnimatedCooldownData> N = new LinkedHashMap<>();
   private final List<CooldownsComponent.DemoCooldownData> O = new ArrayList<>();
   private final Animation P = new Animation();
   private final Animation Q = new Animation();
   private final Animation R = new Animation();
   private long S = 0L;
   private int T = 0;
   private boolean U = false;
   private boolean V = false;
   private boolean W = false;

   public CooldownsComponent(float var1, float var2) {
      super(var1, var2);
      this.R.d(0.0);
      this.v();
      this.a();
   }

   private void v() {
      this.O.add(new CooldownsComponent.DemoCooldownData(Items.ENDER_PEARL, "Ender Pearl", "0:00"));
      this.O.add(new CooldownsComponent.DemoCooldownData(Items.CHORUS_FRUIT, "Chorus Fruit", "0:00"));
      this.O.add(new CooldownsComponent.DemoCooldownData(Items.ENDER_EYE, "Дезка", "0:00"));
   }

   private boolean w() {
      return this.a.currentScreen instanceof ChatScreen && this.y().isEmpty();
   }

   private void x() {
      if (!this.W) {
         if (ModuleRegistry.aC != null) {
            this.f().a(ModuleRegistry.aC);
            this.W = true;
         }
      }
   }

   @Override
   protected void a() {
      this.x();
      boolean var1 = this.w();
      List<CooldownsComponent.CooldownData> var2 = this.y();
      float var3 = this.g();
      float var4 = 8.5F * var3;
      float var5 = 8.0F * var3;
      float var6 = 24.0F * var3;
      float var7 = 5.0F * var3;
      float var8 = 10.0F * var3;
      float var9 = 2.5F * var3;
      float var10 = 12.0F * var3;
      float var11 = 2.0F * var3;
      float var12 = 6.5F * var3;
      float var13 = 0.5F * var3;
      float var14 = 100.0F * var3;
      int var15 = Math.round(15.0F * var3);
      int var16 = Math.round(14.0F * var3);
      FontRenderer var17 = Fonts.a[Math.max(10, Math.min(48, var15))];
      FontRenderer var18 = Fonts.a[Math.max(10, Math.min(48, var16))];
      if (var1) {
         long var19 = System.currentTimeMillis();
         if (var19 - this.S >= 1000L) {
            this.T = (this.T + 1) % this.O.size();
            this.S = var19;
         }
      }

      HashSet var29 = new HashSet<>();

      for (CooldownsComponent.CooldownData var21 : var2) {
         var29.add(var21.a);
      }

      for (CooldownsComponent.AnimatedCooldownData var32 : this.N.values()) {
         if (!var29.contains(var32.a) && !var32.h) {
            var32.h = true;
            var32.f.a(0.0, 0.20000000782532884, Easings.h);
         }
      }

      int var31 = 0;

      for (CooldownsComponent.CooldownData var22 : var2) {
         CooldownsComponent.AnimatedCooldownData var23 = this.N.get(var22.a);
         if (var23 == null) {
            var23 = new CooldownsComponent.AnimatedCooldownData(var22.a, var22.b, var22.c, var22.d, var22.e);
            var23.f.d(0.0);
            var23.f.a(1.0, 0.20000000782532884, Easings.h);
            var23.g.d(var31);
            this.N.put(var22.a, var23);
         } else {
            var23.b = var22.b;
            var23.c = var22.c;
            var23.d = var22.d;
            var23.e = var22.e;
            var23.h = false;
            if (var23.f.i() < 1.0) {
               var23.f.a(1.0, 0.20000000782532884, Easings.h);
            }

            if (Math.abs(var23.g.i() - var31) > 0.010000001415674692) {
               var23.g.a(var31, 0.20000000782532884, Easings.h);
            }
         }

         var31++;
      }

      this.N.entrySet().removeIf(var0 -> var0.getValue().h && var0.getValue().f.j() < 0.010000001415674692);

      for (CooldownsComponent.AnimatedCooldownData var36 : this.N.values()) {
         var36.f.a();
         var36.g.a();
      }

      boolean var35 = this.V;
      this.V = false;
      int var37 = 0;
      if (var1) {
         this.V = true;
         var37 = 1;
      } else {
         for (CooldownsComponent.AnimatedCooldownData var24 : this.N.values()) {
            if (!var24.h) {
               this.V = true;
               var37++;
            }
         }
      }

      if (this.V && !var35) {
         this.R.a(1.0, 0.20000000782532884, Easings.h);
      } else if (!this.V && var35) {
         this.R.a(0.0, 0.20000000782532884, Easings.h);
      } else if (this.V && this.R.i() < 1.0) {
         this.R.a(1.0, 0.20000000782532884, Easings.h);
      }

      this.R.a();
      float var40 = 0.0F;
      if (var1) {
         CooldownsComponent.DemoCooldownData var41 = this.O.get(this.T);
         float var25 = var17.a(var41.b);
         float var26 = var18.a(var41.c) + var12 * 2.0F + var13 * 2.0F;
         var40 = var8 + var9 + var25 + var9 * 2.0F + var26;
      } else {
         for (CooldownsComponent.AnimatedCooldownData var44 : this.N.values()) {
            if (!var44.h) {
               float var46 = var17.a(var44.c);
               float var27 = var18.a(var44.d) + var12 * 2.0F + var13 * 2.0F;
               float var28 = var8 + var9 + var46 + var9 * 2.0F + var27;
               var40 = Math.max(var40, var28);
            }
         }
      }

      float var43 = Math.max(var14, var40);
      float var45 = var4 * 2.0F + var43;
      float var47 = 1.0F * var3;
      float var48 = var37 == 0 ? 0.0F : var37 * var10 + (var37 - 1) * var11;
      float var49 = var6 + var47 + var7 + var48 + var7 + 2.0F * var3;
      if (!this.U) {
         this.Q.d(var45);
         this.P.d(var49);
         this.U = true;
      } else {
         if (Math.abs(this.Q.i() - var45) > 0.5) {
            this.Q.a(var45, 0.20000000782532884, Easings.h);
         }

         if (Math.abs(this.P.i() - var49) > 0.5) {
            this.P.a(var49, 0.20000000782532884, Easings.h);
         }
      }

      this.Q.a();
      this.P.a();
      this.d = (float)this.Q.j();
      this.e = (float)this.P.j();
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (this.a.player != null) {
         this.a();
         float var5 = (float)this.R.j();
         if (!(var5 < 0.01F)) {
            boolean var6 = this.w();
            float var7 = this.g();
            float var8 = 8.5F * var7;
            float var9 = 8.0F * var7;
            float var10 = 24.0F * var7;
            float var11 = 16.0F * var7;
            float var12 = 5.0F * var7;
            float var13 = 10.0F * var7;
            float var14 = 2.5F * var7;
            float var15 = 12.0F * var7;
            float var16 = 2.0F * var7;
            float var17 = 12.0F * var7;
            float var18 = 6.0F * var7;
            float var19 = 6.5F * var7;
            float var20 = 0.5F * var7;
            int var21 = Math.round(16.0F * var7);
            int var22 = Math.round(15.0F * var7);
            int var23 = Math.round(14.0F * var7);
            boolean var24 = var5 < 0.99F;
            if (var24) {
               var2.c(this.b, this.c, this.d, this.e, var1);
            }

            float var25 = var24 ? 1.0F : var5;
            FontRenderer var26 = Fonts.b[Math.max(10, Math.min(48, var21))];
            FontRenderer var27 = Fonts.a[Math.max(10, Math.min(48, var22))];
            FontRenderer var28 = Fonts.a[Math.max(10, Math.min(48, var23))];
            Color var29 = this.a(m, var25);
            Color var30 = this.a(n, var25);
            var2.a(this.b, this.c, this.d, this.e, var9, var29, var29, var30, var30, var1);
            float var31 = this.b + var8;
            float var32 = this.c + var10 / 2.0F;
            int var33 = Math.round(22.0F * var7);
            FontRenderer var34 = Fonts.d[Math.max(12, Math.min(48, var33))];
            float var35 = var34.a("\ue906");
            float var36 = var34.b("\ue906");
            float var37 = var31 + (var11 - var35) / 2.0F - 4.0F;
            float var38 = var32 - var36 / 4.0F + 0.5F;
            var34.a("\ue906", var37, var38, this.a(v, var25), this.a(w, var25), var1);
            float var39 = var32 - var26.b("Cooldowns") / 4.0F + 1.0F * var7;
            var26.a("Cooldowns", var31 + var11 - 2.0F * var7, var39, this.a(o, var25), var1);
            float var40 = this.c + var10;
            var2.a(this.b, var40, this.d, 1.0F * var7, 0.0F, this.a(q, var25), var1);
            float var41 = var40 + 1.0F * var7;
            float var42 = this.e - var10 - 1.0F * var7;
            var2.a().a(this.b, var41, this.d, var42, 0.0F, var1);
            float var43 = var40 + 1.0F * var7 + var12;
            if (var6) {
               CooldownsComponent.DemoCooldownData var44 = this.O.get(this.T);
               this.a(var1, var2, var27, var28, var31, var43, var44, var25, var7);
            } else {
               for (CooldownsComponent.AnimatedCooldownData var45 : this.N.values()) {
                  float var46 = (float)var45.f.j();
                  float var47 = var24 ? var46 : var46 * var5;
                  if (!(var47 < 0.01F)) {
                     float var48 = (float)var45.g.j();
                     float var49 = var43 + var48 * (var15 + var16);
                     this.a(var1, var2, var27, var28, var31, var49, var45, var47, var7);
                  }
               }
            }

            var2.a().a(var1);
            if (var24) {
               var2.a(var5, var1);
            }
         }
      }
   }

   private void a(
      MatrixStack var1,
      Render var2,
      FontRenderer var3,
      FontRenderer var4,
      float var5,
      float var6,
      CooldownsComponent.DemoCooldownData var7,
      float var8,
      float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 10.0F * var9;
      float var12 = 2.5F * var9;
      float var13 = 8.5F * var9;
      float var14 = 6.5F * var9;
      float var15 = 0.5F * var9;
      float var16 = 12.0F * var9;
      float var17 = 6.0F * var9;
      float var18 = var6 + var10 / 2.0F;
      Color var19 = this.a(p, var8);
      float var20 = var18 - var11 / 2.0F;
      this.a(var1, var2, new ItemStack(var7.a), var5, var20, var11, var8);
      float var22 = var18 - var3.b(var7.b) / 4.0F;
      var3.a(var7.b, var5 + var11 + var12, var22, var19, var1);
      float var23 = var4.a(var7.c) + var14 * 2.0F + var15 * 2.0F - 2.0F * var9;
      float var24 = this.b + this.d - var13 - var23;
      float var25 = var18 - var16 / 2.0F - var15;
      float var26 = var16 + var15 * 2.0F;
      Color var27 = this.a(t, var8);
      Color var28 = this.a(u, var8);
      Color var29 = this.a(r, var8);
      Color var30 = this.a(s, var8);
      var2.a(var24, var25, var23, var26, var17, var27, var27, var28, var28, var1);
      var2.a(var24 + var15, var25 + var15, var23 - var15 * 2.0F, var16, var17 - var15, var29, var29, var30, var30, var1);
      float var31 = var18 - var4.b(var7.c) / 4.0F;
      float var32 = var24 + (var23 - var4.a(var7.c)) / 2.0F;
      var4.a(var7.c, var32, var31, var19, var1);
   }

   private void a(
      MatrixStack var1,
      Render var2,
      FontRenderer var3,
      FontRenderer var4,
      float var5,
      float var6,
      CooldownsComponent.AnimatedCooldownData var7,
      float var8,
      float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 10.0F * var9;
      float var12 = 2.5F * var9;
      float var13 = 8.5F * var9;
      float var14 = 6.5F * var9;
      float var15 = 0.5F * var9;
      float var16 = 12.0F * var9;
      float var17 = 6.0F * var9;
      float var18 = var6 + var10 / 2.0F;
      Color var19 = this.a(p, var8);
      float var20 = var18 - var11 / 2.0F;
      this.a(var1, var2, var7.b, var5, var20, var11, var8);
      float var22 = var18 - var3.b(var7.c) / 4.0F;
      var3.a(var7.c, var5 + var11 + var12, var22, var19, var1);
      float var23 = var4.a(var7.d) + var14 * 2.0F + var15 * 2.0F - 2.0F * var9;
      float var24 = this.b + this.d - var13 - var23;
      float var25 = var18 - var16 / 2.0F - var15;
      float var26 = var16 + var15 * 2.0F;
      Color var27 = this.a(t, var8);
      Color var28 = this.a(u, var8);
      Color var29 = this.a(r, var8);
      Color var30 = this.a(s, var8);
      var2.a(var24, var25, var23, var26, var17, var27, var27, var28, var28, var1);
      var2.a(var24 + var15, var25 + var15, var23 - var15 * 2.0F, var16, var17 - var15, var29, var29, var30, var30, var1);
      float var31 = var18 - var4.b(var7.d) / 4.0F;
      float var32 = var24 + (var23 - var4.a(var7.d)) / 2.0F;
      var4.a(var7.d, var32, var31, var19, var1);
   }

   private void a(MatrixStack var1, Render var2, ItemStack var3, float var4, float var5, float var6, float var7) {
      if (!(var7 < 0.01F)) {
         HudItemSpriteRenderer.a(var2, var1, var3, var4, var5, var6, var7);
      }
   }

   private Color a(Color var1, float var2) {
      int var3 = Math.max(0, Math.min(255, (int)(var1.getAlpha() * var2)));
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var3);
   }

   private List<CooldownsComponent.CooldownData> y() {
      ArrayList<CooldownsComponent.CooldownData> var1 = new ArrayList<>();
      if (this.a.player == null) {
         return var1;
      } else {
         HashSet var2 = new HashSet<>();

         for (int var3 = 0; var3 < this.a.player.getInventory().size(); var3++) {
            ItemStack var4 = this.a.player.getInventory().getStack(var3);
            if (!var4.isEmpty()) {
               Item var5 = var4.getItem();
               if (!var2.contains(var5)) {
                  CooldownUtil.CooldownInfo var6 = CooldownUtil.a(this.a.player.getItemCooldownManager(), var5);
                  if (var6.a()) {
                     var2.add(var5);
                     int var7 = var6.c - var6.a;
                     String var8 = this.b(var7);
                     String var9 = this.a(var4);
                     var1.add(new CooldownsComponent.CooldownData(var5, var4, var9, var8, var7));
                  }
               }
            }
         }

         var1.sort(Comparator.comparingInt(var0 -> var0.e));
         return var1;
      }
   }

   private String a(ItemStack var1) {
      return var1.getName().getString();
   }

   private String b(int var1) {
      if (var1 <= 0) {
         return "0.0s";
      } else {
         float var2 = var1 / 20.0F;
         return String.format("%.1fs", var2);
      }
   }

   @Environment(EnvType.CLIENT)
   private static class AnimatedCooldownData {
      final Item a;
      ItemStack b;
      String c;
      String d;
      int e;
      final Animation f = new Animation();
      final Animation g = new Animation();
      boolean h = false;

      AnimatedCooldownData(Item var1, ItemStack var2, String var3, String var4, int var5) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class CooldownData {
      final Item a;
      final ItemStack b;
      final String c;
      final String d;
      final int e;

      CooldownData(Item var1, ItemStack var2, String var3, String var4, int var5) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class DemoCooldownData {
      final Item a;
      final String b;
      final String c;

      DemoCooldownData(Item var1, String var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
