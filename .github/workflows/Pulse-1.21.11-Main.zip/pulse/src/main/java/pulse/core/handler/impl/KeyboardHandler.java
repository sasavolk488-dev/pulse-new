package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.menu.markers.MarkerEntry;
import pulse.ui.clickgui.menu.markers.MarkerManager;
import pulse.core.event.impl.KeyEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;

@HandlerInfo
@Environment(EnvType.CLIENT)
public class KeyboardHandler extends Handler {
   private static final double a = 500.0;

   @EventHandler
   @Compile
   public void a(KeyEvent var1) {
      if (var1.c() != 1) {
         return;
      }
      MinecraftClient client = MinecraftClient.getInstance();
      if (pulse.utils.input.KeyBindings.a(var1.a(), var1.b(), var1.d())) {
         var screen = client.currentScreen;
         if (client.currentScreen instanceof pulse.ui.clickgui.ClickGuiScreen) {
            if (pulse.ui.clickgui.common.OverlayElement.a().b()) {
               ((pulse.ui.clickgui.ClickGuiScreen)screen).d();
            } else {
               ((pulse.ui.clickgui.ClickGuiScreen)screen).a();
            }
            return;
         }
         if (client.currentScreen == null) {
            client.setScreen(pulse.Pulse.l().k());
            return;
         }
      }
      if (client.currentScreen != null) {
         return;
      }
      int markerKey = pulse.ui.clickgui.menu.markers.MarkerSettings.f();
      if (pulse.ui.clickgui.menu.markers.MarkerSettings.e() && markerKey != 0 && var1.a() == markerKey) {
         this.a(client);
         return;
      }
      int pingKey = pulse.ui.clickgui.menu.markers.MarkerSettings.b();
      if (pulse.ui.clickgui.menu.markers.MarkerSettings.a() && pingKey != 0 && var1.a() == pingKey) {
         pulse.core.handler.HandlerRegistry.k.d();
         return;
      }
      for (pulse.features.modules.Module module : pulse.features.modules.ModuleRegistry.b()) {
         if (module.j() != 0 && module.j() == var1.a()) {
            module.d();
         }
      }
   }

   private void a(MinecraftClient var1) {
      if (var1.player != null && var1.world != null) {
         Vec3d var2 = var1.player.getCameraPosVec(1.0F);
         Vec3d var3 = var1.player.getRotationVec(1.0F);
         Vec3d var4 = var2.add(var3.multiply(500.0));
         BlockHitResult var5 = var1.world.raycast(new RaycastContext(var2, var4, ShapeType.OUTLINE, FluidHandling.NONE, var1.player));
         if (var5.getType() == Type.BLOCK) {
            BlockPos var6 = var5.getBlockPos();
            MarkerEntry var7 = new MarkerEntry("Быстрая метка", var6.getX(), var6.getY(), var6.getZ(), ClickGuiColors.X, MarkerEntry.IconType.c);
            MarkerManager.a(var7);
         }
      }
   }

   static {
      NativeMethodLookup.lookup(KeyboardHandler.class, 26);
   }
}
