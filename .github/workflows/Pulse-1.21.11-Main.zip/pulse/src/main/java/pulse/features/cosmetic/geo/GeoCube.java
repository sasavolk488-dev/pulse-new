package pulse.features.cosmetic.geo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GeoCube {
   public GeoQuad[] a = new GeoQuad[6];
   public Vec3F b;
   public Vec3F c;
   public Vec3F d;
   public float e;
   public boolean f;

   public GeoCube(float var1, float var2, float var3) {
      this.b = new Vec3F(var1, var2, var3);
      this.c = new Vec3F(0.0F, 0.0F, 0.0F);
      this.d = new Vec3F(0.0F, 0.0F, 0.0F);
      this.e = 0.0F;
      this.f = false;
   }
}
