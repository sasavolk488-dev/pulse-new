package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.NarratorMode;
import net.minecraft.client.util.NarratorManager;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({NarratorManager.class})
public class NarratorManagerMixin {
   @Inject(
      method = {"narrateChatMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableNarrateChatMessage(Text var1, CallbackInfo var2) {
      var2.cancel();
   }

   @Inject(
      method = {"narrate"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableNarrate(Text var1, CallbackInfo var2) {
      var2.cancel();
   }

   @Inject(
      method = {"narrateSystemMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableNarrateSystemMessage(Text var1, CallbackInfo var2) {
      var2.cancel();
   }

   @Inject(
      method = {"narrateSystemImmediately(Lnet/minecraft/text/Text;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableNarrateSystemImmediately(Text var1, CallbackInfo var2) {
      var2.cancel();
   }

   @Inject(
      method = {"narrateSystemImmediately(Ljava/lang/String;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableNarrateSystemImmediately(String var1, CallbackInfo var2) {
      var2.cancel();
   }

   @Inject(
      method = {"onModeChange"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableModeChangeToast(NarratorMode var1, CallbackInfo var2) {
      var2.cancel();
   }

   @Inject(
      method = {"isActive"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$forceInactive(CallbackInfoReturnable<Boolean> var1) {
      var1.setReturnValue(false);
   }

   @Inject(
      method = {"clear"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableClear(CallbackInfo var1) {
      var1.cancel();
   }

   @Inject(
      method = {"checkNarratorLibrary"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableLibraryCheck(boolean var1, CallbackInfo var2) {
      var2.cancel();
   }
}
