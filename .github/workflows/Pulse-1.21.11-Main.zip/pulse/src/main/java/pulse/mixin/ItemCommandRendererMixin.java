package pulse.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.ItemCommandRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl.ItemCommand;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.utils.render.vertex.PulseTintedItemCommand;
import pulse.utils.render.vertex.TintVertexConsumerProvider;

@Environment(EnvType.CLIENT)
@Mixin({ItemCommandRenderer.class})
public abstract class ItemCommandRendererMixin {
   @Redirect(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/ItemRenderer;renderItem(Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II[ILjava/util/List;Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/render/item/ItemRenderState$Glint;)V",
         ordinal = 0
      )
   )
   private void pulse$tintMaceItem(
      ItemDisplayContext var1,
      MatrixStack var2,
      VertexConsumerProvider var3,
      int var4,
      int var5,
      int[] var6,
      List<BakedQuad> var7,
      RenderLayer var8,
      Glint var9,
      @Local ItemCommand var10
   ) {
      int var11 = ((PulseTintedItemCommand)(Object)var10).pulse$getTint();
      if (var11 != 0) {
         float var12 = (var11 >> 16 & 0xFF) / 255.0F;
         float var13 = (var11 >> 8 & 0xFF) / 255.0F;
         float var14 = (var11 & 0xFF) / 255.0F;
         var3 = new TintVertexConsumerProvider((VertexConsumerProvider)var3, var12, var13, var14, 1.0F);
      }

      ItemRenderer.renderItem(var1, var2, (VertexConsumerProvider)var3, var4, var5, var6, var7, var8, var9);
   }
}
