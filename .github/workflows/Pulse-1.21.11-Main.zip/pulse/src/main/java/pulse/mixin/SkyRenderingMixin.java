package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.SkyboxRenderEvent;

@Environment(EnvType.CLIENT)
@Mixin({SkyRendering.class})
public abstract class SkyRenderingMixin {
   @Inject(
      method = {"renderTopSky"},
      at = {@At("TAIL")}
   )
   private void pulse$drawSkybox(int var1, CallbackInfo var2) {
      EventHandler.a.post(new SkyboxRenderEvent());
   }
}
