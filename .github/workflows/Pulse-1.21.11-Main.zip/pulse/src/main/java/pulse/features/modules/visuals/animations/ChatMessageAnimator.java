package pulse.features.modules.visuals.animations;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.utils.animation.util.Easing;
import pulse.utils.animation.util.Easings;

@Environment(EnvType.CLIENT)
public class ChatMessageAnimator {
   private float a;
   private float b;
   private float c;
   private long d = 0L;
   private long e = 200L;
   private final Easing f = Easings.h;

   public ChatMessageAnimator(float var1, float var2, long var3) {
      this.a = var1;
      this.b = var1;
      this.c = var2;
      this.e = Math.max(1L, var3);
      this.d = System.currentTimeMillis();
   }

   public void a() {
      if (this.d != 0L) {
         long var1 = System.currentTimeMillis();
         double var3 = var1 - this.d;
         double var5 = this.e;
         if (var3 >= var5) {
            this.a = this.c;
            this.d = 0L;
         } else {
            double var7 = var3 / var5;
            double var9 = this.f.ease(var7);
            this.a = (float)(this.b + (this.c - this.b) * var9);
         }
      }
   }

   public float b() {
      return this.a;
   }

   public boolean c() {
      return this.d != 0L;
   }

   public boolean d() {
      return this.d == 0L && this.a == this.c;
   }
}
