package pulse.features.modules.utilities.ft;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class StructureSignatures {
   private static final List<StructureSignature> a = b();

   private StructureSignatures() {
   }

   public static List<StructureSignature> a() {
      return a;
   }

   private static List<StructureSignature> b() {
      ArrayList var0 = new ArrayList();
      var0.add(
         a(
            "trap_quad_30s",
            FunTimeItemType.a,
            30000L,
            a("entity.wither.break_block", 0.5F, 1.0F),
            a("entity.evoker_fangs.attack", 0.5F, 0.85F),
            a("ui.toast.challenge_complete", 0.35F, 1.5F),
            a("entity.ender_dragon.growl", 0.2F, 1.5F)
         )
      );
      var0.add(
         a(
            "plast_quad_20s",
            FunTimeItemType.b,
            20000L,
            a("entity.wither.break_block", 0.7F, 1.0F),
            a("entity.evoker_fangs.attack", 0.5F, 0.85F),
            a("ui.toast.challenge_complete", 0.35F, 1.5F),
            a("entity.ender_dragon.growl", 0.2F, 1.5F)
         )
      );
      var0.add(
         a(
            "trap_triple_15s",
            FunTimeItemType.a,
            15000L,
            a("entity.wither.ambient", 0.7F, 0.5F),
            a("entity.zombie_villager.converted", 0.55F, 0.85F),
            a("entity.ender_dragon.hurt", 0.6F, 0.5F)
         )
      );
      var0.add(a("trap_wither_dragon_15s", FunTimeItemType.a, 15000L, a("entity.wither.break_block", 0.7F, 1.0F), a("entity.ender_dragon.hurt", 0.6F, 0.5F)));
      var0.add(a("trap_piston_dragon_15s", FunTimeItemType.a, 15000L, a("entity.ender_dragon.hurt", 0.6F, 0.5F), a("block.piston.extend", 0.6F, 0.5F)));
      var0.add(a("trap_piston_15s", FunTimeItemType.a, 15000L, a("block.piston.extend", 0.7F, 0.5F)));
      var0.add(
         a(
            "trap_blaze_ghast_piston_15s",
            FunTimeItemType.a,
            15000L,
            a("entity.blaze.shoot", 0.7F, 1.0F),
            a("entity.ghast.hurt", 0.6F, 0.5F),
            a("block.piston.contract", 0.45F, 0.5F)
         )
      );
      var0.add(
         a(
            "trap_blaze_dragon_shulker_15s",
            FunTimeItemType.a,
            15000L,
            a("entity.blaze.hurt", 0.7F, 0.5F),
            a("entity.ender_dragon.flap", 0.7F, 0.85F),
            a("block.shulker_box.close", 0.6F, 1.5F)
         )
      );
      var0.add(
         a(
            "trap_beacon_phantom_dragon_15s",
            FunTimeItemType.a,
            15000L,
            a("block.beacon.power_select", 0.7F, 1.0F),
            a("entity.phantom.ambient", 0.6F, 0.5F),
            a("entity.ender_dragon.hurt", 0.55F, 0.5F)
         )
      );
      var0.add(
         a(
            "trap_netherite_piston_skeleton_15s",
            FunTimeItemType.a,
            15000L,
            a("item.armor.equip_netherite", 0.7F, 0.5F),
            a("block.piston.contract", 0.45F, 1.5F),
            a("entity.skeleton.death", 0.45F, 0.5F)
         )
      );
      var0.add(
         a(
            "trap_piston_evoker_dragon_15s",
            FunTimeItemType.a,
            15000L,
            a("block.piston.extend", 0.7F, 0.5F),
            a("entity.evoker.cast_spell", 0.7F, 0.85F),
            a("entity.ender_dragon.hurt", 0.6F, 0.5F)
         )
      );
      var0.add(
         a(
            "trap_lightning_blaze_lava_15s",
            FunTimeItemType.a,
            15000L,
            a("entity.lightning_bolt.impact", 0.25F, 0.75F),
            a("entity.blaze.shoot", 0.6F, 0.75F),
            a("block.lava.pop", 0.7F, 0.5F)
         )
      );
      var0.add(
         a(
            "trap_enderman_dragon_shulker_15s",
            FunTimeItemType.a,
            15000L,
            a("entity.enderman.ambient", 0.7F, 0.5F),
            a("entity.ender_dragon.flap", 0.7F, 0.85F),
            a("block.shulker_box.close", 0.6F, 0.5F)
         )
      );
      var0.add(a("trap_netherite_piston_15s", FunTimeItemType.a, 15000L, a("item.armor.equip_netherite", 0.35F, 0.65F), a("block.piston.extend", 0.45F, 0.75F)));
      var0.add(a("trap_glass_snow_15s", FunTimeItemType.a, 15000L, a("block.glass.break", 0.7F, 2.0F), a("block.snow.break", 0.2F, 1.5F)));
      var0.add(a("trap_thunder_phantom_15s", FunTimeItemType.a, 15000L, a("entity.lightning_bolt.thunder", 0.7F, 1.0F), a("entity.phantom.death", 0.6F, 0.5F)));
      var0.add(a("plast_anvil_20s", FunTimeItemType.b, 20000L, a("block.anvil.place", 0.7F, 1.1F)));
      var0.sort(Comparator.comparingInt(StructureSignature::a).reversed());
      return List.copyOf(var0);
   }

   private static StructureSignature a(String var0, FunTimeItemType var1, long var2, SoundSignature... var4) {
      return new StructureSignature(var0, var1, var2, List.of(var4));
   }

   private static SoundSignature a(String var0, float var1, float var2) {
      return new SoundSignature(Identifier.ofVanilla(var0), SoundCategory.RECORDS, var1, var2);
   }
}
