package pulse.core.event.impl;

import java.util.UUID;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class PlayerJoinEvent extends Event {
   private final String a;
   private final UUID b;

   @Generated
   public String a() {
      return this.a;
   }

   @Generated
   public UUID b() {
      return this.b;
   }

   @Generated
   public PlayerJoinEvent(String var1, UUID var2) {
      this.a = var1;
      this.b = var2;
   }
}
