package pulse.features.modules.utilities;

import java.awt.Color;
import java.util.ArrayList;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.features.modules.utilities.ft.RegionSize;
import pulse.utils.render.Fonts;
import pulse.utils.render.font.FontRenderer;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.RegionListSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.RenderUtils;
import pulse.utils.render.ScreenUtils;

@ModuleInfo(
   a = "FT Regions",
   b = "Зоны регионов FunTime по заданным координатам",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FunTimeRegionsModule extends Module {
   private final RegionListSetting a = new RegionListSetting("Регионы");
   private final SeparatorSetting b = new SeparatorSetting("Отображение");
   private final BooleanSetting c = new BooleanSetting("Предпросмотр установки", true);
   private final BooleanSetting f = new BooleanSetting("Подписи размера", true);
   private final SeparatorSetting g = new SeparatorSetting("Цвет");
   private final BooleanSetting h = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting i = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.h.q());

   @EventHandler
   public void a(RenderEvent var1) {
      if (d.world != null && d.player != null) {
         MatrixStack var2 = var1.a();
         int var3 = this.o().getRGB();

         for (RegionListSetting.Entry var5 : this.a.b()) {
            RenderUtils.a(var2, this.a(this.a(var5)), var3);
         }

         FunTimeRegionsModule.Zone var6 = this.n();
         if (var6 != null) {
            RenderUtils.a(var2, this.a(var6), var3);
            RenderUtils.b(var2, this.a(var6.pos()), var3);
         }
      }
   }

   @EventHandler
   public void a(RenderHudPostEvent var1) {
      if (d.world != null && d.player != null) {
         if (this.f.q()) {
            ArrayList<FunTimeRegionsModule.Zone> var2 = new ArrayList<>();

            for (RegionListSetting.Entry var4 : this.a.b()) {
               var2.add(this.a(var4));
            }

            FunTimeRegionsModule.Zone var14 = this.n();
            if (var14 != null) {
               var2.add(var14);
            }

            if (!var2.isEmpty()) {
               FontRenderer var15 = Fonts.b[12];
               Color var5 = this.o();
               Color var6 = ClickGuiColors.a(ClickGuiColors.ab, 160);

               for (FunTimeRegionsModule.Zone var8 : var2) {
                  Vec3d var9 = new Vec3d(var8.pos().getX() + 0.5, var8.pos().getY() + 0.5, var8.pos().getZ() + 0.5);
                  Vec3d var10 = ScreenUtils.a(var9);
                  if (var10 != null && ScreenUtils.b(var10)) {
                     String var11 = var8.radius() + "x" + var8.radius();
                     float var12 = a((float)var10.x - var15.a(var11) / 2.0F);
                     float var13 = a((float)var10.y - var15.b(var11) / 2.0F);
                     var15.a(var11, var12 + 0.5F, var13 + 0.5F, var6, var1.a());
                     var15.a(var11, var12, var13, var5, var1.a());
                  }
               }
            }
         }
      }
   }

   private FunTimeRegionsModule.Zone n() {
      if (!this.c.q()) {
         return null;
      } else {
         RegionSize var1 = RegionSize.a(d.player.getMainHandStack().getItem());
         if (var1 == null) {
            var1 = RegionSize.a(d.player.getOffHandStack().getItem());
         }

         if (var1 == null) {
            return null;
         } else if (d.crosshairTarget instanceof BlockHitResult var2 && var2.getType() == Type.BLOCK) {
            BlockPos var4 = var2.getBlockPos();
            if (!d.world.getBlockState(var4).isReplaceable()) {
               var4 = var4.offset(var2.getSide());
            }

            return new FunTimeRegionsModule.Zone(var4, var1.b());
         } else {
            return null;
         }
      }
   }

   private FunTimeRegionsModule.Zone a(RegionListSetting.Entry var1) {
      int var2 = RegionSize.a(var1.d()).b();
      return new FunTimeRegionsModule.Zone(new BlockPos(var1.a(), var1.b(), var1.c()), var2);
   }

   private Box a(FunTimeRegionsModule.Zone var1) {
      BlockPos var2 = var1.pos();
      int var3 = var1.radius();
      return new Box(
         var2.getX() - var3 + 0.010000000236923387,
         var2.getY() - var3 + 0.010000000236923387,
         var2.getZ() - var3 + 0.010000000236923387,
         var2.getX() + var3 + 1 - 0.010000000236923387,
         var2.getY() + var3 + 1 - 0.010000000236923387,
         var2.getZ() + var3 + 1 - 0.010000000236923387
      );
   }

   private Box a(BlockPos var1) {
      return new Box(var1.getX(), var1.getY(), var1.getZ(), var1.getX() + 1, var1.getY() + 1, var1.getZ() + 1);
   }

   private static float a(float var0) {
      return Math.round(var0 * 2.0F) / 2.0F;
   }

   private Color o() {
      if (this.h.q()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         if (var1 != null) {
            return var1.n();
         }
      }

      return this.i.q();
   }

   @Environment(EnvType.CLIENT)
   private record Zone(BlockPos pos, int radius) {
   }
}
