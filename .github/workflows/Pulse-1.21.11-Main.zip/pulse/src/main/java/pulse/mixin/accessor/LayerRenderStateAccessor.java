package pulse.mixin.accessor;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.json.Transformation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin(
   targets = {"net/minecraft/client/render/item/ItemRenderState$LayerRenderState"}
)
public interface LayerRenderStateAccessor {
   @Mutable
   @Accessor("quads")
   void pulse$setQuads(List<BakedQuad> var1);

   @Accessor("glint")
   void pulse$setGlint(Glint var1);

   @Accessor("glint")
   Glint pulse$getGlint();

   @Accessor("transform")
   Transformation pulse$getTransform();
}
