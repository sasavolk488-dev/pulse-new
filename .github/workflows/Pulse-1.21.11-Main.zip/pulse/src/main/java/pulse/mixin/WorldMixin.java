package pulse.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.AtmosphereModule;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({World.class})
public class WorldMixin {
   @Unique
   private AtmosphereModule pulse$weatherOverride() {
      AtmosphereModule var1 = ModuleRegistry.r;
      if (var1 == null || !var1.o()) {
         return null;
      } else {
         return (Object)this != MinecraftClient.getInstance().world ? null : var1;
      }
   }

   @Inject(
      method = {"isRaining"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsRaining(CallbackInfoReturnable<Boolean> var1) {
      RenderTweaksModule var2 = ModuleRegistry.h;
      if (var2 != null && var2.n()) {
         var1.setReturnValue(false);
      } else {
         AtmosphereModule var3 = this.pulse$weatherOverride();
         if (var3 != null) {
            var1.setReturnValue(var3.r() > 0.2F);
         }
      }
   }

   @Inject(
      method = {"isThundering"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsThundering(CallbackInfoReturnable<Boolean> var1) {
      RenderTweaksModule var2 = ModuleRegistry.h;
      if (var2 != null && var2.n()) {
         var1.setReturnValue(false);
      } else {
         AtmosphereModule var3 = this.pulse$weatherOverride();
         if (var3 != null) {
            var1.setReturnValue(var3.t() > 0.9F);
         }
      }
   }

   @Inject(
      method = {"hasRain"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onHasRain(BlockPos var1, CallbackInfoReturnable<Boolean> var2) {
      RenderTweaksModule var3 = ModuleRegistry.h;
      if (var3 != null && var3.n()) {
         var2.setReturnValue(false);
      }
   }

   @Inject(
      method = {"getRainGradient"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetRainGradient(float var1, CallbackInfoReturnable<Float> var2) {
      RenderTweaksModule var3 = ModuleRegistry.h;
      if (var3 != null && var3.n()) {
         var2.setReturnValue(0.0F);
      } else {
         AtmosphereModule var4 = this.pulse$weatherOverride();
         if (var4 != null) {
            var2.setReturnValue(var4.r());
         }
      }
   }

   @Inject(
      method = {"getThunderGradient"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetThunderGradient(float var1, CallbackInfoReturnable<Float> var2) {
      RenderTweaksModule var3 = ModuleRegistry.h;
      if (var3 != null && var3.n()) {
         var2.setReturnValue(0.0F);
      } else {
         AtmosphereModule var4 = this.pulse$weatherOverride();
         if (var4 != null) {
            var2.setReturnValue(var4.t());
         }
      }
   }

   @ModifyReturnValue(
      method = {"getTimeOfDay"},
      at = {@At("RETURN")}
   )
   private long pulse$atmosphereTime(long var1) {
      AtmosphereModule var3 = ModuleRegistry.r;
      if (var3 != null && var3.n()) {
         return (Object)this == MinecraftClient.getInstance().world ? var3.q() : var1;
      } else {
         return var1;
      }
   }
}
