package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import pulse.features.modules.visuals.animations.ChatAnimationHolder;

@Environment(EnvType.CLIENT)
@Mixin(
   targets = {"net/minecraft/client/gui/hud/ChatHud$Hud"}
)
public class ChatHudHudMixin {
   @ModifyArg(
      method = {"text"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/font/DrawnTextConsumer;text(Lnet/minecraft/client/font/Alignment;IILnet/minecraft/client/font/DrawnTextConsumer$Transformation;Lnet/minecraft/text/OrderedText;)V"
      ),
      index = 1
   )
   private int injectChatXOffset(int var1) {
      return var1 + (int)ChatAnimationHolder.a;
   }
}
