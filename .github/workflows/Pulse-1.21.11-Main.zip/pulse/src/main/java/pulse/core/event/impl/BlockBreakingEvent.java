package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.BlockPos;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class BlockBreakingEvent extends Event {
   private final BlockPos a;
   private final int b;

   @Generated
   public BlockPos a() {
      return this.a;
   }

   @Generated
   public int b() {
      return this.b;
   }

   @Generated
   public BlockBreakingEvent(BlockPos var1, int var2) {
      this.a = var1;
      this.b = var2;
   }
}
