package pulse.features.modules.hud;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Inventory HUD",
   b = "Отображает содержимое инвентаря на экране",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class InventoryHudModule extends Module {
   private final NumberSetting a = new NumberSetting("Масштаб", 1.0F, 0.8F, 2.0F, 0.1F);
   private final BooleanSetting b = new BooleanSetting("Общий фон", true);
   private final BooleanSetting c = new BooleanSetting("Фон слотов", false);

   public InventoryHudModule() {
      this.d();
   }

   @Generated
   public NumberSetting n() {
      return this.a;
   }

   @Generated
   public BooleanSetting o() {
      return this.b;
   }

   @Generated
   public BooleanSetting p() {
      return this.c;
   }
}
