package pulse.features.phrase;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import pulse.Pulse;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@Environment(EnvType.CLIENT)
public final class PhraseManager {
   private static final long b = 2600L;
   private static final long c = 700L;
   private static final long d = 1500L;
   public static final long a = 500L;
   private static final int e = 3;
   private static final long f = 15000L;
   private static final PhraseManager g = new PhraseManager();
   private final Map<Integer, PhraseManager.Phrase> h = new ConcurrentHashMap<>();
   private final List<Integer> i = new ArrayList<>();
   private volatile List<Integer> j = List.of();
   private final Map<String, PhraseManager.Bubble> k = new ConcurrentHashMap<>();
   private final ArrayDeque<Long> l = new ArrayDeque<>();

   private PhraseManager() {
   }

   public static PhraseManager a() {
      return g;
   }

   public void b() {
      this.h.clear();
      synchronized (this.i) {
         this.i.clear();
      }
   }

   public void a(int var1, String var2, String var3, Identifier var4) {
      this.h.put(var1, new PhraseManager.Phrase(var1, var2, var3, var4));
      synchronized (this.i) {
         if (!this.i.contains(var1)) {
            this.i.add(var1);
         }
      }
   }

   public void a(int var1, Identifier var2) {
      PhraseManager.Phrase var3 = this.h.get(var1);
      if (var3 != null) {
         this.h.put(var1, new PhraseManager.Phrase(var3.id(), var3.name(), var3.text(), var2));
      }
   }

   public PhraseManager.Phrase a(int var1) {
      return this.h.get(var1);
   }

   public int c() {
      return this.h.size();
   }

   public void a(Collection<Integer> var1) {
      ArrayList var2 = new ArrayList();
      synchronized (this.i) {
         for (Integer var5 : this.i) {
            if (var1.contains(var5)) {
               var2.add(var5);
            }
         }
      }

      for (Integer var9 : var1) {
         if (!var2.contains(var9)) {
            var2.add(var9);
         }
      }

      this.j = List.copyOf(var2);
      Pulse.m().info("[Phrase] надето фраз: {}", this.j.size());
   }

   public List<Integer> d() {
      ArrayList var1 = new ArrayList();

      for (Integer var3 : this.j) {
         if (this.h.containsKey(var3)) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public String e() {
      long var1 = System.currentTimeMillis();
      synchronized (this.l) {
         while (!this.l.isEmpty() && var1 - this.l.peekFirst() > 15000L) {
            this.l.pollFirst();
         }

         if (this.l.size() >= 3) {
            long var4 = (15000L - (var1 - this.l.peekFirst()) + 999L) / 1000L;
            return "Слишком часто — подожди " + var4 + "с";
         } else {
            return null;
         }
      }
   }

   public void b(int var1) {
      PhraseManager.Phrase var2 = this.h.get(var1);
      if (var2 != null) {
         MinecraftClient var3 = MinecraftClient.getInstance();
         String var4 = var3.player != null ? var3.player.getGameProfile().name() : null;
         if (var4 != null) {
            synchronized (this.l) {
               this.l.addLast(System.currentTimeMillis());
            }

            Pulse.m().info("[Phrase] кидаю id={} «{}», ник {}, озвучка {} мс", var1, var2.text(), var4, PhraseAudio.a(var1));
            this.a(var4, var2);
            RealtimeSyncServiceV2.L().e(var1);
         }
      }
   }

   public void a(String var1, int var2) {
      PhraseManager.Phrase var3 = this.h.get(var2);
      if (var3 != null) {
         this.a(var1, var3);
      }
   }

   private void a(String var1, PhraseManager.Phrase var2) {
      this.k.put(var1, new PhraseManager.Bubble(var2.text(), System.currentTimeMillis(), c(var2.id())));
      PhraseAudio.a(var1, var2.id());
   }

   private static long c(int var0) {
      int var1 = PhraseAudio.a(var0);
      return var1 <= 0 ? 2600L : Math.max(1500L, var1 + 700L);
   }

   public PhraseManager.Bubble a(String var1) {
      PhraseManager.Bubble var2 = this.k.get(var1);
      if (var2 == null) {
         return null;
      } else if (var2.b()) {
         this.k.remove(var1, var2);
         return null;
      } else {
         return var2;
      }
   }

   public void b(String var1) {
      this.k.remove(var1);
      PhraseAudio.a(var1);
   }

   public void f() {
      this.k.clear();
      PhraseAudio.c();
   }

   public String g() {
      LinkedHashMap var1 = new LinkedHashMap();
      var1.put("каталог", this.h.size());
      var1.put("надето", this.j.size());
      var1.put("пузырей", this.k.size());
      return var1.toString();
   }

   @Environment(EnvType.CLIENT)
   public record Bubble(String text, long shownAt, long lifetimeMs) {
      public long a() {
         return System.currentTimeMillis() - this.shownAt;
      }

      public boolean b() {
         return this.a() >= this.lifetimeMs;
      }

      public float c() {
         long var1 = this.lifetimeMs - this.a();
         if (var1 >= 500L) {
            return 1.0F;
         } else {
            return var1 <= 0L ? 0.0F : (float)var1 / 500.0F;
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public record Phrase(int id, String name, String text, Identifier icon) {
   }
}
