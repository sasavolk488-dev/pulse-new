package pulse.core.handler;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.EventHandler;

@Environment(EnvType.CLIENT)
public abstract class Handler {
   private boolean a;

   public void a() {
      HandlerInfo var1 = this.getClass().getAnnotation(HandlerInfo.class);
      this.a(var1.a());
   }

   public void a(boolean var1) {
      if (this.a != var1) {
         this.a = var1;
         if (var1) {
            this.d();
         } else {
            this.e();
         }
      }
   }

   public void b() {
      this.a(!this.a);
   }

   private void d() {
      EventHandler.a.subscribe(this);
   }

   private void e() {
      EventHandler.a.unsubscribe(this);
   }

   @Generated
   public boolean c() {
      return this.a;
   }
}
