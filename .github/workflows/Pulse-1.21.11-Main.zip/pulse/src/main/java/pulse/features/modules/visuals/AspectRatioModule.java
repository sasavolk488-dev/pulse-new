package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.utils.animation.Animation;
import pulse.utils.animation.AnimationType;
import pulse.utils.animation.util.Easings;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Aspect Ratio",
   b = "Изменяет соотношение сторон экрана",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class AspectRatioModule extends Module {
   public final ModeSetting a = new ModeSetting("Пресеты", new String[]{"16:9", "4:3", "21:9", "1:1", "Кастом"}, "16:9");
   public final NumberSetting b = new NumberSetting("Соотношение", 1.78F, 0.5F, 3.0F, 0.01F).a(() -> this.a.b("Кастом"));
   private final Animation c = new Animation(Easings.n, AnimationType.b);
   private boolean f = false;

   @Compile
   @Override
   public void e() {
      super.e();
      this.c.d(this.o());
      this.f = true;
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.f = false;
   }

   public float n() {
      float var1 = this.p();
      if (!this.f) {
         this.c.d(var1);
         this.f = true;
      }

      this.c.a();
      this.c.a(var1, 0.25, Easings.n, true);
      return (float)this.c.j();
   }

   private float o() {
      try {
         int var1 = d.getWindow().getFramebufferWidth();
         int var2 = d.getWindow().getFramebufferHeight();
         return var2 <= 0 ? this.p() : (float)var1 / var2;
      } catch (Exception var3) {
         return this.p();
      }
   }

   private float p() {
      String var1 = this.a.e();

      return switch (var1) {
         case "16:9" -> 1.7777778F;
         case "4:3" -> 1.3333334F;
         case "21:9" -> 2.3333333F;
         case "1:1" -> 1.0F;
         case "Кастом" -> this.b.b();
         default -> 1.7777778F;
      };
   }

   static {
      NativeMethodLookup.lookup(AspectRatioModule.class, 80);
   }
}
