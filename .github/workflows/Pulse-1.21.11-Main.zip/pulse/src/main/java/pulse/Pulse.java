package pulse;

import aethereal.NativeMethodLookup;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.Security;
import java.util.concurrent.ThreadFactory;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import pulse.services.auth.DeviceAuthManager;
import pulse.services.auth.TokenStorage;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.config.cloud.CloudConfigManager;
import pulse.features.cosmetic.CosmeticTextureManager;
import pulse.services.discord.DiscordRPC;
import pulse.features.emote.EmoteBundleManager;
import pulse.features.graffiti.GraffitiBundleManager;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.music.MusicHandler;
import pulse.features.modules.hud.DraggableManager;
import pulse.ui.menu.MenuState;
import pulse.features.modules.ModuleRegistry;
import pulse.features.phrase.PhraseBundleManager;
import pulse.utils.render.Render;
import pulse.utils.render.backends.gl.GlBackend;
import pulse.utils.render.core.Renderer2D;
import pulse.utils.render.impl.MinecraftRender;
import pulse.utils.render.shader.ShaderRegistry;
import pulse.features.resourcepack.ResourcePackService;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;
import pulse.utils.net.ApiRouter;
import pulse.utils.render.TextureRegistry;
import pulse.services.accounts.UserInfo;
import sun.misc.Unsafe;

@Environment(EnvType.CLIENT)
public class Pulse implements Runnable, ThreadFactory {
   public static final String a = "pulse";
   public static final String b = "2.0.4";
   private static final String c = "https://backend4.pulsevisuals.pro";
   private static final String d = "https://backend1.pulsevisuals.pro";
   private static final String[] e = new String[]{"https://pulsevisuals.pro", "https://eu.pulsevisuals.pro"};
   private static final Pulse f = new Pulse();
   private static final Logger g = LogManager.getLogger("pulse");
   private static UserInfo h = null;
   private static String i = null;
   private static String j = null;
   private static int k = 0;
   private String l;
   private String m = null;
   private GlBackend n;
   private Renderer2D o;
   private Render p;
   private boolean q = false;
   private static boolean r = false;
   private Screen s;
   private boolean localUiInitialized;
   private boolean localUiInitializing;

   private static void q() {
      try {
         Security.setProperty("crypto.policy", "unlimited");
      } catch (Exception var8) {
      }

      try {
         Class var9 = Class.forName("javax.crypto.JceSecurity");
         Field var10 = var9.getDeclaredField("isRestricted");
         var10.setAccessible(true);
         var10.set(null, false);
      } catch (Exception var7) {
         try {
            Field var0 = Unsafe.class.getDeclaredField("theUnsafe");
            var0.setAccessible(true);
            Unsafe var1 = (Unsafe)var0.get(null);
            Class var2 = Class.forName("javax.crypto.JceSecurity");
            Field var3 = var2.getDeclaredField("isRestricted");
            long var4 = var1.staticFieldOffset(var3);
            var1.putBoolean(var2, var4, false);
         } catch (Exception var6) {
            g.warn("Failed to unlock crypto policy: " + var6.getMessage());
         }
      }
   }

   private static boolean hasRenderContext() {
      if (!RenderSystem.isOnRenderThread()) {
         return false;
      }
      MinecraftClient client = MinecraftClient.getInstance();
      if (client == null || client.getWindow() == null) {
         return false;
      }
      long window = client.getWindow().getHandle();
      if (window == 0L || GLFW.glfwGetCurrentContext() != window) {
         return false;
      }
      try {
         return GL.getCapabilities() != null;
      } catch (IllegalStateException exception) {
         return false;
      }
   }

   public void a() {
      if (this.n == null && hasRenderContext()) {
         this.n = new GlBackend();
         this.o = new Renderer2D(this.n);
         this.p = new MinecraftRender(this.o);
      }
   }

   public void b() {
      if (this.localUiInitialized || this.localUiInitializing) {
         return;
      }
      pulse.utils.input.KeyBindings.a();
      if (!hasRenderContext() || MinecraftClient.getInstance().getOverlay() != null) {
         return;
      }
      this.localUiInitializing = true;
      try {
         this.a();
         TextureRegistry.a();
         ShaderRegistry.b();
         if (ModuleRegistry.b().isEmpty()) {
            ModuleRegistry.a();
         }
         HandlerRegistry.registerUiHandlers();
         DraggableManager.a().b();
         DraggableManager.a().c();
         DraggableManager.a().d();
         this.localUiInitialized = true;
      } finally {
         this.localUiInitializing = false;
      }
   }

   @Override
   public void run() {
      g.info("Shutdown...");
      Thread var1 = new Thread(() -> {
         try {
            if (CloudConfigManager.a().i()) {
               CloudConfigManager.a().c();
            }
         } catch (Exception var4) {
            g.error("Failed to save config on shutdown", (Throwable)var4);
         }

         try {
            if (RealtimeSyncServiceV2.L().b()) {
               RealtimeSyncServiceV2.L().f("game_closed");
            }
         } catch (Exception var3x) {
            g.error("Failed to disconnect on shutdown", (Throwable)var3x);
         }

         try {
            MusicHandler.h();
         } catch (Exception var2) {
            g.error("Failed to shutdown WMedia", (Throwable)var2);
         }

         try {
            DiscordRPC.a().c();
         } catch (Exception var1x) {
            g.error("Failed to stop Discord RPC", (Throwable)var1x);
         }
      }, "Pulse-Shutdown-Worker");
      var1.setDaemon(true);
      var1.start();

      try {
         var1.join(5000L);
      } catch (InterruptedException var3) {
      }

      if (var1.isAlive()) {
         g.warn("Shutdown hook timed out after 5s, forcing exit");
         var1.interrupt();
      }
   }

   @Override
   public Thread newThread(Runnable var1) {
      Thread var2 = new Thread(var1, "RS");
      var2.setDaemon(true);
      return var2;
   }

   private static String r() {
      for (String var1 : ApiRouter.a()) {
         String var2 = var1 + "/public/get-backend";

         try {
            HttpURLConnection var3 = (HttpURLConnection)new URL(var2).openConnection();
            var3.setRequestMethod("GET");
            var3.setConnectTimeout(5000);
            var3.setReadTimeout(5000);
            int var4 = var3.getResponseCode();
            if (var4 != 200) {
               g.warn("get-backend on " + var1 + " returned " + var4 + ", trying next");
            } else {
               StringBuilder var5 = new StringBuilder();
               BufferedReader var6 = new BufferedReader(new InputStreamReader(var3.getInputStream(), StandardCharsets.UTF_8));

               String var7;
               try {
                  while ((var7 = var6.readLine()) != null) {
                     var5.append(var7);
                  }
               } catch (Throwable var10) {
                  try {
                     var6.close();
                  } catch (Throwable var9) {
                     var10.addSuppressed(var9);
                  }

                  throw var10;
               }

               var6.close();
               String var12 = var5.toString();
               var7 = a(var12, "freak");
               if (var7 != null) {
                  int var8 = var7.indexOf(58);
                  j = var8 > 0 ? var7.substring(0, var8) : var7;
               }

               String var14 = a(var12, "backend");
               if (var14 != null) {
                  g.info("Geo-routing: backend=" + var14 + " freak=" + j + " via=" + var1);
                  return var14;
               }
            }
         } catch (Exception var11) {
            g.warn("get-backend on " + var1 + " failed (" + var11.getMessage() + "), trying next");
         }
      }

      g.warn("All API mirrors failed for get-backend, using default backend");
      return "https://backend4.pulsevisuals.pro";
   }

   private static String a(String var0, String var1) {
      String var2 = "\"" + var1 + "\":\"";
      int var3 = var0.indexOf(var2);
      if (var3 < 0) {
         return null;
      } else {
         int var4 = var3 + var2.length();
         int var5 = var0.indexOf(34, var4);
         return var5 <= var4 ? null : var0.substring(var4, var5);
      }
   }

   public static String c() {
      return j;
   }

   private String s() {
      if (TokenStorage.b()) {
         String var1 = TokenStorage.c();
         if (var1 != null && !var1.isEmpty()) {
            g.info("Токен загружен из локального хранилища: " + TokenStorage.a());
            return var1;
         }
      }

      String var4 = this.t();
      if (var4 != null) {
         g.info("Токен загружен из JAR");
         return var4;
      } else {
         g.info("Токен не найден, запуск Device Auth Flow...");
         DeviceAuthManager var2 = new DeviceAuthManager();
         String var3 = var2.a();
         if (var3 != null) {
            this.m = var3;
         }

         return var3;
      }
   }

   private String t() {
      try {
         InputStream var1 = this.getClass().getResourceAsStream("/token.txt");
         if (var1 == null) {
            return null;
         } else {
            String var4;
            try (BufferedReader var2 = new BufferedReader(new InputStreamReader(var1, StandardCharsets.UTF_8))) {
               String var3 = var2.readLine();
               if (var3 == null || var3.trim().isEmpty()) {
                  return null;
               }

               var4 = var3.trim();
            }

            return var4;
         }
      } catch (IOException var7) {
         return null;
      }
   }

   public static void a(String var0) {
      g.info("MESSAGE: " + var0);

      try {
         String var1 = System.getProperty("os.name").toLowerCase();
         if (var1.contains("win")) {
            String var2 = var0.replace("'", "''").replace("\"", "\\\"");
            String[] var3 = new String[]{
               "powershell.exe",
               "-Command",
               "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('" + var2 + "', 'Pulse', 'OK', 'Information')"
            };
            new ProcessBuilder(var3).start();
         }
      } catch (Exception var4) {
         g.error("Не удалось показать сообщение", (Throwable)var4);
      }
   }

   public static void d() {
      System.err.println("ВНИМАНИЕ: Отключите антивирус и перезапустите приложение!");

      try {
         e();
      } catch (Exception var1) {
         System.err.println("Не удалось показать окно предупреждения");
      }
   }

   public static void e() {
      String var0 = "Вам открылся ролик следуйте по инструкции из ролика";
      String[] var1 = new String[]{
         "powershell.exe",
         "-Command",
         "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('" + var0 + "', 'Инструкция', 'OK', 'Information')"
      };

      try {
         ProcessBuilder var2 = new ProcessBuilder(var1);
         Process var8 = var2.start();
         Thread.sleep(500L);
         f();
         var8.waitFor();
      } catch (Exception var7) {
         try {
            String[] var3 = new String[]{
               "cmd.exe",
               "/c",
               "echo msgbox \"" + var0 + "\", 64, \"Инструкция\" > \"%temp%\\msg.vbs\" && cscript //nologo \"%temp%\\msg.vbs\" && del \"%temp%\\msg.vbs\""
            };
            ProcessBuilder var4 = new ProcessBuilder(var3);
            Process var5 = var4.start();
            Thread.sleep(500L);
            f();
            var5.waitFor();
         } catch (Exception var6) {
            System.err.println("Не удалось показать сообщение пользователю");
         }
      }
   }

   public static void f() {
      try {
         String var0 = "https://youtu.be/IkJgubhmweo?si=blxuhgPZxoCytDN_";
         String[] var1 = new String[]{"cmd.exe", "/c", "start", var0};
         ProcessBuilder var2 = new ProcessBuilder(var1);
         var2.start();
      } catch (Exception var4) {
         try {
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler https://youtu.be/IkJgubhmweo?si=blxuhgPZxoCytDN_");
         } catch (Exception var3) {
            System.err.println("Не удалось открыть браузер");
         }
      }
   }

   public static String g() {
      for (String var3 : e) {
         if (b(var3)) {
            return var3;
         }
      }

      return e[0];
   }

   public static String h() {
      return i != null ? i : "https://backend4.pulsevisuals.pro";
   }

   public static String i() {
      return ApiRouter.b();
   }

   private static boolean b(String var0) {
      try {
         URL var1 = new URL(var0);
         HttpURLConnection var2 = (HttpURLConnection)var1.openConnection();
         var2.setRequestMethod("HEAD");
         var2.setConnectTimeout(3000);
         var2.setReadTimeout(3000);
         var2.connect();
         int var3 = var2.getResponseCode();
         var2.disconnect();
         return var3 >= 200 && var3 < 500;
      } catch (Exception var4) {
         return false;
      }
   }

   public Screen j() {
      return this.k();
   }

   public ClickGuiScreen k() {
      this.b();
      if (!(this.s instanceof ClickGuiScreen)) {
         this.s = new ClickGuiScreen();
      }

      return (ClickGuiScreen)this.s;
   }

   public void a(Screen var1) {
      this.s = var1;
   }

   @Generated
   public static Pulse l() {
      return f;
   }

   @Generated
   public static Logger m() {
      return g;
   }

   @Generated
   public static UserInfo n() {
      return h;
   }

   @Generated
   public static void a(UserInfo var0) {
      h = var0;
   }

   @Generated
   public Renderer2D o() {
      return this.o;
   }

   @Generated
   public Render p() {
      return this.p;
   }

   public void v() {
      this.a();
      TextureRegistry.a();
      ShaderRegistry.b();
      ModuleRegistry.a();
      HandlerRegistry.a();
      DraggableManager.a().b();
      DraggableManager.a().c();
      DraggableManager.a().d();
      CloudConfigManager.a().b();
      ClickGuiScreen var1 = this.k();
      if (var1.j() != null) {
         var1.j().e();
      }

      CosmeticTextureManager.a().b();
      ResourcePackService.a().c();
      EmoteBundleManager.a();
      GraffitiBundleManager.b();
      PhraseBundleManager.a();
      MenuState.a();
   }

   static {
      NativeMethodLookup.lookup(Pulse.class, 0);
   }
}
