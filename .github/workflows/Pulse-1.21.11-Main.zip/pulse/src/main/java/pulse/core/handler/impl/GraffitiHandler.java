package pulse.core.handler.impl;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.MouseEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.features.graffiti.GraffitiDecal;
import pulse.features.graffiti.GraffitiEntry;
import pulse.features.graffiti.GraffitiManager;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.world.BillboardLayers;
import pulse.utils.input.KeyBindings;
import pulse.utils.render.ScaleUtils;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class GraffitiHandler extends Handler implements IMinecraft {
   private static final double c = 5.0;
   private static final float f = 0.008F;
   private static final float g = 1.0F;
   private static final float h = 0.55F;
   private static final double i = 64.0;
   private static final long j = 30000L;
   private static final long k = 5000L;
   public static volatile boolean a = false;
   public static volatile boolean b = false;
   private long l;
   private boolean m;
   private boolean n;
   private int o;
   private final Animation p = new Animation();
   private int q = -1;
   private BlockPos r;
   private Direction s;
   private static final double t = 18.0;
   private Vec3d u;
   private Vec3d v;
   private Vec3d w;
   private long x;
   private static final float y = 44.0F;
   private static final float z = 56.0F;
   private static final int A = 4;
   private static final float B = 110.0F;
   private static final float C = 0.45F;
   private static final float D = 1.35F;
   private static final double E = 14.0;
   private static final Color F = new Color(115, 83, 255, 235);
   private static final Color G = new Color(223, 223, 243);
   private float H = 0.45F;
   private final float[] I = new float[4];
   private long J;
   private int K;
   private boolean L;
   private boolean M;
   private float N;
   private float O;
   private float P;

   @Override
   public void a() {
      super.a();
      if (!this.n) {
         this.n = true;
         ClientTickEvents.END_CLIENT_TICK.register(var1 -> this.d());
      }
   }

   private void d() {
      if (d.player != null && d.world != null) {
         if (++this.o >= 20) {
            this.o = 0;
            GraffitiManager.a().e();
         }

         boolean var1 = KeyBindings.c != null && KeyBindings.c.isPressed();
         if (var1 && !this.m && d.currentScreen == null && !EmoteHandler.a && !PhraseHandler.a) {
            this.e();
         } else if (!var1 && this.m) {
            this.b(true);
         }

         this.m = var1;
         if (a && d.currentScreen != null) {
            this.b(false);
         }

         if (a) {
            this.l();
         }
      } else {
         this.f();
      }
   }

   private void e() {
      a = true;
      b = false;
      this.q = -1;
      this.r = null;
      this.s = null;
      this.H = 0.45F;
      Arrays.fill(this.I, 1.0F);
      this.J = 0L;
      this.K = 0;
      this.L = false;
      this.M = false;
      this.p.d(0.0);
      this.p.a(1.0, 0.25, Easings.F);
      this.l();
   }

   private void b(boolean var1) {
      boolean var2 = b;
      a = false;
      if (b) {
         this.h();
      }

      this.p.a(0.0, 0.15000003063475162, Easings.g);
      if (var1 && !var2) {
         if (this.r != null && this.s != null) {
            GraffitiEntry var3 = GraffitiManager.a().c();
            if (var3 != null) {
               if (GraffitiManager.a().b(var3) <= 0) {
                  this.a("§cЗаряды «" + var3.c() + "» кончились");
               } else if (this.k()) {
                  Direction var4 = this.s.getAxis().isVertical() ? d.player.getHorizontalFacing() : null;
                  GraffitiManager.a().a(this.r, this.s, var4);
                  d.world
                     .playSoundClient(
                        d.player.getX(), d.player.getY(), d.player.getZ(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 0.5F, 1.5F, false
                     );
               }
            }
         }
      }
   }

   private void f() {
      a = false;
      if (b) {
         this.h();
      }

      this.m = false;
      this.p.d(0.0);
      this.r = null;
      this.s = null;
      this.u = null;
   }

   private void g() {
      b = true;
      if (d.mouse.isCursorLocked()) {
         d.mouse.unlockCursor();
      }
   }

   private void h() {
      b = false;
      if (d.currentScreen == null && !d.mouse.isCursorLocked()) {
         d.mouse.lockCursor();
      }
   }

   private double i() {
      return d.mouse.getX() * ((double)d.getWindow().getFramebufferWidth() / d.getWindow().getWidth()) / 2.0;
   }

   private double j() {
      return d.mouse.getY() * ((double)d.getWindow().getFramebufferHeight() / d.getWindow().getHeight()) / 2.0;
   }

   private boolean k() {
      long var1 = System.currentTimeMillis();
      if (var1 - this.l < 30000L) {
         long var3 = (30000L - (var1 - this.l) + 999L) / 1000L;
         this.a("§cГраффити можно раз в 30с — подожди " + var3 + "с");
         return false;
      } else {
         this.l = var1;
         return true;
      }
   }

   private void a(String var1) {
      if (d.player != null) {
         d.player.sendMessage(Text.literal(var1), true);
      }
   }

   private void l() {
      this.r = null;
      this.s = null;
      if (d.player != null && d.world != null) {
         Vec3d var1 = d.player.getCameraPosVec(1.0F);
         Vec3d var2 = var1.add(d.player.getRotationVec(1.0F).multiply(5.0));
         BlockHitResult var3 = d.world.raycast(new RaycastContext(var1, var2, ShapeType.OUTLINE, FluidHandling.NONE, d.player));
         if (var3.getType() == Type.BLOCK) {
            this.r = var3.getBlockPos();
            this.s = var3.getSide();
         }
      }
   }

   @EventHandler
   public void a(MouseEvent var1) {
      if (a) {
         var1.a(true);
         if (var1.e() == 1) {
            if (var1.d() == 1) {
               if (b) {
                  this.h();
               } else {
                  this.g();
               }
            } else if (var1.d() == 0 && b) {
               var var2 = GraffitiManager.a().b();
               if (this.L && this.K + 4 < var2.size()) {
                  this.K += 4;
                  Arrays.fill(this.I, 1.0F);
                  this.q = -1;
               } else if (this.M && this.K > 0) {
                  this.K = Math.max(0, this.K - 4);
                  Arrays.fill(this.I, 1.0F);
                  this.q = -1;
               } else {
                  if (this.q >= 0 && this.K + this.q < var2.size()) {
                     GraffitiManager.a().a((GraffitiEntry)var2.get(this.K + this.q));
                     this.h();
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void a(RenderEvent var1) {
      if (d.world != null && d.player != null) {
         String var2 = GraffitiManager.a().f();
         List<GraffitiDecal> var3 = GraffitiManager.a().d();
         GraffitiEntry var4 = a && this.r != null ? GraffitiManager.a().c() : null;
         if (!var3.isEmpty() || var4 != null) {
            Vec3d var5 = d.gameRenderer.getCamera().getCameraPos();
            long var6 = System.currentTimeMillis();

            for (GraffitiDecal var9 : var3) {
               if (var9.worldKey().equals(var2)) {
                  long var10 = var6 - var9.placedAt();
                  if (var10 <= 90000L) {
                     Vec3d var12 = a(var9.pos(), var9.face());
                     double var13 = d.player.getEntityPos().distanceTo(var12);
                     if (!(var13 > 64.0)) {
                        float var15 = (float)Math.min(1.0, (64.0 - var13) / 8.0);
                        long var16 = 90000L - var10;
                        if (var16 < 5000L) {
                           var15 *= (float)var16 / 5000.0F;
                        }

                        this.a(var1.a(), var5, var9.pos(), var9.face(), var9.imageUp(), var9.entry(), var15);
                     }
                  }
               }
            }

            if (var4 != null) {
               Direction var18 = this.s.getAxis().isVertical() ? d.player.getHorizontalFacing() : null;
               float var19 = (float)Math.max(0.0, Math.min(1.0, this.p.j()));
               this.a(a(this.r, this.s), Vec3d.of(this.s.getVector()), a(this.s, var18));
               this.a(var1.a(), var5, this.u, this.v, this.w, this.s == Direction.DOWN, var4, 0.55F * var19);
            } else {
               this.u = null;
            }
         }
      }
   }

   private static Vec3d a(BlockPos var0, Direction var1) {
      return Vec3d.ofCenter(var0).add(Vec3d.of(var1.getVector()).multiply(0.5080000078305602));
   }

   private static Vec3d a(Direction var0, Direction var1) {
      if (var0.getAxis().isVertical()) {
         Direction var2 = var1 != null ? var1 : Direction.NORTH;
         return Vec3d.of(var2.getVector());
      } else {
         return new Vec3d(0.0, 1.0, 0.0);
      }
   }

   private void a(Vec3d var1, Vec3d var2, Vec3d var3) {
      long var4 = System.nanoTime();
      if (this.u == null) {
         this.u = var1;
         this.v = var2;
         this.w = var3;
         this.x = var4;
      } else {
         double var6 = Math.min(0.1000000029985075, (var4 - this.x) / 1.0E9);
         this.x = var4;
         double var8 = 1.0 - Math.exp(-var6 * 18.0);
         this.u = this.u.lerp(var1, var8);
         Vec3d var10 = this.v.lerp(var2, var8);
         Vec3d var11 = this.w.lerp(var3, var8);
         if (!(var10.lengthSquared() < 0.010000004308315486) && !(var11.lengthSquared() < 0.010000004308315486)) {
            this.v = var10.normalize();
            Vec3d var12 = var11.subtract(this.v.multiply(var11.dotProduct(this.v)));
            this.w = var12.lengthSquared() < 0.010000004308315486 ? var3 : var12.normalize();
         } else {
            this.u = var1;
            this.v = var2;
            this.w = var3;
         }
      }
   }

   private void a(MatrixStack var1, Vec3d var2, BlockPos var3, Direction var4, Direction var5, GraffitiEntry var6, float var7) {
      this.a(var1, var2, a(var3, var4), Vec3d.of(var4.getVector()), a(var4, var5), var4 == Direction.DOWN, var6, var7);
   }

   private void a(MatrixStack var1, Vec3d var2, Vec3d var3, Vec3d var4, Vec3d var5, boolean var6, GraffitiEntry var7, float var8) {
      if (!(var8 <= 0.01F)) {
         Vec3d var9 = var5.crossProduct(var4);
         if (var6) {
            var9 = var9.multiply(-1.0);
         }

         float var10 = var7.g();
         float var11 = var10 >= 1.0F ? 1.0F : 1.0F * var10;
         float var12 = var10 >= 1.0F ? 1.0F / var10 : 1.0F;
         float var13 = var11 / 2.0F;
         float var14 = var12 / 2.0F;
         Vec3d var15 = var3.subtract(var2);
         Vec3d var16 = var15.subtract(var9.multiply(var13)).add(var5.multiply(var14));
         Vec3d var17 = var15.add(var9.multiply(var13)).add(var5.multiply(var14));
         Vec3d var18 = var15.add(var9.multiply(var13)).subtract(var5.multiply(var14));
         Vec3d var19 = var15.subtract(var9.multiply(var13)).subtract(var5.multiply(var14));
         int var20 = (int)(Math.max(0.0F, Math.min(1.0F, var8)) * 255.0F);
         Matrix4f var21 = var1.peek().getPositionMatrix();
         RenderLayer var22 = BillboardLayers.a(var7.d(), false, false);
         Immediate var23 = d.getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer var24 = var23.getBuffer(var22);
         var24.vertex(var21, (float)var16.x, (float)var16.y, (float)var16.z).texture(0.0F, 0.0F).color(255, 255, 255, var20);
         var24.vertex(var21, (float)var17.x, (float)var17.y, (float)var17.z).texture(1.0F, 0.0F).color(255, 255, 255, var20);
         var24.vertex(var21, (float)var18.x, (float)var18.y, (float)var18.z).texture(1.0F, 1.0F).color(255, 255, 255, var20);
         var24.vertex(var21, (float)var19.x, (float)var19.y, (float)var19.z).texture(0.0F, 1.0F).color(255, 255, 255, var20);
         var23.draw(var22);
      }
   }

   @EventHandler
   public void a(RenderHudPostEvent var1) {
      this.p.a();
      float var2 = (float)Math.max(0.0, Math.min(1.0, this.p.j()));
      if (!(var2 < 0.01F)) {
         MatrixStack var3 = var1.a();
         ScaleUtils.a(2.0);
         float var4 = d.getWindow().getFramebufferWidth() / 2.0F;
         float var5 = d.getWindow().getFramebufferHeight() / 2.0F;
         float var6 = var4 / 2.0F;
         Render var7 = Pulse.l().p();
         var var8 = GraffitiManager.a().b();
         GraffitiEntry var9 = GraffitiManager.a().c();
         if (a && this.r == null && var9 != null) {
            float var10 = 90.0F * var2;
            float var11 = var9.g();
            float var12 = var11 >= 1.0F ? var10 : var10 * var11;
            float var13 = var11 >= 1.0F ? var10 / var11 : var10;
            Color var14 = new Color(255, 255, 255, (int)(165.0F * var2));
            var7.a(var9.d(), var6 - var12 / 2.0F, var5 / 2.0F - var13 / 2.0F - 20.0F, var12, var13, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var14, var3);
            Fonts.b[16].b("Слишком далеко от блока", var6, var5 / 2.0F + var13 / 2.0F - 10.0F, new Color(255, 120, 120, (int)(255.0F * var2)), var3);
            int var15 = GraffitiManager.a().b(var9);
            Color var16 = var15 <= 0 ? new Color(255, 100, 100, (int)(255.0F * var2)) : new Color(235, 235, 245, (int)(220.0F * var2));
            Fonts.b[14].b("x" + var15, var6, var5 / 2.0F + var13 / 2.0F + 6.0F, var16, var3);
         }

         float var39 = (1.0F - var2) * 40.0F;
         if (var8.isEmpty()) {
            Fonts.b[16].b("Купите граффити на сайте и наденьте его", var6, var5 - 110.0F - 22.0F + var39, G, var3);
            ScaleUtils.a();
         } else {
            if (this.K >= var8.size()) {
               this.K = 0;
            }

            int var40 = Math.min(4, var8.size() - this.K);
            boolean var41 = this.K + 4 < var8.size();
            boolean var42 = this.K > 0;
            this.q = -1;
            this.L = false;
            this.M = false;
            float var43 = 100.0F;
            float var44 = var40 * 44.0F + (var40 - 1) * 56.0F;
            float var45 = var6 - var44 / 2.0F;
            float var17 = var5 - 110.0F - 44.0F + var39;
            this.N = var45 + var44 + 39.2F;
            this.O = var45 - 39.2F;
            this.P = var17 + 22.0F;
            if (b) {
               double var18 = this.i();
               double var20 = this.j();
               if (var20 >= var17 - 10.0F && var20 <= var17 + 44.0F + 10.0F) {
                  int var22 = (int)Math.floor((var18 - var45 + 28.0) / var43);
                  if (var22 >= 0 && var22 < var40) {
                     this.q = var22;
                  }

                  if (var41 && Math.abs(var18 - this.N) <= 18.0 && Math.abs(var20 - this.P) <= 26.0) {
                     this.L = true;
                     this.q = -1;
                  }

                  if (var42 && Math.abs(var18 - this.O) <= 18.0 && Math.abs(var20 - this.P) <= 26.0) {
                     this.M = true;
                     this.q = -1;
                  }
               }
            }

            int var46 = -1;

            for (int var19 = 0; var19 < var40; var19++) {
               if (var9 != null && var9.b().equals(((GraffitiEntry)var8.get(this.K + var19)).b())) {
                  var46 = var19;
                  break;
               }
            }

            long var47 = System.nanoTime();
            double var21 = this.J == 0L ? 0.016000002111168185 : Math.min(0.1000000029985075, (var47 - this.J) / 1.0E9);
            this.J = var47;
            float var23 = (float)(1.0 - Math.exp(-var21 * 14.0));
            this.H = this.H + ((b ? 1.0F : 0.45F) - this.H) * var23;

            for (int var24 = 0; var24 < var40; var24++) {
               float var25 = var24 == this.q ? 1.35F : 1.0F;
               this.I[var24] = this.I[var24] + (var25 - this.I[var24]) * var23;
            }

            GraffitiManager var48 = GraffitiManager.a();

            for (int var49 = 0; var49 < var40; var49++) {
               GraffitiEntry var26 = (GraffitiEntry)var8.get(this.K + var49);
               float var27 = var45 + var49 * var43 + 22.0F;
               float var28 = var17 + 22.0F;
               float var29 = 44.0F * this.I[var49];
               float var30 = var26.g();
               float var31 = var30 >= 1.0F ? var29 : var29 * var30;
               float var32 = var30 >= 1.0F ? var29 / var30 : var29;
               int var33 = var48.b(var26);
               float var34 = var33 <= 0 ? 0.3F : (var49 == var46 ? 1.0F : 0.7F);
               Color var35 = new Color(255, 255, 255, (int)(255.0F * var2 * this.H * var34));
               var7.a(var26.d(), var27 - var31 / 2.0F, var28 - var32 / 2.0F, var31, var32, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var35, var3);
               int var36 = (int)(255.0F * var2 * this.H * (var49 == var46 ? 1.0F : 0.75F));
               Color var37 = var49 == var46 ? new Color(255, 255, 255, var36) : new Color(G.getRed(), G.getGreen(), G.getBlue(), var36);
               Fonts.b[15].b(a(var26.c(), 12), var27, var17 + 44.0F + 8.0F, var37, var3);
               Color var38 = var33 <= 0
                  ? new Color(255, 100, 100, var36)
                  : (var49 == var46 ? new Color(235, 235, 245, var36) : new Color(160, 160, 175, var36));
               Fonts.b[14].b("x" + var33, var27, var17 + 44.0F + 24.0F, var38, var3);
            }

            if (var41 || var42) {
               FontRenderer var50 = Fonts.b[46];
               float var52 = this.P - var50.b("›") / 2.0F + 8.0F;
               if (var41) {
                  int var53 = (int)(255.0F * var2 * this.H * (this.L ? 1.0F : 0.6F));
                  Color var55 = this.L ? new Color(F.getRed(), F.getGreen(), F.getBlue(), var53) : new Color(G.getRed(), G.getGreen(), G.getBlue(), var53);
                  var50.b("›", this.N, var52, var55, var3);
               }

               if (var42) {
                  int var54 = (int)(255.0F * var2 * this.H * (this.M ? 1.0F : 0.6F));
                  Color var56 = this.M ? new Color(F.getRed(), F.getGreen(), F.getBlue(), var54) : new Color(G.getRed(), G.getGreen(), G.getBlue(), var54);
                  var50.b("‹", this.O, var52, var56, var3);
               }
            }

            String var51 = b ? "ЛКМ — выбрать" : "ПКМ — выбор  •  отпусти G — нанести";
            Fonts.b[14].b(var51, var6, var17 + 44.0F + 44.0F, new Color(223, 223, 243, (int)(150.0F * var2 * this.H)), var3);
            ScaleUtils.a();
         }
      }
   }

   private static String a(String var0, int var1) {
      return var0.length() <= var1 ? var0 : var0.substring(0, var1 - 1) + "…";
   }
}
