package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class ItemOverlayRenderEvent extends Event {
   private final ItemStack a;
   private final int b;
   private final int c;

   @Generated
   public ItemStack a() {
      return this.a;
   }

   @Generated
   public int b() {
      return this.b;
   }

   @Generated
   public int c() {
      return this.c;
   }

   @Generated
   public ItemOverlayRenderEvent(ItemStack var1, int var2, int var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
