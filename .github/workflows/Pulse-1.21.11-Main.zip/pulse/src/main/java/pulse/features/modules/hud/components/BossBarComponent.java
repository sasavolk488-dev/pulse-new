package pulse.features.modules.hud.components;

import java.awt.Color;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix3x2fStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.config.cloud.CloudConfigManager;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.hud.DraggableManager;
import pulse.features.modules.hud.VanillaPositioned;
import pulse.features.modules.hud.snap.SnapResult;
import pulse.mixin.accessor.BossBarHudAccessor;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.RenderTweaksModule;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@Environment(EnvType.CLIENT)
public class BossBarComponent extends DraggableComponent implements VanillaPositioned {
   private static final float m = 8.0F;
   private static final Color n = new Color(160, 160, 165);
   private static final String o = "Bossbar";
   private static final int p = 182;
   private static BossBarComponent q;
   private boolean r = true;
   private float s;
   private float t;
   private float u;
   private float v;
   private final Animation w = new Animation().d(0.0);

   public BossBarComponent(float var1, float var2) {
      super(var1, var2);
      q = this;
   }

   public static BossBarComponent v() {
      return q;
   }

   @Override
   public boolean c() {
      if (this.a.world != null && this.a.player != null) {
         RenderTweaksModule var1 = ModuleRegistry.h;
         return var1 != null && var1.s() ? false : !this.y().isEmpty() || DraggableManager.a().p();
      } else {
         return false;
      }
   }

   @Override
   public boolean b() {
      return this.r;
   }

   @Override
   public void a(boolean var1) {
      this.r = var1;
   }

   public boolean w() {
      return !this.r || !(Math.abs(this.g() - 1.0F) < 0.001F);
   }

   private Map<UUID, ClientBossBar> y() {
      BossBarHud var1 = this.a.inGameHud.getBossBarHud();
      return ((BossBarHudAccessor)var1).getBossBars();
   }

   private float z() {
      return (float)(this.a.getWindow().getScaleFactor() / 2.0);
   }

   private void A() {
      TextRenderer var1 = this.a.textRenderer;
      int var2 = this.a.getWindow().getScaledWidth();
      int var3 = this.a.getWindow().getScaledHeight();
      var var4 = this.y();
      int var5;
      int var6;
      if (var4.isEmpty()) {
         var5 = var1.getWidth("Bossbar");
         var6 = 1;
      } else {
         var5 = 0;
         var6 = 0;
         byte var7 = 12;

         for (ClientBossBar var9 : var4.values()) {
            var6++;
            var5 = Math.max(var5, var1.getWidth(var9.getName()));
            var7 += 19;
            if (var7 >= var3 / 3) {
               break;
            }
         }
      }

      this.u = Math.max(182, var5);
      this.v = 14 + (var6 - 1) * 19;
      this.s = var2 / 2.0F - this.u / 2.0F;
      this.t = 3.0F;
   }

   private float B() {
      return (this.s + this.u / 2.0F) * this.z() - this.d / 2.0F;
   }

   private float C() {
      return this.t * this.z();
   }

   @Override
   protected void a() {
      this.A();
      float var1 = this.z() * this.g();
      this.d = this.u * var1;
      this.e = this.v * var1;
   }

   private void c(float var1, float var2) {
      if (this.r) {
         this.b = this.B();
         this.c = this.C();
      }

      this.b = Math.max(0.0F, Math.min(this.b, var1 - this.d));
      this.c = Math.max(0.0F, Math.min(this.c, var2 - this.e));
   }

   @Override
   public boolean a(double var1, double var3, int var5) {
      if (var5 == 2 && this.a(var1, var3)) {
         this.x();
         return true;
      } else {
         return super.a(var1, var3, var5);
      }
   }

   public void x() {
      if (!this.r) {
         this.r = true;
         CloudConfigManager.a().h();
      }
   }

   @Override
   public void a(SnapResult var1, float var2, float var3) {
      super.a(var1, var2, var3);
      if (this.j()) {
         this.a(!DraggableManager.a().t(), var2, var3);
      }
   }

   private void a(boolean var1, float var2, float var3) {
      float var4 = this.B();
      float var5 = this.C();
      boolean var6 = Math.abs(this.b - var4) <= 8.0F && Math.abs(this.c - var5) <= 8.0F;
      if (var1 && var6) {
         this.b = var4;
         this.c = var5;
         this.u().a(this.b, this.c, this.d, this.e, var2, var3);
         if (!this.r) {
            this.r = true;
            CloudConfigManager.a().h();
         }
      } else if (this.r) {
         this.r = false;
         CloudConfigManager.a().h();
      }
   }

   public void a(Matrix3x2fStack var1) {
      this.A();
      float var2 = this.z();
      float var3 = this.g();
      this.d = this.u * var2 * var3;
      this.e = this.v * var2 * var3;
      float var4 = this.a.getWindow().getFramebufferWidth() / 2.0F;
      float var5 = this.a.getWindow().getFramebufferHeight() / 2.0F;
      this.c(var4, var5);
      float var6 = this.b / var2;
      float var7 = this.c / var2;
      var1.translate(var6, var7);
      var1.scale(var3, var3);
      var1.translate(-this.s, -this.t);
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (DraggableManager.a().p()) {
         this.a();
         this.c(var3, var4);
         var2.a(this.b, this.c, this.d, this.e, 0.0F, ScoreboardComponent.a(n, 12), var1);
         float var5 = this.j() && !this.r ? 1.0F : 0.0F;
         this.w.a(var5, 0.1500000715265438, Easings.h, true);
         this.w.a();
         float var6 = (float)this.w.j();
         if (var6 > 0.01F) {
            float var7 = this.B();
            float var8 = this.C();
            var2.a(var7, var8, this.d, this.e, 0.0F, ScoreboardComponent.a(n, (int)(8.0F * var6)), var1);
            var2.b(var7, var8, this.d, this.e, 1.0F, ScoreboardComponent.a(n, (int)(45.0F * var6)), var1);
         }

         if (this.y().isEmpty()) {
            this.a(var1);
         }
      }
   }

   private void a(MatrixStack var1) {
      int var2 = Math.max(8, Math.min(48, Math.round(24.0F * this.g())));
      FontRenderer var3 = Fonts.a[var2];
      float var4 = var3.a("Bossbar");
      float var5 = var3.b("Bossbar") / 2.0F;
      var3.a("Bossbar", this.b + (this.d - var4) / 2.0F, this.c + (this.e - var5) / 2.0F, ScoreboardComponent.a(n, 90), var1);
   }
}
