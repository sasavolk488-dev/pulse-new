package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Optional;
import java.util.function.Predicate;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import pulse.core.event.impl.InputEvent;
import pulse.core.event.impl.KeyEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.KeySetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Item Swap",
   b = "Автоматически меняет предмет в левой руке при нажатии клавиши",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ItemSwapModule extends Module {
   private static final int a = 2;
   private final ModeSetting b = new ModeSetting("Менять с", new String[]{"Сфера", "Тотем"}, "Сфера");
   private final ModeSetting c = new ModeSetting("Менять на", new String[]{"Сфера", "Тотем"}, "Тотем");
   private final KeySetting f = new KeySetting("Кнопка свапа", -1);
   private boolean g = false;
   private boolean h = false;
   private int i = 0;
   private int j = 0;
   private boolean k = false;
   private int l = 0;
   private int m = 0;
   private String n = "";
   private int o = -1;
   private int p = -1;
   private int q = -1;

   @EventHandler
   @Compile
   public void a(KeyEvent var1) {
      KeySetting binding = this.f;
      if (d.player == null || d.world == null || d.currentScreen != null) {
         return;
      }
      if (var1.a() == binding.b() && var1.c() == 1) {
         try {
            this.n = this.q();
         } catch (RuntimeException | Error error) {
            this.n = null;
            throw error;
         }
         Optional<Integer> slot = this.a(this::c);
         if (slot.isPresent()) {
            this.b(slot.get());
         } else if (!this.a(this.n)) {
            d.player.sendMessage(Text.literal("§cНе найден предмет для свапа!"), true);
         } else {
            this.g = true;
            this.i = 0;
            this.k = false;
            this.l = 0;
         }
      }
   }

   @EventHandler
   @Compile
      public void a(UpdateEvent var1) {
      if (d.player == null) {
         return;
      }
      if (this.h) {
         this.n();
      }
      if (this.g) {
         this.o();
      }
   }

   @EventHandler
   @Compile
      public void a(InputEvent var1) {
      if (this.g) {
         var1.a(true);
      }
   }

   private void b(int var1) {
      this.o = d.player.getInventory().getSelectedSlot();
      this.p = var1;
      this.h = true;
      this.j = 0;
      this.m = 0;
   }

   private void n() {
      if (this.m > 0) {
         this.m--;
      } else {
         switch (this.j) {
            case 0:
               d.player.getInventory().setSelectedSlot(this.p);
               this.m = 2;
               this.j = 1;
               break;
            case 1:
               d.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
               this.m = 2;
               this.j = 2;
               break;
            case 2:
               d.player.getInventory().setSelectedSlot(this.o);
               d.player.sendMessage(Text.literal("§fСвапнул на ").append(d.player.getOffHandStack().getName()), true);
               this.h = false;
               this.j = 0;
         }
      }
   }

   private void o() {
      if (this.l > 0) {
         this.l--;
      } else {
         switch (this.i) {
            case 0:
               Optional var3 = this.b(var1x -> this.a(var1x, this.n));
               if (!var3.isPresent()) {
                  d.player.sendMessage(Text.literal("§cНе найден предмет для свапа!"), true);
                  this.p();
                  return;
               }

               this.q = (Integer)var3.get();
               this.l = 1;
               this.i = 1;
               break;
            case 1:
               ItemStack var1 = d.player.getInventory().getStack(this.q);
               if (!this.a(var1, this.n)) {
                  Optional var2 = this.b(var1x -> this.a(var1x, this.n));
                  if (!var2.isPresent()) {
                     this.p();
                     return;
                  }

                  this.q = (Integer)var2.get();
               }

               this.c(this.q);
               this.l = 1;
               this.i = 2;
               break;
            case 2:
               d.player.networkHandler.sendPacket(new CloseHandledScreenC2SPacket(d.player.currentScreenHandler.syncId));
               this.l = 1;
               this.i = 3;
               break;
            case 3:
               if (this.a(d.player.getOffHandStack(), this.n)) {
                  d.player.sendMessage(Text.literal("§fСвапнул на ").append(d.player.getOffHandStack().getName()), true);
               } else {
                  d.player.sendMessage(Text.literal("§cСвап не подтвердился"), true);
               }

               this.p();
         }
      }
   }

   private void p() {
      this.g = false;
      this.i = 0;
      this.k = false;
      this.l = 0;
      this.q = -1;
   }

   private void c(int var1) {
      byte var2 = 40;
      d.interactionManager.clickSlot(d.player.currentScreenHandler.syncId, var1, var2, SlotActionType.SWAP, d.player);
   }

   private String q() {
      ItemStack var1 = d.player.getOffHandStack();
      String var2 = this.b.e();
      String var3 = this.c.e();
      return this.a(var1, var2) ? var3 : var2;
   }

   private boolean a(String var1) {
      return "Тотем".equals(var1) || "Сфера".equals(var1);
   }

   private boolean a(ItemStack var1, String var2) {
      if (var1.isEmpty()) {
         return false;
      } else {
         switch (var2) {
            case "Сфера":
               return var1.getItem() == Items.PLAYER_HEAD;
            case "Тотем":
               return var1.getItem() == Items.TOTEM_OF_UNDYING;
            default:
               return false;
         }
      }
   }

   private Optional<Integer> a(Predicate<ItemStack> var1) {
      for (int var2 = 0; var2 < 9; var2++) {
         ItemStack var3 = d.player.getInventory().getStack(var2);
         if (var1.test(var3)) {
            return Optional.of(var2);
         }
      }

      return Optional.empty();
   }

   private Optional<Integer> b(Predicate<ItemStack> var1) {
      for (int var2 = 9; var2 < 36; var2++) {
         ItemStack var3 = d.player.getInventory().getStack(var2);
         if (var1.test(var3)) {
            return Optional.of(var2);
         }
      }

      return Optional.empty();
   }

   @Compile
   @Override
      public void e() {
      super.e();
      this.g = false;
      this.h = false;
      this.i = 0;
      this.j = 0;
      this.k = false;
      this.l = 0;
      this.m = 0;
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.h = false;
      this.g = false;
      this.k = false;
      this.i = 0;
      this.l = 0;
   }

   public boolean c(ItemStack var1) {
      return this.a(var1, this.n);
   }

   static {
      NativeMethodLookup.lookup(ItemSwapModule.class, 65);
   }
}
