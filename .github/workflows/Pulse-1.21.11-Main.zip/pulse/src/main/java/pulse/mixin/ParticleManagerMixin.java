package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.OptimizationModule;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({ParticleManager.class})
public class ParticleManagerMixin {
   @Inject(
      method = {"addParticle(Lnet/minecraft/client/particle/Particle;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$limitParticle(Particle var1, CallbackInfo var2) {
      if (var1 != null) {
         OptimizationModule var3 = ModuleRegistry.W;
         if (var3 != null && var3.n()) {
            Vec3d var4 = var1.getBoundingBox().getCenter();
            if (var3.a(var4.x, var4.y, var4.z)) {
               var2.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onAddParticle(
      ParticleEffect var1, double var2, double var4, double var6, double var8, double var10, double var12, CallbackInfoReturnable<Particle> var14
   ) {
      RenderTweaksModule var15 = ModuleRegistry.h;
      if (var15 != null
         && var15.v()
         && (
            var1.getType() == ParticleTypes.BUBBLE
               || var1.getType() == ParticleTypes.BUBBLE_COLUMN_UP
               || var1.getType() == ParticleTypes.BUBBLE_POP
               || var1.getType() == ParticleTypes.CURRENT_DOWN
               || var1.getType() == ParticleTypes.UNDERWATER
         )) {
         var14.setReturnValue(null);
      }
   }
}
