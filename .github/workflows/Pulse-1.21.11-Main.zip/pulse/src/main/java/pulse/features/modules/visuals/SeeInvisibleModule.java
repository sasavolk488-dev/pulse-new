package pulse.features.modules.visuals;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.RenderEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.WorldRenderHelper;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.game.EntityUtils;

@ModuleInfo(
   a = "See Invisible",
   b = "Помечает невидимых игроков без брони анимированным кругом на полу",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class SeeInvisibleModule extends Module {
   private static final float a = 0.6F;
   private static final float b = 0.02F;
   private static final float c = 2.0F;
   private static final int f = 6;
   private final SeparatorSetting g = new SeparatorSetting("Цвет");
   private final BooleanSetting h = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting i = new ColorSetting("Кастомный цвет", new Color(190, 90, 255)).a(() -> !this.h.a());
   private final NumberSetting j = new NumberSetting("Прозрачность", 0.9F, 0.1F, 1.0F, 0.05F);
   private final Map<PlayerEntity, Animation> k = new HashMap<>();
   private double l = 0.0;
   private long m = System.currentTimeMillis();
   private static final float[] n = new float[361];
   private static final float[] o = new float[361];

   @EventHandler
   public void a(RenderEvent var1) {
      if (d.player != null && d.world != null) {
         long var2 = System.currentTimeMillis();
         float var4 = Math.min((float)(var2 - this.m) / 1000.0F, 0.1F);
         this.m = var2;
         this.l += var4;

         for (PlayerEntity var6 : d.world.getPlayers()) {
            if (this.a(var6)) {
               this.k.computeIfAbsent(var6, var0 -> new Animation()).a(1.0, 0.35000007841782976, Easings.f, true);
            }
         }

         if (!this.k.isEmpty()) {
            Camera var25 = d.getEntityRenderDispatcher().camera;
            Vec3d var26 = var25.getCameraPos();
            var1.a().push();
            Entry var7 = var1.a().peek();
            Matrix4f var8 = var7.getPositionMatrix();
            Color var9 = this.n();
            float var10 = var9.getRed() / 255.0F;
            float var11 = var9.getGreen() / 255.0F;
            float var12 = var9.getBlue() / 255.0F;
            ArrayList<float[]> var13 = new ArrayList<>();
            Iterator var14 = this.k.entrySet().iterator();

            while (var14.hasNext()) {
               java.util.Map.Entry var15 = (java.util.Map.Entry)var14.next();
               PlayerEntity var16 = (PlayerEntity)var15.getKey();
               Animation var17 = (Animation)var15.getValue();
               if (var16.isAlive() && var16.getEntityWorld() == d.world) {
                  if (!this.a(var16)) {
                     var17.a(0.0, 0.35000007841782976, Easings.f, true);
                  }

                  var17.a();
                  if (var17.d() && var17.i() == 0.0) {
                     var14.remove();
                  } else {
                     float var18 = (float)var17.j();
                     if (!(var18 <= 0.01F)) {
                        Vec3d var19 = EntityUtils.a(var16, var1.b());
                        if (var19 == null) {
                           var19 = var16.getEntityPos();
                        }

                        if (var19 != null) {
                           float var20 = var18 * this.j.b();
                           float var21 = (float)this.l + var16.getId() % 100 * 0.37F;
                           float var22 = (float)(var19.x - var26.x);
                           float var23 = (float)(var19.y + 0.020000007F - var26.y);
                           float var24 = (float)(var19.z - var26.z);
                           var13.add(new float[]{var22, var23, var24, var20, var21});
                        }
                     }
                  }
               } else {
                  var14.remove();
               }
            }

            if (var13.isEmpty()) {
               var1.a().pop();
            } else {
               Immediate var27 = WorldRenderHelper.a();
               VertexConsumer var28 = var27.getBuffer(RenderLayers.debugQuads());

               for (float[] var31 : var13) {
                  this.a(var28, var8, var31[0], var31[1], var31[2], var10, var11, var12, var31[3], var31[4]);
                  this.b(var28, var8, var31[0], var31[1], var31[2], var10, var11, var12, var31[3], var31[4]);
               }

               var27.draw(RenderLayers.debugQuads());
               VertexConsumer var30 = var27.getBuffer(RenderLayers.lines());

               for (float[] var33 : var13) {
                  this.a(var30, var7, var33[0], var33[1], var33[2], var10, var11, var12, var33[3]);
               }

               var27.draw(RenderLayers.lines());
               var1.a().pop();
            }
         }
      }
   }

   private boolean a(PlayerEntity var1) {
      if (var1 == d.player) {
         return false;
      } else if (!var1.isAlive()) {
         return false;
      } else {
         return var1.squaredDistanceTo(d.player) > 10000.0 ? false : EntityUtils.a((LivingEntity)var1);
      }
   }

   private void a(VertexConsumer var1, Matrix4f var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      float var11 = 0.8F + 0.2F * (float)Math.sin(var10 * 2.200000597123437);
      float var12 = 0.32F * var11 * var9;
      float var13 = 0.6F;

      for (byte var14 = 0; var14 < 360; var14 += 6) {
         int var15 = var14 + 6;
         float var16 = var3 + o[var14] * var13;
         float var17 = var5 + n[var14] * var13;
         float var18 = var3 + o[var15] * var13;
         float var19 = var5 + n[var15] * var13;
         var1.vertex(var2, var3, var4, var5).color(var6, var7, var8, var12);
         var1.vertex(var2, var3, var4, var5).color(var6, var7, var8, var12);
         var1.vertex(var2, var18, var4, var19).color(var6, var7, var8, 0.0F);
         var1.vertex(var2, var16, var4, var17).color(var6, var7, var8, 0.0F);
      }
   }

   private void b(VertexConsumer var1, Matrix4f var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      float var11 = 0.5F + 0.5F * (float)Math.sin(var10 * 2.200000597123437);
      float var12 = 2.0F * (0.85F + 0.15F * var11);
      float var13 = 0.6F;

      for (byte var14 = 0; var14 < 360; var14 += 6) {
         int var15 = var14 + 6;
         float var16 = var3 + o[var14] * var13;
         float var17 = var5 + n[var14] * var13;
         float var18 = var3 + o[var15] * var13;
         float var19 = var5 + n[var15] * var13;
         float var20 = (float)Math.max(0.11999995553824505, Math.sin(Math.toRadians(var14 * 3) + var10 * 2.5));
         float var21 = (float)Math.max(0.11999995553824505, Math.sin(Math.toRadians(var15 * 3) + var10 * 2.5));
         float var22 = 0.43F * var9 * var20;
         float var23 = 0.43F * var9 * var21;
         var1.vertex(var2, var16, var4, var17).color(var6, var7, var8, var22);
         var1.vertex(var2, var18, var4, var19).color(var6, var7, var8, var23);
         var1.vertex(var2, var18, var4 + var12, var19).color(var6, var7, var8, 0.0F);
         var1.vertex(var2, var16, var4 + var12, var17).color(var6, var7, var8, 0.0F);
      }
   }

   private void a(VertexConsumer var1, Entry var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      float var10 = 0.6F;

      for (byte var11 = 0; var11 < 360; var11 += 6) {
         int var12 = var11 + 6;
         float var13 = var3 + o[var11] * var10;
         float var14 = var5 + n[var11] * var10;
         float var15 = var3 + o[var12] * var10;
         float var16 = var5 + n[var12] * var10;
         a(var1, var2, var13, var4, var14, var15, var4, var16, var6, var7, var8, var9);
      }
   }

   private static void a(
      VertexConsumer var0, Entry var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11
   ) {
      float var12 = var5 - var2;
      float var13 = var6 - var3;
      float var14 = var7 - var4;
      float var15 = (float)Math.sqrt(var12 * var12 + var13 * var13 + var14 * var14);
      if (!(var15 < 1.0E-6F)) {
         var12 /= var15;
         var13 /= var15;
         var14 /= var15;
         var0.vertex(var1, var2, var3, var4).color(var8, var9, var10, var11).normal(var1, var12, var13, var14).lineWidth(2.0F);
         var0.vertex(var1, var5, var6, var7).color(var8, var9, var10, var11).normal(var1, var12, var13, var14).lineWidth(2.0F);
      }
   }

   private Color n() {
      if (this.h.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         if (var1 != null) {
            return var1.n();
         }
      }

      return this.i.a();
   }

   @Override
   public void f() {
      super.f();
      this.k.clear();
   }

   static {
      for (int var0 = 0; var0 <= 360; var0++) {
         double var1 = Math.toRadians(var0);
         n[var0] = (float)Math.sin(var1);
         o[var0] = (float)Math.cos(var1);
      }
   }
}
