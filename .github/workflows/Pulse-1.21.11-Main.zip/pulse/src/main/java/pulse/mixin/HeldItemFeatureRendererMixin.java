package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.state.ArmedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.emote.EmoteManager;

@Environment(EnvType.CLIENT)
@Mixin({HeldItemFeatureRenderer.class})
public abstract class HeldItemFeatureRendererMixin {
   @Inject(
      method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/ArmedEntityRenderState;FF)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$hideHeldItemDuringEmote(
      MatrixStack var1, OrderedRenderCommandQueue var2, int var3, ArmedEntityRenderState var4, float var5, float var6, CallbackInfo var7
   ) {
      if (var4 instanceof PlayerEntityRenderState var8) {
         if (EmoteManager.a().b()) {
            MinecraftClient var9 = MinecraftClient.getInstance();
            if (var9.world != null) {
               if (var9.world.getEntityById(var8.id) instanceof AbstractClientPlayerEntity var10 && EmoteManager.a().b(var10)) {
                  var7.cancel();
               }
            }
         }
      }
   }
}
