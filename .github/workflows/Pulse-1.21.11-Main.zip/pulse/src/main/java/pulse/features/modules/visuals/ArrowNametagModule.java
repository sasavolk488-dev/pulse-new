package pulse.features.modules.visuals;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Arrow Nametag",
   b = "Рисует имя над воткнутыми стрелами с необычным названием",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class ArrowNametagModule extends Module {
}
