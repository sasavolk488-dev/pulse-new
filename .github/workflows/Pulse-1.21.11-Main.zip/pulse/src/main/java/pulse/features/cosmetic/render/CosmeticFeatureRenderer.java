package pulse.features.cosmetic.render;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import pulse.Pulse;
import pulse.features.cosmetic.loader.CosmeticLoader;
import pulse.features.cosmetic.model.CosmeticModel;
import pulse.services.tracker.v2.ModUserTrackerV2;
import pulse.services.accounts.UserInfo;

@Environment(EnvType.CLIENT)
public class CosmeticFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
   private static final String[] a = new String[]{"hat", "wings", "pet", "bodywear"};
   private static final List<CosmeticModel> b = List.of();
   private final CosmeticRenderer c = CosmeticRenderer.a();

   public CosmeticFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> var1) {
      super(var1);
   }

   public void a(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, PlayerEntityRenderState var4, float var5, float var6) {
      if (!var4.invisible) {
         MinecraftClient var7 = MinecraftClient.getInstance();
         AbstractClientPlayerEntity var8 = this.a(var7, var4.id);
         if (var8 != null) {
            List<CosmeticModel> var9 = this.a(var8);
            if (!var9.isEmpty()) {
               PlayerEntityModel var10 = this.getContextModel();

               for (CosmeticModel var12 : var9) {
                  var1.push();
                  this.c.a(var12, var8, var1, var2, var3, var10, 0.0F);
                  var1.pop();
               }
            }
         }
      }
   }

   private AbstractClientPlayerEntity a(MinecraftClient var1, int var2) {
      if (var1.world == null) {
         return null;
      } else {
         Entity var3 = var1.world.getEntityById(var2);
         return var3 instanceof AbstractClientPlayerEntity ? (AbstractClientPlayerEntity)var3 : null;
      }
   }

   private List<CosmeticModel> a(AbstractClientPlayerEntity var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      boolean var3 = var2.player != null && var2.player.getId() == var1.getId();
      String var4 = var3 ? null : var1.getGameProfile().name();
      if (!var3 && !ModUserTrackerV2.d().a(var4)) {
         return b;
      } else {
         UserInfo var5 = var3 ? Pulse.n() : null;
         if (var3 && var5 == null) {
            return b;
         } else {
            ArrayList var6 = null;

            for (String var10 : a) {
               Integer var11 = var3 ? var5.c(var10) : ModUserTrackerV2.d().a(var4, var10);
               if (var11 != null) {
                  CosmeticModel var12 = CosmeticLoader.a().a(var11);
                  if (var12 != null && var12.e() != null) {
                     if (var6 == null) {
                        var6 = new ArrayList<>(4);
                     }

                     var6.add(var12);
                  }
               }
            }

            return (List<CosmeticModel>)(var6 != null ? var6 : b);
         }
      }
   }

   @Override
   public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state, float limbAngle, float limbDistance) {
      this.a(matrices, queue, light, (PlayerEntityRenderState)state, limbAngle, limbDistance);
   }
}
