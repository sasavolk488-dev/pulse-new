package pulse.mixin;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.client.gui.hud.ChatHudLine.Visible;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.animations.ChatAnimationHolder;
import pulse.features.modules.visuals.animations.ChatMessageAnimator;

@Environment(EnvType.CLIENT)
@Mixin({ChatHud.class})
public abstract class ChatHudMixin {
   @Shadow
   @Final
   private List<Visible> visibleMessages;

   @Shadow
   protected abstract int getWidth();

   @Unique
   private boolean isChatAnimationEnabled() {
      return ModuleRegistry.t != null && ModuleRegistry.t.k() && ModuleRegistry.t.c.a();
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/hud/ChatHud$Backend;IIZ)V"},
      at = {@At("HEAD")}
   )
   private void onPrivateRenderHead(@Coerce Object var1, int var2, int var3, boolean var4, CallbackInfo var5) {
      ChatAnimationHolder.a = 0.0F;
      if (this.isChatAnimationEnabled()) {
         ChatAnimationHolder.a();
      }
   }

   @Inject(
      method = {"addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V"},
      at = {@At("TAIL")}
   )
   private void onAddMessage(CallbackInfo var1) {
      if (this.isChatAnimationEnabled()) {
         if (!this.visibleMessages.isEmpty()) {
            int var2 = this.getWidth();
            long var3 = (long)ModuleRegistry.t.f.q().floatValue();
            Visible var5 = this.visibleMessages.get(0);
            if (!ChatAnimationHolder.b(var5)) {
               ChatAnimationHolder.a(var5, new ChatMessageAnimator(-var2, 0.0F, var3));
            }
         }
      }
   }

   @Inject(
      method = {"clear"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onClear(boolean var1, CallbackInfo var2) {
      ChatAnimationHolder.b();
      if (ModuleRegistry.an != null && ModuleRegistry.an.n()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$chatHelperAntiSpam(Text var1, @Nullable MessageSignatureData var2, @Nullable MessageIndicator var3, CallbackInfo var4) {
      if (ModuleRegistry.an != null) {
         ChatHud var5 = (ChatHud)(Object)this;
         if (ModuleRegistry.an.a(var5, var1)) {
            var4.cancel();
         }
      }
   }
}
