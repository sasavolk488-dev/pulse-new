package pulse.features.cosmetic.geo;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.HashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public class GeoModelParser {
   private static final float a = 0.001F;
   private static final float b = 5.0E-4F;
   private static final int c = 0;
   private static final int d = 1;
   private static final int e = 2;
   private static final int f = 3;
   private static final int g = 4;
   private static final int h = 5;
   private static final int i = 6;
   private static final int j = 7;

   public static GeoModel a(String var0) {
      try {
         JsonObject var1 = JsonParser.parseString(var0).getAsJsonObject();
         return a(var1);
      } catch (Exception var2) {
         Pulse.m().error("Не разобрали модель Bedrock", (Throwable)var2);
         return null;
      }
   }

   private static GeoModel a(JsonObject var0) {
      JsonArray var1 = var0.getAsJsonArray("minecraft:geometry");
      if (var1 != null && var1.size() != 0) {
         JsonObject var2 = var1.get(0).getAsJsonObject();
         JsonObject var3 = var2.getAsJsonObject("description");
         int var4 = var3 != null && var3.has("texture_width") ? var3.get("texture_width").getAsInt() : 64;
         int var5 = var3 != null && var3.has("texture_height") ? var3.get("texture_height").getAsInt() : 64;
         GeoModel var6 = new GeoModel();
         var6.b = var4;
         var6.c = var5;
         JsonArray var7 = var2.getAsJsonArray("bones");
         if (var7 != null) {
            HashMap var8 = new HashMap();

            for (JsonElement var10 : var7) {
               GeoBone var11 = a(var10.getAsJsonObject(), var4, var5);
               var8.put(var11.d, var11);
            }

            for (JsonElement var15 : var7) {
               JsonObject var16 = var15.getAsJsonObject();
               GeoBone var12 = (GeoBone)var8.get(var16.get("name").getAsString());
               GeoBone var13 = var16.has("parent") ? (GeoBone)var8.get(var16.get("parent").getAsString()) : null;
               if (var13 != null) {
                  var13.b.add(var12);
                  var12.a = var13;
               } else {
                  if (var16.has("parent")) {
                     Pulse.m().warn("Кость «{}»: родитель «{}» не найден, рисуем от корня", var12.d, var16.get("parent").getAsString());
                  }

                  var6.a.add(var12);
               }
            }
         }

         return var6;
      } else {
         Pulse.m().error("В модели нет minecraft:geometry");
         return null;
      }
   }

   private static GeoBone a(JsonObject var0, int var1, int var2) {
      GeoBone var3 = new GeoBone(var0.get("name").getAsString());
      if (var0.has("pivot")) {
         JsonArray var4 = var0.getAsJsonArray("pivot");
         var3.f = -var4.get(0).getAsFloat();
         var3.g = var4.get(1).getAsFloat();
         var3.h = var4.get(2).getAsFloat();
      }

      if (var0.has("rotation")) {
         JsonArray var7 = var0.getAsJsonArray("rotation");
         var3.a((float)Math.toRadians(-var7.get(0).getAsFloat()));
         var3.b((float)Math.toRadians(-var7.get(1).getAsFloat()));
         var3.c((float)Math.toRadians(var7.get(2).getAsFloat()));
      }

      var3.e = var0.has("neverRender") && var0.get("neverRender").getAsBoolean();
      Float var8 = var0.has("inflate") ? var0.get("inflate").getAsFloat() : null;
      if (var0.has("cubes")) {
         for (JsonElement var6 : var0.getAsJsonArray("cubes")) {
            var3.c.add(a(var6.getAsJsonObject(), var1, var2, var8));
         }
      }

      return var3;
   }

   private static GeoCube a(JsonObject var0, int var1, int var2, Float var3) {
      float[] var4 = a(var0, "origin", new float[]{0.0F, 0.0F, 0.0F});
      float[] var5 = a(var0, "size", new float[]{0.0F, 0.0F, 0.0F});
      float[] var6 = a(var0, "pivot", new float[]{0.0F, 0.0F, 0.0F});
      float[] var7 = a(var0, "rotation", new float[]{0.0F, 0.0F, 0.0F});
      boolean var8 = var0.has("mirror") && var0.get("mirror").getAsBoolean();
      float var9 = var0.has("inflate") ? var0.get("inflate").getAsFloat() : (var3 == null ? 0.0F : var3);
      float var10 = var9 / 16.0F;
      GeoCube var11 = new GeoCube(var5[0], var5[1], var5[2]);
      var11.c = new Vec3F(-var6[0], var6[1], var6[2]);
      var11.d = new Vec3F((float)Math.toRadians(-var7[0]), (float)Math.toRadians(-var7[1]), (float)Math.toRadians(var7[2]));
      var11.e = var9;
      var11.f = var8;
      a(var11, var4, var5, var10, var8, var0, var1, var2);
      return var11;
   }

   private static void a(GeoCube var0, float[] var1, float[] var2, float var3, boolean var4, JsonObject var5, int var6, int var7) {
      float var8 = -(var1[0] + var2[0]) / 16.0F;
      float var9 = var1[1] / 16.0F;
      float var10 = var1[2] / 16.0F;
      float var11 = var8 - var3;
      float var12 = var8 + var2[0] / 16.0F + var3;
      float var13 = var9 - var3;
      float var14 = var9 + var2[1] / 16.0F + var3;
      float var15 = var10 - var3;
      float var16 = var10 + var2[2] / 16.0F + var3;
      if (var12 - var11 < 5.0E-4F) {
         float var17 = (var11 + var12) * 0.5F;
         var11 = var17 - 0.001F;
         var12 = var17 + 0.001F;
      }

      if (var14 - var13 < 5.0E-4F) {
         float var22 = (var13 + var14) * 0.5F;
         var13 = var22 - 0.001F;
         var14 = var22 + 0.001F;
      }

      if (var16 - var15 < 5.0E-4F) {
         float var23 = (var15 + var16) * 0.5F;
         var15 = var23 - 0.001F;
         var16 = var23 + 0.001F;
      }

      float[][] var24 = new float[][]{
         {var11, var13, var15},
         {var11, var13, var16},
         {var11, var14, var15},
         {var11, var14, var16},
         {var12, var14, var15},
         {var12, var14, var16},
         {var12, var13, var15},
         {var12, var13, var16}
      };
      JsonElement var18 = var5.get("uv");
      boolean var19 = var18 != null && var18.isJsonArray();
      GeoModelParser.Face[] var20 = GeoModelParser.Face.values();

      for (int var21 = 0; var21 < var20.length; var21++) {
         var0.a[var21] = var19 ? a(var24, var18.getAsJsonArray(), var2, var20[var21], var4, var6, var7) : a(var24, var18, var20[var21], var4, var6, var7);
      }
   }

   private static GeoQuad a(float[][] var0, JsonElement var1, GeoModelParser.Face var2, boolean var3, int var4, int var5) {
      if (var1 != null && var1.isJsonObject()) {
         JsonObject var6 = var1.getAsJsonObject();
         if (!var6.has(var2.g)) {
            return null;
         } else {
            JsonObject var7 = var6.getAsJsonObject(var2.g);
            JsonArray var8 = var7.getAsJsonArray("uv");
            JsonArray var9 = var7.getAsJsonArray("uv_size");
            if (var8 != null && var9 != null) {
               float var10 = var9.get(0).getAsFloat();
               float var11 = var9.get(1).getAsFloat();
               if (!(Math.abs(var10) < 0.001F) && !(Math.abs(var11) < 0.001F)) {
                  int var12 = var7.has("uv_rotation") ? var7.get("uv_rotation").getAsInt() : 0;
                  return a(a(var0, var2, false, var3), var8.get(0).getAsFloat(), var8.get(1).getAsFloat(), var10, var11, var12, var4, var5, var3, var2);
               } else {
                  return null;
               }
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private static GeoQuad a(float[][] var0, JsonArray var1, float[] var2, GeoModelParser.Face var3, boolean var4, int var5, int var6) {
      float var7 = var1.get(0).getAsFloat();
      float var8 = var1.get(1).getAsFloat();
      float var9 = (float)Math.floor(var2[0]);
      float var10 = (float)Math.floor(var2[1]);
      float var11 = (float)Math.floor(var2[2]);
      float var12;
      float var13;
      float var14;
      float var15;
      switch (var3) {
         case a:
            var12 = var7 + var11 + var9;
            var13 = var8 + var11;
            var14 = var11;
            var15 = var10;
            break;
         case b:
            var12 = var7;
            var13 = var8 + var11;
            var14 = var11;
            var15 = var10;
            break;
         case c:
            var12 = var7 + var11;
            var13 = var8 + var11;
            var14 = var9;
            var15 = var10;
            break;
         case d:
            var12 = var7 + var11 + var9 + var11;
            var13 = var8 + var11;
            var14 = var9;
            var15 = var10;
            break;
         case e:
            var12 = var7 + var11;
            var13 = var8;
            var14 = var9;
            var15 = var11;
            break;
         case f:
            var12 = var7 + var11 + var9;
            var13 = var8 + var11;
            var14 = var9;
            var15 = -var11;
            break;
         default:
            var12 = 0.0F;
            var13 = 0.0F;
            var14 = 0.0F;
            var15 = 0.0F;
      }

      return a(a(var0, var3, true, var4), var12, var13, var14, var15, 0, var5, var6, var4, var3);
   }

   private static float[][] a(float[][] var0, GeoModelParser.Face var1, boolean var2, boolean var3) {
      return switch (var1) {
         case a -> var3 ? b(var0) : a(var0);
         case b -> var3 ? a(var0) : b(var0);
         case c -> c(var0);
         case d -> d(var0);
         case e -> var3 && !var2 ? f(var0) : e(var0);
         case f -> var3 && !var2 ? e(var0) : f(var0);
      };
   }

   private static float[][] a(float[][] var0) {
      return new float[][]{var0[3], var0[2], var0[0], var0[1]};
   }

   private static float[][] b(float[][] var0) {
      return new float[][]{var0[4], var0[5], var0[7], var0[6]};
   }

   private static float[][] c(float[][] var0) {
      return new float[][]{var0[2], var0[4], var0[6], var0[0]};
   }

   private static float[][] d(float[][] var0) {
      return new float[][]{var0[5], var0[3], var0[1], var0[7]};
   }

   private static float[][] e(float[][] var0) {
      return new float[][]{var0[3], var0[5], var0[4], var0[2]};
   }

   private static float[][] f(float[][] var0) {
      return new float[][]{var0[0], var0[6], var0[7], var0[1]};
   }

   private static GeoQuad a(
      float[][] var0, float var1, float var2, float var3, float var4, int var5, float var6, float var7, boolean var8, GeoModelParser.Face var9
   ) {
      float var10 = (var1 + var3) / var6;
      float var11 = (var2 + var4) / var7;
      var1 /= var6;
      var2 /= var7;
      float var12 = var9.h;
      float var13 = var9.i;
      float var14 = var9.j;
      if (!var8) {
         float var15 = var10;
         var10 = var1;
         var1 = var15;
      } else {
         var12 = -var12;
      }

      float[] var21 = a(var5, var1, var2, var10, var11);
      GeoVertex[] var16 = new GeoVertex[4];

      for (int var17 = 0; var17 < 4; var17++) {
         float[] var18 = var0[var17];
         var16[var17] = new GeoVertex(var18[0], var18[1], var18[2], var21[var17 * 2], var21[var17 * 2 + 1]);
      }

      return new GeoQuad(var16, var12, var13, var14);
   }

   private static float[] a(int var0, float var1, float var2, float var3, float var4) {
      int var5 = (var0 % 360 + 360) % 360 / 90;

      return switch (var5) {
         case 1 -> new float[]{var3, var2, var3, var4, var1, var4, var1, var2};
         case 2 -> new float[]{var3, var4, var1, var4, var1, var2, var3, var2};
         case 3 -> new float[]{var1, var4, var1, var2, var3, var2, var3, var4};
         default -> new float[]{var1, var2, var3, var2, var3, var4, var1, var4};
      };
   }

   private static float[] a(JsonObject var0, String var1, float[] var2) {
      if (var0.has(var1) && var0.get(var1).isJsonArray()) {
         JsonArray var3 = var0.getAsJsonArray(var1);
         return var3.size() < 3 ? var2 : new float[]{var3.get(0).getAsFloat(), var3.get(1).getAsFloat(), var3.get(2).getAsFloat()};
      } else {
         return var2;
      }
   }

   @Environment(EnvType.CLIENT)
   private static enum Face {
      a("west", -1.0F, 0.0F, 0.0F),
      b("east", 1.0F, 0.0F, 0.0F),
      c("north", 0.0F, 0.0F, -1.0F),
      d("south", 0.0F, 0.0F, 1.0F),
      e("up", 0.0F, 1.0F, 0.0F),
      f("down", 0.0F, -1.0F, 0.0F);

      final String g;
      final float h;
      final float i;
      final float j;

      private Face(String var3, float var4, float var5, float var6) {
         this.g = var3;
         this.h = var4;
         this.i = var5;
         this.j = var6;
      }

      private static GeoModelParser.Face[] a() {
         return new GeoModelParser.Face[]{a, b, c, d, e, f};
      }
   }
}
