package pulse.features.cosmetic.geo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GeoVertex {
   public Vec3F a;
   public float b;
   public float c;

   public GeoVertex(float var1, float var2, float var3, float var4, float var5) {
      this.a = new Vec3F(var1, var2, var3);
      this.b = var4;
      this.c = var5;
   }

   public GeoVertex(Vec3F var1, float var2, float var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
