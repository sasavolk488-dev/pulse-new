package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import pulse.Pulse;
import pulse.ui.menu.MenuState;
import pulse.ui.menu.PulseGameMenuScreen;
import pulse.mixin.accessor.GameMenuScreenAccessor;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public class GameMenuReplaceMixin {
   @ModifyVariable(
      method = {"setScreen"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private Screen pulse$replaceGameMenuScreen(Screen var1) {
      return (Screen)(var1 instanceof GameMenuScreen
            && ((GameMenuScreenAccessor)var1).pulse$isShowMenu()
            && MenuState.d()
            && Pulse.l() != null
            && Pulse.l().p() != null
         ? new PulseGameMenuScreen()
         : var1);
   }
}
