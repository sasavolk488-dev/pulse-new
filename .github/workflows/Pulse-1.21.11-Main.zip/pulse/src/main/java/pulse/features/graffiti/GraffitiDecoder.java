package pulse.features.graffiti;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.metadata.IIOMetadataNode;
import javax.imageio.stream.ImageInputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class GraffitiDecoder {
   static final int a = 64;
   private static final int b = 4096;
   private static final int c = 20;
   private static final int d = 100;

   private GraffitiDecoder() {
   }

   static GraffitiDecoder.Frames a(Path var0) throws Exception {
      String var1 = var0.getFileName().toString().toLowerCase();
      int var2 = var1.lastIndexOf(46);
      String var3 = var2 >= 0 ? var1.substring(var2 + 1) : "png";
      return a(Files.readAllBytes(var0), var3);
   }

   static GraffitiDecoder.Frames a(byte[] var0, String var1) throws Exception {
      String var2 = var1 == null ? "png" : var1.toLowerCase();
      if (var2.equals("webp")) {
         return c(var0);
      } else {
         return var2.equals("gif") ? d(var0) : a(var0);
      }
   }

   private static GraffitiDecoder.Frames a(byte[] var0) throws Exception {
      b(var0);
      BufferedImage var1 = ImageIO.read(new ByteArrayInputStream(var0));
      if (var1 == null) {
         throw new IOException("не декодируется");
      } else {
         return new GraffitiDecoder.Frames(new BufferedImage[]{var1}, new int[]{0});
      }
   }

   private static void b(byte[] var0) throws Exception {
      try (
         ByteArrayInputStream var1 = new ByteArrayInputStream(var0);
         ImageInputStream var2 = ImageIO.createImageInputStream(var1);
      ) {
         Iterator var3 = ImageIO.getImageReaders(var2);
         if (!var3.hasNext()) {
            throw new IOException("нет декодера под формат");
         }

         ImageReader var4 = (ImageReader)var3.next();
         var4.setInput(var2, true);
         int var5 = var4.getWidth(0);
         int var6 = var4.getHeight(0);
         var4.dispose();
         if (var5 > 4096 || var6 > 4096) {
            throw new IOException("слишком большой (" + var5 + "x" + var6 + ")");
         }
      }
   }

   private static GraffitiDecoder.Frames c(byte[] var0) throws Exception {
      WebpAnimInfo var1 = WebpAnimInfo.a(var0);
      if (!var1.a()) {
         return a(var0);
      } else if (var1.a <= 4096 && var1.b <= 4096) {
         GraffitiDecoder.Frames var20;
         try (
            ByteArrayInputStream var2 = new ByteArrayInputStream(var0);
            ImageInputStream var3 = ImageIO.createImageInputStream(var2);
         ) {
            Iterator var4 = ImageIO.getImageReaders(var3);
            if (!var4.hasNext()) {
               throw new IOException("webp-декодер не подхватился (SPI)");
            }

            ImageReader var5 = (ImageReader)var4.next();
            var5.setInput(var3, false);
            int var6 = Math.min(var5.getNumImages(true), var1.c.size());
            int var7 = var1.a > 0 ? var1.a : var5.getWidth(0);
            int var8 = var1.b > 0 ? var1.b : var5.getHeight(0);
            BufferedImage var9 = new BufferedImage(var7, var8, 2);
            Graphics2D var10 = var9.createGraphics();
            BufferedImage[] var11 = new BufferedImage[var6];
            int[] var12 = new int[var6];

            for (int var13 = 0; var13 < var6; var13++) {
               WebpAnimInfo.Frame var14 = var1.c.get(var13);
               BufferedImage var15 = var5.read(var13);
               if (!var14.blendAlpha()) {
                  a(var9, var14.x(), var14.y(), var15.getWidth(), var15.getHeight());
               }

               var10.drawImage(var15, var14.x(), var14.y(), null);
               var11[var13] = a(var9);
               var12[var13] = var14.durationMs() <= 0 ? 100 : Math.max(20, var14.durationMs());
               if (var14.disposeToBackground()) {
                  a(var9, var14.x(), var14.y(), var15.getWidth(), var15.getHeight());
               }
            }

            var10.dispose();
            var5.dispose();
            var20 = a(new GraffitiDecoder.Frames(var11, var12));
         }

         return var20;
      } else {
         throw new IOException("слишком большой канвас (" + var1.a + "x" + var1.b + ")");
      }
   }

   private static GraffitiDecoder.Frames d(byte[] var0) throws Exception {
      b(var0);

      GraffitiDecoder.Frames var27;
      try (
         ByteArrayInputStream var1 = new ByteArrayInputStream(var0);
         ImageInputStream var2 = ImageIO.createImageInputStream(var1);
      ) {
         Iterator var3 = ImageIO.getImageReadersBySuffix("gif");
         if (!var3.hasNext()) {
            throw new IOException("нет GIF-декодера");
         }

         ImageReader var4 = (ImageReader)var3.next();
         var4.setInput(var2, false);
         int var5 = var4.getNumImages(true);
         BufferedImage var6 = var4.read(0);
         int[] var7 = a(var4);
         int var8 = var7[0] > 0 ? var7[0] : var6.getWidth();
         int var9 = var7[1] > 0 ? var7[1] : var6.getHeight();
         BufferedImage var10 = new BufferedImage(var8, var9, 2);
         Graphics2D var11 = var10.createGraphics();
         BufferedImage[] var12 = new BufferedImage[var5];
         int[] var13 = new int[var5];
         BufferedImage var14 = null;
         String var15 = "none";
         int var16 = 0;
         int var17 = 0;
         int var18 = 0;
         int var19 = 0;

         for (int var20 = 0; var20 < var5; var20++) {
            BufferedImage var21 = var20 == 0 ? var6 : var4.read(var20);
            GraffitiDecoder.GifFrameMeta var22 = a(var4, var20);
            if ("restoreToPrevious".equals(var15) && var14 != null) {
               var11.drawImage(var14, 0, 0, null);
            } else if ("restoreToBackgroundColor".equals(var15)) {
               a(var10, var16, var17, var18, var19);
            }

            var14 = "restoreToPrevious".equals(var22.d) ? a(var10) : null;
            var11.drawImage(var21, var22.a, var22.b, null);
            var12[var20] = a(var10);
            var13[var20] = Math.max(20, var22.c);
            var15 = var22.d;
            var16 = var22.a;
            var17 = var22.b;
            var18 = var21.getWidth();
            var19 = var21.getHeight();
         }

         var11.dispose();
         var4.dispose();
         var27 = a(new GraffitiDecoder.Frames(var12, var13));
      }

      return var27;
   }

   private static GraffitiDecoder.Frames a(GraffitiDecoder.Frames var0) {
      int var1 = var0.images.length;
      if (var1 <= 64) {
         return var0;
      } else {
         int var2 = (var1 + 64 - 1) / 64;
         int var3 = (var1 + var2 - 1) / var2;
         BufferedImage[] var4 = new BufferedImage[var3];
         int[] var5 = new int[var3];

         for (int var6 = 0; var6 < var1; var6++) {
            int var7 = var6 / var2;
            if (var6 % var2 == 0) {
               var4[var7] = var0.images[var6];
            }

            var5[var7] += var0.delaysMs[var6];
         }

         return new GraffitiDecoder.Frames(var4, var5);
      }
   }

   private static BufferedImage a(BufferedImage var0) {
      BufferedImage var1 = new BufferedImage(var0.getWidth(), var0.getHeight(), 2);
      var1.getGraphics().drawImage(var0, 0, 0, null);
      return var1;
   }

   private static void a(BufferedImage var0, int var1, int var2, int var3, int var4) {
      for (int var5 = Math.max(0, var2); var5 < var2 + var4 && var5 < var0.getHeight(); var5++) {
         for (int var6 = Math.max(0, var1); var6 < var1 + var3 && var6 < var0.getWidth(); var6++) {
            var0.setRGB(var6, var5, 0);
         }
      }
   }

   private static int[] a(ImageReader var0) {
      try {
         IIOMetadata var1 = var0.getStreamMetadata();
         if (var1 == null) {
            return new int[]{0, 0};
         } else {
            IIOMetadataNode var2 = (IIOMetadataNode)var1.getAsTree(var1.getNativeMetadataFormatName());
            IIOMetadataNode var3 = a(var2, "LogicalScreenDescriptor");
            return var3 == null ? new int[]{0, 0} : new int[]{a(var3.getAttribute("logicalScreenWidth")), a(var3.getAttribute("logicalScreenHeight"))};
         }
      } catch (Exception var4) {
         return new int[]{0, 0};
      }
   }

   private static GraffitiDecoder.GifFrameMeta a(ImageReader var0, int var1) {
      GraffitiDecoder.GifFrameMeta var2 = new GraffitiDecoder.GifFrameMeta();

      try {
         IIOMetadata var3 = var0.getImageMetadata(var1);
         IIOMetadataNode var4 = (IIOMetadataNode)var3.getAsTree(var3.getNativeMetadataFormatName());
         IIOMetadataNode var5 = a(var4, "ImageDescriptor");
         if (var5 != null) {
            var2.a = a(var5.getAttribute("imageLeftPosition"));
            var2.b = a(var5.getAttribute("imageTopPosition"));
         }

         IIOMetadataNode var6 = a(var4, "GraphicControlExtension");
         if (var6 != null) {
            var2.c = a(var6.getAttribute("delayTime")) * 10;
            String var7 = var6.getAttribute("disposalMethod");
            if (var7 != null && !var7.isEmpty()) {
               var2.d = var7;
            }
         }
      } catch (Exception var8) {
      }

      return var2;
   }

   private static IIOMetadataNode a(IIOMetadataNode var0, String var1) {
      for (int var2 = 0; var2 < var0.getLength(); var2++) {
         if (var0.item(var2) instanceof IIOMetadataNode var3 && var3.getNodeName().equals(var1)) {
            return var3;
         }
      }

      return null;
   }

   private static int a(String var0) {
      try {
         return var0 != null && !var0.isEmpty() ? Integer.parseInt(var0) : 0;
      } catch (NumberFormatException var2) {
         return 0;
      }
   }

   @Environment(EnvType.CLIENT)
   record Frames(BufferedImage[] images, int[] delaysMs) {
      boolean a() {
         return this.images.length > 1;
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class GifFrameMeta {
      int a;
      int b;
      int c = 100;
      String d = "none";
   }
}
