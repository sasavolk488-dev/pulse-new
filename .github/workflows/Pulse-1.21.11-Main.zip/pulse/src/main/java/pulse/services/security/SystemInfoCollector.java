package pulse.services.security;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;


//собирал инфу
@Environment(EnvType.CLIENT)
public class SystemInfoCollector {

   public static String a() {
      return "";
   }

   public static String b() {
      return "";
   }

   public static String c() {
      return "";
   }

   public static List<String> d() {
      return Collections.emptyList();
   }

   public static List<String> e() {
      return Collections.emptyList();
   }

   public static List<String> f() {
      return Collections.emptyList();
   }

   public static List<String> g() {
      return Collections.emptyList();
   }

   public static String h() {
      return "";
   }

   public static SystemInfoCollector.SystemInfo a(String var0) {
      return new SystemInfoCollector.SystemInfo(
              "",
              "",
              "",
              Collections.emptyList(),
              Collections.emptyList(),
              Collections.emptyList(),
              Collections.emptyList()
      );
   }

   public static SystemInfoCollector.SystemInfo i() {
      return a((String) null);
   }

   public static String j() {
      return "";
   }

   public static String b(String var0) {
      return "";
   }

   public static String a(SystemInfoCollector.SystemInfo var0) {
      return "";
   }

   @Environment(EnvType.CLIENT)
   public static class SystemInfo {
      private String a;
      private String b;
      private String c;
      private List<String> d;
      private List<String> e;
      private List<String> f;
      private List<String> g;

      public SystemInfo(String var1, String var2, String var3,
                        List<String> var4, List<String> var5,
                        List<String> var6, List<String> var7) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = new ArrayList<>(var4);
         this.e = new ArrayList<>(var5);
         this.f = new ArrayList<>(var6);
         this.g = new ArrayList<>(var7);
      }

      public SystemInfo(String var1, String var2, String var3,
                        List<String> var4, List<String> var5,
                        List<String> var6) {
         this(var1, var2, var3, var4, var5, var6, Collections.emptyList());
      }

      public String a() {
         return "";
      }

      public String b() {
         return "";
      }

      public String c() {
         return "";
      }

      public List<String> d() {
         return Collections.emptyList();
      }

      public List<String> e() {
         return Collections.emptyList();
      }

      public List<String> f() {
         return Collections.emptyList();
      }

      public List<String> g() {
         return Collections.emptyList();
      }

      public String h() {
         return "";
      }

      public String i() {
         return "";
      }

      public String j() {
         return "";
      }

      public String k() {
         return "";
      }
   }
}