package pulse.core.handler;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.handler.impl.AeParticleHandler;
import pulse.core.handler.impl.AnarchyFinderHandler;
import pulse.core.handler.impl.ChestSorterHandler;
import pulse.core.handler.impl.ClickGuiRenderHandler;
import pulse.core.handler.impl.DebuffTimeHandler;
import pulse.core.handler.impl.EmoteHandler;
import pulse.core.handler.impl.FunTimeAuthHandler;
import pulse.core.handler.impl.GraffitiHandler;
import pulse.core.handler.impl.HWJoinerHandler;
import pulse.core.handler.impl.InventoryBuilderHandler;
import pulse.core.handler.impl.KeyboardHandler;
import pulse.core.handler.impl.MarkerRenderHandler;
import pulse.core.handler.impl.ParticleHandler;
import pulse.core.handler.impl.PhraseHandler;
import pulse.core.handler.impl.PlayerPingHandler;
import pulse.core.handler.impl.ServerIntegrationHandler;
import pulse.core.handler.impl.SplashRenderHandler;
import pulse.core.handler.impl.TargetHandler;
import pulse.core.handler.impl.autoevent.AutoEventHandler;
import pulse.core.handler.impl.music.MusicHandler;
import pulse.services.tracker.v2.PartyHealthReporter;
import pulse.services.tracker.v2.PartyInventoryReporter;
import pulse.services.security.ProtectionCore;

@Environment(EnvType.CLIENT)
public class HandlerRegistry {
   private static final List<Handler> w = new ArrayList<>();
   public static final ServerIntegrationHandler a = new ServerIntegrationHandler();
   public static final KeyboardHandler b = new KeyboardHandler();
   public static final AutoEventHandler c = new AutoEventHandler();
   public static final ClickGuiRenderHandler d = new ClickGuiRenderHandler();
   public static final TargetHandler e = new TargetHandler();
   public static final MarkerRenderHandler f = new MarkerRenderHandler();
   public static final ParticleHandler g = new ParticleHandler();
   public static final DebuffTimeHandler h = new DebuffTimeHandler();
   public static final AnarchyFinderHandler i = new AnarchyFinderHandler();
   public static final MusicHandler j = new MusicHandler();
   public static final PlayerPingHandler k = new PlayerPingHandler();
   public static final InventoryBuilderHandler l = new InventoryBuilderHandler();
   public static final SplashRenderHandler m = new SplashRenderHandler();
   public static final EmoteHandler n = new EmoteHandler();
   public static final PhraseHandler o = new PhraseHandler();
   public static final AeParticleHandler p = new AeParticleHandler();
   public static final ChestSorterHandler q = new ChestSorterHandler();
   public static final HWJoinerHandler r = new HWJoinerHandler();
   public static final FunTimeAuthHandler s = new FunTimeAuthHandler();
   public static final PartyHealthReporter t = new PartyHealthReporter();
   public static final PartyInventoryReporter u = new PartyInventoryReporter();
   public static final GraffitiHandler v = new GraffitiHandler();

   public static void a() {
      if (ProtectionCore.b()) {
         ProtectionCore.c();
         a(a);
         a(b);
         a(c);
         a(d);
         a(e);
         a(f);
         a(g);
         a(h);
         a(i);
         a(j);
         a(k);
         a(l);
         a(m);
         a(n);
         a(p);
         a(q);
         a(r);
         a(s);
         a(t);
         a(u);
         a(v);
         a(o);
      }
   }

   public static void registerUiHandlers() {
      a(b);
      a(d);
   }

   private static void a(Handler var0) {
      if (!w.contains(var0)) {
         var0.a();
         w.add(var0);
      }
   }

   public static List<Handler> b() {
      return new ArrayList<>(w);
   }
}
