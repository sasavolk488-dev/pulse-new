package pulse.mixin.accessor;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.ChatHudLine.Visible;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({ChatHud.class})
public interface ChatHudAccessor {
   @Accessor("messages")
   List<ChatHudLine> getMessages();

   @Accessor("visibleMessages")
   List<Visible> getVisibleMessages();
}
