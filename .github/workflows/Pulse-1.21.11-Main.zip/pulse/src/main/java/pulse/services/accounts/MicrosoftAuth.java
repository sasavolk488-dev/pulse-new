package pulse.services.accounts;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public final class MicrosoftAuth {
   private static final String a = "54fd49e4-2103-4044-9603-2b028c814ec3";
   private static final String b = "XboxLive.signin%20XboxLive.offline_access";
   private static final Duration c = Duration.ofSeconds(30L);
   private static final Pattern d = Pattern.compile("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})");
   private static final String e = "$1-$2-$3-$4-$5";
   private static final HttpClient f = HttpClient.newBuilder().connectTimeout(c).followRedirects(Redirect.NEVER).build();
   private static volatile Thread g;
   private static final AtomicBoolean h = new AtomicBoolean();

   private MicrosoftAuth() {
   }

   public static boolean a() {
      Thread var0 = g;
      return var0 != null && var0.isAlive();
   }

   public static void b() {
      h.set(true);
      Thread var0 = g;
      if (var0 != null) {
         var0.interrupt();
      }
   }

   public static void a(MicrosoftAuth.Listener var0) {
      a(
         var0,
         () -> {
            JsonObject var1 = a(
               b(
                  "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode",
                  "client_id=54fd49e4-2103-4044-9603-2b028c814ec3&scope=XboxLive.signin%20XboxLive.offline_access"
               ),
               "Microsoft не выдал код входа"
            );
            String var2 = var1.get("device_code").getAsString();
            String var3 = var1.get("user_code").getAsString();
            String var4 = var1.get("verification_uri").getAsString();
            long var5 = System.currentTimeMillis() + var1.get("expires_in").getAsLong() * 1000L;
            long var7 = Math.max(1L, var1.get("interval").getAsLong());
            var0.a(var3, var4);

            while (System.currentTimeMillis() < var5) {
               Thread.sleep(var7 * 1000L);
               if (h.get()) {
                  return null;
               }

               HttpResponse var9 = b(
                  "https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
                  "grant_type=urn:ietf:params:oauth:grant-type:device_code&client_id=54fd49e4-2103-4044-9603-2b028c814ec3&device_code=" + b(var2)
               );
               JsonObject var10 = JsonParser.parseString((String)var9.body()).getAsJsonObject();
               if (var9.statusCode() == 200) {
                  return a(var10.get("access_token").getAsString(), a(var10, "refresh_token"));
               }

               String var11 = a(var10, "error");
               if (!"authorization_pending".equals(var11)) {
                  if (!"slow_down".equals(var11)) {
                     if ("authorization_declined".equals(var11)) {
                        throw new MicrosoftAuth.AuthException("Вход отменён в браузере");
                     }

                     if (!"expired_token".equals(var11)) {
                        throw new MicrosoftAuth.AuthException("Ошибка авторизации Microsoft: " + var11);
                     }
                     break;
                  }

                  var7 += 5L;
               }
            }

            throw new MicrosoftAuth.AuthException("Время входа истекло — попробуйте ещё раз");
         }
      );
   }

   public static void a(Supplier<String> var0, MicrosoftAuth.Listener var1) {
      a(
         var1,
         () -> {
            String var1x = (String)var0.get();
            if (var1x != null && !var1x.isEmpty()) {
               HttpResponse var2 = b(
                  "https://login.live.com/oauth20_token.srf",
                  "client_id=54fd49e4-2103-4044-9603-2b028c814ec3&refresh_token="
                     + b(var1x)
                     + "&grant_type=refresh_token&scope=XboxLive.signin%20XboxLive.offline_access"
               );
               if (var2.statusCode() != 200) {
                  throw new MicrosoftAuth.AuthException("Сессия Microsoft истекла — войдите в аккаунт заново");
               } else {
                  JsonObject var3 = JsonParser.parseString((String)var2.body()).getAsJsonObject();
                  return a(var3.get("access_token").getAsString(), a(var3, "refresh_token"));
               }
            } else {
               throw new MicrosoftAuth.AuthException("Сохранённая сессия недоступна — войдите через браузер");
            }
         }
      );
   }

   private static void a(MicrosoftAuth.Listener var0, MicrosoftAuth.Flow var1) {
      if (a()) {
         var0.a("Вход уже выполняется");
      } else {
         h.set(false);
         Thread var2 = new Thread(() -> {
            try {
               MicrosoftAuth.Result var2x = var1.run();
               if (var2x != null && !h.get()) {
                  var0.a(var2x);
               }
            } catch (InterruptedException var3) {
            } catch (MicrosoftAuth.AuthException var4) {
               if (!h.get()) {
                  var0.a(var4.getMessage());
               }
            } catch (Throwable var5) {
               Pulse.m().error("Ошибка входа через Microsoft", var5);
               if (!h.get()) {
                  var0.a("Не удалось войти через Microsoft — подробности в логе");
               }
            }
         }, "Pulse-MicrosoftAuth");
         var2.setDaemon(true);
         g = var2;
         var2.start();
      }
   }

   private static MicrosoftAuth.Result a(String var0, String var1) throws Exception {
      JsonObject var2 = new JsonObject();
      var2.addProperty("AuthMethod", "RPS");
      var2.addProperty("SiteName", "user.auth.xboxlive.com");
      var2.addProperty("RpsTicket", "d=" + var0);
      JsonObject var3 = new JsonObject();
      var3.add("Properties", var2);
      var3.addProperty("RelyingParty", "http://auth.xboxlive.com");
      var3.addProperty("TokenType", "JWT");
      HttpResponse var4 = c("https://user.auth.xboxlive.com/user/authenticate", var3.toString());
      if (var4.statusCode() != 200) {
         throw new MicrosoftAuth.AuthException("Xbox Live не принял вход (код " + var4.statusCode() + ")");
      } else {
         JsonObject var5 = JsonParser.parseString((String)var4.body()).getAsJsonObject();
         String var6 = var5.get("Token").getAsString();
         String var7 = var5.getAsJsonObject("DisplayClaims").getAsJsonArray("xui").get(0).getAsJsonObject().get("uhs").getAsString();
         JsonObject var8 = new JsonObject();
         JsonArray var9 = new JsonArray();
         var9.add(var6);
         var8.add("UserTokens", var9);
         var8.addProperty("SandboxId", "RETAIL");
         JsonObject var10 = new JsonObject();
         var10.add("Properties", var8);
         var10.addProperty("RelyingParty", "rp://api.minecraftservices.com/");
         var10.addProperty("TokenType", "JWT");
         HttpResponse var11 = c("https://xsts.auth.xboxlive.com/xsts/authorize", var10.toString());
         if (var11.statusCode() == 401) {
            throw new MicrosoftAuth.AuthException(a((String)var11.body()));
         } else if (var11.statusCode() != 200) {
            throw new MicrosoftAuth.AuthException("XSTS не принял вход (код " + var11.statusCode() + ")");
         } else {
            JsonObject var12 = JsonParser.parseString((String)var11.body()).getAsJsonObject();
            String var13 = var12.get("Token").getAsString();
            JsonObject var14 = new JsonObject();
            var14.addProperty("identityToken", "XBL3.0 x=" + var7 + ";" + var13);
            HttpResponse var15 = c("https://api.minecraftservices.com/authentication/login_with_xbox", var14.toString());
            if (var15.statusCode() != 200) {
               throw new MicrosoftAuth.AuthException("Minecraft services не приняли вход (код " + var15.statusCode() + ")");
            } else {
               String var16 = JsonParser.parseString((String)var15.body()).getAsJsonObject().get("access_token").getAsString();
               HttpResponse var17 = f.send(
                  HttpRequest.newBuilder()
                     .uri(URI.create("https://api.minecraftservices.com/minecraft/profile"))
                     .header("Accept", "application/json")
                     .header("Authorization", "Bearer " + var16)
                     .timeout(c)
                     .GET()
                     .build(),
                  BodyHandlers.ofString()
               );
               if (var17.statusCode() == 404) {
                  throw new MicrosoftAuth.AuthException("На этом аккаунте нет лицензии Minecraft");
               } else if (var17.statusCode() != 200) {
                  throw new MicrosoftAuth.AuthException("Не удалось получить профиль Minecraft (код " + var17.statusCode() + ")");
               } else {
                  JsonObject var18 = JsonParser.parseString((String)var17.body()).getAsJsonObject();
                  String var19 = var18.get("id").getAsString();
                  Matcher var20 = d.matcher(var19);
                  if (!var20.matches()) {
                     throw new MicrosoftAuth.AuthException("Некорректный UUID профиля: " + var19);
                  } else {
                     UUID var21 = UUID.fromString(var20.replaceAll("$1-$2-$3-$4-$5"));
                     String var22 = var18.get("name").getAsString();
                     String var23 = var1 != null ? Dpapi.c(var1) : null;
                     return new MicrosoftAuth.Result(var22, var21, var16, var1, var23);
                  }
               }
            }
         }
      }
   }

   private static String a(String var0) {
      long var1 = 0L;

      try {
         var1 = JsonParser.parseString(var0).getAsJsonObject().get("XErr").getAsLong();
      } catch (Exception var4) {
      }

      if (var1 == 2148916233L) {
         return "К этому Microsoft-аккаунту не привязан Xbox";
      } else if (var1 == 2148916235L) {
         return "Xbox недоступен в вашем регионе";
      } else {
         return var1 != 2148916236L && var1 != 2148916237L && var1 != 2148916238L
            ? "Xbox отклонил вход (XErr " + var1 + ")"
            : "Требуется взрослый аккаунт Xbox (18+)";
      }
   }

   private static HttpResponse<String> b(String var0, String var1) throws Exception {
      return f.send(
         HttpRequest.newBuilder()
            .uri(URI.create(var0))
            .header("Accept", "application/json")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .timeout(c)
            .POST(BodyPublishers.ofString(var1))
            .build(),
         BodyHandlers.ofString()
      );
   }

   private static HttpResponse<String> c(String var0, String var1) throws Exception {
      return f.send(
         HttpRequest.newBuilder()
            .uri(URI.create(var0))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .timeout(c)
            .POST(BodyPublishers.ofString(var1))
            .build(),
         BodyHandlers.ofString()
      );
   }

   private static JsonObject a(HttpResponse<String> var0, String var1) throws MicrosoftAuth.AuthException {
      if (var0.statusCode() != 200) {
         throw new MicrosoftAuth.AuthException(var1 + " (код " + var0.statusCode() + ")");
      } else {
         return JsonParser.parseString((String)var0.body()).getAsJsonObject();
      }
   }

   private static String a(JsonObject var0, String var1) {
      return var0.has(var1) ? var0.get(var1).getAsString() : null;
   }

   private static String b(String var0) {
      return URLEncoder.encode(var0, StandardCharsets.UTF_8);
   }

   @Environment(EnvType.CLIENT)
   private static final class AuthException extends Exception {
      AuthException(String var1) {
         super(var1);
      }
   }

   @Environment(EnvType.CLIENT)
   private interface Flow {
      MicrosoftAuth.Result run() throws Exception;
   }

   @Environment(EnvType.CLIENT)
   public interface Listener {
      void a(String var1, String var2);

      void a(MicrosoftAuth.Result var1);

      void a(String var1);
   }

   @Environment(EnvType.CLIENT)
   public static final class Result {
      public final String a;
      public final UUID b;
      public final String c;
      public final String d;
      final String e;

      Result(String var1, UUID var2, String var3, String var4, String var5) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
      }
   }
}
