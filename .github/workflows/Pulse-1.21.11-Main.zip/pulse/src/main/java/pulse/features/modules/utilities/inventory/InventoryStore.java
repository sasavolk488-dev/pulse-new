package pulse.features.modules.utilities.inventory;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import pulse.Pulse;
import pulse.core.api.IMinecraft;

@Environment(EnvType.CLIENT)
public final class InventoryStore implements IMinecraft {
   private static final String b = ".dat";
   public static final int a = 20;
   private static final Pattern c = Pattern.compile("[^\\p{L}\\p{N} _-]");

   private InventoryStore() {
   }

   private static Path b() {
      return d.runDirectory.toPath().resolve("pulse_cache").resolve("inventories");
   }

   private static Path f(String var0) {
      return b().resolve(var0 + ".dat");
   }

   private static RegistryOps<NbtElement> a(WrapperLookup var0) {
      return RegistryOps.of(NbtOps.INSTANCE, var0);
   }

   @Compile
   public static String a(String var0) {
      if (var0 == null) {
         return "";
      }
      String name = c.matcher(var0).replaceAll("").trim();
      if (name.length() > 20) {
         name = name.substring(0, 20).trim();
      }
      return name;
   }

   public static List<InventoryStore.Entry> a() {
      ArrayList<InventoryStore.Entry> var0 = new ArrayList<>();
      Path var1 = b();
      if (!Files.isDirectory(var1)) {
         return var0;
      } else {
         try (var var2 = Files.list(var1)) {
            var2.filter(var0x -> var0x.getFileName().toString().endsWith(".dat")).sorted().forEach(var1x -> {
               String var2x = var1x.getFileName().toString();
               var2x = var2x.substring(0, var2x.length() - ".dat".length());
               var0.add(new InventoryStore.Entry(var2x, a(var1x)));
            });
         } catch (Exception var7) {
            Pulse.m().error("Не удалось получить список сохранённых инвентарей", (Throwable)var7);
         }

         return var0;
      }
   }

   private static int a(Path var0) {
      try {
         NbtCompound var1 = NbtIo.readCompressed(var0, NbtSizeTracker.ofUnlimitedBytes());
         return var1.getKeys().size();
      } catch (Exception var2) {
         return 0;
      }
   }

   public static boolean b(String var0) {
      return Files.exists(f(var0));
   }

   @Compile
   public static boolean c(String var0) {
      if (d.player == null) {
         return false;
      }
      try {
         if (var0.isEmpty()) {
            return false;
         }
         var inventory = d.player.getInventory();
         RegistryOps<NbtElement> ops = a(d.player.getRegistryManager());
         NbtCompound root = new NbtCompound();
         for (int slot = 0; slot < inventory.size(); slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (!stack.isEmpty()) {
               Object encoded = ItemStack.CODEC.encodeStart(ops, stack).getOrThrow();
               root.put("slot_" + slot, (NbtElement)encoded);
            }
         }
         Files.createDirectories(b());
         NbtIo.writeCompressed(root, f(var0));
         return true;
      } catch (Exception failure) {
         Pulse.m().error("Не удалось сохранить инвентарь " + var0, (Throwable)failure);
         return false;
      }
   }

   @Compile
   public static Map<Integer, ItemStack> d(String var0) {
      if (d.player == null) {
         return null;
      }
      Path path;
      try {
         path = f(var0);
      } catch (Exception failure) {
         Pulse.m().error("Не удалось загрузить инвентарь " + var0, (Throwable)failure);
         return null;
      }
      if (!Files.exists(path)) {
         return null;
      }
      try {
         RegistryOps<NbtElement> ops = a(d.player.getRegistryManager());
         NbtCompound root = NbtIo.readCompressed(path, NbtSizeTracker.ofUnlimitedBytes());
         Map<Integer, ItemStack> result = new java.util.HashMap<>();
         for (String key : root.getKeys()) {
            if (!key.startsWith("slot_")) {
               continue;
            }
            int slot;
            try {
               slot = Integer.parseInt(key.substring(5));
            } catch (NumberFormatException ignored) {
               continue;
            }
            NbtElement element = root.get(key);
            if (element != null) {
               ItemStack.CODEC.parse(ops, element).result().ifPresent(stack -> a(result, slot, stack));
            }
         }
         return result;
      } catch (Exception failure) {
         Pulse.m().error("Не удалось загрузить инвентарь " + var0, (Throwable)failure);
         return null;
      }
   }

   public static boolean e(String var0) {
      try {
         return Files.deleteIfExists(f(var0));
      } catch (Exception var2) {
         Pulse.m().error("Не удалось удалить инвентарь " + var0, (Throwable)var2);
         return false;
      }
   }

   public static boolean a(String var0, String var1) {
      if (var0 != null && var1 != null && !var1.isEmpty() && !var0.equals(var1)) {
         try {
            Path var2 = f(var0);
            Path var3 = f(var1);
            if (Files.exists(var2) && !Files.exists(var3)) {
               Files.move(var2, var3);
               return true;
            } else {
               return false;
            }
         } catch (Exception var4) {
            Pulse.m().error("Не удалось переименовать инвентарь " + var0 + " -> " + var1, (Throwable)var4);
            return false;
         }
      } else {
         return false;
      }
   }

   public static void a(Map var0, int var1, ItemStack var2) {
      var0.put(var1, var2);
   }

   static {
      NativeMethodLookup.lookup(InventoryStore.class, 35);
   }

   @Environment(EnvType.CLIENT)
   public static final class Entry {
      public final String a;
      public final int b;

      Entry(String var1, int var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
