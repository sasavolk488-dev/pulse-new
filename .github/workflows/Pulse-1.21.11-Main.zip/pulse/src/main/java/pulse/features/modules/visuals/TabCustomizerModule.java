package pulse.features.modules.visuals;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.PlayerListEntry;
import pulse.ui.clickgui.menu.friends.CloudFriendEntry;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.services.tracker.v2.CloudFriendsCache;
import pulse.services.tracker.v2.GroupManagerClient;
import pulse.services.tracker.v2.GroupMemberDto;
import pulse.utils.game.FriendUtils;

@ModuleInfo(
   a = "Tab Customizer",
   b = "Кастомизация списка игроков (TAB)",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class TabCustomizerModule extends Module {
   public final BooleanSetting a = new BooleanSetting("Подсветка себя", true);
   public final BooleanSetting b = new BooleanSetting("Подсветка друзей", true);
   public final ColorSetting c = new ColorSetting("Цвет друзей", new Color(0, 230, 118)).a(() -> this.b.q());
   public final BooleanSetting f = new BooleanSetting("Подсветка группы", true);
   public final BooleanSetting g = new BooleanSetting("Головы игроков", true);
   public final ModeSetting h = new ModeSetting("Пинг", new String[]{"Полоски", "Цифры", "Скрыто"}, "Цифры");
   public final BooleanSetting i = new BooleanSetting("Друзья наверху", true);
   public final BooleanSetting j = new BooleanSetting("Скрыть шапку", false);
   public final BooleanSetting k = new BooleanSetting("Скрыть подвал", false);
   private static final int l = 72;
   private static final int m = 4244735;

   public boolean n() {
      return this.a.q() || this.b.q() || this.f.q();
   }

   public Integer a(PlayerListEntry var1) {
      String var2 = c(var1);
      if (var2 == null) {
         return null;
      } else if (this.a.q() && this.a(var2)) {
         return c(ModuleRegistry.aw.n().getRGB());
      } else {
         if (this.f.q()) {
            Integer var3 = this.c(var2);
            if (var3 != null) {
               return c(var3);
            }
         }

         return this.b.q() && this.b(var2) ? c(this.c.b()) : null;
      }
   }

   public int b(PlayerListEntry var1) {
      String var2 = c(var1);
      if (var2 == null) {
         return 3;
      } else if (this.a(var2)) {
         return 0;
      } else if (this.c(var2) != null) {
         return 1;
      } else {
         return this.b(var2) ? 2 : 3;
      }
   }

   public boolean o() {
      return this.i.q();
   }

   public boolean p() {
      return this.g.q();
   }

   public boolean q() {
      return this.j.q();
   }

   public boolean r() {
      return this.k.q();
   }

   public boolean s() {
      return this.h.c("Скрыто");
   }

   public boolean t() {
      return this.h.c("Цифры");
   }

   public int b(int var1) {
      if (var1 < 0) {
         return -6381922;
      } else if (var1 < 50) {
         return -16718218;
      } else if (var1 < 100) {
         return -5314048;
      } else if (var1 < 150) {
         return -5317;
      } else {
         return var1 < 250 ? -22746 : -44462;
      }
   }

   private static String c(PlayerListEntry var0) {
      return var0 != null && var0.getProfile() != null ? var0.getProfile().name() : null;
   }

   private boolean a(String var1) {
      return d.player != null && var1.equalsIgnoreCase(d.player.getGameProfile().name());
   }

   private boolean b(String var1) {
      if (FriendUtils.a(var1)) {
         return true;
      } else {
         try {
            for (CloudFriendEntry var3 : CloudFriendsCache.a().c()) {
               if (var3.k() != null && var3.k().equalsIgnoreCase(var1)) {
                  return true;
               }
            }
         } catch (Exception var4) {
         }

         return false;
      }
   }

   private Integer c(String var1) {
      try {
         if (!GroupManagerClient.a().c()) {
            return null;
         }

         for (GroupMemberDto var3 : GroupManagerClient.a().d()) {
            if (this.a(var3, var1)) {
               return var3.i() != null ? var3.i() : 4244735;
            }
         }
      } catch (Exception var4) {
      }

      return null;
   }

   private boolean a(GroupMemberDto var1, String var2) {
      if (var1.c() != null && var1.c().equalsIgnoreCase(var2)) {
         return true;
      } else {
         CloudFriendEntry var3 = CloudFriendsCache.a().a(var1.a());
         if (var3 != null && var3.k() != null && var3.k().equalsIgnoreCase(var2)) {
            return true;
         } else if (var1.c() == null) {
            return var1.d() != null && var1.d().equalsIgnoreCase(var2) ? true : var1.b() != null && var1.b().equalsIgnoreCase(var2);
         } else {
            return false;
         }
      }
   }

   private static int c(int var0) {
      return 1207959552 | var0 & 16777215;
   }
}
