package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.debug.EntityHitboxDebugRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.HitboxCustomizerModule;

@Environment(EnvType.CLIENT)
@Mixin({EntityHitboxDebugRenderer.class})
public abstract class EntityHitboxDebugRendererMixin {
   @Inject(
      method = {"drawHitbox"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onDrawHitbox(Entity var1, float var2, boolean var3, CallbackInfo var4) {
      HitboxCustomizerModule var5 = ModuleRegistry.j;
      if (var5 != null && var5.k()) {
         var5.a(var1, var2);
         var4.cancel();
      }
   }
}
