package pulse.features.modules.hud.snap;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.hud.DraggableComponent;

@Environment(EnvType.CLIENT)
public class SnapEngine {
   private static final float a = 6.0F;
   private static final float b = 5.0F;
   private static final float c = 10.0F;

   public static SnapResult a(DraggableComponent var0, float var1, float var2, float var3, float var4, List<DraggableComponent> var5, boolean var6) {
      if (var6) {
         float var22 = Math.max(5.0F, Math.min(var1, var3 - var0.o() - 5.0F));
         float var23 = Math.max(5.0F, Math.min(var2, var4 - var0.p() - 5.0F));
         return SnapResult.a(var22, var23);
      } else {
         float var7 = var0.o();
         float var8 = var0.p();
         ArrayList var9 = new ArrayList();
         float var10 = var1;
         float var11 = var2;
         boolean var12 = false;
         boolean var13 = false;
         float var15 = var1 + var7;
         float var16 = var1 + var7 / 2.0F;
         float var18 = var2 + var8;
         float var19 = var2 + var8 / 2.0F;
         SnapEngine.SnapCandidate var20 = a(var1, var15, var16, var7, var3, var4, var5, var0, var2, var18);
         if (var20 != null) {
            var10 = var20.b;
            var9.add(var20.c);
            var12 = true;
         }

         SnapEngine.SnapCandidate var21 = b(var2, var18, var19, var8, var3, var4, var5, var0, var1, var15);
         if (var21 != null) {
            var11 = var21.b;
            var9.add(var21.c);
            var13 = true;
         }

         var10 = Math.max(5.0F, Math.min(var10, var3 - var7 - 5.0F));
         var11 = Math.max(5.0F, Math.min(var11, var4 - var8 - 5.0F));
         return new SnapResult(var10, var11, var9, var12, var13);
      }
   }

   private static SnapEngine.SnapCandidate a(
      float var0, float var1, float var2, float var3, float var4, float var5, List<DraggableComponent> var6, DraggableComponent var7, float var8, float var9
   ) {
      SnapEngine.SnapCandidate var10 = null;
      if (Math.abs(var0 - 5.0F) < 6.0F) {
         float var11 = Math.abs(var0 - 5.0F);
         SnapLine var12 = new SnapLine(SnapLine.Type.b, SnapLine.Source.a, 5.0F, Math.max(0.0F, var8 - 10.0F), Math.min(var5, var9 + 10.0F));
         var10 = a(var10, var11, 5.0F, var12);
      }

      if (Math.abs(var1 - (var4 - 5.0F)) < 6.0F) {
         float var22 = Math.abs(var1 - (var4 - 5.0F));
         float var24 = var4 - 5.0F - var3;
         SnapLine var13 = new SnapLine(SnapLine.Type.b, SnapLine.Source.a, var4 - 5.0F, Math.max(0.0F, var8 - 10.0F), Math.min(var5, var9 + 10.0F));
         var10 = a(var10, var22, var24, var13);
      }

      float var23 = var4 / 2.0F;
      if (Math.abs(var2 - var23) < 6.0F) {
         float var25 = Math.abs(var2 - var23);
         float var27 = var23 - var3 / 2.0F;
         SnapLine var14 = new SnapLine(SnapLine.Type.b, SnapLine.Source.b, var23, Math.max(0.0F, var8 - 10.0F), Math.min(var5, var9 + 10.0F));
         var10 = a(var10, var25, var27, var14);
      }

      for (DraggableComponent var28 : var6) {
         if (var28 != var7) {
            float var29 = var28.m();
            float var15 = var28.m() + var28.o();
            float var16 = var28.m() + var28.o() / 2.0F;
            float var17 = var28.n();
            float var18 = var28.n() + var28.p();
            if (Math.abs(var0 - var29) < 6.0F) {
               float var19 = Math.abs(var0 - var29);
               SnapLine var20 = a(var29, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var19, var29, var20);
            }

            if (Math.abs(var1 - var15) < 6.0F) {
               float var30 = Math.abs(var1 - var15);
               float var34 = var15 - var3;
               SnapLine var21 = a(var15, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var30, var34, var21);
            }

            if (Math.abs(var0 - var15) < 6.0F) {
               float var31 = Math.abs(var0 - var15);
               SnapLine var35 = a(var15, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var31, var15, var35);
            }

            if (Math.abs(var1 - var29) < 6.0F) {
               float var32 = Math.abs(var1 - var29);
               float var36 = var29 - var3;
               SnapLine var38 = a(var29, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var32, var36, var38);
            }

            if (Math.abs(var2 - var16) < 6.0F) {
               float var33 = Math.abs(var2 - var16);
               float var37 = var16 - var3 / 2.0F;
               SnapLine var39 = a(var16, var8, var9, var17, var18, SnapLine.Source.d);
               var10 = a(var10, var33, var37, var39);
            }
         }
      }

      return var10;
   }

   private static SnapEngine.SnapCandidate b(
      float var0, float var1, float var2, float var3, float var4, float var5, List<DraggableComponent> var6, DraggableComponent var7, float var8, float var9
   ) {
      SnapEngine.SnapCandidate var10 = null;
      if (Math.abs(var0 - 5.0F) < 6.0F) {
         float var11 = Math.abs(var0 - 5.0F);
         SnapLine var12 = new SnapLine(SnapLine.Type.a, SnapLine.Source.a, 5.0F, Math.max(0.0F, var8 - 10.0F), Math.min(var4, var9 + 10.0F));
         var10 = a(var10, var11, 5.0F, var12);
      }

      if (Math.abs(var1 - (var5 - 5.0F)) < 6.0F) {
         float var22 = Math.abs(var1 - (var5 - 5.0F));
         float var24 = var5 - 5.0F - var3;
         SnapLine var13 = new SnapLine(SnapLine.Type.a, SnapLine.Source.a, var5 - 5.0F, Math.max(0.0F, var8 - 10.0F), Math.min(var4, var9 + 10.0F));
         var10 = a(var10, var22, var24, var13);
      }

      float var23 = var5 / 2.0F;
      if (Math.abs(var2 - var23) < 6.0F) {
         float var25 = Math.abs(var2 - var23);
         float var27 = var23 - var3 / 2.0F;
         SnapLine var14 = new SnapLine(SnapLine.Type.a, SnapLine.Source.b, var23, Math.max(0.0F, var8 - 10.0F), Math.min(var4, var9 + 10.0F));
         var10 = a(var10, var25, var27, var14);
      }

      for (DraggableComponent var28 : var6) {
         if (var28 != var7) {
            float var29 = var28.n();
            float var15 = var28.n() + var28.p();
            float var16 = var28.n() + var28.p() / 2.0F;
            float var17 = var28.m();
            float var18 = var28.m() + var28.o();
            if (Math.abs(var0 - var29) < 6.0F) {
               float var19 = Math.abs(var0 - var29);
               SnapLine var20 = b(var29, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var19, var29, var20);
            }

            if (Math.abs(var1 - var15) < 6.0F) {
               float var30 = Math.abs(var1 - var15);
               float var34 = var15 - var3;
               SnapLine var21 = b(var15, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var30, var34, var21);
            }

            if (Math.abs(var0 - var15) < 6.0F) {
               float var31 = Math.abs(var0 - var15);
               SnapLine var35 = b(var15, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var31, var15, var35);
            }

            if (Math.abs(var1 - var29) < 6.0F) {
               float var32 = Math.abs(var1 - var29);
               float var36 = var29 - var3;
               SnapLine var38 = b(var29, var8, var9, var17, var18, SnapLine.Source.c);
               var10 = a(var10, var32, var36, var38);
            }

            if (Math.abs(var2 - var16) < 6.0F) {
               float var33 = Math.abs(var2 - var16);
               float var37 = var16 - var3 / 2.0F;
               SnapLine var39 = b(var16, var8, var9, var17, var18, SnapLine.Source.d);
               var10 = a(var10, var33, var37, var39);
            }
         }
      }

      return var10;
   }

   private static SnapLine a(float var0, float var1, float var2, float var3, float var4, SnapLine.Source var5) {
      float var6 = Math.min(var1, var3) - 10.0F;
      float var7 = Math.max(var2, var4) + 10.0F;
      return new SnapLine(SnapLine.Type.b, var5, var0, Math.max(0.0F, var6), var7);
   }

   private static SnapLine b(float var0, float var1, float var2, float var3, float var4, SnapLine.Source var5) {
      float var6 = Math.min(var1, var3) - 10.0F;
      float var7 = Math.max(var2, var4) + 10.0F;
      return new SnapLine(SnapLine.Type.a, var5, var0, Math.max(0.0F, var6), var7);
   }

   private static SnapEngine.SnapCandidate a(SnapEngine.SnapCandidate var0, float var1, float var2, SnapLine var3) {
      return var0 != null && !(var1 < var0.a) ? var0 : new SnapEngine.SnapCandidate(var1, var2, var3);
   }

   @Environment(EnvType.CLIENT)
   private static class SnapCandidate {
      final float a;
      final float b;
      final SnapLine c;

      SnapCandidate(float var1, float var2, SnapLine var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
