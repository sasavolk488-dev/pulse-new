package pulse.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ConfigData {
   public static final int a = 1;
   private int b = 1;
   private ConfigMetadata c;
   private Map<String, ConfigData.ModuleData> d = new HashMap<>();
   private List<ConfigData.FriendData> e = new ArrayList<>();
   private List<ConfigData.MarkerData> f = new ArrayList<>();
   private ConfigData.MarkerSettingsData g = new ConfigData.MarkerSettingsData();
   private Map<String, ConfigData.HudPositionData> h = new HashMap<>();
   private String i = "BOTTOM";
   private ConfigData.WatermarkSettingsData j = new ConfigData.WatermarkSettingsData();
   private ConfigData.ClientColorData k = new ConfigData.ClientColorData();
   private Map<String, String> l = new HashMap<>();

   public ConfigData() {
   }

   public ConfigData(ConfigMetadata var1) {
      this.c = var1;
   }

   public int a() {
      return this.b;
   }

   public void a(int var1) {
      this.b = var1;
   }

   public ConfigMetadata b() {
      return this.c;
   }

   public void a(ConfigMetadata var1) {
      this.c = var1;
   }

   public Map<String, ConfigData.ModuleData> c() {
      return this.d;
   }

   public void a(Map<String, ConfigData.ModuleData> var1) {
      this.d = var1;
   }

   public List<ConfigData.FriendData> d() {
      return this.e;
   }

   public void a(List<ConfigData.FriendData> var1) {
      this.e = var1;
   }

   public List<ConfigData.MarkerData> e() {
      return this.f;
   }

   public void b(List<ConfigData.MarkerData> var1) {
      this.f = var1;
   }

   public ConfigData.MarkerSettingsData f() {
      return this.g;
   }

   public void a(ConfigData.MarkerSettingsData var1) {
      this.g = var1;
   }

   public Map<String, ConfigData.HudPositionData> g() {
      return this.h;
   }

   public void b(Map<String, ConfigData.HudPositionData> var1) {
      this.h = var1;
   }

   public String h() {
      return this.i;
   }

   public void a(String var1) {
      this.i = var1;
   }

   public ConfigData.WatermarkSettingsData i() {
      return this.j;
   }

   public void a(ConfigData.WatermarkSettingsData var1) {
      this.j = var1;
   }

   public ConfigData.ClientColorData j() {
      return this.k;
   }

   public void a(ConfigData.ClientColorData var1) {
      this.k = var1;
   }

   public Map<String, String> k() {
      return this.l;
   }

   public void c(Map<String, String> var1) {
      this.l = var1;
   }

   @Environment(EnvType.CLIENT)
   public static class ClientColorData {
      private String a = "Статичный";
      private float b = 0.75F;
      private float c = 0.81F;
      private float d = 0.89F;
      private float e = 0.0F;
      private float f = 0.0F;
      private float g = 1.0F;
      private float h = 0.58F;
      private float i = 0.51F;
      private float j = 0.96F;

      public String a() {
         return this.a;
      }

      public void a(String var1) {
         this.a = var1;
      }

      public float b() {
         return this.b;
      }

      public void a(float var1) {
         this.b = var1;
      }

      public float c() {
         return this.c;
      }

      public void b(float var1) {
         this.c = var1;
      }

      public float d() {
         return this.d;
      }

      public void c(float var1) {
         this.d = var1;
      }

      public float e() {
         return this.e;
      }

      public void d(float var1) {
         this.e = var1;
      }

      public float f() {
         return this.f;
      }

      public void e(float var1) {
         this.f = var1;
      }

      public float g() {
         return this.g;
      }

      public void f(float var1) {
         this.g = var1;
      }

      public float h() {
         return this.h;
      }

      public void g(float var1) {
         this.h = var1;
      }

      public float i() {
         return this.i;
      }

      public void h(float var1) {
         this.i = var1;
      }

      public float j() {
         return this.j;
      }

      public void i(float var1) {
         this.j = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class FriendData {
      private String a;
      private String b;

      public FriendData() {
      }

      public FriendData(String var1, String var2) {
         this.a = var1;
         this.b = var2;
      }

      public String a() {
         return this.a;
      }

      public void a(String var1) {
         this.a = var1;
      }

      public String b() {
         return this.b;
      }

      public void b(String var1) {
         this.b = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class HudPositionData {
      private float a;
      private float b;
      private float c = 1.0F;
      private boolean d = true;

      public HudPositionData() {
      }

      public HudPositionData(float var1, float var2, float var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public float a() {
         return this.a;
      }

      public void a(float var1) {
         this.a = var1;
      }

      public float b() {
         return this.b;
      }

      public void b(float var1) {
         this.b = var1;
      }

      public float c() {
         return this.c;
      }

      public void c(float var1) {
         this.c = var1;
      }

      public boolean d() {
         return this.d;
      }

      public void a(boolean var1) {
         this.d = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class MarkerData {
      private String a;
      private int b;
      private int c;
      private int d;
      private int e;
      private String f;
      private boolean g;
      private long h;
      private int i;
      private long j;

      public String a() {
         return this.a;
      }

      public void a(String var1) {
         this.a = var1;
      }

      public int b() {
         return this.b;
      }

      public void a(int var1) {
         this.b = var1;
      }

      public int c() {
         return this.c;
      }

      public void b(int var1) {
         this.c = var1;
      }

      public int d() {
         return this.d;
      }

      public void c(int var1) {
         this.d = var1;
      }

      public int e() {
         return this.e;
      }

      public void d(int var1) {
         this.e = var1;
      }

      public String f() {
         return this.f;
      }

      public void b(String var1) {
         this.f = var1;
      }

      public boolean g() {
         return this.g;
      }

      public void a(boolean var1) {
         this.g = var1;
      }

      public long h() {
         return this.h;
      }

      public void a(long var1) {
         this.h = var1;
      }

      public int i() {
         return this.i;
      }

      public void e(int var1) {
         this.i = var1;
      }

      public long j() {
         return this.j;
      }

      public void b(long var1) {
         this.j = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class MarkerSettingsData {
      private boolean a = true;
      private int b = 0;
      private boolean c = false;
      private boolean d = true;
      private boolean e = false;
      private boolean f = true;
      private int g = 1452;
      private boolean h = true;
      private boolean i = true;
      private boolean j = true;
      private boolean k = true;
      private boolean l = true;

      public boolean a() {
         return this.a;
      }

      public void a(boolean var1) {
         this.a = var1;
      }

      public int b() {
         return this.b;
      }

      public void a(int var1) {
         this.b = var1;
      }

      public boolean c() {
         return this.c;
      }

      public void b(boolean var1) {
         this.c = var1;
      }

      public boolean d() {
         return this.d;
      }

      public void c(boolean var1) {
         this.d = var1;
      }

      public boolean e() {
         return this.e;
      }

      public void d(boolean var1) {
         this.e = var1;
      }

      public boolean f() {
         return this.f;
      }

      public void e(boolean var1) {
         this.f = var1;
      }

      public int g() {
         return this.g;
      }

      public void b(int var1) {
         this.g = var1;
      }

      public boolean h() {
         return this.h;
      }

      public void f(boolean var1) {
         this.h = var1;
      }

      public boolean i() {
         return this.i;
      }

      public void g(boolean var1) {
         this.i = var1;
      }

      public boolean j() {
         return this.j;
      }

      public void h(boolean var1) {
         this.j = var1;
      }

      public boolean k() {
         return this.k;
      }

      public void i(boolean var1) {
         this.k = var1;
      }

      public boolean l() {
         return this.l;
      }

      public void j(boolean var1) {
         this.l = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class ModuleData {
      private boolean a;
      private int b;
      private Map<String, ConfigData.SettingData> c = new HashMap<>();

      public ModuleData() {
      }

      public ModuleData(boolean var1, int var2) {
         this.a = var1;
         this.b = var2;
      }

      public boolean a() {
         return this.a;
      }

      public void a(boolean var1) {
         this.a = var1;
      }

      public int b() {
         return this.b;
      }

      public void a(int var1) {
         this.b = var1;
      }

      public Map<String, ConfigData.SettingData> c() {
         return this.c;
      }

      public void a(Map<String, ConfigData.SettingData> var1) {
         this.c = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class SettingData {
      private String a;
      private Object b;
      private Float c;
      private Float d;
      private Float e;
      private int[] f;
      private Boolean g;
      private Integer h;

      public SettingData() {
      }

      public SettingData(String var1, Object var2) {
         this.a = var1;
         this.b = var2;
      }

      public String a() {
         return this.a;
      }

      public void a(String var1) {
         this.a = var1;
      }

      public Object b() {
         return this.b;
      }

      public void a(Object var1) {
         this.b = var1;
      }

      public Float c() {
         return this.c;
      }

      public void a(Float var1) {
         this.c = var1;
      }

      public Float d() {
         return this.d;
      }

      public void b(Float var1) {
         this.d = var1;
      }

      public Float e() {
         return this.e;
      }

      public void c(Float var1) {
         this.e = var1;
      }

      public int[] f() {
         return this.f;
      }

      public void a(int[] var1) {
         this.f = var1;
      }

      public Boolean g() {
         return this.g;
      }

      public void a(Boolean var1) {
         this.g = var1;
      }

      public Integer h() {
         return this.h;
      }

      public void a(Integer var1) {
         this.h = var1;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class WatermarkSettingsData {
      private boolean a = true;
      private boolean b = true;
      private boolean c = true;
      private boolean d = true;
      private boolean e = true;

      public boolean a() {
         return this.a;
      }

      public void a(boolean var1) {
         this.a = var1;
      }

      public boolean b() {
         return this.b;
      }

      public void b(boolean var1) {
         this.b = var1;
      }

      public boolean c() {
         return this.c;
      }

      public void c(boolean var1) {
         this.c = var1;
      }

      public boolean d() {
         return this.d;
      }

      public void d(boolean var1) {
         this.d = var1;
      }

      public boolean e() {
         return this.e;
      }

      public void e(boolean var1) {
         this.e = var1;
      }
   }
}
