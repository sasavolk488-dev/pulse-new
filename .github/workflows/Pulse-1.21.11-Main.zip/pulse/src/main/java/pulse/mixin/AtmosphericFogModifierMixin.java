package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.AtmosphericFogModifier;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.WorldCustomizerModule;

@Environment(EnvType.CLIENT)
@Mixin({AtmosphericFogModifier.class})
public abstract class AtmosphericFogModifierMixin {
   @Inject(
      method = {"getFogColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$customFogColor(ClientWorld var1, Camera var2, int var3, float var4, CallbackInfoReturnable<Integer> var5) {
      WorldCustomizerModule var6 = ModuleRegistry.k;
      if (var6 != null && var6.n()) {
         int var7 = var6.t() | 0xFF000000;
         var5.setReturnValue(var7);
      }
   }

   @Inject(
      method = {"applyStartEndModifier"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$customFogDistance(FogData var1, Camera var2, ClientWorld var3, float var4, RenderTickCounter var5, CallbackInfo var6) {
      WorldCustomizerModule var7 = ModuleRegistry.k;
      if (var7 != null) {
         if (var7.p()) {
            var1.environmentalStart = Float.MAX_VALUE;
            var1.environmentalEnd = Float.MAX_VALUE;
            var1.renderDistanceStart = Float.MAX_VALUE;
            var1.renderDistanceEnd = Float.MAX_VALUE;
            var1.skyEnd = Float.MAX_VALUE;
            var1.cloudEnd = Float.MAX_VALUE;
            var6.cancel();
         } else if (var7.o()) {
            float var8 = var7.q();
            float var9 = var7.r();
            var1.environmentalStart = var8;
            var1.environmentalEnd = var9;
            var1.skyEnd = var9;
            var1.cloudEnd = var9;
            var6.cancel();
         }
      }
   }
}
