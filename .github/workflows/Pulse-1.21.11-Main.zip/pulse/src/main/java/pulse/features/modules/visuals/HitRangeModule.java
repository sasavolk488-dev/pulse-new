package pulse.features.modules.visuals;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import pulse.core.event.impl.RenderEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.render.world.HitRangeLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.game.EntityUtils;

@ModuleInfo(
   a = "Hit Range",
   b = "Рисует на полу под игроками круг радиусом атаки: зелёный — есть досягаемая цель, красный — нет",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class HitRangeModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Свой круг", true);
   private final BooleanSetting b = new BooleanSetting("Чужие круги", true);
   private static final double c = 10.0;
   private final SeparatorSetting f = new SeparatorSetting("Отображение");
   private final BooleanSetting g = new BooleanSetting("Заливка", true);
   private final NumberSetting h = new NumberSetting("Прозрачность заливки", 0.25F, 0.0F, 0.8F, 0.05F).a(this.g::a);
   private final NumberSetting i = new NumberSetting("Толщина линии", 2.0F, 1.0F, 5.0F, 0.5F);
   private final NumberSetting j = new NumberSetting("Высота над полом", 0.02F, 0.0F, 0.5F, 0.01F);
   private final SeparatorSetting k = new SeparatorSetting("Цвет");
   private final ColorSetting l = new ColorSetting("Цель в радиусе", new Color(60, 255, 90));
   private final ColorSetting m = new ColorSetting("Нет цели", new Color(255, 60, 60));

   @EventHandler
   public void a(RenderEvent var1) {
      if (d.player != null && d.world != null) {
         Vec3d var2 = d.gameRenderer.getCamera().getCameraPos();
         MatrixStack var3 = var1.a();
         Matrix4f var4 = var3.peek().getPositionMatrix();
         ArrayList var5 = new ArrayList<>();

         for (PlayerEntity var7 : d.world.getPlayers()) {
            if (var7.isAlive() && !EntityUtils.b(var7)) {
               var5.add(var7);
            }
         }

         ArrayList<float[]> var14 = new ArrayList<>();

         for (PlayerEntity var8 : d.world.getPlayers()) {
            if (var8.isAlive() && (var8 == d.player ? this.a.a() : this.b.a() && !EntityUtils.b(var8) && !(d.player.squaredDistanceTo(var8) > 100.0))) {
               double var9 = this.a(var8);
               boolean var11 = this.a(var8, var9, var5);
               Color var12 = var11 ? this.l.a() : this.m.a();
               Vec3d var13 = EntityUtils.a(var8, var1.b());
               if (var13 == null) {
                  var13 = var8.getEntityPos();
               }

               if (var13 != null) {
                  var14.add(
                     new float[]{
                        (float)(var13.x - var2.x),
                        (float)(var13.y + this.j.b() - var2.y),
                        (float)(var13.z - var2.z),
                        (float)var9,
                        var12.getRed() / 255.0F,
                        var12.getGreen() / 255.0F,
                        var12.getBlue() / 255.0F
                     }
                  );
               }
            }
         }

         if (!var14.isEmpty()) {
            Immediate var16 = d.getBufferBuilders().getEntityVertexConsumers();
            boolean var17 = this.g.a() && this.h.b() > 0.0F;
            float var18 = this.h.b();
            float var10 = MathHelper.clamp(this.i.b() / 16.0F, 0.0F, 1.0F);
            if (var17) {
               VertexConsumer var19 = var16.getBuffer(HitRangeLayers.c);

               for (float[] var23 : var14) {
                  this.a(var19, var4, var23[0], var23[1], var23[2], var23[3], var23[4], var23[5], var23[6], var18);
               }

               var16.draw(HitRangeLayers.c);
            }

            VertexConsumer var20 = var16.getBuffer(HitRangeLayers.d);

            for (float[] var24 : var14) {
               this.a(var20, var4, var24[0], var24[1], var24[2], var24[3], var24[4], var24[5], var24[6], var10);
            }

            var16.draw(HitRangeLayers.d);
         }
      }
   }

   private void a(VertexConsumer var1, Matrix4f var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      var1.vertex(var2, var3 - var6, var4, var5 - var6).texture(0.0F, 0.0F).color(var7, var8, var9, var10);
      var1.vertex(var2, var3 - var6, var4, var5 + var6).texture(0.0F, 1.0F).color(var7, var8, var9, var10);
      var1.vertex(var2, var3 + var6, var4, var5 + var6).texture(1.0F, 1.0F).color(var7, var8, var9, var10);
      var1.vertex(var2, var3 + var6, var4, var5 - var6).texture(1.0F, 0.0F).color(var7, var8, var9, var10);
   }

   private double a(PlayerEntity var1) {
      return var1.getAttributeValue(EntityAttributes.ENTITY_INTERACTION_RANGE);
   }

   private boolean a(PlayerEntity var1, double var2, List<PlayerEntity> var4) {
      Vec3d var5 = var1.getEyePos();
      double var6 = var2 * var2;
      double var8 = var2 + 3.0;
      double var10 = var8 * var8;

      for (PlayerEntity var13 : var4) {
         if (var13 != var1 && !(var5.squaredDistanceTo(var13.getEntityPos()) > var10)) {
            Box var14 = var13.getBoundingBox();
            double var15 = MathHelper.clamp(var5.x, var14.minX, var14.maxX);
            double var17 = MathHelper.clamp(var5.y, var14.minY, var14.maxY);
            double var19 = MathHelper.clamp(var5.z, var14.minZ, var14.maxZ);
            double var21 = var5.x - var15;
            double var23 = var5.y - var17;
            double var25 = var5.z - var19;
            if (var21 * var21 + var23 * var23 + var25 * var25 <= var6) {
               return true;
            }
         }
      }

      return false;
   }
}
