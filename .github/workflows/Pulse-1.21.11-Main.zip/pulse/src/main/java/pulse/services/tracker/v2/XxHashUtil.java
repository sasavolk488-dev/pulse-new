package pulse.services.tracker.v2;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class XxHashUtil {
   private static long a = -7046029288634856825L;
   private static long b = -4417276706812531889L;
   private static long c = 1609587929392839161L;
   private static long d = -8796714831421723037L;
   private static long e = 2870177450012600261L;
   private static long f = 0L;

   private XxHashUtil() {
   }

   public static long a(Set<String> var0) {
      if (var0 != null && !var0.isEmpty()) {
         ArrayList var1 = new ArrayList(var0);
         Collections.sort(var1);
         String var2 = String.join("\u0000", var1);
         byte[] var3 = var2.getBytes(StandardCharsets.UTF_8);
         return a(var3, f);
      } else {
         return a(new byte[0], f);
      }
   }

   public static long a(byte[] var0, long var1) {
      int var3 = var0.length;
      int var4 = 0;
      long var22;
      if (var3 >= 32) {
         long var7 = var1 + a + b;
         long var9 = var1 + b;
         long var11 = var1;
         long var13 = var1 - a;
         int var15 = var3 - 32;

         do {
            var7 = a(var7, a(var0, var4));
            var4 += 8;
            var9 = a(var9, a(var0, var4));
            var4 += 8;
            var11 = a(var11, a(var0, var4));
            var4 += 8;
            var13 = a(var13, a(var0, var4));
            var4 += 8;
         } while (var4 <= var15);

         var22 = Long.rotateLeft(var7, 1) + Long.rotateLeft(var9, 7) + Long.rotateLeft(var11, 12) + Long.rotateLeft(var13, 18);
         var22 = b(var22, var7);
         var22 = b(var22, var9);
         var22 = b(var22, var11);
         var22 = b(var22, var13);
      } else {
         var22 = var1 + e;
      }

      for (var22 += var3; var4 + 8 <= var3; var4 += 8) {
         long var27 = a(0L, a(var0, var4));
         var22 ^= var27;
         var22 = Long.rotateLeft(var22, 27) * a + d;
      }

      if (var4 + 4 <= var3) {
         var22 ^= (b(var0, var4) & 4294967295L) * a;
         var22 = Long.rotateLeft(var22, 23) * b + c;
         var4 += 4;
      }

      while (var4 < var3) {
         var22 ^= (var0[var4] & 255) * e;
         var22 = Long.rotateLeft(var22, 11) * a;
         var4++;
      }

      return a(var22);
   }

   private static long a(long var0, long var2) {
      var0 += var2 * b;
      var0 = Long.rotateLeft(var0, 31);
      return var0 * a;
   }

   private static long b(long var0, long var2) {
      var2 = a(0L, var2);
      var0 ^= var2;
      return var0 * a + d;
   }

   private static long a(long var0) {
      var0 ^= var0 >>> 33;
      var0 *= b;
      var0 ^= var0 >>> 29;
      var0 *= c;
      return var0 ^ var0 >>> 32;
   }

   private static long a(byte[] var0, int var1) {
      return var0[var1] & 255L
         | (var0[var1 + 1] & 255L) << 8
         | (var0[var1 + 2] & 255L) << 16
         | (var0[var1 + 3] & 255L) << 24
         | (var0[var1 + 4] & 255L) << 32
         | (var0[var1 + 5] & 255L) << 40
         | (var0[var1 + 6] & 255L) << 48
         | (var0[var1 + 7] & 255L) << 56;
   }

   private static int b(byte[] var0, int var1) {
      return var0[var1] & 0xFF | (var0[var1 + 1] & 0xFF) << 8 | (var0[var1 + 2] & 0xFF) << 16 | (var0[var1 + 3] & 0xFF) << 24;
   }
}
