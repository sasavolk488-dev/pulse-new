package pulse.features.modules.utilities;

import java.util.function.Supplier;

public final class FTHelperModule$$Lambda$20 implements Supplier {
   private final FTHelperModule c0;

   public FTHelperModule$$Lambda$20(FTHelperModule var1) {
      this.c0 = var1;
   }

   @Override
   public Object get() {
      return this.c0.r();
   }
}
