package pulse.features.modules.utilities;

import java.util.function.Supplier;

public final class FTHelperModule$$Lambda$21 implements Supplier {
   @Override
   public Object get() {
      return FTHelperModule.q();
   }
}
