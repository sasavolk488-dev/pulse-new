package pulse.mixin;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.Lancing;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.json.Transformation;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.consume.UseAction;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.mixin.accessor.ItemRenderStateAccessor;
import pulse.mixin.accessor.LayerRenderStateAccessor;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.MaceHelperModule;
import pulse.features.modules.visuals.CustomHandModule;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.utils.render.world.HandOutlineRenderer;

@Environment(EnvType.CLIENT)
@Mixin({HeldItemRenderer.class})
public abstract class HeldItemRendererMixin {
   @Shadow
   @Final
   private MinecraftClient client;
   @Shadow
   private ItemStack offHand;
   @Shadow
   @Final
   private ItemModelManager itemModelManager;
   private static final int PULSE_TRAIL_MAX = 14;
   private static final ArrayDeque<Matrix4f>[] pulse$trail = new ArrayDeque[]{new ArrayDeque<>(), new ArrayDeque<>()};
   private static Immediate pulse$maskImmediate;

   @Shadow
   public abstract void renderItem(LivingEntity var1, ItemStack var2, ItemDisplayContext var3, MatrixStack var4, OrderedRenderCommandQueue var5, int var6);

   @Shadow
   protected abstract void renderArmHoldingItem(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, float var4, float var5, Arm var6);

   @Shadow
   protected abstract void renderMapInOneHand(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, float var4, Arm var5, float var6, ItemStack var7);

   @Shadow
   protected abstract void renderMapInBothHands(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, float var4, float var5, float var6);

   @Shadow
   protected abstract void applyEatOrDrinkTransformation(MatrixStack var1, float var2, Arm var3, ItemStack var4, PlayerEntity var5);

   @Shadow
   private void applySwingOffset(MatrixStack var1, Arm var2, float var3) {
   }

   @Shadow
   private void applyEquipOffset(MatrixStack var1, Arm var2, float var3) {
   }

   @Inject(
      method = {"applySwingOffset"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void applySwingOffset_tr(MatrixStack var1, Arm var2, float var3, CallbackInfo var4) {
      CustomHandModule var5 = ModuleRegistry.f;
      if (var5 != null && var5.k() && var5.n()) {
         int var10 = var2 == Arm.RIGHT ? 1 : -1;
         float var11 = var5.c.b() * 10.0F;
         float var12 = MathHelper.sin(var3 * var3 * (float) Math.PI);
         var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var10 * (45.0F + var12 * (-var11 / 4.0F))));
         float var9 = MathHelper.sin(MathHelper.sqrt(var3) * (float) Math.PI);
         var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var10 * var9 * -(var11 / 4.0F)));
         var1.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var9 * -var11));
         var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var10 * -45.0F));
      } else {
         int var6 = var2 == Arm.RIGHT ? 1 : -1;
         float var7 = MathHelper.sin(var3 * var3 * (float) Math.PI);
         var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var6 * (45.0F + var7 * -20.0F)));
         float var8 = MathHelper.sin(MathHelper.sqrt(var3) * (float) Math.PI);
         var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var6 * var8 * -20.0F));
         var1.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var8 * -80.0F));
         var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var6 * -45.0F));
      }

      var4.cancel();
   }

   @Inject(
      method = {"applyEquipOffset"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void applyEquipOffset_tr(MatrixStack var1, Arm var2, float var3, CallbackInfo var4) {
      CustomHandModule var5 = ModuleRegistry.f;
      int var6 = var2 == Arm.RIGHT ? 1 : -1;
      if (var5 != null && var5.k()) {
         boolean var11 = var2 == this.client.options.getMainArm().getValue();
         float var7;
         float var8;
         float var9;
         float var10;
         if (var11) {
            var7 = var5.q.b();
            var8 = var5.r.b();
            var9 = var5.s.b();
            var10 = var5.t.b();
         } else {
            var7 = var5.u.b();
            var8 = var5.v.b();
            var9 = var5.w.b();
            var10 = var5.x.b();
         }

         boolean var12 = var5.a.b("Без анимации");
         var1.translate(var6 * 0.56F, -0.52F + var3 * (var12 ? -0.6F : (var5.n() ? 0.0F : -0.6F)), -0.72F);
         var1.scale(var7, var7, var7);
         var1.translate(var8, var9, var10);
      } else {
         var1.translate(var6 * 0.56F, -0.52F + var3 * -0.6F, -0.72F);
      }

      var4.cancel();
   }

   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderFirstPersonItem_tr(
      AbstractClientPlayerEntity var1,
      float var2,
      float var3,
      Hand var4,
      float var5,
      ItemStack var6,
      float var7,
      MatrixStack var8,
      OrderedRenderCommandQueue var9,
      int var10,
      CallbackInfo var11
   ) {
      if (var1.isUsingSpyglass()) {
         var11.cancel();
      } else {
         boolean var12 = var4 == Hand.MAIN_HAND;
         Arm var13 = var12 ? var1.getMainArm() : var1.getMainArm().getOpposite();
         CustomHandModule var14 = ModuleRegistry.f;
         var8.push();
         if (var6.isEmpty()) {
            if (var12 && !var1.isInvisible()) {
               this.renderArmHoldingItem(var8, var9, var10, var7, var5, var13);
            }
         } else if (var6.isOf(Items.FILLED_MAP)) {
            if (var12 && this.offHand.isEmpty()) {
               this.renderMapInBothHands(var8, var9, var10, var3, var7, var5);
            } else {
               this.renderMapInOneHand(var8, var9, var10, var7, var13, var5, var6);
            }
         } else if (var6.isOf(Items.CROSSBOW)) {
            boolean var15 = CrossbowItem.isCharged(var6);
            boolean var20 = var13 == Arm.RIGHT;
            int var21 = var20 ? 1 : -1;
            if (var1.isUsingItem() && var1.getItemUseTimeLeft() > 0 && var1.getActiveHand() == var4) {
               this.applyEquipOffset(var8, var13, var7);
               var8.translate(var21 * -0.4785682F, -0.094387F, 0.05731531F);
               var8.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-11.935F));
               var8.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var21 * 65.3F));
               var8.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var21 * -9.785F));
               float var29 = var6.getMaxUseTime(var1) - (var1.getItemUseTimeLeft() - var2 + 1.0F);
               float var34 = var29 / CrossbowItem.getPullTime(var6, var1);
               if (var34 > 1.0F) {
                  var34 = 1.0F;
               }

               if (var34 > 0.1F) {
                  float var37 = MathHelper.sin((var29 - 0.1F) * 1.3F);
                  float var19 = var34 - 0.1F;
                  float var22 = var37 * var19;
                  var8.translate(var22 * 0.0F, var22 * 0.004F, var22 * 0.0F);
               }

               var8.translate(var34 * 0.0F, var34 * 0.0F, var34 * 0.04F);
               var8.scale(1.0F, 1.0F, 1.0F + var34 * 0.2F);
               var8.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(var21 * 45.0F));
            } else {
               float var16 = -0.4F * MathHelper.sin(MathHelper.sqrt(var5) * (float) Math.PI);
               float var17 = 0.2F * MathHelper.sin(MathHelper.sqrt(var5) * (float) (Math.PI * 2));
               float var18 = -0.2F * MathHelper.sin(var5 * (float) Math.PI);
               var8.translate(var21 * var16, var17, var18);
               this.applyEquipOffset(var8, var13, var7);
               this.applySwingOffset(var8, var13, var5);
               if (var15 && var5 < 0.001F && var12) {
                  var8.translate(var21 * -0.641864F, 0.0F, 0.0F);
                  var8.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var21 * 10.0F));
               }
            }

            ItemDisplayContext var48 = var20 ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND : ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
            this.renderHandTrail(var14, var1, var6, var48, var8, var9, var10, var4);
            this.renderHandOutline(var14, var1, var6, var48, var8, var9, var10);
            if (var14 == null || !var14.k() || !var14.f.a() || !var14.n.a()) {
               this.renderItem(var1, var6, var48, var8, var9, var10);
            }

            this.renderHandShader(var14, var1, var6, var48, var8, var9, var10);
         } else {
            boolean var28 = var13 == Arm.RIGHT;
            if (var1.isUsingItem() && var1.getItemUseTimeLeft() > 0 && var1.getActiveHand() == var4) {
               int var43 = var28 ? 1 : -1;
               UseAction var50 = var6.getUseAction();
               if (!var50.hasNoOffset()) {
                  this.applyEquipOffset(var8, var13, var7);
               }

               switch (var50) {
                  case EAT:
                  case DRINK:
                     this.applyEatOrDrinkTransformation(var8, var2, var13, var6, var1);
                     this.applyEquipOffset(var8, var13, var7);
                     break;
                  case BOW:
                     var8.translate(var43 * -0.2785682F, 0.18344387F, 0.15731531F);
                     var8.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-13.935F));
                     var8.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var43 * 35.3F));
                     var8.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var43 * -9.785F));
                     float var47 = var6.getMaxUseTime(var1) - (var1.getItemUseTimeLeft() - var2 + 1.0F);
                     float var32 = var47 / 20.0F;
                     var32 = (var32 * var32 + var32 * 2.0F) / 3.0F;
                     if (var32 > 1.0F) {
                        var32 = 1.0F;
                     }

                     if (var32 > 0.1F) {
                        float var36 = MathHelper.sin((var47 - 0.1F) * 1.3F);
                        float var39 = var32 - 0.1F;
                        float var41 = var36 * var39;
                        var8.translate(var41 * 0.0F, var41 * 0.004F, var41 * 0.0F);
                     }

                     var8.translate(var32 * 0.0F, var32 * 0.0F, var32 * 0.04F);
                     var8.scale(1.0F, 1.0F, 1.0F + var32 * 0.2F);
                     var8.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(var43 * 45.0F));
                     break;
                  case TRIDENT:
                     var8.translate(var43 * -0.5F, 0.7F, 0.1F);
                     var8.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-55.0F));
                     var8.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var43 * 35.3F));
                     var8.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var43 * -9.785F));
                     float var46 = var6.getMaxUseTime(var1) - (var1.getItemUseTimeLeft() - var2 + 1.0F);
                     float var31 = var46 / 10.0F;
                     if (var31 > 1.0F) {
                        var31 = 1.0F;
                     }

                     if (var31 > 0.1F) {
                        float var35 = MathHelper.sin((var46 - 0.1F) * 1.3F);
                        float var38 = var31 - 0.1F;
                        float var40 = var35 * var38;
                        var8.translate(var40 * 0.0F, var40 * 0.004F, var40 * 0.0F);
                     }

                     var8.translate(0.0F, 0.0F, var31 * 0.2F);
                     var8.scale(1.0F, 1.0F, 1.0F + var31 * 0.2F);
                     var8.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(var43 * 45.0F));
                     break;
                  case SPEAR:
                     var8.translate(var43 * 0.56F, -0.52F, -0.72F);
                     float var45 = var6.getMaxUseTime(var1) - (var1.getItemUseTimeLeft() - var2 + 1.0F);
                     Lancing.method_75396(var1.getTimeSinceLastKineticAttack(var2), var8, var45, var13, var6);
               }
            } else if (var1.isUsingRiptide()) {
               this.applyEquipOffset(var8, var13, var7);
               int var42 = var28 ? 1 : -1;
               var8.translate(var42 * -0.4F, 0.8F, 0.3F);
               var8.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var42 * 65.0F));
               var8.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var42 * -85.0F));
            } else {
               float var49 = -0.4F * MathHelper.sin(MathHelper.sqrt(var5) * (float) Math.PI);
               float var44 = 0.2F * MathHelper.sin(MathHelper.sqrt(var5) * (float) (Math.PI * 2));
               float var30 = -0.2F * MathHelper.sin(var5 * (float) Math.PI);
               int var23 = var28 ? 1 : -1;
               if (var14 == null || !var14.k() || var14.a.b("Без анимации")) {
                  var8.translate(var23 * var49, var44, var30);
               }

               this.applyEquipOffset(var8, var13, var7);
               boolean var24 = var4 == Hand.MAIN_HAND;
               if (var14 == null || !var14.k() || !var24) {
                  this.applySwingOffset(var8, var13, var5);
               } else if (var14.a.b("Без анимации")) {
                  this.applySwingOffset(var8, var13, var5);
               } else if (var14.n()) {
                  var14.a(var8, var5, () -> this.applySwingOffset(var8, var13, var5), var13 != this.client.options.getMainArm().getValue());
               } else {
                  this.applySwingOffset(var8, var13, var5);
               }
            }

            ItemDisplayContext var51 = var28 ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND : ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
            this.renderHandTrail(var14, var1, var6, var51, var8, var9, var10, var4);
            this.renderHandOutline(var14, var1, var6, var51, var8, var9, var10);
            if (var14 == null || !var14.k() || !var14.f.a() || !var14.n.a()) {
               int var52 = this.maceHandTint(var6);
               if (var52 != 0) {
                  MaceHelperModule.b(var52);

                  try {
                     this.renderItem(var1, var6, var51, var8, var9, var10);
                  } finally {
                     MaceHelperModule.b(0);
                  }
               } else {
                  this.renderItem(var1, var6, var51, var8, var9, var10);
               }
            }

            this.renderHandShader(var14, var1, var6, var51, var8, var9, var10);
         }

         var8.pop();
         var11.cancel();
      }
   }

   private int maceHandTint(ItemStack var1) {
      MaceHelperModule var2 = ModuleRegistry.X;
      if (var2 != null && var2.k() && var2.q() && var2.a(var1)) {
         Color var3 = var2.a(var2.p());
         return 0xFF000000 | var3.getRed() << 16 | var3.getGreen() << 8 | var3.getBlue();
      } else {
         return 0;
      }
   }

   private void renderHandShader(
      CustomHandModule var1,
      AbstractClientPlayerEntity var2,
      ItemStack var3,
      ItemDisplayContext var4,
      MatrixStack var5,
      OrderedRenderCommandQueue var6,
      int var7
   ) {
      if (var1 != null && var1.k() && var1.f.a()) {
         if (!var3.isEmpty() && var2.getEntityWorld() != null) {
            String var8 = var1.h.e();
            ItemRenderState var9 = new ItemRenderState();
            int var10 = var2.getId() + var4.ordinal();
            this.itemModelManager.clearAndUpdate(var9, var3, var4, var2.getEntityWorld(), var2, var10);
            Color var11 = var1.p();
            float var12 = var11.getRed() / 255.0F;
            float var13 = var11.getGreen() / 255.0F;
            float var14 = var11.getBlue() / 255.0F;
            float var15 = var1.m.b();
            long var16 = (long)(System.currentTimeMillis() * 0.2 * var1.l.b()) & 65535L;
            int var18 = (int)(var16 & 255L);
            int var19 = (int)(var16 >> 8 & 255L);
            int var20 = var18 & 65535 | (var19 & 65535) << 16;
            boolean var21 = var4.isLeftHand();
            ItemRenderStateAccessor var22 = (ItemRenderStateAccessor)var9;
            LayerRenderState[] var23 = var22.pulse$getLayers();
            int var24 = var22.pulse$getLayerCount();

            for (int var25 = 0; var25 < var24; var25++) {
               LayerRenderState var26 = var23[var25];
               if (var26 != null) {
                  List<BakedQuad> var27 = var26.getQuads();
                  if (!var27.isEmpty()) {
                     LayerRenderStateAccessor var28 = (LayerRenderStateAccessor)var26;
                     Transformation var29 = var28.pulse$getTransform();
                     HashMap<Identifier, List<BakedQuad>> var30 = new HashMap<>();

                     for (BakedQuad var32 : var27) {
                        var30.computeIfAbsent(var32.sprite().getAtlasId(), var0 -> new ArrayList<>()).add(var32);
                     }

                     var5.push();
                     if (var29 != null) {
                        var29.apply(var21, var5.peek());
                     }

                     for (Entry<Identifier, List<BakedQuad>> var36 : var30.entrySet()) {
                        RenderLayer var33 = BlockOverlayLayers.a(var8, (Identifier)var36.getKey());
                        List<BakedQuad> var34 = var36.getValue();
                        var6.submitCustom(var5, var33, (var6x, var7x) -> {
                           for (BakedQuad var9x : var34) {
                              var7x.quad(var6x, var9x, var12, var13, var14, var15, var20, OverlayTexture.DEFAULT_UV);
                           }
                        });
                     }

                     var5.pop();
                  }
               }
            }
         }
      }
   }

   private void renderHandTrail(
      CustomHandModule var1,
      AbstractClientPlayerEntity var2,
      ItemStack var3,
      ItemDisplayContext var4,
      MatrixStack var5,
      OrderedRenderCommandQueue var6,
      int var7,
      Hand var8
   ) {
      ArrayDeque<Matrix4f> var9 = pulse$trail[var8.ordinal()];
      if (var1 != null && var1.k() && var1.i.a() && !var3.isEmpty() && var2.getEntityWorld() != null) {
         if (!var9.isEmpty()) {
            ItemRenderState var10 = new ItemRenderState();
            int var11 = var2.getId() + var4.ordinal();
            this.itemModelManager.clearAndUpdate(var10, var3, var4, var2.getEntityWorld(), var2, var11);
            Color var12 = var1.p();
            float var13 = var12.getRed() / 255.0F;
            float var14 = var12.getGreen() / 255.0F;
            float var15 = var12.getBlue() / 255.0F;
            float var16 = var1.k.b();
            float var17 = var1.j.b();
            boolean var18 = var4.isLeftHand();
            Matrix4f[] var19 = var9.toArray(new Matrix4f[0]);

            for (int var20 = var19.length - 1; var20 >= 0; var20--) {
               float var21 = var16 * (float)Math.pow(var17, var20 + 1);
               if (!(var21 < 0.02F)) {
                  if (var21 > 1.0F) {
                     var21 = 1.0F;
                  }

                  this.renderHandTrailGhost(var10, var19[var20], var18, var6, var13, var14, var15, var21);
               }
            }
         }

         var9.addFirst(new Matrix4f(var5.peek().getPositionMatrix()));

         while (var9.size() > 14) {
            var9.removeLast();
         }
      } else {
         var9.clear();
      }
   }

   private void renderHandOutline(
      CustomHandModule var1,
      AbstractClientPlayerEntity var2,
      ItemStack var3,
      ItemDisplayContext var4,
      MatrixStack var5,
      OrderedRenderCommandQueue var6,
      int var7
   ) {
      if (HandOutlineRenderer.a()) {
         if (!var3.isEmpty() && var2.getEntityWorld() != null) {
            ItemRenderState var8 = new ItemRenderState();
            int var9 = var2.getId() + var4.ordinal();
            this.itemModelManager.clearAndUpdate(var8, var3, var4, var2.getEntityWorld(), var2, var9);
            boolean var10 = var4.isLeftHand();
            if (pulse$maskImmediate == null) {
               pulse$maskImmediate = VertexConsumerProvider.immediate(new BufferAllocator(2048));
            }

            Immediate var11 = pulse$maskImmediate;
            HandOutlineRenderer.c();

            try {
               ItemRenderStateAccessor var12 = (ItemRenderStateAccessor)var8;
               LayerRenderState[] var13 = var12.pulse$getLayers();
               int var14 = var12.pulse$getLayerCount();

               for (int var15 = 0; var15 < var14; var15++) {
                  LayerRenderState var16 = var13[var15];
                  if (var16 != null) {
                     List<BakedQuad> var17 = var16.getQuads();
                     if (!var17.isEmpty()) {
                        LayerRenderStateAccessor var18 = (LayerRenderStateAccessor)var16;
                        Transformation var19 = var18.pulse$getTransform();
                        HashMap<Identifier, List<BakedQuad>> var20 = new HashMap<>();

                        for (BakedQuad var22 : var17) {
                           var20.computeIfAbsent(var22.sprite().getAtlasId(), var0 -> new ArrayList<>()).add(var22);
                        }

                        var5.push();
                        if (var19 != null) {
                           var19.apply(var10, var5.peek());
                        }

                        for (Entry<Identifier, List<BakedQuad>> var31 : var20.entrySet()) {
                           RenderLayer var23 = BlockOverlayLayers.b((Identifier)var31.getKey());
                           VertexConsumer var24 = var11.getBuffer(var23);

                           for (BakedQuad var26 : var31.getValue()) {
                              var24.quad(var5.peek(), var26, 1.0F, 1.0F, 1.0F, 1.0F, 0, OverlayTexture.DEFAULT_UV);
                           }
                        }

                        var5.pop();
                     }
                  }
               }

               var11.draw();
            } finally {
               HandOutlineRenderer.d();
            }
         }
      }
   }

   private void renderHandTrailGhost(
      ItemRenderState var1, Matrix4f var2, boolean var3, OrderedRenderCommandQueue var4, float var5, float var6, float var7, float var8
   ) {
      ItemRenderStateAccessor var9 = (ItemRenderStateAccessor)var1;
      LayerRenderState[] var10 = var9.pulse$getLayers();
      int var11 = var9.pulse$getLayerCount();
      MatrixStack var12 = new MatrixStack();
      var12.peek().getPositionMatrix().set(var2);

      for (int var13 = 0; var13 < var11; var13++) {
         LayerRenderState var14 = var10[var13];
         if (var14 != null) {
            List<BakedQuad> var15 = var14.getQuads();
            if (!var15.isEmpty()) {
               LayerRenderStateAccessor var16 = (LayerRenderStateAccessor)var14;
               Transformation var17 = var16.pulse$getTransform();
               HashMap<Identifier, List<BakedQuad>> var18 = new HashMap<>();

               for (BakedQuad var20 : var15) {
                  var18.computeIfAbsent(var20.sprite().getAtlasId(), var0 -> new ArrayList<>()).add(var20);
               }

               var12.push();
               if (var17 != null) {
                  var17.apply(var3, var12.peek());
               }

               float var24 = var8;

               for (Entry<Identifier, List<BakedQuad>> var21 : var18.entrySet()) {
                  RenderLayer var22 = BlockOverlayLayers.a((Identifier)var21.getKey());
                  List<BakedQuad> var23 = var21.getValue();
                  var4.submitCustom(var12, var22, (var5x, var6x) -> {
                     for (BakedQuad var8x : var23) {
                        var6x.quad(var5x, var8x, var5, var6, var7, var24, 0, OverlayTexture.DEFAULT_UV);
                     }
                  });
               }

               var12.pop();
            }
         }
      }
   }
}
