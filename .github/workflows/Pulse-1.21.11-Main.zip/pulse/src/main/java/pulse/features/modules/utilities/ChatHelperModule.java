package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import pulse.core.event.impl.ChatEvent;
import pulse.mixin.accessor.ChatHudAccessor;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;

@ModuleInfo(
   a = "Chat Helper",
   b = "Антиспам и сохранение истории чата",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ChatHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Анти спам", false);
   private final BooleanSetting b = new BooleanSetting("Сохранять историю", false);
   private final BooleanSetting c = new BooleanSetting("Фикс раскладки команд", true);
   private static final String f = "йцукенгшщзхъфывапролджэячсмитьбю.ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ,";
   private static final String g = "qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:\"ZXCVBNM<>?";
   private String h = "";
   private int i = 1;
   private ChatHudLine j = null;
   private static boolean k = false;

   public boolean a(ChatHud var1, Text var2) {
      if (k) {
         return false;
      } else if (!this.a.a() || !this.k()) {
         return false;
      } else if (d.player == null) {
         return false;
      } else {
         String var3 = var2.getString();
         ChatHudAccessor var4 = (ChatHudAccessor)var1;
         if (this.h.equals(var3) && this.j != null) {
            var var5 = var4.getMessages();
            var var6 = var4.getVisibleMessages();
            int var7 = this.j.creationTick();
            var5.remove(this.j);
            var6.removeIf(var1x -> var1x.addedTime() == var7);
            this.i++;
            MutableText var8 = Text.literal("").append(var2).append(Text.literal(Formatting.GRAY + " [x" + this.i + "]"));
            k = true;

            try {
               var1.addMessage(var8);
            } finally {
               k = false;
            }
         } else {
            this.i = 1;
            k = true;

            try {
               var1.addMessage(var2);
            } finally {
               k = false;
            }
         }

         var var17 = var4.getMessages();
         this.j = var17.isEmpty() ? null : (ChatHudLine)var17.get(0);
         this.h = var3;
         return true;
      }
   }

   @EventHandler
   @Compile
   public void a(ChatEvent var1) {
      BooleanSetting layout = this.c;
      if (!layout.a() || d.player == null) {
         return;
      }
      String message = var1.d();
      if (!message.startsWith("/") && !message.startsWith(".")) {
         return;
      }
      String payload = message.substring(1);
      int space = payload.indexOf(' ');
      String command = space == -1 ? payload : payload.substring(0, space);
      if (command.isEmpty()) {
         return;
      }
      boolean mapped = false;
      boolean unsupported = false;
      for (char character : command.toCharArray()) {
         if (f.indexOf(character) != -1) {
            mapped = true;
         } else if (!Character.isDigit(character)) {
            unsupported = true;
         }
      }
      if (!mapped || unsupported) {
         return;
      }
      StringBuilder corrected = new StringBuilder();
      for (char character : command.toCharArray()) {
         int index = f.indexOf(character);
         corrected.append(index == -1 ? character : g.charAt(index));
      }
      if (space != -1) {
         corrected.append(payload.substring(space));
      }
      var1.b();
      d.player.networkHandler.sendChatCommand(corrected.toString());
   }

   public boolean n() {
      return this.k() && this.b.a();
   }

   static {
      NativeMethodLookup.lookup(ChatHelperModule.class, 54);
   }
}
