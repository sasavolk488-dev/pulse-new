package pulse.features.resourcepack;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;
import pulse.utils.net.ApiRouter;

@Environment(EnvType.CLIENT)
public final class ResourcePackService {
   private static final int a = 50;
   private static final int b = 51;
   private static final ResourcePackService c = new ResourcePackService();
   private final CopyOnWriteArrayList<ResourcePackService.ReadyPack> d = new CopyOnWriteArrayList<>();
   private volatile boolean e = false;

   public static ResourcePackService a() {
      return c;
   }

   private ResourcePackService() {
   }

   public List<ResourcePackService.ReadyPack> b() {
      return this.d;
   }

   private Path e() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cache").resolve("packs");
   }

   public void c() {
      if (!this.e) {
         this.e = true;
         new Thread(() -> {
            try {
               this.f();
            } catch (Exception var5) {
               Pulse.m().error("Ошибка загрузки ресурс-паков", (Throwable)var5);
            } finally {
               this.e = false;
            }
         }, "ResourcePack-Loader").start();
      }
   }

   public void d() {
      Pulse.m().info("РП: получено событие обновления, перезагрузка списка паков");
      this.c();
   }

   private void f() throws Exception {
      RealtimeSyncServiceV2 var1 = RealtimeSyncServiceV2.L();
      if (var1 != null && var1.b()) {
         JSONObject var2 = var1.a(50, 0, new JSONObject());
         if (var2 != null && var2.optBoolean("ok", false)) {
            JSONArray var3 = var2.optJSONArray("packs");
            if (var3 != null && var3.length() != 0) {
               Files.createDirectories(this.e());
               this.d.clear();

               for (int var4 = 0; var4 < var3.length(); var4++) {
                  JSONObject var5 = var3.getJSONObject(var4);
                  int var6 = var5.getInt("id");
                  String var7 = var5.optString("name", "Resource Pack");
                  String var8 = var5.optString("contentHash", "");

                  try {
                     Path var9 = this.e().resolve(var6 + ".ppack");
                     Path var10 = this.e().resolve(var6 + ".hash");
                     boolean var11 = !Files.exists(var9) || !PpackContainer.a(var9) || !var8.equals(this.a(var10));
                     if (var11) {
                        if (!this.a(var6, var1.c(), var9)) {
                           Pulse.m().warn("РП: не удалось скачать пак {}", var6);
                           continue;
                        }

                        this.a(var10, var8);
                        Pulse.m().info("РП: скачан пак {} ({})", var6, var7);
                     } else {
                        Pulse.m().info("РП: пак {} актуален в кэше", var6);
                     }

                     JSONObject var12 = var1.a(51, 0, new JSONObject().put("packId", var6));
                     if (var12 != null && var12.optBoolean("ok", false)) {
                        String var13 = var12.getJSONObject("data").getString("dek");
                        byte[] var14 = a(var13);

                        PpackContainer var15;
                        try {
                           var15 = PpackContainer.a(var9, var14);
                        } catch (Exception var17) {
                           Pulse.m().warn("РП: пак {} не расшифровался ({}), перекачиваю", var6, var17.getMessage());
                           Files.deleteIfExists(var9);
                           Files.deleteIfExists(var10);
                           if (!this.a(var6, var1.c(), var9)) {
                              Pulse.m().warn("РП: повторная закачка пака {} не удалась", var6);
                              continue;
                           }

                           this.a(var10, var8);
                           var15 = PpackContainer.a(var9, var14);
                        }

                        this.d.add(new ResourcePackService.ReadyPack(String.valueOf(var6), var7, var15));
                        Pulse.m().info("РП: пак {} готов (format={})", var6, var15.a());
                     } else {
                        Pulse.m().warn("РП: не получен DEK для пака {}", var6);
                     }
                  } catch (Exception var18) {
                     Pulse.m().error("РП: ошибка подготовки пака {}", var6, var18);
                  }
               }

               if (this.d.isEmpty()) {
                  Pulse.m().info("РП: нет готовых паков");
               } else {
                  this.g();
               }
            } else {
               Pulse.m().info("РП: купленных паков нет");
            }
         } else {
            Pulse.m().warn("РП: RP_LIST не вернул ok");
         }
      } else {
         Pulse.m().warn("РП: нет авторизованной сессии, пропуск загрузки");
      }
   }

   private void g() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      var1.execute(() -> {
         try {
            ResourcePackManager var2 = var1.getResourcePackManager();
            var2.scanPacks();
            boolean var3 = false;

            for (ResourcePackService.ReadyPack var5 : this.d) {
               String var6 = "pulse_rp/" + var5.id();
               if (var1.options.resourcePacks.contains(var6) && var2.hasProfile(var6)) {
                  var3 = true;
                  break;
               }
            }

            if (var3) {
               var1.options.addResourcePackProfilesToManager(var2);
               var1.reloadResources();
               Pulse.m().info("РП: восстановлены включённые паки, доступно: {}", this.d.size());
            } else {
               Pulse.m().info("РП: доступно паков в списке: {}", this.d.size());
            }
         } catch (Exception var7) {
            Pulse.m().error("РП: ошибка регистрации паков", (Throwable)var7);
         }
      });
   }

   private boolean a(int var1, int var2, Path var3) {
      if (var2 <= 0) {
         return false;
      } else {
         for (String var5 : ApiRouter.a()) {
            HttpURLConnection var6 = null;

            boolean var22;
            try {
               URL var7 = new URL(var5 + "/creator-resource-packs/" + var1 + "/download?userId=" + var2);
               var6 = (HttpURLConnection)var7.openConnection();
               var6.setRequestMethod("GET");
               var6.setConnectTimeout(15000);
               var6.setReadTimeout(60000);
               int var8 = var6.getResponseCode();
               if (var8 != 200) {
                  Pulse.m().warn("РП: download пак {} -> HTTP {}", var1, var8);
                  continue;
               }

               try (InputStream var9 = var6.getInputStream()) {
                  ByteArrayOutputStream var10 = new ByteArrayOutputStream();
                  byte[] var11 = new byte[8192];

                  int var12;
                  while ((var12 = var9.read(var11)) != -1) {
                     var10.write(var11, 0, var12);
                  }

                  Files.write(var3, var10.toByteArray());
               }

               var22 = true;
            } catch (Exception var20) {
               Pulse.m().warn("РП: ошибка download пак {} с {}: {}", var1, var5, var20.getMessage());
               continue;
            } finally {
               if (var6 != null) {
                  var6.disconnect();
               }
            }

            return var22;
         }

         return false;
      }
   }

   private String a(Path var1) {
      try {
         if (Files.exists(var1)) {
            return new String(Files.readAllBytes(var1), StandardCharsets.UTF_8).trim();
         }
      } catch (Exception var3) {
      }

      return null;
   }

   private void a(Path var1, String var2) {
      try {
         Files.write(var1, var2.getBytes(StandardCharsets.UTF_8));
      } catch (Exception var4) {
      }
   }

   private static byte[] a(String var0) {
      int var1 = var0.length();
      byte[] var2 = new byte[var1 / 2];

      for (byte var3 = 0; var3 < var1; var3 += 2) {
         var2[var3 / 2] = (byte)((Character.digit(var0.charAt(var3), 16) << 4) + Character.digit(var0.charAt(var3 + 1), 16));
      }

      return var2;
   }

   @Environment(EnvType.CLIENT)
   public record ReadyPack(String id, String name, PpackContainer container) {
   }
}
