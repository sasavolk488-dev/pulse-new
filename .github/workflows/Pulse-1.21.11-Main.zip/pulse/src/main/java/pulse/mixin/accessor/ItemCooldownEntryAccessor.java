package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin(
   targets = {"net/minecraft/entity/player/ItemCooldownManager$Entry"}
)
public interface ItemCooldownEntryAccessor {
   @Accessor("startTick")
   int pulse$getStartTick();

   @Accessor("endTick")
   int pulse$getEndTick();
}
