package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.FrameEvent;
import pulse.core.event.impl.TotemPopEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.ParticleHandler;
import pulse.core.handler.impl.particle.ParticleTextures;
import pulse.core.handler.impl.particle.PhysicsMode;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;

@ModuleInfo(
   a = "Particles",
   b = "Создаёт частицы при выполнении условий",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class ParticlesModule extends Module {
   private final ModeSetting a = new ModeSetting("Условия", new String[]{"При ударе", "При сносе тотема"}, new int[]{0});
   private final BooleanSetting b = new BooleanSetting("Индивидуальные настройки", false);
   private final SeparatorSetting c = new SeparatorSetting("Общие настройки").a(() -> !this.b.a());
   private final ModeSetting f = new ModeSetting("Тип частиц", ParticleTextures.f, "Звезда").a(() -> !this.b.a());
   private final ModeSetting g = new ModeSetting("Режим физики", PhysicsMode.b(), "Реалистичная").a(() -> !this.b.a());
   private final NumberSetting h = new NumberSetting("Количество", 4.0F, 1.0F, 20.0F, 1.0F).a(() -> !this.b.a());
   private final NumberSetting i = new NumberSetting("Размер", 0.3F, 0.1F, 0.75F, 0.05F).a(() -> !this.b.a());
   private final NumberSetting j = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F).a(() -> !this.b.a());
   private final NumberSetting k = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F).a(() -> !this.b.a());
   private final NumberSetting l = new NumberSetting("Масштаб начало", 1.0F, 0.0F, 2.0F, 0.05F).a(() -> !this.b.a());
   private final NumberSetting m = new NumberSetting("Масштаб пик", 1.0F, 0.0F, 2.0F, 0.05F).a(() -> !this.b.a());
   private final NumberSetting n = new NumberSetting("Масштаб конец", 1.0F, 0.0F, 2.0F, 0.05F).a(() -> !this.b.a());
   private final BooleanSetting o = new BooleanSetting("Цвет клиента", true).a(() -> !this.b.a());
   private final ColorSetting p = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.o.a() && !this.b.a());
   private final BooleanSetting q = new BooleanSetting("Градиент", false).a(() -> !this.b.a());
   private final ColorSetting r = new ColorSetting("Конечный цвет", Color.WHITE).a(() -> this.q.a() && !this.b.a());
   private final SeparatorSetting s = new SeparatorSetting("Удар").a(() -> this.b.a() && this.a.b("При ударе"));
   private final ModeSetting t = new ModeSetting("Тип частиц", ParticleTextures.f, "Звезда").a(() -> this.b.a() && this.a.b("При ударе"));
   private final ModeSetting u = new ModeSetting("Режим физики", PhysicsMode.b(), "Реалистичная").a(() -> this.b.a() && this.a.b("При ударе"));
   private final NumberSetting v = new NumberSetting("Количество", 4.0F, 1.0F, 20.0F, 1.0F).a(() -> this.b.a() && this.a.b("При ударе"));
   private final NumberSetting w = new NumberSetting("Размер", 0.3F, 0.1F, 0.75F, 0.05F).a(() -> this.b.a() && this.a.b("При ударе"));
   private final NumberSetting x = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F).a(() -> this.b.a() && this.a.b("При ударе"));
   private final NumberSetting y = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F).a(() -> this.b.a() && this.a.b("При ударе"));
   private final BooleanSetting z = new BooleanSetting("Цвет клиента", true).a(() -> this.b.a() && this.a.b("При ударе"));
   private final ColorSetting A = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> this.b.a() && this.a.b("При ударе") && !this.z.a());
   private final BooleanSetting B = new BooleanSetting("Градиент", false).a(() -> this.b.a() && this.a.b("При ударе"));
   private final ColorSetting C = new ColorSetting("Конечный цвет", Color.WHITE).a(() -> this.b.a() && this.a.b("При ударе") && this.B.a());
   private final SeparatorSetting D = new SeparatorSetting("Тотем").a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final ModeSetting E = new ModeSetting("Тип частиц", ParticleTextures.f, "Звезда").a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final ModeSetting F = new ModeSetting("Режим физики", PhysicsMode.b(), "Реалистичная").a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final NumberSetting G = new NumberSetting("Количество", 4.0F, 1.0F, 20.0F, 1.0F).a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final NumberSetting H = new NumberSetting("Размер", 0.3F, 0.1F, 0.75F, 0.05F).a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final NumberSetting I = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F).a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final NumberSetting J = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F).a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final BooleanSetting K = new BooleanSetting("Цвет клиента", true).a(() -> this.b.a() && this.a.b("При сносе тотема"));
   private final ColorSetting L = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> this.b.a() && this.a.b("При сносе тотема") && !this.K.a());
   private long M;
   private Vec3d N;
   private boolean O = false;
   private LivingEntity P;

   @EventHandler
   @Compile
   public void a(AttackEvent var1) {
      if (this.a.b("При ударе") && var1.a() != d.player && var1.a() instanceof LivingEntity) {
         Object target = var1.a();
         Vec3d position = new Vec3d(((LivingEntity)target).getX(), ((LivingEntity)target).getY() + (double)(((LivingEntity)target).getEyeHeight(((LivingEntity)target).getPose()) * 0.5F), ((LivingEntity)target).getZ());
         int color = this.f("attack").getRGB();
         this.a(position, 0.02, color, "attack");
      }
   }

   @EventHandler
   @Compile
   public void a(TotemPopEvent var1) {
      if (this.a.b("При сносе тотема")) {
         try {
            this.P = var1.a();
         } catch (RuntimeException | Error exception) {
            this.P = null;
            throw exception;
         }
         this.N = new Vec3d(this.P.getX(), this.P.getY() + (double)this.P.getEyeHeight(this.P.getPose()), this.P.getZ());
         this.M = System.currentTimeMillis();
         this.O = true;
      }
   }

   @EventHandler
   public void a(FrameEvent var1) {
      if (this.a.b("При сносе тотема") && this.O) {
         if (System.currentTimeMillis() - this.M > 1500L) {
            this.O = false;
            this.P = null;
         } else {
            if (this.P != null && this.P.isAlive()) {
               this.N = new Vec3d(this.P.getX(), this.P.getY() + this.P.getHeight() / 2.0, this.P.getZ());
            }

            for (int var2 = 0; var2 < 2; var2++) {
               double var3 = 0.40000007271887716;

               Vec3d var5;
               do {
                  var5 = new Vec3d(
                     ThreadLocalRandom.current().nextDouble(-1.0, 1.0),
                     ThreadLocalRandom.current().nextDouble(0.1000000004947689, 1.0),
                     ThreadLocalRandom.current().nextDouble(-1.0, 1.0)
                  );
               } while (var5.lengthSquared() > 1.0);

               var5 = var5.normalize().multiply(var3);
               int var6 = ThreadLocalRandom.current().nextBoolean() ? -233 : -16449792;
               PhysicsMode var7 = PhysicsMode.a(this.b.a() ? this.F.e() : this.g.e());
               float var8 = this.b.a() ? this.H.b() : this.i.b();
               int var9 = this.b.a() ? this.I.c() : this.j.c();
               Identifier var10 = this.g("totem");
               HandlerRegistry.g.d().a(this.N).b(var5).a(var9).a(var8).a(var10).b(var6).a(this.l.b(), this.m.b(), this.n.b()).a(var7).a();
            }
         }
      }
   }

   private void a(Vec3d var1, double var2, int var4, String var5) {
      var4 = ColorUtils.a(var4);
      int var6 = this.b.a() ? this.a(var5) : this.h.c();
      int var7 = var6 * 3 * var6;
      int var8 = this.b.a() ? this.c(var5) : this.j.c();
      int var9 = var8 - 10;
      int var10 = var8 + 10;
      float var11 = this.b.a() ? this.b(var5) : this.i.b();
      float var12 = var11 - 0.05F;
      float var13 = var11 + 0.05F;
      double var14 = this.b.a() ? this.d(var5) : this.k.b();
      PhysicsMode var16 = PhysicsMode.a(this.b.a() ? this.e(var5) : this.g.e());
      Identifier var17 = this.g(var5);
      boolean var18 = this.b.a() ? var5.equals("attack") && this.B.a() : this.q.a();
      int var19 = ColorUtils.a(this.b.a() ? this.C.b() : this.r.b());

      for (int var20 = 0; var20 < var7; var20++) {
         int var21 = ThreadLocalRandom.current().nextInt(var9, var10);
         float var22 = var12 + ThreadLocalRandom.current().nextFloat() * (var13 - var12);
         Vec3d var23 = new Vec3d(
            ThreadLocalRandom.current().nextDouble(-var2, var2),
            ThreadLocalRandom.current().nextDouble(0.0, var2),
            ThreadLocalRandom.current().nextDouble(-var2, var2)
         );
         if (var23.lengthSquared() > 0.0) {
            var23 = var23.normalize().multiply(ThreadLocalRandom.current().nextDouble(0.005000000243979068, var14));
         }

         ParticleHandler.Builder var24 = HandlerRegistry.g.d().a(var1).b(var23).a(var21).a(var22).a(var17).a(this.l.b(), this.m.b(), this.n.b()).a(var16);
         if (var18) {
            var24.a(var4, var19);
         } else {
            var24.b(var4);
         }

         var24.a();
      }
   }

   private int a(String var1) {
      switch (var1) {
         case "attack":
            return this.v.c();
         case "totem":
            return this.G.c();
         default:
            return this.h.c();
      }
   }

   private float b(String var1) {
      switch (var1) {
         case "attack":
            return this.w.b();
         case "totem":
            return this.H.b();
         default:
            return this.i.b();
      }
   }

   private int c(String var1) {
      switch (var1) {
         case "attack":
            return this.x.c();
         case "totem":
            return this.I.c();
         default:
            return this.j.c();
      }
   }

   private double d(String var1) {
      switch (var1) {
         case "attack":
            return this.y.b();
         case "totem":
            return this.J.b();
         default:
            return this.k.b();
      }
   }

   private String e(String var1) {
      switch (var1) {
         case "attack":
            return this.u.e();
         case "totem":
            return this.F.e();
         default:
            return this.g.e();
      }
   }

   private Color f(String var1) {
      if (this.b.a()) {
         switch (var1) {
            case "attack":
               return this.z.a() ? ModuleRegistry.aw.n() : this.A.a();
            case "totem":
               return this.K.a() ? ModuleRegistry.aw.n() : this.L.a();
         }
      }

      if (this.o.a()) {
         ClientColorModule var2 = ModuleRegistry.aw;
         return var2.n();
      } else {
         return this.p.a();
      }
   }

   private Identifier g(String var1) {
      String var2;
      if (this.b.a()) {
         switch (var1) {
            case "attack":
               var2 = this.t.e();
               break;
            case "totem":
               var2 = this.E.e();
               break;
            default:
               var2 = this.f.e();
         }
      } else {
         var2 = this.f.e();
      }

      return ParticleTextures.a(var2);
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.O = false;
      this.P = null;
   }

   static {
      NativeMethodLookup.lookup(ParticlesModule.class, 86);
   }
}
