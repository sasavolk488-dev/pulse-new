package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.sound.AbstractSoundInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({AbstractSoundInstance.class})
public interface AbstractSoundInstanceAccessor {
   @Accessor("volume")
   float pulse$getVolume();

   @Accessor("volume")
   void pulse$setVolume(float var1);

   @Accessor("pitch")
   float pulse$getPitch();

   @Accessor("pitch")
   void pulse$setPitch(float var1);
}
