package pulse.services.tracker.v2;

import java.util.List;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface SyncCallback {
   void a(int var1, Set<String> var2);

   void a(int var1, long var2, List<DeltaOp> var4);
}
