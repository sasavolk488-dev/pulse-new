package pulse.core.settings;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.Item;

@Environment(EnvType.CLIENT)
public class ItemColorSetting extends Setting<Boolean> {
   private final Item a;
   private Color b;

   public ItemColorSetting(String var1, String var2, Item var3, boolean var4, Color var5) {
      super(var1, var2, var4);
      this.a = var3;
      this.b = var5;
   }

   public ItemColorSetting(String var1, Item var2, boolean var3, Color var4) {
      this(var1, "", var2, var3, var4);
   }

   public ItemColorSetting(String var1, Item var2, Color var3) {
      this(var1, "", var2, false, var3);
   }

   public boolean b() {
      return this.q();
   }

   public void a(boolean var1) {
      this.a(Boolean.valueOf(var1));
   }

   public void c() {
      this.a(Boolean.valueOf(!this.q()));
   }

   public Item d() {
      return this.a;
   }

   public Color e() {
      return this.b;
   }

   public void a(Color var1) {
      this.b = var1;
   }

   public int f() {
      return this.b.getRGB();
   }
}
