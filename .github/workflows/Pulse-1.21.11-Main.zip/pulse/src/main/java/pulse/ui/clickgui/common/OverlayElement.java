package pulse.ui.clickgui.common;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class OverlayElement {
   private static final OverlayElement a = new OverlayElement();
   private static final int b = 80;
   private static final int c = 150;
   private final Animation d = new Animation();
   private boolean e = false;
   private boolean f = false;
   private boolean g = false;
   private boolean h = false;
   private boolean i = false;
   private boolean j = false;

   private OverlayElement() {
   }

   public static OverlayElement a() {
      return a;
   }

   public void a(boolean var1) {
      if (this.f != var1) {
         this.f = var1;
         this.h();
      }
   }

   public void b(boolean var1) {
      if (this.g != var1) {
         this.g = var1;
         this.h();
      }
   }

   public void c(boolean var1) {
      if (this.h != var1) {
         this.h = var1;
         this.h();
      }
   }

   public void d(boolean var1) {
      if (this.i != var1) {
         this.i = var1;
         this.h();
      }
   }

   public void e(boolean var1) {
      if (this.j != var1) {
         this.j = var1;
         this.h();
      }
   }

   public boolean b() {
      return this.f || this.g || this.h || this.i || this.j;
   }

   public boolean c() {
      return this.i;
   }

   public boolean d() {
      return this.j;
   }

   public boolean e() {
      return this.h;
   }

   private void h() {
      boolean var1 = this.b();
      if (var1 != this.e) {
         this.d.a(var1 ? 1.0 : 0.0, var1 ? 0.20000003727846044 : 0.15000000006548567, Easings.h);
         this.e = var1;
      }
   }

   public void f() {
      this.f = false;
      this.g = false;
      this.h = false;
      this.i = false;
      this.j = false;
      this.e = false;
      this.d.d(0.0);
   }

   public void a(MatrixStack var1, Render var2) {
      this.d.a();
      float var3 = (float)this.d.j();
      if (var3 > 0.01F) {
         int var4 = (int)(IMinecraft.u().getWidth() / 2.0F);
         int var5 = (int)(IMinecraft.u().getHeight() / 2.0F);
         int var6 = this.j ? 150 : 80;
         var2.a(0.0F, 0.0F, var4, var5, ClickGuiColors.a(ClickGuiColors.ab, (int)(var6 * var3)), var1);
      }
   }

   public float g() {
      return (float)this.d.j();
   }
}
