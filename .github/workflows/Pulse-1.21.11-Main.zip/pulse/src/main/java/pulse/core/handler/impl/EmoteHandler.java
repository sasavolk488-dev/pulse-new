package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.EmoteMusicPlayer;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.shader.ShaderProgram;
import pulse.utils.render.shader.ShaderRegistry;
import pulse.utils.input.KeyBindings;
import pulse.utils.render.ScaleUtils;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class EmoteHandler extends Handler implements IMinecraft {
   private static final double f = 3.0;
   private static final int g = 3;
   private static final long h = 10000L;
   private final ArrayDeque<Long> i = new ArrayDeque<>();
   public static volatile boolean a = false;
   public static volatile double b = 0.0;
   public static volatile double c = 0.0;
   private final List<String> j = new ArrayList<>();
   private double k;
   private double l;
   private int m = -1;
   private final Animation n = new Animation();
   private boolean o;
   private boolean p;
   private Vec3d q;
   private static final float r = 48.0F;
   private static final float s = 100.0F;
   private static final float t = 0.05F;
   private static final float u = 5.0F;
   private static final float v = 44.0F;
   private static final int w = 7;
   private static final Color x = new Color(13, 13, 17, 205);
   private static final Color y = new Color(115, 83, 255, 215);
   private static final Color z = new Color(10, 10, 14, 235);
   private static final Color A = new Color(115, 83, 255, 230);
   private static final Color B = new Color(223, 223, 243, 235);

   @Override
   public void a() {
      super.a();
      if (!this.p) {
         this.p = true;
         ClientTickEvents.END_CLIENT_TICK.register(var1 -> this.d());
         Pulse.m().info("[Emote] EmoteHandler init — wheel key = {}", KeyBindings.b != null ? KeyBindings.b.getBoundKeyLocalizedText().getString() : "NULL");
      }
   }

   private void d() {
      EmoteManager var1 = EmoteManager.a();
      if (d.player != null && d.world != null) {
         boolean var2 = KeyBindings.b != null && KeyBindings.b.isPressed();
         if (var2 && !this.o && d.currentScreen == null && !GraffitiHandler.a && !PhraseHandler.a) {
            this.e();
         } else if (!var2 && this.o) {
            this.f();
         }

         this.o = var2;
         if (var1.i()) {
            if (this.q == null) {
               this.q = d.player.getEntityPos();
            }

            if (var1.l() || this.g()) {
               var1.k();
               this.q = null;
            }
         } else {
            this.q = null;
         }

         var1.n();
         EmoteMusicPlayer.a().b();
      } else {
         var1.k();
         EmoteMusicPlayer.a().c();
         a = false;
         this.n.d(0.0);
         this.q = null;
      }
   }

   private void e() {
      this.j.clear();

      for (String var2 : EmoteManager.a().f()) {
         if (this.j.size() >= 7) {
            break;
         }

         this.j.add(var2);
      }

      if (this.j.isEmpty()) {
         if (d.player != null) {
            d.player.sendMessage(Text.literal("§cНет надетых эмоций — наденьте их на сайте"), true);
            d.player.sendMessage(Text.literal("§cНет надетых эмоций — наденьте их на сайте"), false);
         }
      } else {
         a = true;
         b = 0.0;
         c = 0.0;
         this.k = 0.0;
         this.l = 0.0;
         this.m = -1;
         this.n.d(0.0);
         this.n.a(1.0, 0.25, Easings.F);
      }
   }

   private void f() {
      if (a) {
         a = false;
         this.n.a(0.0, 0.1500000305767614, Easings.g);
         if (this.m >= 0 && this.m < this.j.size()) {
            if (d.player != null && !EmoteManager.a((LivingEntity)d.player)) {
               d.player.sendMessage(Text.literal("§cНельзя использовать эмоции в невидимости без брони"), true);
               return;
            }

            long var1 = System.currentTimeMillis();

            while (!this.i.isEmpty() && var1 - this.i.peekFirst() > 10000L) {
               this.i.pollFirst();
            }

            if (this.i.size() >= 3) {
               if (d.player != null) {
                  long var3 = (10000L - (var1 - this.i.peekFirst()) + 999L) / 1000L;
                  d.player.sendMessage(Text.literal("§cСлишком часто — подожди " + var3 + "с"), true);
               }

               return;
            }

            this.i.addLast(var1);
            EmoteManager.a().e(this.j.get(this.m));
            this.q = d.player != null ? d.player.getEntityPos() : null;
         }
      }
   }

   private boolean g() {
      ClientPlayerEntity var1 = d.player;
      if (var1 == null) {
         return true;
      } else if (var1.isDead() || var1.hurtTime > 0) {
         return true;
      } else if (!EmoteManager.a((LivingEntity)var1)) {
         return true;
      } else if (var1.isSwimming() || var1.isGliding() || var1.isInsideWall()) {
         return true;
      } else if (!d.options.attackKey.isPressed() && !d.options.useKey.isPressed()) {
         Input var2 = var1.input;
         if (var2 != null) {
            PlayerInput var3 = var2.playerInput;
            if (var3 != null && (var3.jump() || var3.sneak())) {
               return true;
            }
         }

         if (this.q != null) {
            double var7 = var1.getX() - this.q.x;
            double var5 = var1.getZ() - this.q.z;
            if (var7 * var7 + var5 * var5 > 9.0) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   @EventHandler
   @Compile
   public void a(RenderHudPostEvent var1) {
      this.n.a();
      float opacity = (float)this.n.j();
      if (opacity < 0.01F || this.j.isEmpty()) {
         return;
      }
      if (a) {
         this.k += b * 1.4;
         this.l += c * 1.4;
         b = 0.0;
         c = 0.0;
         double radius = Math.sqrt(this.k * this.k + this.l * this.l);
         boolean select;
         if (!(radius > 41.0)) {
            select = radius > 32.800000000000004;
         } else {
            double scale = 41.0 / radius;
            this.k *= scale;
            this.l *= scale;
            select = true;
         }
         if (select) {
            int size = this.j.size();
            double angle = ((Math.atan2(this.l, this.k) + 1.5707963267948966)
               % 6.283185307179586 + 6.283185307179586) % 6.283185307179586;
            this.m = (int)(angle / (6.283185307179586 / size));
            if (this.m >= size) {
               this.m = size - 1;
            }
         } else {
            this.m = -1;
         }
      }
      this.a(var1.a(), opacity);
   }

   private void a(MatrixStack var1, float var2) {
      int var3 = this.j.size();
      if (var3 != 0) {
         ScaleUtils.a(2.0);
         float var4 = (float)(d.getWindow().getFramebufferWidth() / 2.0 / 2.0);
         float var5 = (float)(d.getWindow().getFramebufferHeight() / 2.0 / 2.0);
         float var6 = Math.max(0.0F, Math.min(1.0F, var2));
         float var7 = 48.0F * var6;
         float var8 = 100.0F * var6;
         float var9 = (float)(6.28318531416587 / var3);
         float var10 = (float) (-Math.PI / 2);
         Optional var11 = ShaderRegistry.a().a("emote_wheel");
         if (var11.isPresent()) {
            ShaderProgram var12 = (ShaderProgram)var11.get();
            float var13 = 104.0F;
            float var14 = var13 * 2.0F;
            float var15 = var4 - var13;
            float var16 = var5 - var13;
            var12.d();
            Matrix4f var17 = new Matrix4f()
               .setOrtho(0.0F, d.getWindow().getFramebufferWidth() / 2.0F, d.getWindow().getFramebufferHeight() / 2.0F, 0.0F, -1.0F, 1.0F);
            float[] var18 = new float[16];
            var17.get(var18);
            var12.a("ProjMat", var18);
            var12.a("ModelViewMat", new float[]{1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F});
            var12.a("size", var14);
            var12.a("innerR", var7);
            var12.a("outerR", var8);
            var12.a("centerR", 0.0F);
            var12.a("accentR", 0.0F);
            var12.a("cursorR", a ? 5.0F * var6 : 0.0F);
            var12.b("count", var3);
            var12.b("selected", this.m);
            var12.a("gap", var3 <= 1 ? 0.0F : 0.05F);
            var12.a("opacity", var6);
            var12.a("cursor", (float)this.k * var6, (float)this.l * var6);
            var12.a("bgColor", x);
            var12.a("hoverColor", y);
            var12.a("centerColor", z);
            var12.a("accentColor", A);
            var12.a("cursorColor", B);
            boolean var19 = GL11.glIsEnabled(3042);
            GL11.glEnable(3042);
            GL14.glBlendFuncSeparate(770, 771, 1, 771);
            ShaderProgram.a(var15, var16, var14, var14);
            if (!var19) {
               GL11.glDisable(3042);
            }

            var12.e();
         }

         if (var6 > 0.5F) {
            Render var25 = Pulse.l().p();
            float var26 = 44.0F * var6;

            for (int var27 = 0; var27 < var3; var27++) {
               float var29 = var10 + (var27 + 0.5F) * var9;
               float var30 = (var7 + var8) / 2.0F;
               float var31 = var4 + (float)Math.cos(var29) * var30;
               float var32 = var5 + (float)Math.sin(var29) * var30;
               Color var33 = var27 == this.m ? Color.WHITE : new Color(255, 255, 255, 200);
               String var20 = this.j.get(var27);
               Identifier var21 = EmoteManager.a().b(var20);
               if (var21 != null) {
                  var25.a(var21, var31 - var26 / 2.0F, var32 - var26 / 2.0F, var26, var26, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var33, var1);
               } else {
                  FontRenderer var22 = Fonts.b[14];
                  String var23 = this.a(EmoteManager.a().a(var20), 12);
                  Color var24 = var27 == this.m ? new Color(255, 255, 255) : new Color(223, 223, 243);
                  var22.b(var23, var31, var32 - var22.b(var23) / 2.0F, var24, var1);
               }
            }

            String var28 = this.m >= 0 ? EmoteManager.a().a(this.j.get(this.m)) : "Выбери эмоцию";
            Fonts.b[18].b(var28, var4, var5 - var8 - 18.0F, new Color(255, 255, 255), var1);
         }

         ScaleUtils.a();
      }
   }

   private String a(String var1, int var2) {
      return var1.length() <= var2 ? var1 : var1.substring(0, var2 - 1) + "…";
   }

   static {
      NativeMethodLookup.lookup(EmoteHandler.class, 24);
   }
}
