package pulse.services.tracker.v2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class DeltaFlushTask implements Runnable {
   private final TabSyncManager a;

   public DeltaFlushTask(TabSyncManager var1) {
      this.a = var1;
   }

   @Override
   public void run() {
      this.a.i();
   }
}
