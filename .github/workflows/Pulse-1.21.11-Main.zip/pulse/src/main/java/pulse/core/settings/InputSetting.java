package pulse.core.settings;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class InputSetting extends Setting<String> {
   private final InputSetting.InputType a;
   private final String b;
   private Integer c;
   private Integer d;

   public InputSetting(String var1, String var2, InputSetting.InputType var3, String var4, String var5) {
      super(var1, var2, var4);
      this.a = var3;
      this.b = var5;
   }

   public InputSetting(String var1, InputSetting.InputType var2, String var3, String var4) {
      this(var1, "", var2, var3, var4);
   }

   public InputSetting(String var1, String var2) {
      this(var1, "", InputSetting.InputType.a, var2, "");
   }

   public InputSetting(String var1, InputSetting.InputType var2, String var3) {
      this(var1, "", var2, var3, "");
   }

   public InputSetting a(int var1, int var2) {
      this.c = var1;
      this.d = var2;
      return this;
   }

   public boolean e() {
      return this.c != null && this.d != null;
   }

   public int f() {
      return this.c;
   }

   public int g() {
      return this.d;
   }

   public int h() {
      int var1 = this.c != null ? this.c : Integer.MIN_VALUE;
      int var2 = this.d != null ? this.d : Integer.MAX_VALUE;

      try {
         long var3 = Long.parseLong(this.q().trim());
         return (int)Math.max((long)var1, Math.min((long)var2, var3));
      } catch (Exception var5) {
         return this.c != null ? this.c : 0;
      }
   }

   public void a(String var1) {
      super.a(this.c(var1));
   }

   private String c(String var1) {
      if (this.e() && var1 != null && !var1.isEmpty()) {
         try {
            long var2 = Long.parseLong(var1.trim());
            return String.valueOf(Math.max((long)this.c.intValue(), Math.min((long)this.d.intValue(), var2)));
         } catch (NumberFormatException var4) {
            return String.valueOf(this.c);
         }
      } else {
         return var1;
      }
   }

   public String i() {
      return this.q();
   }

   public void b(String var1) {
      this.a(var1);
   }

   public InputSetting.InputType j() {
      return this.a;
   }

   public String k() {
      return this.b;
   }

   public boolean c() {
      return this.q() == null || this.q().isEmpty();
   }

   public InputSetting c(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.c(var1);
   }

   @Environment(EnvType.CLIENT)
   public static enum InputType {
      a,
      b,
      c,
      d,
      e;

      private static InputSetting.InputType[] a() {
         return new InputSetting.InputType[]{a, b, c, d, e};
      }
   }
}
