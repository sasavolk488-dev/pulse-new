package pulse.core.handler.impl.autoevent.parser;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Formatting;
import pulse.core.handler.impl.autoevent.AutoEventHandler;
import pulse.core.handler.impl.autoevent.EventConfig;
import pulse.core.handler.impl.autoevent.ServerEventParser;
import pulse.core.api.IMinecraft;
import pulse.utils.game.ChatUtils;

@Environment(EnvType.CLIENT)
public class FillCubeEventParser implements IMinecraft, ServerEventParser {
   private static final Set<String> a = Collections.unmodifiableSet(
      new HashSet<>(Arrays.asList("дерево мудрости", "пиратский корабль", "пороховой карьер", "павший самурай", "экскалибур"))
   );
   private static final Pattern b = Pattern.compile("\\[([^\\]]+)\\]");
   private static final Pattern c = Pattern.compile("на карте активен ивент (.+?),");
   private static final Pattern f = Pattern.compile("координаты: x:(-?\\d+) y:(-?\\d+) z:(-?\\d+)");
   private static final Pattern g = Pattern.compile("\\[(.+?)\\]");
   private static final Pattern h = Pattern.compile("координаты:\\s*(-?\\d+);\\s*(-?\\d+);\\s*(-?\\d+)");
   private static final Pattern i = Pattern.compile("начало через (\\d+) минут\\w*");
   private static final Map<String, EventConfig> j;
   private String k = "";
   private int l = -1;

   @Override
   public boolean a(String var1) {
      return var1 == null ? false : var1.toLowerCase().contains("fillcube");
   }

   @Override
   public boolean a(String var1, String var2, AutoEventHandler var3) {
      boolean var4 = false;
      if (var1.contains("на карте активен ивент")) {
         this.a(var2, var3);
         var4 = true;
      } else if (var1.contains("следующий ивент:")) {
         this.c(var2);
         var4 = true;
      } else if (var2.contains("║") && var2.contains("координаты:")) {
         this.b(var2, var3);
         var4 = true;
      } else if (this.b(var1) && !var2.equals(this.k) && d.player != null && d.player.age != this.l) {
         this.k = var2;
         this.l = d.player.age;
         ChatUtils.a("events");
      }

      return var4;
   }

   private boolean b(String var1) {
      Matcher var2 = b.matcher(var1);

      while (var2.find()) {
         String var3 = var2.group(1).toLowerCase().trim();
         if (a.contains(var3)) {
            return true;
         }
      }

      return false;
   }

   private void a(String var1, AutoEventHandler var2) {
      String[] var3 = var1.split("\\n");
      String var4 = null;
      int[] var5 = null;

      for (String var9 : var3) {
         var9 = Formatting.strip(var9).trim().toLowerCase();
         if (var9.contains("на карте активен ивент")) {
            Matcher var10 = c.matcher(var9);
            if (var10.find()) {
               var4 = var10.group(1).trim();
            }
         }

         if (var9.contains("координаты:")) {
            Matcher var15 = f.matcher(var9);
            if (var15.find()) {
               int var11 = Integer.parseInt(var15.group(1));
               int var12 = Integer.parseInt(var15.group(2));
               int var13 = Integer.parseInt(var15.group(3));
               var5 = new int[]{var11, var12, var13};
            }
         }
      }

      if (var4 != null && var5 != null && a.contains(var4)) {
         var2.a(var4, var5, 0);
         var2.a(this.d(var4), null);
      }
   }

   private void c(String var1) {
   }

   private String d(String var1) {
      return var1 != null && !var1.isEmpty() ? var1.substring(0, 1).toUpperCase() + var1.substring(1) : var1;
   }

   private void b(String var1, AutoEventHandler var2) {
      String[] var3 = var1.split("\\n");
      String var4 = null;
      int[] var5 = null;
      int var6 = 0;

      for (String var10 : var3) {
         var10 = Formatting.strip(var10).trim();
         if (var10.contains("[") && var10.contains("]")) {
            Matcher var11 = g.matcher(var10);
            if (var11.find()) {
               String var12 = var11.group(1).toLowerCase();

               for (String var14 : a) {
                  if (var12.equals(var14)) {
                     var4 = var14;
                     break;
                  }
               }
            }
         }

         if (var10.toLowerCase().contains("координаты:")) {
            Matcher var16 = h.matcher(var10);
            if (var16.find()) {
               int var18 = Integer.parseInt(var16.group(1));
               int var19 = Integer.parseInt(var16.group(2));
               int var20 = Integer.parseInt(var16.group(3));
               var5 = new int[]{var18, var19, var20};
            }
         }

         if (var10.toLowerCase().contains("начало через")) {
            Matcher var17 = i.matcher(var10.toLowerCase());
            if (var17.find()) {
               var6 = Integer.parseInt(var17.group(1)) * 60;
            }
         }
      }

      if (var4 != null && var5 != null) {
         var2.a(var4, var5, var6);
         var2.a(this.d(var4), null);
      }
   }

   @Override
   public Set<String> a() {
      return a;
   }

   @Override
   public Map<String, EventConfig> b() {
      return j;
   }

   @Override
   public String c() {
      return "/events";
   }

   static {
      HashMap var0 = new HashMap();
      var0.put("дерево мудрости", new EventConfig(new Color(34, 139, 34)));
      var0.put("пиратский корабль", new EventConfig(new Color(139, 69, 19)));
      var0.put("пороховой карьер", new EventConfig(new Color(105, 105, 105)));
      var0.put("павший самурай", new EventConfig(new Color(220, 20, 60)));
      var0.put("экскалибур", new EventConfig(new Color(255, 215, 0)));
      j = Collections.unmodifiableMap(var0);
   }
}
