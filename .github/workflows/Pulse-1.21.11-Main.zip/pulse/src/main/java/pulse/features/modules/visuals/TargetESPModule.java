package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.RenderEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.utils.render.world.TrailHistory;
import pulse.utils.render.world.TrailLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;
import pulse.utils.game.EntityUtils;
import pulse.utils.render.RenderUtils;

@ModuleInfo(
   a = "Target ESP",
   b = "Отображает ESP вокруг цели",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class TargetESPModule extends Module {
   private final ModeSetting a = new ModeSetting("Режим", new String[]{"Призраки", "Круг", "Квадратик", "Орбита", "Кольца", "Ленты"}, "Орбита");
   private final SeparatorSetting b = new SeparatorSetting("Кольца").a(() -> this.a.b("Кольца"));
   private final NumberSetting c = new NumberSetting("Дальность", 64.0F, 16.0F, 160.0F, 4.0F).a(() -> this.a.b("Кольца"));
   private final NumberSetting f = new NumberSetting("Шаг колец", 12.0F, 4.0F, 32.0F, 1.0F).a(() -> this.a.b("Кольца"));
   private final NumberSetting g = new NumberSetting("Толщина", 5.0F, 1.0F, 12.0F, 0.5F).a(() -> this.a.b("Кольца"));
   private final NumberSetting h = new NumberSetting("Скорость", 24.0F, 4.0F, 64.0F, 1.0F).a(() -> this.a.b("Кольца"));
   private final SeparatorSetting i = new SeparatorSetting("Призраки").a(() -> this.a.b("Призраки"));
   private final NumberSetting j = new NumberSetting("Скорость анимации", 1.5F, 0.5F, 5.0F, 0.1F).a(() -> this.a.b("Призраки"));
   private final NumberSetting k = new NumberSetting("Размер частиц", 0.25F, 0.05F, 0.5F, 0.01F).a(() -> this.a.b("Призраки"));
   private final NumberSetting l = new NumberSetting("Количество призраков", 4.0F, 2.0F, 6.0F, 1.0F).a(() -> this.a.b("Призраки"));
   private final SeparatorSetting m = new SeparatorSetting("Круг").a(() -> this.a.b("Круг"));
   private final NumberSetting n = new NumberSetting("Скорость анимации", 1.5F, 0.5F, 5.0F, 0.1F).a(() -> this.a.b("Круг"));
   private final SeparatorSetting o = new SeparatorSetting("Квадратик").a(() -> this.a.b("Квадратик"));
   private final NumberSetting p = new NumberSetting("Скорость анимации", 2.5F, 0.5F, 5.0F, 0.1F).a(() -> this.a.b("Квадратик"));
   private final NumberSetting q = new NumberSetting("Размер квадратика", 1.4F, 0.5F, 2.0F, 0.1F).a(() -> this.a.b("Квадратик"));
   private final SeparatorSetting r = new SeparatorSetting("Орбита").a(() -> this.a.b("Орбита"));
   private final ModeSetting s = new ModeSetting("Форма", new String[]{"Стрелки", "Ромбы", "Кубы"}, "Стрелки").a(() -> this.a.b("Орбита"));
   private final NumberSetting t = new NumberSetting("Скорость анимации", 1.5F, 0.5F, 5.0F, 0.1F).a(() -> this.a.b("Орбита"));
   private final NumberSetting u = new NumberSetting("Фигур по кругу", 3.0F, 2.0F, 8.0F, 1.0F).a(() -> this.a.b("Орбита"));
   private final NumberSetting v = new NumberSetting("Слоёв по высоте", 3.0F, 2.0F, 5.0F, 1.0F).a(() -> this.a.b("Орбита"));
   private final NumberSetting w = new NumberSetting("Отступ между слоями", 1.0F, 0.3F, 2.0F, 0.05F).a(() -> this.a.b("Орбита"));
   private final NumberSetting x = new NumberSetting("Дистанция", 0.9F, 0.5F, 2.0F, 0.05F).a(() -> this.a.b("Орбита"));
   private final NumberSetting y = new NumberSetting("Размер фигур", 0.2F, 0.08F, 0.4F, 0.01F).a(() -> this.a.b("Орбита"));
   private final BooleanSetting z = new BooleanSetting("Вращение", true).a(() -> this.a.b("Орбита"));
   private final BooleanSetting A = new BooleanSetting("Шейдер", true).a(() -> this.a.b("Орбита"));
   private final ModeSetting B = new ModeSetting("Тип шейдера", new String[]{"Небула", "Звёзды", "Паутина", "Плазма"}, "Небула")
      .a(() -> this.a.b("Орбита") && this.A.a());
   private final BooleanSetting C = new BooleanSetting("Свечение", true).a(() -> this.a.b("Орбита"));
   private final NumberSetting D = new NumberSetting("Размер свечения", 0.85F, 0.1F, 1.0F, 0.05F).a(() -> this.a.b("Орбита") && this.C.a());
   private final NumberSetting E = new NumberSetting("Прозрачность свечения", 0.25F, 0.1F, 1.0F, 0.05F).a(() -> this.a.b("Орбита") && this.C.a());
   private final SeparatorSetting F = new SeparatorSetting("Ленты").a(() -> this.a.b("Ленты"));
   private final NumberSetting G = new NumberSetting("Количество лент", 3.0F, 1.0F, 4.0F, 1.0F).a(() -> this.a.b("Ленты"));
   private final NumberSetting H = new NumberSetting("Длина", 0.6F, 0.2F, 1.2F, 0.05F).a(() -> this.a.b("Ленты"));
   private final NumberSetting I = new NumberSetting("Скорость вращения", 1.0F, 0.2F, 3.0F, 0.1F).a(() -> this.a.b("Ленты"));
   private final NumberSetting J = new NumberSetting("Размер", 0.3F, 0.1F, 0.8F, 0.05F).a(() -> this.a.b("Ленты"));
   private final NumberSetting K = new NumberSetting("Свечение", 40.0F, 0.0F, 100.0F, 5.0F).a(() -> this.a.b("Ленты"));
   private final BooleanSetting L = new BooleanSetting("Хвост за движением", true).a(() -> this.a.b("Ленты"));
   private final SeparatorSetting M = new SeparatorSetting("Цвет");
   private final BooleanSetting N = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting O = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.N.a());
   private final SeparatorSetting P = new SeparatorSetting("При ударе");
   private final BooleanSetting Q = new BooleanSetting("Включить", true);
   private final BooleanSetting R = new BooleanSetting("Изменять цвет", true).a(() -> this.Q.a());
   private final ColorSetting S = new ColorSetting("Цвет урона", new Color(255, 50, 50)).a(() -> this.Q.a() && this.R.a());
   private final BooleanSetting T = new BooleanSetting("Ускорять анимацию", true).a(() -> this.Q.a());
   private final NumberSetting U = new NumberSetting("Множитель ускорения", 3.0F, 1.2F, 5.0F, 0.1F).a(() -> this.Q.a() && this.T.a());
   private final NumberSetting V = new NumberSetting("Длительность эффекта", 0.8F, 0.3F, 2.0F, 0.1F).a(() -> this.Q.a() && this.T.a());
   private static final float[] W = new float[361];
   private static final float[] X = new float[361];
   private static final Vec3d[] Y;
   private final Map<LivingEntity, Animation> Z = new HashMap<>();
   private final Identifier aa = Identifier.of("pulse", "textures/target.png");
   private final Map<LivingEntity, Integer> ab = new HashMap<>();
   private final Map<LivingEntity, Long> ac = new HashMap<>();
   private final Map<LivingEntity, Double> ad = new HashMap<>();
   private final Map<LivingEntity, Double> ae = new HashMap<>();
   private long af = System.currentTimeMillis();
   private final TrailHistory ag = new TrailHistory();
   private LivingEntity ah;
   private final double[] ai = new double[44];
   private final double[] aj = new double[44];
   private final double[] ak = new double[44];
   private int al;
   private float[] am = new float[0];
   private float[] an = new float[0];
   private float[] ao = new float[0];
   private float[] ap = new float[0];
   private float[] aq = new float[0];
   private float[] ar = new float[0];
   private int[] as = new int[0];

   @EventHandler
   public void a(RenderEvent var1) {
      long var2 = System.currentTimeMillis();
      float var4 = (float)(var2 - this.af) / 1000.0F;
      this.af = var2;
      var4 = Math.min(var4, 0.1F);
      LivingEntity var5 = HandlerRegistry.e.h();
      if (var5 != null && this.a(var5)) {
         Animation var6 = this.Z.computeIfAbsent(var5, var0 -> new Animation());
         var6.a(1.0, 0.5, Easings.f, true);
      }

      HashSet<LivingEntity> var14 = new HashSet<>();

      for (Entry var8 : this.Z.entrySet()) {
         LivingEntity var9 = (LivingEntity)var8.getKey();
         if (!this.a(var9)) {
            var14.add(var9);
         } else {
            Animation var10 = (Animation)var8.getValue();
            if (var9 != var5) {
               var10.a(0.0, 0.5, Easings.f, true);
            }

            var10.a();
            if (var10.d() && var10.i() == 0.0) {
               var14.add(var9);
            } else {
               this.a(var9, var4);
               String var11 = this.a.e();
               switch (var11) {
                  case "Призраки":
                     this.b(var1, var9, (float)var10.j());
                     break;
                  case "Круг":
                     this.c(var1, var9, (float)var10.j());
                     break;
                  case "Квадратик":
                     this.a(var1, var9, (float)var10.j());
                     break;
                  case "Орбита":
                     this.d(var1, var9, (float)var10.j());
                     break;
                  case "Ленты":
                     this.e(var1, var9, (float)var10.j());
               }
            }
         }
      }

      for (LivingEntity var16 : var14) {
         this.Z.remove(var16);
         this.ad.remove(var16);
         this.ae.remove(var16);
         this.ab.remove(var16);
         this.ac.remove(var16);
      }
   }

   private void a(LivingEntity var1, float var2) {
      float var3 = this.c(var1);
      double var4 = this.ad.getOrDefault(var1, 0.0);
      var4 += var2 * var3 * 50.0;
      this.ad.put(var1, var4 % 360.0);
      double var6 = this.ae.getOrDefault(var1, 0.0);
      var6 += var2 * var3 * 2.5;
      this.ae.put(var1, var6);
   }

   private boolean a(LivingEntity var1) {
      if (var1 == null) {
         return false;
      } else if (!var1.isAlive()) {
         return false;
      } else if (var1.getEntityWorld() != d.world) {
         return false;
      } else {
         return var1.getWidth() <= 0.0F || var1.getHeight() <= 0.0F ? false : !(var1.squaredDistanceTo(d.player) > 10000.0);
      }
   }

   private void a(RenderEvent var1, LivingEntity var2, float var3) {
      if (!(var3 <= 0.0F) && var2 != null && this.a(var2)) {
         Vec3d var4 = EntityUtils.a(var2, var1.b());
         if (var4 == null) {
            var4 = var2.getLerpedPos(1.0F);
         }

         if (var4 != null) {
            double var5 = this.ad.getOrDefault(var2, 0.0);
            double var7 = this.ae.getOrDefault(var2, 0.0);
            float var9 = this.q.b();
            double var10 = 0.0500000015302267 * Math.sin(var7);
            float var12 = (float)(var9 * (1.0 + var10)) * var3;
            Vec3d var13 = new Vec3d(var4.x, var4.y + var2.getHeight() / 2.0F, var4.z);
            Color var14 = this.b(var2);
            int var15 = ColorUtils.a(var14.getRGB());
            int var16 = Math.max(1, (int)(var3 * 255.0F));
            int var17 = ColorUtils.a(var15, var16);
            RenderUtils.a(var1.a(), var13, var12, var17, this.aa, (float)var5, true);
         }
      }
   }

   private void b(RenderEvent var1, LivingEntity var2, float var3) {
      if (this.a(var2) && !(var3 <= 0.0F)) {
         Vec3d var4 = EntityUtils.a(var2, var1.b());
         if (var4 == null) {
            var4 = var2.getLerpedPos(1.0F);
         }

         if (var4 != null) {
            byte var5 = 15;
            double var6 = 50.0;
            double var8 = Math.toRadians(50.0);
            double var10 = var8 / 15.0;
            int var12 = this.l.c();
            double var13 = this.ae.getOrDefault(var2, 0.0);
            float var15 = Math.max(var2.getWidth(), 0.5F);
            float var16 = Math.max(var2.getHeight(), 0.5F);
            double var17 = var15 + 0.3000000610967008;
            double var19 = var4.y + var16 / 2.0F;
            double var21 = var3;
            int var23 = ColorUtils.a(this.b(var2).getRGB());
            int var24 = Math.max(1, (int)(var21 * 150.0));
            int var25 = ColorUtils.a(var23, var24);
            float var26 = this.k.b();

            for (int var27 = 0; var27 < var12; var27++) {
               double var28 = var13 + var27 * 3.141592895733897 / 2.0;
               Vec3d var30 = Y[var27];
               double var31 = 0.0;
               double var33 = 1.0;
               double var35 = 0.0;
               if (Math.abs(var30.y) > 0.9900000244327833) {
                  var31 = 1.0;
                  var33 = 0.0;
               }

               double var37 = var30.y * var35 - var30.z * var33;
               double var39 = var30.z * var31 - var30.x * var35;
               double var41 = var30.x * var33 - var30.y * var31;
               double var43 = Math.sqrt(var37 * var37 + var39 * var39 + var41 * var41);
               var37 /= var43;
               var39 /= var43;
               var41 /= var43;
               double var45 = var30.y * var41 - var30.z * var39;
               double var47 = var30.z * var37 - var30.x * var41;
               double var49 = var30.x * var39 - var30.y * var37;
               double var51 = Math.sqrt(var45 * var45 + var47 * var47 + var49 * var49);
               var45 /= var51;
               var47 /= var51;
               var49 /= var51;

               for (int var53 = 0; var53 < 15; var53++) {
                  double var54 = var53 * var10 + var28;
                  double var56 = Math.cos(var54);
                  double var58 = Math.sin(var54);
                  double var60 = (var37 * var56 + var45 * var58) * var17;
                  double var62 = (var39 * var56 + var47 * var58) * var17;
                  double var64 = (var41 * var56 + var49 * var58) * var17;
                  float var66 = var26 * (1.0F + var53 / 15.0F);

                  try {
                     RenderUtils.a(var1.a(), new Vec3d(var4.x + var60, var19 + var62, var4.z + var64), var66, var25);
                  } catch (Exception var68) {
                  }
               }
            }
         }
      }
   }

   private void c(RenderEvent var1, LivingEntity var2, float var3) {
      if (!(var3 <= 0.0F) && var2 != null && this.a(var2)) {
         float var4 = var2.getWidth() * 0.7F;
         Vec3d var5 = EntityUtils.a(var2, var1.b());
         if (var5 == null) {
            var5 = var2.getLerpedPos(1.0F);
         }

         double var6 = this.ae.getOrDefault(var2, 0.0);
         double var8 = 6.283185895793643;
         double var10 = var6 % var8;
         double var12 = var8 / 2.0;
         boolean var14 = var10 > var12;
         double var15 = var10 / var12;
         var15 = var14 ? var15 - 1.0 : 1.0 - var15;
         var15 = var15 < 0.5 ? 2.0 * var15 * var15 : 1.0 - Math.pow(-2.0 * var15 + 2.0, 2.0) / 2.0;
         double var17 = var2.getHeight() / 2.0F * (var15 > 0.5 ? 1.0 - var15 : var15) * (var14 ? -1 : 1);
         MatrixStack var19 = var1.a();
         Vec3d var20 = d.gameRenderer.getCamera().getCameraPos();
         Color var21 = this.b(var2);
         var19.push();
         float var22 = var21.getRed() / 255.0F;
         float var23 = var21.getGreen() / 255.0F;
         float var24 = var21.getBlue() / 255.0F;
         float var25 = 0.39215687F * var3;
         float var26 = var3;
         float var27 = (float)(var5.y + var2.getHeight() * var15 - var20.y);
         float var28 = (float)(var5.y + var2.getHeight() * var15 + var17 - var20.y);
         float var29 = (float)var20.x;
         float var30 = (float)var20.z;
         float var31 = (float)var5.x;
         float var32 = (float)var5.z;
         Immediate var33 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer var34 = var33.getBuffer(BlockOverlayLayers.f);
         net.minecraft.client.util.math.MatrixStack.Entry var35 = var19.peek();

         for (int var36 = 0; var36 < 360; var36++) {
            float var37 = var31 + X[var36] * var4 - var29;
            float var38 = var32 + W[var36] * var4 - var30;
            float var39 = var31 + X[var36 + 1] * var4 - var29;
            float var40 = var32 + W[var36 + 1] * var4 - var30;
            var34.vertex(var35, var37, var27, var38).color(var22, var23, var24, var25).normal(var35, 0.0F, 1.0F, 0.0F);
            var34.vertex(var35, var37, var28, var38).color(var22, var23, var24, 0.0F).normal(var35, 0.0F, 1.0F, 0.0F);
            var34.vertex(var35, var39, var28, var40).color(var22, var23, var24, 0.0F).normal(var35, 0.0F, 1.0F, 0.0F);
            var34.vertex(var35, var37, var27, var38).color(var22, var23, var24, var25).normal(var35, 0.0F, 1.0F, 0.0F);
            var34.vertex(var35, var39, var28, var40).color(var22, var23, var24, 0.0F).normal(var35, 0.0F, 1.0F, 0.0F);
            var34.vertex(var35, var39, var27, var40).color(var22, var23, var24, var25).normal(var35, 0.0F, 1.0F, 0.0F);
         }

         VertexConsumer var46 = var33.getBuffer(BlockOverlayLayers.h);

         for (int var47 = 0; var47 < 360; var47++) {
            float var48 = var31 + X[var47] * var4 - var29;
            float var49 = var32 + W[var47] * var4 - var30;
            float var50 = var31 + X[var47 + 1] * var4 - var29;
            float var41 = var32 + W[var47 + 1] * var4 - var30;
            float var42 = -W[var47];
            float var43 = X[var47];
            var46.vertex(var35, var48, var27, var49).color(var22, var23, var24, var26).normal(var35, var42, 0.0F, var43).lineWidth(2.0F);
            var46.vertex(var35, var50, var27, var41).color(var22, var23, var24, var26).normal(var35, var42, 0.0F, var43).lineWidth(2.0F);
         }

         var33.draw(BlockOverlayLayers.h);
         var33.draw(BlockOverlayLayers.f);
         var19.pop();
      }
   }

   private void d(RenderEvent var1, LivingEntity var2, float var3) {
      if (!(var3 <= 0.0F) && this.a(var2)) {
         Vec3d var4 = EntityUtils.a(var2, var1.b());
         if (var4 == null) {
            var4 = var2.getLerpedPos(1.0F);
         }

         if (var4 != null) {
            MatrixStack var5 = var1.a();
            Vec3d var6 = d.gameRenderer.getCamera().getCameraPos();
            Color var7 = this.b(var2);
            int var8 = this.u.c();
            int var9 = this.v.c();
            float var10 = this.x.b() + var2.getWidth() / 2.0F;
            float var11 = this.y.b() * var3;
            float var12 = var2.getHeight();
            Vec3d var13 = new Vec3d(var4.x, var4.y + var12 / 2.0F, var4.z);
            double var14 = 0.0;
            if (this.z.a()) {
               var14 = this.ad.getOrDefault(var2, 0.0);
            }

            double var16 = this.ae.getOrDefault(var2, 0.0);
            double var18 = Math.sin(var16) * 0.08000002625566278;
            float var20 = (float)(var10 + var18);
            boolean var21 = false;
            String var22 = this.s.e();
            float var23 = (var9 - 1) / 2.0F;
            float var24 = this.w.b();
            float var25 = var12 * var24;
            float var26 = (var12 - var25) / 2.0F;
            if (this.C.a()) {
               float var27 = this.D.b();
               int var28 = (int)(var3 * 255.0F * this.E.b());
               int var29 = ColorUtils.a(ColorUtils.a(var7.getRGB()), var28);

               for (int var30 = 0; var30 < var9; var30++) {
                  float var31 = var26 + var25 * var30 / (var9 - 1);
                  float var32 = (float)(var4.y + var31);
                  float var33 = Math.abs(var30 - var23) / Math.max(var23, 0.001F);
                  float var34 = 1.0F - var33 * 0.3F;
                  float var35 = var20 * var34;
                  double var36 = 360.0 / var8 / 2.0 * (var30 % 2);

                  for (int var38 = 0; var38 < var8; var38++) {
                     double var39 = Math.toRadians(var14 + var36 + 360.0 * var38 / var8);
                     float var41 = (float)(var13.x + var35 * Math.cos(var39));
                     float var42 = (float)(var13.z + var35 * Math.sin(var39));
                     float var43 = var41;
                     float var44 = var32;
                     float var45 = var42;
                     if (var22.equals("Стрелки")) {
                        double var46 = var13.x - var41;
                        double var48 = var13.y - var32;
                        double var50 = var13.z - var42;
                        double var52 = Math.sqrt(var46 * var46 + var48 * var48 + var50 * var50);
                        if (var52 > 9.99999658950374E-4) {
                           var46 /= var52;
                           var48 /= var52;
                           var50 /= var52;
                        }

                        float var54 = var11 * 0.75F;
                        var43 = (float)(var41 + var46 * var54);
                        var44 = (float)(var32 + var48 * var54);
                        var45 = (float)(var42 + var50 * var54);
                     }

                     Vec3d var83 = new Vec3d(var43, var44, var45);
                     RenderUtils.a(var5, var83, var27, var29);
                  }
               }
            }

            var5.push();
            Matrix4f var66 = var5.peek().getPositionMatrix();

            for (int var67 = 0; var67 < var9; var67++) {
               float var69 = var26 + var25 * var67 / (var9 - 1);
               float var70 = (float)(var4.y + var69);
               float var71 = Math.abs(var67 - var23) / Math.max(var23, 0.001F);
               float var72 = 1.0F - var71 * 0.3F;
               float var73 = var20 * var72;
               double var74 = 360.0 / var8 / 2.0 * (var67 % 2);

               for (int var75 = 0; var75 < var8; var75++) {
                  double var37 = Math.toRadians(var14 + var74 + 360.0 * var75 / var8);
                  float var76 = (float)(var13.x + var73 * Math.cos(var37));
                  float var40 = (float)(var13.z + var73 * Math.sin(var37));
                  double var77 = var13.x - var76;
                  double var79 = var13.y - var70;
                  double var81 = var13.z - var40;
                  double var47 = Math.sqrt(var77 * var77 + var79 * var79 + var81 * var81);
                  var77 /= var47;
                  var79 /= var47;
                  var81 /= var47;
                  double var49 = 0.0;
                  double var51 = 1.0;
                  double var53 = 0.0;
                  double var55 = var79 * var53 - var81 * var51;
                  double var57 = var81 * var49 - var77 * var53;
                  double var59 = var77 * var51 - var79 * var49;
                  double var61 = Math.sqrt(var55 * var55 + var57 * var57 + var59 * var59);
                  if (var61 > 9.99999658950374E-4) {
                     var55 /= var61;
                     var57 /= var61;
                     var59 /= var61;
                  }

                  var49 = var57 * var81 - var59 * var79;
                  var51 = var59 * var77 - var55 * var81;
                  var53 = var55 * var79 - var57 * var77;
                  int var63 = (int)(var3 * 220.0F);
                  switch (var22) {
                     case "Стрелки":
                        this.a(var5, var6, var7, var21, var76, var70, var40, var77, var79, var81, var49, var51, var53, var55, var57, var59, var11, var63);
                        break;
                     case "Ромбы":
                        this.b(var5, var6, var7, var21, var76, var70, var40, var77, var79, var81, var49, var51, var53, var55, var57, var59, var11, var63);
                        break;
                     case "Кубы":
                        this.a(var5, var6, var7, var21, var76, var70, var40, var49, var51, var53, var55, var57, var59, var11, var63);
                  }
               }
            }

            Immediate var68 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
            var68.draw(BlockOverlayLayers.f);
            var5.pop();
         }
      }
   }

   private void a(
      MatrixStack var1,
      Vec3d var2,
      Color var3,
      boolean var4,
      float var5,
      float var6,
      float var7,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      double var20,
      double var22,
      double var24,
      float var26,
      int var27
   ) {
      float var28 = (float)(var5 + var8 * var26 * 1.5 - var2.x);
      float var29 = (float)(var6 + var10 * var26 * 1.5 - var2.y);
      float var30 = (float)(var7 + var12 * var26 * 1.5 - var2.z);
      float var31 = var26 * 0.5F;
      float var32 = (float)(var5 + var14 * var31 - var2.x);
      float var33 = (float)(var6 + var16 * var31 - var2.y);
      float var34 = (float)(var7 + var18 * var31 - var2.z);
      float var35 = (float)(var5 - var14 * var31 - var2.x);
      float var36 = (float)(var6 - var16 * var31 - var2.y);
      float var37 = (float)(var7 - var18 * var31 - var2.z);
      float var38 = (float)(var5 + var20 * var31 - var2.x);
      float var39 = (float)(var6 + var22 * var31 - var2.y);
      float var40 = (float)(var7 + var24 * var31 - var2.z);
      float var41 = (float)(var5 - var20 * var31 - var2.x);
      float var42 = (float)(var6 - var22 * var31 - var2.y);
      float var43 = (float)(var7 - var24 * var31 - var2.z);
      this.a(var1, var3, var4, var28, var29, var30, var32, var33, var34, var35, var36, var37, var38, var39, var40, var41, var42, var43, var27);
   }

   private void b(
      MatrixStack var1,
      Vec3d var2,
      Color var3,
      boolean var4,
      float var5,
      float var6,
      float var7,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      double var20,
      double var22,
      double var24,
      float var26,
      int var27
   ) {
      double var28 = var16 * var24 - var18 * var22;
      double var30 = var18 * var20 - var14 * var24;
      double var32 = var14 * var22 - var16 * var20;
      float var34 = (float)(var5 + var14 * var26 * 1.2000001195824168 - var2.x);
      float var35 = (float)(var6 + var16 * var26 * 1.2000001195824168 - var2.y);
      float var36 = (float)(var7 + var18 * var26 * 1.2000001195824168 - var2.z);
      float var37 = (float)(var5 - var14 * var26 * 1.2000001195824168 - var2.x);
      float var38 = (float)(var6 - var16 * var26 * 1.2000001195824168 - var2.y);
      float var39 = (float)(var7 - var18 * var26 * 1.2000001195824168 - var2.z);
      float var40 = var26 * 0.6F;
      float var41 = (float)(var5 + var20 * var40 + var28 * var40 - var2.x);
      float var42 = (float)(var6 + var22 * var40 + var30 * var40 - var2.y);
      float var43 = (float)(var7 + var24 * var40 + var32 * var40 - var2.z);
      float var44 = (float)(var5 + var20 * var40 - var28 * var40 - var2.x);
      float var45 = (float)(var6 + var22 * var40 - var30 * var40 - var2.y);
      float var46 = (float)(var7 + var24 * var40 - var32 * var40 - var2.z);
      float var47 = (float)(var5 - var20 * var40 - var28 * var40 - var2.x);
      float var48 = (float)(var6 - var22 * var40 - var30 * var40 - var2.y);
      float var49 = (float)(var7 - var24 * var40 - var32 * var40 - var2.z);
      float var50 = (float)(var5 - var20 * var40 + var28 * var40 - var2.x);
      float var51 = (float)(var6 - var22 * var40 + var30 * var40 - var2.y);
      float var52 = (float)(var7 - var24 * var40 + var32 * var40 - var2.z);
      this.a(var1, var3, var4, var34, var35, var36, var41, var42, var43, var44, var45, var46, var27);
      this.a(var1, var3, var4, var34, var35, var36, var44, var45, var46, var47, var48, var49, var27);
      this.a(var1, var3, var4, var34, var35, var36, var47, var48, var49, var50, var51, var52, var27);
      this.a(var1, var3, var4, var34, var35, var36, var50, var51, var52, var41, var42, var43, var27);
      this.a(var1, var3, var4, var37, var38, var39, var44, var45, var46, var41, var42, var43, var27);
      this.a(var1, var3, var4, var37, var38, var39, var47, var48, var49, var44, var45, var46, var27);
      this.a(var1, var3, var4, var37, var38, var39, var50, var51, var52, var47, var48, var49, var27);
      this.a(var1, var3, var4, var37, var38, var39, var41, var42, var43, var50, var51, var52, var27);
   }

   private void a(
      MatrixStack var1,
      Vec3d var2,
      Color var3,
      boolean var4,
      float var5,
      float var6,
      float var7,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      float var20,
      int var21
   ) {
      float var22 = var20 * 0.5F;
      double var23 = var10 * var18 - var12 * var16;
      double var25 = var12 * var14 - var8 * var18;
      double var27 = var8 * var16 - var10 * var14;
      float[][] var29 = new float[8][3];
      int var30 = 0;

      for (byte var31 = -1; var31 <= 1; var31 += 2) {
         for (byte var32 = -1; var32 <= 1; var32 += 2) {
            for (byte var33 = -1; var33 <= 1; var33 += 2) {
               var29[var30][0] = (float)(var5 + var8 * var22 * var31 + var14 * var22 * var32 + var23 * var22 * var33 - var2.x);
               var29[var30][1] = (float)(var6 + var10 * var22 * var31 + var16 * var22 * var32 + var25 * var22 * var33 - var2.y);
               var29[var30][2] = (float)(var7 + var12 * var22 * var31 + var18 * var22 * var32 + var27 * var22 * var33 - var2.z);
               var30++;
            }
         }
      }

      int[][] var36 = new int[][]{{0, 1, 3, 2}, {4, 6, 7, 5}, {0, 4, 5, 1}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 5, 7, 3}};

      for (int[] var35 : var36) {
         this.a(
            var1,
            var3,
            var4,
            var29[var35[0]][0],
            var29[var35[0]][1],
            var29[var35[0]][2],
            var29[var35[1]][0],
            var29[var35[1]][1],
            var29[var35[1]][2],
            var29[var35[2]][0],
            var29[var35[2]][1],
            var29[var35[2]][2],
            var21
         );
         this.a(
            var1,
            var3,
            var4,
            var29[var35[0]][0],
            var29[var35[0]][1],
            var29[var35[0]][2],
            var29[var35[2]][0],
            var29[var35[2]][1],
            var29[var35[2]][2],
            var29[var35[3]][0],
            var29[var35[3]][1],
            var29[var35[3]][2],
            var21
         );
      }
   }

   private void a(
      MatrixStack var1,
      Color var2,
      boolean var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      int var13
   ) {
      Immediate var14 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
      VertexConsumer var15 = var14.getBuffer(BlockOverlayLayers.f);
      net.minecraft.client.util.math.MatrixStack.Entry var16 = var1.peek();
      int var17 = var2.getRed();
      int var18 = var2.getGreen();
      int var19 = var2.getBlue();
      int var21 = var13 * 3 / 4;
      var15.vertex(var16, var4, var5, var6).color(var17, var18, var19, var13);
      var15.vertex(var16, var7, var8, var9).color(var17, var18, var19, var21);
      var15.vertex(var16, var10, var11, var12).color(var17, var18, var19, var21);
   }

   private void a(
      MatrixStack var1,
      Color var2,
      boolean var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17,
      float var18,
      int var19
   ) {
      this.a(var1, var2, var3, var4, var5, var6, var7, var8, var9, var13, var14, var15, var19);
      this.a(var1, var2, var3, var4, var5, var6, var13, var14, var15, var10, var11, var12, var19);
      this.a(var1, var2, var3, var4, var5, var6, var10, var11, var12, var16, var17, var18, var19);
      this.a(var1, var2, var3, var4, var5, var6, var16, var17, var18, var7, var8, var9, var19);
   }

   private void e(RenderEvent var1, LivingEntity var2, float var3) {
      if (!(var3 <= 0.0F) && this.a(var2)) {
         LivingEntity var4 = HandlerRegistry.e.h();
         if (var4 == null || !this.a(var4)) {
            var4 = this.w();
         }

         if (var2 == var4) {
            Vec3d var5 = d.gameRenderer.getCamera().getCameraPos();
            this.a(var2, var1.b(), var5, var3);
            net.minecraft.client.util.math.MatrixStack.Entry var6 = var1.a().peek();
            Immediate var7 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
            VertexConsumer var8 = var7.getBuffer(TrailLayers.d);
            float var9 = this.K.b();
            if (var9 >= 1.0F) {
               float var10 = var9 / 100.0F;
               this.a(var8, var6, 1.0F + 5.0F * var10, 0.09F * var10);
               this.a(var8, var6, 1.0F + 2.5F * var10, 0.14F * var10);
            }

            this.a(var8, var6, 1.5F, 0.2F);
            this.a(var8, var6, 1.0F, 0.75F);
            var7.draw(TrailLayers.d);
         }
      }
   }

   private void a(LivingEntity var1, float var2, Vec3d var3, float var4) {
      this.al = Math.max(this.G.c(), 1);
      int var5 = this.al * 44;
      if (this.as.length < var5) {
         this.am = new float[var5];
         this.an = new float[var5];
         this.ao = new float[var5];
         this.ap = new float[var5];
         this.aq = new float[var5];
         this.ar = new float[var5];
         this.as = new int[var5];
      }

      double var6 = System.currentTimeMillis() % 86400000L * 9.99999658950374E-4;
      if (var1 != this.ah) {
         this.ag.a();
         this.ah = var1;
      }

      Vec3d var8 = EntityUtils.a(var1, var2);
      if (var8 == null) {
         var8 = var1.getEntityPos();
      }

      this.ag.a(var6, var8.x, var8.y, var8.z);
      double var9 = this.H.b();

      for (int var11 = 0; var11 < 44; var11++) {
         this.ag.b(this.L.a() ? var6 - var9 * var11 / 43.0 : var6);
         this.ai[var11] = this.ag.a;
         this.aj[var11] = this.ag.b;
         this.ak[var11] = this.ag.c;
      }

      double var63 = this.I.b();
      double var13 = 6.0 * var63;
      double var15 = var13 * 0.4699998263707552 + 0.8999997637528397;
      float var17 = var1.getWidth() * 0.8F + 0.15F;
      double var18 = var1.getHeight() * 0.5500000238673242;
      double var20 = var1.getHeight() * 0.2800000671266847;
      Color var22 = this.b(var1);
      float[] var23 = Color.RGBtoHSB(var22.getRed(), var22.getGreen(), var22.getBlue(), null);
      float var24 = var23[0] * 360.0F;
      float var25 = var23[1];
      float var26 = var23[2];
      int var27 = var22.getAlpha();
      float var28 = this.J.b() * 0.5F * var4;
      float var29 = this.J.b() * 0.3F * var4;
      float var30 = Math.min((float)(var9 / 0.6000000004775451), 1.0F);

      for (int var31 = 0; var31 < this.al; var31++) {
         int var32 = var31 * 44;
         double var33 = var31 * 0.5500000238673242;
         float var35 = 1.0F + 0.15F * b(var31 * 7 + 1);
         float var36 = 0.7F + 0.45F * b(var31 * 13 + 5);
         float var37 = 0.85F + 0.25F * b(var31 * 5 + 2);
         float var38 = (var31 - (this.al - 1) * 0.5F) * 0.04F;

         for (int var39 = 0; var39 < 44; var39++) {
            float var40 = var39 / 43.0F;
            double var41 = var6 - var9 * var40;
            double var43 = var41 * var13;
            float var45 = (float)Math.cos(var43);
            float var46 = (float)Math.sin(var43);
            double var47 = Math.sin(var41 * var15) * var20;
            float var49 = 0.1F + 0.9F * a(var40 / 0.55F);
            float var50 = var29 * var49 * var37;
            float var51 = (float)(
               0.7200000596652452 * Math.sin(var40 * 10.5 * var35 * var30 - var6 * 6.800002395362118 * var63 + var33)
                  + 0.2800000671266847 * Math.sin(var40 * 23.0 * var30 - var6 * 11.0 * var63 + var33 * 3.1000002919739944)
            );
            float var52 = (float)Math.sin(
               var40 * 6.400000194653936 * var35 * var30 - var6 * 5.199998226800132 * var63 + var33 * 1.700000725073051 + 1.299999532718391
            );
            float var53 = var51 * 0.8F * var50;
            float var54 = var52 * 0.35F * var50 + var38 * var49;
            int var55 = var32 + var39;
            this.am[var55] = (float)(this.ai[var39] + var45 * (var17 + var54) - var3.x);
            this.an[var55] = (float)(this.aj[var39] + var18 + var47 + var53 - var3.y);
            this.ao[var55] = (float)(this.ak[var39] + var46 * (var17 + var54) - var3.z);
            float var56 = a((var40 - 0.45F) / 0.55F);
            float var57 = (float)(0.5 + 0.5 * Math.sin(var40 * 47.0 - var6 * 8.300002885804862 * var63 + var33 * 2.4000004892281264));
            float var58 = Math.min(1.0F, var40 * 14.0F) * (0.9F - 0.45F * var40) * (1.0F - var56 * (0.55F + 0.45F * var57));
            float var59 = var25 * (0.35F + 0.65F * Math.min(1.0F, var40 * 9.0F));
            this.as[var55] = ColorUtils.a(a(var24 + 10.0F * var40, var59, var26), (int)(var27 * var4 * var58));
            float var60 = (0.45F + 0.55F * Math.min(1.0F, var40 * 4.0F)) * (1.0F - a((var40 - 0.5F) / 0.5F) * 0.95F);
            float var61 = (float)(0.6000000004775451 * Math.sin(var40 * 7.300000149017666 * var30 - var6 * 5.399999524156042 * var63 + var33));
            float var62 = var28 * var60 * var36;
            this.ap[var55] = var45 * (float)Math.sin(var61) * var62;
            this.aq[var55] = (float)Math.cos(var61) * var62;
            this.ar[var55] = var46 * (float)Math.sin(var61) * var62;
         }
      }
   }

   private void a(VertexConsumer var1, net.minecraft.client.util.math.MatrixStack.Entry var2, float var3, float var4) {
      for (int var5 = 0; var5 < this.al; var5++) {
         int var6 = var5 * 44;

         for (int var7 = 0; var7 < 43; var7++) {
            int var8 = var6 + var7;
            int var9 = var8 + 1;
            int var10 = a(this.as[var8], var4);
            int var11 = a(this.as[var9], var4);
            int var12 = a(var10, 0.45F);
            int var13 = a(var11, 0.45F);
            var1.vertex(var2, this.am[var8] - this.ap[var8] * var3, this.an[var8] - this.aq[var8] * var3, this.ao[var8] - this.ar[var8] * var3).color(var10);
            var1.vertex(var2, this.am[var8] + this.ap[var8] * var3, this.an[var8] + this.aq[var8] * var3, this.ao[var8] + this.ar[var8] * var3).color(var12);
            var1.vertex(var2, this.am[var9] + this.ap[var9] * var3, this.an[var9] + this.aq[var9] * var3, this.ao[var9] + this.ar[var9] * var3).color(var13);
            var1.vertex(var2, this.am[var9] - this.ap[var9] * var3, this.an[var9] - this.aq[var9] * var3, this.ao[var9] - this.ar[var9] * var3).color(var11);
         }
      }
   }

   private static float b(int var0) {
      float var1 = (float)(Math.sin(var0 * 12.9898F + 1.7F) * 43758.56F);
      return var1 - (float)Math.floor(var1);
   }

   private static float a(float var0) {
      float var1 = Math.max(0.0F, Math.min(1.0F, var0));
      return var1 * var1 * (3.0F - 2.0F * var1);
   }

   private static int a(float var0, float var1, float var2) {
      return Color.HSBtoRGB(var0 / 360.0F, Math.max(0.0F, Math.min(1.0F, var1)), Math.max(0.0F, Math.min(1.0F, var2)));
   }

   private static int a(int var0, float var1) {
      return ColorUtils.a(var0, (int)((var0 >>> 24) * var1));
   }

   private LivingEntity w() {
      LivingEntity var1 = null;
      double var2 = 0.010000000487503427;

      for (Entry var5 : this.Z.entrySet()) {
         if (this.a((LivingEntity)var5.getKey())) {
            double var6 = ((Animation)var5.getValue()).j();
            if (var6 > var2) {
               var2 = var6;
               var1 = (LivingEntity)var5.getKey();
            }
         }
      }

      return var1;
   }

   public boolean n() {
      return this.k() && this.a.b("Кольца") && d.world != null ? this.w() != null : false;
   }

   public boolean a(Entity var1) {
      if (this.k() && this.a.b("Кольца")) {
         if (var1 instanceof LivingEntity var2 && this.a(var2)) {
            Animation var3 = this.Z.get(var2);
            return var3 != null && var3.j() > 0.010000000487503427;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public LivingEntity o() {
      return this.w();
   }

   public float b(Entity var1) {
      if (var1 instanceof LivingEntity var2) {
         Animation var3 = this.Z.get(var2);
         return var3 == null ? 0.0F : (float)var3.j();
      } else {
         return 0.0F;
      }
   }

   public float p() {
      LivingEntity var1 = this.w();
      if (var1 == null) {
         return 0.0F;
      } else {
         Animation var2 = this.Z.get(var1);
         return var2 == null ? 0.0F : (float)var2.j();
      }
   }

   public float q() {
      return this.c.b();
   }

   public float r() {
      return this.f.b();
   }

   public float s() {
      return this.g.b();
   }

   public float t() {
      return this.h.b();
   }

   public Color v() {
      return this.b(this.w());
   }

   private Color b(LivingEntity var1) {
      if (this.Q.a() && this.R.a() && var1 != null && var1.hurtTime > 0) {
         float var2 = var1.hurtTime / 10.0F;
         Color var3 = this.x();
         Color var4 = this.S.a();
         int var5 = (int)(var3.getRed() + (var4.getRed() - var3.getRed()) * var2);
         int var6 = (int)(var3.getGreen() + (var4.getGreen() - var3.getGreen()) * var2);
         int var7 = (int)(var3.getBlue() + (var4.getBlue() - var3.getBlue()) * var2);
         return new Color(Math.max(0, Math.min(255, var5)), Math.max(0, Math.min(255, var6)), Math.max(0, Math.min(255, var7)));
      } else {
         return this.x();
      }
   }

   private Color x() {
      if (this.N.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         if (var1 != null) {
            return var1.n();
         }
      }

      return this.O.a();
   }

   private float y() {
      String var1 = this.a.e();
      switch (var1) {
         case "Призраки":
            return this.j.b();
         case "Круг":
            return this.n.b();
         case "Квадратик":
            return this.p.b();
         case "Орбита":
            return this.t.b();
         default:
            return 1.5F;
      }
   }

   private float c(LivingEntity var1) {
      float var2 = this.y();
      if (this.Q.a() && this.T.a() && var1 != null) {
         int var3 = var1.hurtTime;
         int var4 = this.ab.getOrDefault(var1, 0);
         this.ab.put(var1, var3);
         if (var3 >= 9 && var4 < 9) {
            this.ac.put(var1, System.currentTimeMillis());
         }

         Long var5 = this.ac.get(var1);
         if (var5 == null) {
            return var2;
         } else {
            float var6 = (float)(System.currentTimeMillis() - var5) / 1000.0F;
            float var7 = this.V.b();
            if (var6 > var7) {
               return var2;
            } else {
               float var8 = var6 / var7;
               float var9;
               if (var8 < 0.15F) {
                  float var10 = var8 / 0.15F;
                  var9 = var10 * var10 * (3.0F - 2.0F * var10);
               } else {
                  float var12 = (var8 - 0.15F) / 0.85F;
                  float var11 = 1.0F - var12 * var12 * (3.0F - 2.0F * var12);
                  var9 = var11;
               }

               float var13 = this.U.b();
               return var2 * (1.0F + (var13 - 1.0F) * var9);
            }
         }
      } else {
         return var2;
      }
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.Z.clear();
      this.ab.clear();
      this.ac.clear();
      this.ag.a();
      this.ah = null;
   }

   static {
      NativeMethodLookup.lookup(TargetESPModule.class, 87);

      for (int var0 = 0; var0 <= 360; var0++) {
         double var1 = Math.toRadians(var0);
         W[var0] = (float)Math.sin(var1);
         X[var0] = (float)Math.cos(var1);
      }

      Vec3d[] var3 = new Vec3d[]{
         new Vec3d(1.0, 1.0, 1.0),
         new Vec3d(-1.0, 1.0, -1.0),
         new Vec3d(1.0, -1.0, 1.0),
         new Vec3d(-1.0, -1.0, 1.0),
         new Vec3d(1.0, 1.0, -1.0),
         new Vec3d(-1.0, -1.0, -1.0)
      };
      Y = new Vec3d[var3.length];

      for (int var4 = 0; var4 < var3.length; var4++) {
         Y[var4] = var3[var4].normalize();
      }
   }
}
