package pulse.features.modules.utilities.ft;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import pulse.core.api.IMinecraft;

@Environment(EnvType.CLIENT)
public final class StructureTracker implements IMinecraft {
   public static final long a = 1000L;
   public static final long b = 1500L;
   private static final double c = 24.0;
   private static final double f = 3.0;
   private final Queue<DetectedSound> g = new ConcurrentLinkedQueue<>();
   private final List<DetectedSound> h = new ArrayList<>();
   private final Set<BlockPos> i = new HashSet<>();
   private final List<StructureTracker.Placement> j = new ArrayList<>();

   public void a(PlaySoundS2CPacket var1) {
      if (var1.getCategory() == SoundCategory.RECORDS) {
         Identifier var2 = this.a(var1.getSound());
         if (var2 != null) {
            Vec3d var3 = new Vec3d(var1.getX(), var1.getY(), var1.getZ());
            this.g
               .add(new DetectedSound(var2, var1.getCategory(), var1.getVolume(), var1.getPitch(), var3, BlockPos.ofFloored(var3), System.currentTimeMillis()));
         }
      }
   }

   public void a(boolean var1, boolean var2) {
      long var3 = System.currentTimeMillis();
      if (d.player != null && d.world != null) {
         Vec3d var5 = d.player.getEntityPos();
         double var6 = 576.0;
         this.i.clear();

         DetectedSound var8;
         while ((var8 = this.g.poll()) != null) {
            if (var3 - var8.timestampMs() <= 1000L && !(var5.squaredDistanceTo(var8.pos()) > var6)) {
               this.h.add(var8);
               this.i.add(var8.blockPos());
            }
         }

         long var9 = var3 - 1000L;
         this.h.removeIf(var2x -> var2x.timestampMs() < var9);

         for (BlockPos var12 : this.i) {
            this.a(var12, var3, var1, var2);
         }

         this.i.clear();
         long var13 = var3 - 1500L;
         this.j.removeIf(var2x -> var2x.timeMs() < var13);
      } else {
         this.a();
      }
   }

   public StructureTracker.Placement a(FunTimeItemType var1, Vec3d var2, double var3, long var5, long var7) {
      StructureTracker.Placement var9 = null;
      double var10 = 0.0;
      boolean var12 = false;
      double var13 = var3 * var3;

      for (StructureTracker.Placement var16 : this.j) {
         if (var5 - var16.timeMs() <= var7) {
            double var17 = Vec3d.ofCenter(var16.blockPos()).squaredDistanceTo(var2);
            if (!(var17 > var13)) {
               boolean var19 = var16.type() == var1;
               if (var9 == null || var19 && !var12 || var19 == var12 && var17 < var10) {
                  var9 = var16;
                  var10 = var17;
                  var12 = var19;
               }
            }
         }
      }

      if (var9 != null) {
         this.j.remove(var9);
      }

      return var9;
   }

   public void a() {
      this.g.clear();
      this.h.clear();
      this.i.clear();
      this.j.clear();
   }

   private void a(BlockPos var1, long var2, boolean var4, boolean var5) {
      ArrayList var6 = new ArrayList<>(4);

      for (DetectedSound var8 : this.h) {
         if (var8.blockPos().equals(var1)) {
            var6.add(var8);
         }
      }

      if (!var6.isEmpty()) {
         for (StructureSignature var11 : StructureSignatures.a()) {
            var var9 = this.a(var6, var11);
            if (var9 != null) {
               this.a(var1, var11, var2, var4, var5);
               this.h.removeAll(var9);
               return;
            }
         }
      }
   }

   private List<DetectedSound> a(List<DetectedSound> var1, StructureSignature var2) {
      ArrayList<DetectedSound> var3 = new ArrayList<>(var1);
      ArrayList<DetectedSound> var4 = new ArrayList<>(var2.sounds().size());

      for (SoundSignature var6 : var2.sounds()) {
         DetectedSound var7 = null;

         for (DetectedSound var9 : var3) {
            if (var6.a(var9)) {
               var7 = var9;
               break;
            }
         }

         if (var7 == null) {
            return null;
         }

         var3.remove(var7);
         var4.add(var7);
      }

      return var4;
   }

   private void a(BlockPos var1, StructureSignature var2, long var3, boolean var5, boolean var6) {
      FunTimeItemType var7 = var2.type();
      PlayerEntity var8 = this.a(Vec3d.ofCenter(var1));
      if (var8 != null) {
         FunTimeItemType var9 = this.a(var8);
         if (var9 != FunTimeItemType.c) {
            var7 = var9;
         }
      }

      if (var7 != FunTimeItemType.a || var5) {
         if (var7 != FunTimeItemType.b || var6) {
            this.j.removeIf(var1x -> var1x.blockPos().equals(var1));
            this.j.add(new StructureTracker.Placement(var1, var7, var3));
         }
      }
   }

   private PlayerEntity a(Vec3d var1) {
      if (d.world == null) {
         return null;
      } else {
         AbstractClientPlayerEntity var2 = null;
         double var3 = 9.0;

         for (AbstractClientPlayerEntity var6 : d.world.getPlayers()) {
            double var7 = var6.getEntityPos().squaredDistanceTo(var1);
            if (!(var7 > var3) && this.a(var6) != FunTimeItemType.c) {
               var3 = var7;
               var2 = var6;
            }
         }

         return var2;
      }
   }

   private FunTimeItemType a(PlayerEntity var1) {
      FunTimeItemType var2 = FunTimeItemDetector.a(var1.getMainHandStack());
      return var2 != FunTimeItemType.c ? var2 : FunTimeItemDetector.a(var1.getOffHandStack());
   }

   private Identifier a(RegistryEntry<SoundEvent> var1) {
      return var1.getKey().map(var0 -> var0.getValue()).orElse(null);
   }

   @Environment(EnvType.CLIENT)
   public record Placement(BlockPos blockPos, FunTimeItemType type, long timeMs) {
   }
}
