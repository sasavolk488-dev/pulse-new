package pulse.mixin.accessor;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({PlayerListHud.class})
public interface PlayerListHudAccessor {
   @Accessor("header")
   Text getHeader();

   @Accessor("footer")
   Text getFooter();

   @Accessor("visible")
   boolean isVisible();

   @Accessor("visible")
   void setVisible(boolean var1);

   @Invoker("collectPlayerEntries")
   List<PlayerListEntry> invokeCollectPlayerEntries();
}
