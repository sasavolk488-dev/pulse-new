package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({WorldRenderer.class})
public interface WorldRendererEntityOutlineAccessor {
   @Accessor("entityOutlineFramebuffer")
   Framebuffer pulse$entityOutlineFramebuffer();

   @Invoker("canDrawEntityOutlines")
   boolean pulse$canDrawEntityOutlines();
}
