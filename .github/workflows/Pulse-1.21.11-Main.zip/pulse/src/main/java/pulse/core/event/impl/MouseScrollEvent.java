package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class MouseScrollEvent extends CancellableEvent {
   private final double a;
   private final double b;

   public MouseScrollEvent(double var1, double var3) {
      this.a = var1;
      this.b = var3;
   }

   @Generated
   public double d() {
      return this.a;
   }

   @Generated
   public double e() {
      return this.b;
   }
}
