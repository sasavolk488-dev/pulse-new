package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import pulse.core.event.impl.KeyEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.KeySetting;
import pulse.utils.game.InvUtils;

@ModuleInfo(
   a = "Elytra Swap",
   b = "Автоматически меняет нагрудник на элитры при падении",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ElytraSwapModule extends Module {
   private final KeySetting a = new KeySetting("Кнопка свапа", -1);
   private boolean b = false;
   private int c = 0;
   private boolean f = false;
   private int g = 0;

   @EventHandler
   @Compile
      public void a(KeyEvent var1) {
      if (d.player == null || d.world == null || d.currentScreen != null) {
         return;
      }
      if (var1.a() == this.a.q() && var1.c() == 1 && !this.b) {
         this.b = true;
         this.c = 0;
         this.f = false;
         this.g = 0;
      }
   }

   @EventHandler
   @Compile
   public native void a(UpdateEvent var1);

   private void n() {
      boolean var1 = this.q();
      if (var1) {
         Optional var2 = this.p();
         if (var2.isPresent()) {
            this.b((Integer)var2.get());
            d.player.sendMessage(Text.of(this.g() + ": Снял элитры."), true);
         }
      } else {
         Optional var3 = this.o();
         if (var3.isPresent()) {
            this.b((Integer)var3.get());
            d.player.sendMessage(Text.of(this.g() + ": Надел элитры."), true);
         }
      }
   }

   private void b(int var1) {
      byte var2 = 40;
      byte var3 = 6;
      d.interactionManager.clickSlot(d.player.currentScreenHandler.syncId, var1, var2, SlotActionType.SWAP, d.player);
      d.interactionManager.clickSlot(d.player.currentScreenHandler.syncId, var3, var2, SlotActionType.SWAP, d.player);
      d.interactionManager.clickSlot(d.player.currentScreenHandler.syncId, var1, var2, SlotActionType.SWAP, d.player);
   }

   private Optional<Integer> o() {
      return InvUtils.a(var0 -> var0.getItem() == Items.ELYTRA, true, false);
   }

   private Optional<Integer> p() {
      return InvUtils.a(this::a, true, false);
   }

   private boolean a(ItemStack var1) {
      if (var1.getItem() == Items.ELYTRA) {
         return false;
      } else {
         EquippableComponent var2 = var1.get(DataComponentTypes.EQUIPPABLE);
         return var2 != null && var2.slot() == EquipmentSlot.CHEST;
      }
   }

   private boolean q() {
      ItemStack var1 = d.player.getEquippedStack(EquipmentSlot.CHEST);
      return var1.getItem() == Items.ELYTRA;
   }

   @Compile
   @Override
      public void e() {
      super.e();
      this.b = false;
      this.c = 0;
      this.f = false;
      this.g = 0;
   }

   @Compile
   @Override
      public void f() {
      super.f();
   }

   static {
      NativeMethodLookup.lookup(ElytraSwapModule.class, 56);
   }
}
