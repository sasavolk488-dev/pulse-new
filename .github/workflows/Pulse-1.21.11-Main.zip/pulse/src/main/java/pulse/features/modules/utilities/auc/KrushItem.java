package pulse.features.modules.utilities.auc;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class KrushItem implements AucItem {
   private final String a;
   private final ItemStack b;

   public KrushItem(String var1, Item var2, ItemStack var3, int var4) {
      this.a = var1;
      this.b = var3;
   }

   @Override
   public String a() {
      return this.a;
   }

   @Override
   public String b() {
      return this.a;
   }

   @Override
   public ItemStack c() {
      return this.b.copy();
   }
}
