package pulse.features.modules.utilities.auc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.AttributeModifiersComponent.Entry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import pulse.utils.game.ChatUtils;

@Environment(EnvType.CLIENT)
public final class AucMatcher {
   private static final Map<String, String> a = Map.ofEntries(
      Map.entry("tnt-tier-white", "Таер вайт"), Map.entry("twhite", "Таер вайт"), Map.entry("tnt-tier-black", "Таер блэк"), Map.entry("tblack", "Таер блэк")
   );
   private static final Set<String> b = Set.of("attack_damage", "attack_speed", "max_health", "armor", "armor_toughness", "movement_speed", "luck");

   private AucMatcher() {
   }

   public static String a(ItemStack var0) {
      NbtCompound var1 = g(var0);
      if (var1 == null) {
         return null;
      } else {
         if (var1.contains("minecraft:ftid")) {
            String var2 = var1.getString("minecraft:ftid", "");
            if (!var2.isEmpty()) {
               return var2;
            }
         }

         if (var1.contains("minecraft:don-item")) {
            String var3 = var1.getString("minecraft:don-item", "");
            if (!var3.isEmpty()) {
               return var3;
            }
         }

         return null;
      }
   }

   public static String b(ItemStack var0) {
      String var1 = a(var0);
      return var1 == null ? null : a.get(var1);
   }

   public static String c(ItemStack var0) {
      String var1 = a(var0);
      if (var1 != null) {
         return "id:" + var1;
      } else {
         var var2 = j(var0);
         if (!var2.isEmpty()) {
            Collections.sort(var2);
            return "attr:" + String.join(",", var2);
         } else {
            return null;
         }
      }
   }

   public static String d(ItemStack var0) {
      NbtCompound var1 = g(var0);
      if (var1 == null) {
         return null;
      } else {
         boolean var2 = var1.contains("minecraft:don-item") || var1.contains("minecraft:ftid") || var1.getByte("minecraft:is-tshop", (byte)0) != 0;
         if (!var2) {
            return null;
         } else {
            Text var3 = var0.get(DataComponentTypes.CUSTOM_NAME);
            if (var3 == null) {
               return null;
            } else {
               String var4 = var3.getString();
               return var4 != null && !var4.isEmpty() ? var4 : null;
            }
         }
      }
   }

   private static NbtCompound g(ItemStack var0) {
      if (var0 != null && !var0.isEmpty()) {
         NbtComponent var1 = var0.get(DataComponentTypes.CUSTOM_DATA);
         if (var1 == null) {
            return null;
         } else {
            NbtCompound var2 = var1.copyNbt();
            return var2 != null && !var2.getCompound("PublicBukkitValues").isEmpty() ? var2.getCompoundOrEmpty("PublicBukkitValues") : null;
         }
      } else {
         return null;
      }
   }

   public static AucItem e(ItemStack var0) {
      if (var0 != null && !var0.isEmpty()) {
         for (AucItem var2 : AucItemRegistry.a()) {
            ItemStack var3 = var2.c();
            if (a(var0, var3)) {
               return var2;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static void f(ItemStack var0) {
      ChatUtils.a("&e=== Auc debug: " + var0.getItem().getName().getString() + " ===");
      ChatUtils.a("item=" + var0.getItem());
      Text var1 = var0.get(DataComponentTypes.CUSTOM_NAME);
      ChatUtils.a("custom_name=" + (var1 == null ? "null" : "'" + var1.getString() + "'"));
      PotionContentsComponent var2 = var0.get(DataComponentTypes.POTION_CONTENTS);
      if (var2 != null) {
         int var3 = 0;

         for (StatusEffectInstance var5 : var2.getEffects()) {
            ChatUtils.a("effect " + var5.getEffectType().getIdAsString() + " amp=" + var5.getAmplifier() + " dur=" + var5.getDuration());
            var3++;
         }

         if (var3 == 0) {
            ChatUtils.a("potion: present, no effects (base=" + var2.potion() + ")");
         }
      } else {
         ChatUtils.a("potion: null");
      }

      AttributeModifiersComponent var9 = var0.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
      if (var9 != null) {
         int var10 = 0;

         for (Entry var6 : var9.modifiers()) {
            ChatUtils.a(
               "attr[component] "
                  + var6.attribute().getIdAsString()
                  + " amount="
                  + var6.modifier().value()
                  + " op="
                  + var6.modifier().operation().getId()
                  + " slot="
                  + var6.slot().asString()
            );
            var10++;
         }

         if (var10 == 0) {
            ChatUtils.a("attr[component]: none");
         }
      } else {
         ChatUtils.a("attr[component]: null");
      }

      NbtComponent var11 = var0.get(DataComponentTypes.CUSTOM_DATA);
      if (var11 != null) {
         NbtCompound var13 = var11.copyNbt();
         if (var13 != null && var13.getList("AttributeModifiers").isPresent()) {
            NbtList var16 = var13.getListOrEmpty("AttributeModifiers");

            for (int var7 = 0; var7 < var16.size(); var7++) {
               NbtCompound var8 = var16.getCompoundOrEmpty(var7);
               ChatUtils.a(
                  "attr[nbt] "
                     + var8.getString("AttributeName", "")
                     + " amount="
                     + var8.getDouble("Amount", 0.0)
                     + " op="
                     + var8.getInt("Operation", 0)
                     + " slot="
                     + var8.getString("Slot", "")
               );
            }
         } else {
            ChatUtils.a("custom_data keys=" + (var13 == null ? "null" : var13.getKeys()));
            if (var13 != null) {
               String var15 = var13.toString();
               if (var15.length() > 230) {
                  var15 = var15.substring(0, 230) + "...";
               }

               ChatUtils.a("custom_data nbt=" + var15);
            }
         }
      } else {
         ChatUtils.a("custom_data: null");
      }

      LoreComponent var14 = var0.get(DataComponentTypes.LORE);
      if (var14 != null) {
         for (Text var19 : var14.lines()) {
            ChatUtils.a("lore: '" + var19.getString() + "'");
         }
      }

      ChatUtils.a("&a=> ftid: " + a(var0) + " mapped: " + b(var0));
      String var18 = d(var0);
      ChatUtils.a("&a=> donate-tag: " + (var18 == null ? "no" : "'" + var18 + "'"));
      AucItem var20 = e(var0);
      ChatUtils.a("&a=> catalogue: " + (var20 == null ? "NONE" : var20.b()));
   }

   private static String a(String var0) {
      return var0 == null ? "" : var0.toLowerCase().trim().replaceAll("§.", "").replaceAll("[^a-zа-яё0-9\\s\\[\\]★]", "").replaceAll("\\s+", " ");
   }

   public static boolean a(ItemStack var0, ItemStack var1) {
      if (var0.getItem() != var1.getItem()) {
         return false;
      } else if (var0.getItem() == Items.TOTEM_OF_UNDYING && var1.getItem() == Items.TOTEM_OF_UNDYING) {
         return i(var1) ? c(var0, var1) : !h(var0);
      } else if (var0.getItem() != Items.PLAYER_HEAD || var1.getItem() != Items.PLAYER_HEAD) {
         LoreComponent var2 = var1.get(DataComponentTypes.LORE);
         boolean var3 = var2 != null && !var2.lines().isEmpty();
         if (var3) {
            LoreComponent var13 = var0.get(DataComponentTypes.LORE);
            if (var13 != null && !var13.lines().isEmpty()) {
               var var14 = var13.lines().stream().map(var0x -> a(var0x.getString())).filter(var0x -> !var0x.isEmpty()).collect(Collectors.toList());
               String var15 = String.join(" ", var14);
               boolean var16 = var14.stream().anyMatch(var0x -> var0x.contains("оригинальный предмет") || var0x.contains("★"));

               for (Text var18 : var2.lines()) {
                  String var19 = a(var18.getString());
                  if (!var19.isEmpty()) {
                     boolean var20 = var19.contains("оригинальный предмет") || var19.contains("★");
                     if (var20) {
                        if (!var16) {
                           return false;
                        }
                     } else {
                        boolean var21 = var14.stream().anyMatch(var1x -> var1x.contains(var19) || var19.contains(var1x)) || var15.contains(var19);
                        if (!var21) {
                           return false;
                        }
                     }
                  }
               }

               return true;
            } else {
               return false;
            }
         } else {
            if (var0.getItem() == Items.SPLASH_POTION && var1.getItem() == Items.SPLASH_POTION
               || var0.getItem() == Items.POTION && var1.getItem() == Items.POTION) {
               PotionContentsComponent var4 = var0.get(DataComponentTypes.POTION_CONTENTS);
               PotionContentsComponent var5 = var1.get(DataComponentTypes.POTION_CONTENTS);
               if (var5 != null) {
                  ArrayList<StatusEffectInstance> var6 = new ArrayList<>();
                  var5.getEffects().forEach(var6::add);
                  if (!var6.isEmpty()) {
                     if (var4 == null) {
                        return false;
                     }

                     ArrayList<StatusEffectInstance> var7 = new ArrayList<>();
                     var4.getEffects().forEach(var7::add);
                     if (var7.isEmpty()) {
                        return false;
                     }

                     for (StatusEffectInstance var9 : var6) {
                        boolean var10 = false;

                        for (StatusEffectInstance var12 : var7) {
                           if (var12.getEffectType().equals(var9.getEffectType()) && var12.getAmplifier() == var9.getAmplifier()) {
                              if (var9.getDuration() <= 0) {
                                 var10 = true;
                                 break;
                              }

                              if (Math.abs(var12.getDuration() - var9.getDuration()) <= 20) {
                                 var10 = true;
                                 break;
                              }
                           }
                        }

                        if (!var10) {
                           return false;
                        }
                     }

                     return true;
                  }
               }
            }

            return b(var0, var1);
         }
      } else {
         return i(var1) ? c(var0, var1) : false;
      }
   }

   private static boolean h(ItemStack var0) {
      NbtComponent var1 = var0.get(DataComponentTypes.CUSTOM_DATA);
      if (var1 != null) {
         NbtCompound var2 = var1.copyNbt();
         if (var2 != null && !var2.getListOrEmpty("AttributeModifiers").isEmpty()) {
            return true;
         }
      }

      AttributeModifiersComponent var3 = var0.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
      return var3 != null && var3.modifiers().iterator().hasNext();
   }

   private static boolean i(ItemStack var0) {
      NbtComponent var1 = var0.get(DataComponentTypes.CUSTOM_DATA);
      if (var1 == null) {
         return false;
      } else {
         NbtCompound var2 = var1.copyNbt();
         return var2 != null && !var2.getListOrEmpty("AttributeModifiers").isEmpty();
      }
   }

   private static boolean b(ItemStack var0, ItemStack var1) {
      ItemEnchantmentsComponent var2 = var0.get(DataComponentTypes.ENCHANTMENTS);
      ItemEnchantmentsComponent var3 = var1.get(DataComponentTypes.ENCHANTMENTS);
      if (var3 != null && !var3.isEmpty()) {
         if (var2 != null && !var2.isEmpty()) {
            for (RegistryEntry var5 : var3.getEnchantments()) {
               int var6 = var3.getLevel(var5);
               int var7 = var2.getLevel(var5);
               if (var7 < var6) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   private static boolean c(ItemStack var0, ItemStack var1) {
      NbtComponent var2 = var1.get(DataComponentTypes.CUSTOM_DATA);
      if (var2 == null) {
         return false;
      } else {
         NbtCompound var3 = var2.copyNbt();
         if (var3 == null) {
            return false;
         } else {
            NbtList var4 = var3.getListOrEmpty("AttributeModifiers");
            if (var4.isEmpty()) {
               return false;
            } else {
               ArrayList var5 = new ArrayList<>();

               for (int var6 = 0; var6 < var4.size(); var6++) {
                  NbtCompound var7 = var4.getCompoundOrEmpty(var6);
                  String var8 = a(var7.getString("AttributeName", ""), var7.getDouble("Amount", 0.0));
                  if (var8 != null) {
                     var5.add(var8);
                  }
               }

               var var9 = j(var0);
               return a(var5, var9);
            }
         }
      }
   }

   private static List<String> j(ItemStack var0) {
      ArrayList<String> var1 = new ArrayList<>();
      AttributeModifiersComponent var2 = var0.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
      if (var2 != null && var2.modifiers().iterator().hasNext()) {
         for (Entry var10 : var2.modifiers()) {
            String var11 = a(var10.attribute().getIdAsString(), var10.modifier().value());
            if (var11 != null) {
               var1.add(var11);
            }
         }
      } else {
         NbtComponent var3 = var0.get(DataComponentTypes.CUSTOM_DATA);
         if (var3 != null) {
            NbtCompound var4 = var3.copyNbt();
            if (var4 != null) {
               NbtList var5 = var4.getListOrEmpty("AttributeModifiers");

               for (int var6 = 0; var6 < var5.size(); var6++) {
                  NbtCompound var7 = var5.getCompoundOrEmpty(var6);
                  String var8 = a(var7.getString("AttributeName", ""), var7.getDouble("Amount", 0.0));
                  if (var8 != null) {
                     var1.add(var8);
                  }
               }
            }
         }
      }

      return var1;
   }

   private static String a(String var0, double var1) {
      String var3 = b(var0);
      if (!b.contains(var3)) {
         return null;
      } else {
         String var4 = var1 > 0.0 ? "+" : (var1 < 0.0 ? "-" : "0");
         return var3 + "|" + var4;
      }
   }

   private static String b(String var0) {
      if (var0 == null) {
         return "";
      } else {
         int var1 = var0.indexOf(58);
         if (var1 >= 0) {
            var0 = var0.substring(var1 + 1);
         }

         if (var0.startsWith("generic.")) {
            var0 = var0.substring("generic.".length());
         }

         return var0;
      }
   }

   private static boolean a(List<String> var0, List<String> var1) {
      if (var0.size() != var1.size()) {
         return false;
      } else {
         ArrayList var2 = new ArrayList<>(var1);

         for (String var4 : var0) {
            if (!var2.remove(var4)) {
               return false;
            }
         }

         return var2.isEmpty();
      }
   }
}
