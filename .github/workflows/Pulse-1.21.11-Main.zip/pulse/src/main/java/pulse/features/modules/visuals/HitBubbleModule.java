package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.world.BubbleLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Hit Bubble",
   b = "Показывает анимированные пузыри при атаке",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class HitBubbleModule extends Module {
   private final NumberSetting a = new NumberSetting("Время жизни", 40.0F, 10.0F, 150.0F, 5.0F);
   private final ModeSetting b = new ModeSetting("Текстура", new String[]{"Пузырь 1", "Пузырь 2"}, "Пузырь 1");
   private final SeparatorSetting c = new SeparatorSetting("Цвет");
   private final BooleanSetting f = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting g = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.f.a());
   private final List<HitBubbleModule.HitBubble> h = new ArrayList<>();
   private final Quaternionf i = new Quaternionf();

   @EventHandler
   @Compile
   public void a(AttackEvent var1) {
      if (var1.a() != d.player && var1.a() instanceof net.minecraft.entity.LivingEntity) {
         Vec3d position = this.n();
         if (position != null) {
            float tickDelta = d.getRenderTickCounter().getTickProgress(false);
            float yaw = d.player.getYaw(tickDelta);
            float pitch = d.player.getPitch(tickDelta);
            this.h.add(new HitBubbleModule.HitBubble((float)position.x, (float)position.y, (float)position.z, -yaw, pitch, System.currentTimeMillis()));
         }
      }
   }

   private Vec3d n() {
      if (d.player != null && d.world != null) {
         float var1 = d.getRenderTickCounter().getTickProgress(false);
         Vec3d var2 = d.player.getCameraPosVec(var1);
         Vec3d var3 = d.player.getRotationVec(var1);
         double var4 = 1.0;
         Vec3d var6 = var2.add(var3.multiply(var4));
         BlockHitResult var7 = d.world.raycast(new RaycastContext(var2, var6, ShapeType.OUTLINE, FluidHandling.NONE, d.player));
         return var7 != null && var7.getType() != Type.MISS ? var7.getPos() : var6;
      } else {
         return null;
      }
   }

   @EventHandler
   public void a(RenderEvent var1) {
      if (!this.h.isEmpty()) {
         Vec3d var2 = d.gameRenderer.getCamera().getCameraPos();
         long var3 = System.currentTimeMillis();
         long var5 = (long)(this.a.b() * 50.0F);
         RenderLayer var7 = BubbleLayers.a(this.b.e());
         Immediate var8 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer var9 = var8.getBuffer(var7);
         Color var10 = this.o();
         float var11 = var10.getRed() / 255.0F;
         float var12 = var10.getGreen() / 255.0F;
         float var13 = var10.getBlue() / 255.0F;
         MatrixStack var14 = var1.a();
         var14.push();
         this.h.forEach(var11x -> {
            long var12x = var3 - var11x.f;
            if (var12x < var5) {
               var14.push();
               var14.translate(var11x.a - var2.x, var11x.b - var2.y, var11x.c - var2.z);
               var14.multiply(this.i.rotationY((float)Math.toRadians(var11x.d)));
               var14.multiply(this.i.rotationX((float)Math.toRadians(var11x.e)));
               float var14x = -((float)var12x) / 4.0F;
               float var15 = (float)var12x / 1500.0F;
               this.a(var14, var9, var14x, var15, var11, var12, var13);
               var14.pop();
            }
         });
         var14.pop();
         var8.draw(var7);
         this.h.removeIf(var4 -> var3 - var4.f >= var5);
      }
   }

   private void a(MatrixStack var1, VertexConsumer var2, float var3, float var4, float var5, float var6, float var7) {
      var1.push();
      var1.multiply(this.i.rotationZ((float)Math.toRadians(var3)));
      float var8 = var4 * 2.0F;
      float var9 = (1.0F - var4) * 0.8F;
      if (var9 <= 0.0F) {
         var1.pop();
      } else {
         Matrix4f var10 = var1.peek().getPositionMatrix();
         float var11 = var8 / 2.0F;
         var2.vertex(var10, -var11, -var11, 0.0F).texture(0.0F, 0.0F).color(var5, var6, var7, var9);
         var2.vertex(var10, var11, -var11, 0.0F).texture(1.0F, 0.0F).color(var5, var6, var7, var9);
         var2.vertex(var10, var11, var11, 0.0F).texture(1.0F, 1.0F).color(var5, var6, var7, var9);
         var2.vertex(var10, -var11, var11, 0.0F).texture(0.0F, 1.0F).color(var5, var6, var7, var9);
         var1.pop();
      }
   }

   private Color o() {
      return this.f.a() ? ModuleRegistry.aw.n() : this.g.a();
   }

   static {
      NativeMethodLookup.lookup(HitBubbleModule.class, 83);
   }

   @Environment(EnvType.CLIENT)
   public static class HitBubble {
      public final float a;
      public final float b;
      public final float c;
      public final float d;
      public final float e;
      public final long f;

      public HitBubble(float var1, float var2, float var3, float var4, float var5, long var6) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
         this.f = var6;
      }
   }
}
