package pulse.services.discord;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class DiscordIpcChannel implements AutoCloseable {
   private final boolean a;
   private RandomAccessFile b;
   private SocketChannel c;

   private DiscordIpcChannel(boolean var1) {
      this.a = var1;
   }

   static DiscordIpcChannel a() {
      boolean var0 = System.getProperty("os.name", "").toLowerCase().contains("win");

      for (int var1 = 0; var1 < 10; var1++) {
         DiscordIpcChannel var2 = new DiscordIpcChannel(var0);

         try {
            if (var0) {
               var2.b = new RandomAccessFile("\\\\?\\pipe\\discord-ipc-" + var1, "rw");
            } else {
               Path var3 = a(var1);
               if (var3 == null) {
                  continue;
               }

               var2.c = SocketChannel.open(StandardProtocolFamily.UNIX);
               var2.c.connect(UnixDomainSocketAddress.of(var3));
            }

            return var2;
         } catch (Exception var4) {
            var2.c();
         }
      }

      return null;
   }

   private static Path a(int var0) {
      String[] var1 = new String[]{System.getenv("XDG_RUNTIME_DIR"), System.getenv("TMPDIR"), System.getenv("TMP"), System.getenv("TEMP"), "/tmp"};
      String var2 = "discord-ipc-" + var0;

      for (String var6 : var1) {
         if (var6 != null && !var6.isEmpty()) {
            Path var7 = Path.of(var6, var2);
            if (Files.exists(var7)) {
               return var7;
            }

            for (String var11 : new String[]{"app/com.discordapp.Discord", "snap.discord"}) {
               Path var12 = Path.of(var6, var11, var2);
               if (Files.exists(var12)) {
                  return var12;
               }
            }
         }
      }

      return null;
   }

   void a(int var1, String var2) throws IOException {
      byte[] var3 = var2.getBytes(StandardCharsets.UTF_8);
      ByteBuffer var4 = ByteBuffer.allocate(8 + var3.length).order(ByteOrder.LITTLE_ENDIAN);
      var4.putInt(var1);
      var4.putInt(var3.length);
      var4.put(var3);
      var4.flip();
      if (this.a) {
         this.b.write(var4.array());
      } else {
         while (var4.hasRemaining()) {
            this.c.write(var4);
         }
      }
   }

   String b() throws IOException {
      byte[] var1 = this.b(8);
      if (var1 == null) {
         return null;
      } else {
         ByteBuffer var2 = ByteBuffer.wrap(var1).order(ByteOrder.LITTLE_ENDIAN);
         var2.getInt();
         int var3 = var2.getInt();
         if (var3 > 0 && var3 <= 1048576) {
            byte[] var4 = this.b(var3);
            return var4 == null ? null : new String(var4, StandardCharsets.UTF_8);
         } else {
            return "";
         }
      }
   }

   private byte[] b(int var1) throws IOException {
      byte[] var2 = new byte[var1];
      if (this.a) {
         int var3 = 0;

         while (var3 < var1) {
            int var4 = this.b.read(var2, var3, var1 - var3);
            if (var4 < 0) {
               return null;
            }

            var3 += var4;
         }
      } else {
         ByteBuffer var5 = ByteBuffer.wrap(var2);

         while (var5.hasRemaining()) {
            int var6 = this.c.read(var5);
            if (var6 < 0) {
               return null;
            }
         }
      }

      return var2;
   }

   @Override
   public void close() {
      this.c();
   }

   private void c() {
      try {
         if (this.b != null) {
            this.b.close();
         }
      } catch (Exception var3) {
      }

      try {
         if (this.c != null) {
            this.c.close();
         }
      } catch (Exception var2) {
      }

      this.b = null;
      this.c = null;
   }
}
