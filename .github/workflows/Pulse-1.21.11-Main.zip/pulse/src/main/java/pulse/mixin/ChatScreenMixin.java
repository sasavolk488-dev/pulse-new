package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.widget.ButtonWidget.PressAction;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.ChatEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.features.modules.hud.DraggableManager;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.AnimationsModule;
import pulse.features.modules.visuals.animations.ChatAnimator;
import pulse.services.tracker.v2.GroupManagerClient;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;
import pulse.utils.game.ChatUtils;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
@Mixin({ChatScreen.class})
public abstract class ChatScreenMixin extends Screen {
   @Shadow
   protected TextFieldWidget chatField;
   @Unique
   private boolean matrixPushed = false;
   @Unique
   private int originalChatFieldY = 0;
   @Unique
   private static boolean pulse$groupChatMode = false;
   @Unique
   private ButtonWidget pulse$normalBtn;
   @Unique
   private ButtonWidget pulse$groupBtn;
   @Unique
   private boolean pulse$refocusChat = false;

   protected ChatScreenMixin(Text var1) {
      super(var1);
   }

   @Unique
   private boolean isChatAnimationEnabled() {
      return ModuleRegistry.t != null && ModuleRegistry.t.k() && ModuleRegistry.t.c.a();
   }

   @Inject(
      method = {"sendMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendMessage(String var1, boolean var2, CallbackInfo var3) {
      if (var1 != null) {
         String var4 = var1.trim();
         String var5 = var4.toLowerCase();
         if (var5.equals(".fakemarkers") || var5.startsWith(".fakemarkers ")) {
            int var6 = 20;
            String[] var7 = var4.split("\\s+");
            if (var7.length > 1) {
               try {
                  var6 = Math.max(1, Math.min(500, Integer.parseInt(var7[1])));
               } catch (NumberFormatException var9) {
               }
            }

            HandlerRegistry.c.a(var6);
            var3.cancel();
            return;
         }

         if (var5.equals(".clearmarkers")) {
            HandlerRegistry.c.d();
            ChatUtils.a("&aФейковые метки очищены.");
            var3.cancel();
            return;
         }
      }

      if (pulse$groupChatMode && var1 != null && !var1.trim().isEmpty() && !var1.startsWith("/") && GroupManagerClient.a().c() && RealtimeSyncServiceV2.L().b()
         )
       {
         RealtimeSyncServiceV2.L().a(var1.trim());
         var3.cancel();
      } else {
         ChatEvent var10 = new ChatEvent(var1);
         EventHandler.a.post(var10);
         if (var10.c()) {
            var3.cancel();
         }
      }
   }

   @Unique
   private void pulse$updateChatModeButtons() {
      if (this.pulse$normalBtn != null && this.pulse$groupBtn != null) {
         this.pulse$normalBtn.active = pulse$groupChatMode;
         this.pulse$groupBtn.active = !pulse$groupChatMode;
      }
   }

   @Unique
   private void pulse$focusChatField() {
      this.pulse$refocusChat = true;
   }

   @Unique
   private ButtonWidget pulse$makeModeButton(int var1, int var2, int var3, int var4, String var5, PressAction var6) {
      return new net.minecraft.client.gui.widget.ButtonWidget.Text(var1, var2, var3, var4, Text.literal(var5), var6, var0 -> var0.get()) {
         @Override
         public GuiNavigationPath getNavigationPath(GuiNavigation navigation) {
            return null;
         }
      };
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void onInit(CallbackInfo var1) {
      DraggableManager.a().a(true);
      if (GroupManagerClient.a().c()) {
         byte var2 = 70;
         byte var3 = 16;
         byte var4 = 4;
         int var5 = this.chatField.getY() - var3 - 4;
         this.pulse$normalBtn = this.pulse$makeModeButton(2, var5, var2, var3, "Обычный", var1x -> {
            pulse$groupChatMode = false;
            this.pulse$updateChatModeButtons();
            this.pulse$focusChatField();
         });
         this.pulse$groupBtn = this.pulse$makeModeButton(2 + var2 + var4, var5, var2, var3, "Групповой", var1x -> {
            pulse$groupChatMode = true;
            this.pulse$updateChatModeButtons();
            this.pulse$focusChatField();
         });
         this.addDrawableChild(this.pulse$normalBtn);
         this.addDrawableChild(this.pulse$groupBtn);
         this.pulse$updateChatModeButtons();
      } else {
         pulse$groupChatMode = false;
      }

      if (this.isChatAnimationEnabled()) {
         ChatAnimator var6 = AnimationsModule.o();
         var6.d();
         var6.a((long)ModuleRegistry.t.f.q().floatValue());
         this.originalChatFieldY = this.chatField.getY();
      }
   }

   @Inject(
      method = {"removed"},
      at = {@At("HEAD")}
   )
   private void onRemoved(CallbackInfo var1) {
      DraggableManager.a().a(false);
      if (DraggableManager.a().h() != null) {
         DraggableManager.a().h().i().c();
         DraggableManager.a().h().g();
      }

      MouseUtil.l();
      AnimationsModule.o().d();
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseClicked(Click var1, boolean var2, CallbackInfoReturnable<Boolean> var3) {
      if (DraggableManager.a().a(var1.x(), var1.y(), var1.button())) {
         var3.setReturnValue(true);
      }
   }

   @Override
   public boolean mouseReleased(Click click) {
      return DraggableManager.a().b(click.x(), click.y(), click.button()) ? true : super.mouseReleased(click);
   }

   @Override
   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      DraggableManager.a().a(click.x(), click.y(), offsetX, offsetY);
      return DraggableManager.a().b(click.x(), click.y()) ? true : super.mouseDragged(click, offsetX, offsetY);
   }

   @Inject(
      method = {"mouseScrolled"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseScrolled(double var1, double var3, double var5, double var7, CallbackInfoReturnable<Boolean> var9) {
      if (DraggableManager.a().a(var1, var3, var7)) {
         var9.setReturnValue(true);
      } else {
         if (this.isChatAnimationEnabled() && AnimationsModule.o().c()) {
            var9.setReturnValue(false);
         }
      }
   }

   @Inject(
      method = {"keyPressed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onKeyPressed(KeyInput var1, CallbackInfoReturnable<Boolean> var2) {
      int var3 = var1.key();
      int var4 = var1.modifiers();
      if (DraggableManager.a().a(var3, var4)) {
         var2.setReturnValue(true);
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRenderHead(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      MouseUtil.h();
      if (this.isChatAnimationEnabled()) {
         ChatAnimator var6 = AnimationsModule.o();
         var6.a();
         float var7 = var6.b();
         if (var7 > 0.0F) {
            this.chatField.setY(this.originalChatFieldY + (int)var7);
            var1.getMatrices().pushMatrix();
            var1.getMatrices().translate(0.0F, var7);
            this.matrixPushed = true;
         } else {
            this.matrixPushed = false;
         }
      } else {
         this.matrixPushed = false;
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void onRender(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      if (this.pulse$refocusChat) {
         this.pulse$refocusChat = false;
         this.setFocused(this.chatField);
         this.chatField.setFocused(true);
      }

      if (this.matrixPushed) {
         var1.getMatrices().popMatrix();
         this.matrixPushed = false;
      }

      MinecraftClient var6 = MinecraftClient.getInstance();
      if (var6.isWindowFocused()) {
         DraggableManager.a().a((double)var2, (double)var3);
         if (DraggableManager.a().h() != null) {
            double var7 = var2 * var6.getWindow().getScaleFactor() / 2.0;
            double var9 = var3 * var6.getWindow().getScaleFactor() / 2.0;
            DraggableManager.a().h().a(var7, var9);
         }
      } else {
         DraggableManager.a().a((double)var2, (double)var3);
         if (DraggableManager.a().h() != null) {
            DraggableManager.a().h().g();
         }
      }

      MouseUtil.i();
   }
}
