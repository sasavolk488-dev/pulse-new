package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({Screen.class})
public interface ScreenAccessor {
   @Accessor("client")
   @Mutable
   void pulse$setClient(MinecraftClient var1);

   @Accessor("textRenderer")
   @Mutable
   void pulse$setTextRenderer(TextRenderer var1);
}
