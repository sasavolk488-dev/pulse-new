package pulse.services.tracker.v2;

import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public final class PartyHealthReporter extends Handler {
   private static final float a = 0.5F;
   private static final long b = 250L;
   private static final long c = 5000L;
   private static float d = Float.NaN;
   private static float e = Float.NaN;
   private static float f = Float.NaN;
   private static long g;

   public static void d() {
      g = 0L;
      d = Float.NaN;
   }

   @EventHandler
   public void a(UpdateEvent var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.player != null && var2.world != null) {
         GroupManagerClient var3 = GroupManagerClient.a();
         if (var3.c() && var3.d().size() > 1) {
            float var4 = var2.player.getHealth();
            float var5 = var2.player.getAbsorptionAmount();
            float var6 = var2.player.getMaxHealth();
            long var7 = System.currentTimeMillis();
            boolean var9 = Float.isNaN(d) || Math.abs(var4 - d) >= 0.5F || Math.abs(var5 - e) >= 0.5F || Math.abs(var6 - f) >= 0.5F;
            boolean var10 = var7 - g >= 5000L;
            if (var9 && var7 - g >= 250L || var10) {
               d = var4;
               e = var5;
               f = var6;
               g = var7;

               try {
                  RealtimeSyncServiceV2.L().a(var4, var6, var5);
               } catch (Exception var12) {
               }
            }
         }
      }
   }
}
