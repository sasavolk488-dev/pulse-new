package pulse.features.modules.utilities.auc;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public interface AucItem {
   String a();

   String b();

   ItemStack c();

   default Item d() {
      return this.c().getItem();
   }
}
