package pulse.ui.clickgui.common;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class BottomFadeElement implements GuiElement {
   private static final int a = 50;
   private static final float b = 5.0F;
   private static final float c = 25.0F;
   private int d = 50;
   private float e = 5.0F;
   private float f = 25.0F;
   private Color g = ClickGuiColors.f;
   private float h = 0.0F;
   private boolean i = false;
   private float j;
   private float k;
   private float l;
   private float m;

   public BottomFadeElement() {
   }

   public BottomFadeElement(int var1, float var2, float var3) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
   }

   public BottomFadeElement(int var1, float var2, float var3, Color var4) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
      this.g = var4;
   }

   public void a(int var1) {
      this.d = var1;
   }

   public void a(float var1) {
      this.e = var1;
   }

   public void b(float var1) {
      this.f = var1;
   }

   public void a(Color var1) {
      this.g = var1;
   }

   public void c(float var1) {
      this.h = var1;
   }

   public void a(float var1, float var2, float var3, float var4) {
      this.i = true;
      this.j = var1;
      this.k = var2;
      this.l = var3;
      this.m = var4;
   }

   public void a() {
      this.i = false;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      float var7;
      float var8;
      float var9;
      float var10;
      if (this.i) {
         var7 = this.j;
         var8 = this.k;
         var9 = this.l;
         var10 = this.m;
      } else {
         var7 = var3;
         var8 = var4;
         var9 = ClickGuiScreen.e();
         var10 = ClickGuiScreen.f();
      }

      Color var11 = ClickGuiColors.a(this.g, 0);
      var2.a(var7, var8 + var10 - this.d - this.e + this.h, var9, this.d, this.f, var11, var11, this.g, this.g, var1);
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      Color var8 = ClickGuiColors.a(this.g, var7);
      Color var9 = ClickGuiColors.a(this.g, 0);
      var2.a(var3, var4 + var6 - this.d - this.e + this.h, var5, this.d, 0.0F, var9, var9, var8, var8, var1);
   }

   @Override
   public void a(float var1, float var2, int var3, int var4) {
   }
}
