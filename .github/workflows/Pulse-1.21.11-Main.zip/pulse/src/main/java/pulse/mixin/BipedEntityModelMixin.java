package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.render.BobjLegSegments;
import pulse.features.emote.render.BobjVanillaPose;
import pulse.features.emote.render.LegSegmentOwner;

@Environment(EnvType.CLIENT)
@Mixin({BipedEntityModel.class})
public abstract class BipedEntityModelMixin {
   @Inject(
      method = {"setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V"},
      at = {@At("HEAD")}
   )
   private void pulse$restoreLegs(BipedEntityRenderState var1, CallbackInfo var2) {
      if (BobjLegSegments.a()) {
         BipedEntityModel var3 = (BipedEntityModel)(Object)this;
         var3.rightLeg.visible = true;
         var3.leftLeg.visible = true;
      }
   }

   @Inject(
      method = {"setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V"},
      at = {@At("TAIL")}
   )
   private void pulse$bobjPoseArmor(BipedEntityRenderState var1, CallbackInfo var2) {
      if (var1 instanceof PlayerEntityRenderState var3) {
         if (EmoteManager.a().b()) {
            MinecraftClient var4 = MinecraftClient.getInstance();
            if (var4.world != null) {
               if (var4.world.getEntityById(var3.id) instanceof AbstractClientPlayerEntity var5) {
                  EmoteManager.ActiveRenderData var8 = EmoteManager.a().c(var5);
                  if (var8 != null) {
                     BipedEntityModel var7 = (BipedEntityModel)(Object)this;
                     BobjVanillaPose.a(var7, var8);
                     if (LegSegmentOwner.c(var3.id)) {
                        var7.rightLeg.visible = false;
                        var7.leftLeg.visible = false;
                     }
                  }
               }
            }
         }
      }
   }
}
