package pulse.mixin;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.render.BobjLegSegments;
import pulse.features.emote.render.LegSegmentOwner;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.RenderHeadLayerEvent;
import pulse.core.api.ILivingStateEntity;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.HitColorModule;
import pulse.features.modules.visuals.SelfNametagModule;
import pulse.utils.render.ColorUtils;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>>
   extends EntityRenderer<T, S> {
   @Shadow
   protected M model;
   @Unique
   private static final Identifier PULSE$HIT_COLOR_TEXTURE = Identifier.of("pulse", "textures/misc/white.png");
   @Unique
   private static boolean pulse$currentStateHurt;

   protected LivingEntityRendererMixin() {
      super(null);
   }

   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("HEAD")}
   )
   private void captureEntity(T var1, S var2, float var3, CallbackInfo var4) {
      ((ILivingStateEntity)var2).pulse$setEntity(var1);
   }

   @Inject(
      method = {"getRenderLayer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$hideBodyForBobj(S var1, boolean var2, boolean var3, boolean var4, CallbackInfoReturnable<RenderLayer> var5) {
      if (var1 instanceof PlayerEntityRenderState var6) {
         if (EmoteManager.a().b()) {
            MinecraftClient var7 = MinecraftClient.getInstance();
            if (var7.world != null) {
               if (var7.world.getEntityById(var6.id) instanceof AbstractClientPlayerEntity var8 && EmoteManager.a().c(var8) != null) {
                  var5.setReturnValue(null);
               }
            }
         }
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At("HEAD")}
   )
   private void pulse$captureHitColorState(S var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5) {
      pulse$currentStateHurt = var1.hurt;
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At("RETURN")}
   )
   private void pulse$clearHitColorState(S var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5) {
      pulse$currentStateHurt = false;
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/RenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      ),
      index = 3,
      require = 0
   )
   private RenderLayer pulse$modifyHitColorLayer(RenderLayer var1) {
      return pulse$shouldApplyHitColor() ? RenderLayers.entityTranslucent(PULSE$HIT_COLOR_TEXTURE) : var1;
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      ),
      index = 3,
      require = 0
   )
   private RenderLayer pulse$modifyHitColorLayerOrdered(RenderLayer var1) {
      return this.pulse$modifyHitColorLayer(var1);
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/RenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      ),
      index = 6,
      require = 0
   )
   private int pulse$modifyHitColor(int var1) {
      if (pulse$shouldApplyHitColor()) {
         Color var2 = ModuleRegistry.m.n();
         return ColorUtils.a(var2.getRed(), var2.getGreen(), var2.getBlue(), 255);
      } else {
         return var1;
      }
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      ),
      index = 6,
      require = 0
   )
   private int pulse$modifyHitColorOrdered(int var1) {
      return this.pulse$modifyHitColor(var1);
   }

   @Unique
   private static boolean pulse$shouldApplyHitColor() {
      HitColorModule var0 = ModuleRegistry.m;
      return var0 != null && var0.o() && pulse$currentStateHurt;
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/model/EntityModel;setAngles(Ljava/lang/Object;)V",
         shift = Shift.AFTER
      )}
   )
   private void onRenderHeadLayer(S var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5) {
      if (ModuleRegistry.aB.l() || ModuleRegistry.aA.l() || ModuleRegistry.w.l()) {
         LivingEntity var6 = ((ILivingStateEntity)var1).pulse$getEntity();
         if (var6 != null) {
            EventHandler.a.post(new RenderHeadLayerEvent(var6, var1, var2, this.model, var3));
         }
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/model/EntityModel;setAngles(Ljava/lang/Object;)V",
         shift = Shift.AFTER
      )}
   )
   private void pulse$updateBobjLegs(S var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5) {
      if (var1 instanceof PlayerEntityRenderState && this.model instanceof PlayerEntityModel var6) {
         int var12 = ((PlayerEntityRenderState)var1).id;
         if (((ILivingStateEntity)var1).pulse$getEntity() instanceof AbstractClientPlayerEntity var9) {
            EmoteManager.ActiveRenderData var10 = EmoteManager.a().c(var9);
            if (var10 == null) {
               this.pulse$releaseSegments(var12);
            } else {
               float[][] var11 = var10.model().a(var10.action(), var10.frame());
               BobjLegSegments.a(var6, var10.model(), var11);
               if (BobjLegSegments.a()) {
                  LegSegmentOwner.a(var12);
               } else {
                  LegSegmentOwner.b(var12);
               }
            }
         } else {
            this.pulse$releaseSegments(var12);
         }
      }
   }

   @Unique
   private void pulse$releaseSegments(int var1) {
      if (LegSegmentOwner.c(var1)) {
         LegSegmentOwner.b(var1);
         BobjLegSegments.b();
      }
   }

   @Inject(
      method = {"hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$selfNametag(T var1, double var2, CallbackInfoReturnable<Boolean> var4) {
      SelfNametagModule var5 = ModuleRegistry.q;
      if (var5 != null && var5.k()) {
         MinecraftClient var6 = MinecraftClient.getInstance();
         if (var1 == var6.player) {
            if (var6.options != null) {
               if (!var6.options.getPerspective().isFirstPerson()) {
                  var4.setReturnValue(true);
               }
            }
         }
      }
   }
}
