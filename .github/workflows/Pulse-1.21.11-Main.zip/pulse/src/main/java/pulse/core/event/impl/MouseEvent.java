package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class MouseEvent extends CancellableEvent {
   private final int a;
   private final int b;
   private final int c;
   private final double d;
   private final double e;

   public MouseEvent(int var1, int var2, int var3, double var4, double var6) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var6;
   }

   @Generated
   public int d() {
      return this.a;
   }

   @Generated
   public int e() {
      return this.b;
   }

   @Generated
   public int f() {
      return this.c;
   }

   @Generated
   public double g() {
      return this.d;
   }

   @Generated
   public double h() {
      return this.e;
   }
}
