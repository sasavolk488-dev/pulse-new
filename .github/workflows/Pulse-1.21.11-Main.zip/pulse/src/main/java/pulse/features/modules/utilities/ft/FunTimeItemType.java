package pulse.features.modules.utilities.ft;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum FunTimeItemType {
   a,
   b,
   c;

   private static FunTimeItemType[] a() {
      return new FunTimeItemType[]{a, b, c};
   }
}
