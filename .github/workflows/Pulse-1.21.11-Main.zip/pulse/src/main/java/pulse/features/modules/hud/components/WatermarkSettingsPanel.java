package pulse.features.modules.hud.components;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.common.BottomFadeElement;
import pulse.ui.clickgui.common.settings.BooleanSettingElement;
import pulse.ui.clickgui.common.settings.SettingsContainer;
import pulse.config.cloud.CloudConfigManager;
import pulse.utils.render.Render;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class WatermarkSettingsPanel {
   public static final float a = 150.0F;
   public static final float b = 30.0F;
   public static final float c = 120.0F;
   public static final float d = 9.5F;
   public static final float e = 7.0F;
   private static final int f = 25;
   private static final float g = 5.0F;
   private final Animation h = new Animation();
   private boolean i = false;
   private boolean j = false;
   private float k = 150.0F;
   private float l;
   private float m;
   private float n;
   private float o;
   private float p;
   private float q;
   private final SettingsContainer r;
   private final BottomFadeElement s;
   private final Animation t = new Animation();
   private boolean u = true;
   private final BooleanSettingElement v;
   private final BooleanSettingElement w;
   private final BooleanSettingElement x;
   private final BooleanSettingElement y;
   private final BooleanSettingElement z;

   public WatermarkSettingsPanel() {
      this.r = new SettingsContainer();
      this.r.b(7.0F);
      this.r.a(120.0F);
      this.v = new BooleanSettingElement("Уведомления", true);
      this.w = new BooleanSettingElement("Музыка", true);
      this.x = new BooleanSettingElement("FPS & Ping", true);
      this.y = new BooleanSettingElement("Ивенты", true);
      this.z = new BooleanSettingElement("Функции", true);
      this.r.a(this.v);
      this.r.a(this.w);
      this.r.a(this.x);
      this.r.a(this.y);
      this.r.a(this.z);
      this.s = new BottomFadeElement(25, 5.0F, 9.5F);
      this.h.d(0.0);
      this.t.d(1.0);
   }

   public void a(float var1, float var2, float var3, float var4) {
      this.a(var1, var2, var3, var4, 150.0F);
   }

   public void a(float var1, float var2, float var3, float var4, float var5) {
      if (this.i && !this.j) {
         this.b();
      } else {
         this.n = var1;
         this.o = var2;
         this.p = var3;
         this.q = var4;
         this.k = var5;
         this.l = var1 + var3 / 2.0F - this.k / 2.0F;
         this.m = var2 + var4 + 11.0F;
         this.i = true;
         this.j = false;
         this.h.a(1.0, 0.25, Easings.F);
      }
   }

   public void a(float var1) {
      this.k = var1;
   }

   public float a() {
      return this.k;
   }

   public void b() {
      if (this.i) {
         this.j = true;
         this.r.g();
         this.h.a(0.0, 0.15000007899163395, Easings.g);
      }
   }

   public void c() {
      this.i = false;
      this.j = false;
      this.h.d(0.0);
      this.r.g();
   }

   public boolean d() {
      return this.i;
   }

   public boolean e() {
      return this.j && this.h.d() && this.h.j() < 0.010000003762125306;
   }

   public void f() {
      this.h.a();
      this.t.a();
      if (this.e()) {
         this.i = false;
         this.j = false;
      }
   }

   public float g() {
      float var1 = this.r.m();
      return Math.max(30.0F, Math.min(var1, 120.0F));
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4) {
      if (this.i) {
         this.f();
         float var5 = (float)this.h.j();
         if (!(var5 < 0.01F)) {
            float var6 = this.g();
            float var7 = Math.max(0.0F, Math.min(1.0F, var5));
            int var8 = (int)(255.0F * var7);
            float var9 = this.l + this.k / 2.0F;
            float var10 = this.m + var6 / 2.0F;
            float var11 = this.k * var7;
            float var12 = var6 * var7;
            float var13 = var9 - var11 / 2.0F;
            float var14 = var10 - var12 / 2.0F;
            Color var15 = ClickGuiColors.a(ClickGuiColors.q, var8);
            Color var16 = ClickGuiColors.a(ClickGuiColors.r, var8);
            var2.a(var13 - 0.5F * var7, var14 - 0.5F * var7, var11 + var7, var12 + var7, 9.5F * var7, var15, var15, var16, var16, var1);
            Color var17 = ClickGuiColors.a(ClickGuiColors.e, var8);
            Color var18 = ClickGuiColors.a(ClickGuiColors.f, var8);
            var2.a(var13, var14, var11, var12, 9.5F * var7, var17, var17, var18, var18, var1);
            TextureRegistry.TextureEntry var19 = TextureRegistry.b("arrow_v");
            if (var19 != null) {
               Identifier var20 = var19.a();
               float var21 = var19.b() / 2.0F * var7;
               float var22 = var19.c() / 2.0F * var7;
               float var23 = var13 + var11 / 2.0F;
               float var24 = var14 - var21 / 2.0F - 1.0F;
               Color var25 = ClickGuiColors.a(ClickGuiColors.aa, var8);
               var1.push();
               var1.translate(var23, var24, 0.0F);
               var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-90.0F));
               var1.translate(-var23, -var24, 0.0F);
               float var26 = var23 - var21 / 2.0F - 0.5F;
               float var27 = var24 - var22 / 2.0F;
               var2.a(var20, var26, var27, var21, var22, var25, var1);
               var1.pop();
            }

            if (var7 > 0.1F) {
               float var28 = var14 + 7.0F * var7;
               float var29 = (var12 - 7.0F - 6.0F) * var7;
               var2.a().a(var13, var28, var11, var29, 9.5F * var7, var1);
               int var30 = this.j ? -1 : var3;
               int var31 = this.j ? -1 : var4;
               this.r.a(var1, var2, var13, var14, var11, var12, var30, var31, var7, var7);
               float var32 = var14 + var12;
               boolean var33 = this.r.e(var32);
               boolean var34 = this.r.d(var12) && !var33;
               if (var34 != this.u) {
                  this.t.a(var34 ? 1.0 : 0.0, 0.15000007899163395, Easings.h);
                  this.u = var34;
               }

               float var35 = (float)this.t.j();
               if (var35 > 0.01F) {
                  this.s.a(var1, var2, var13, var14, var11, var12, var7 * var35);
               }

               var2.a().a(var1);
            }
         }
      }
   }

   public boolean a(int var1, int var2) {
      if (!this.i || this.j || this.h.j() < 0.5) {
         return false;
      } else if (this.d(var1, var2)) {
         boolean var3 = this.r.a(this.l, this.m, this.k, this.g(), var1, var2);
         if (var3) {
            CloudConfigManager.a().h();
         }

         return var3;
      } else if (this.r.d()) {
         this.r.g();
         return true;
      } else {
         return false;
      }
   }

   public boolean b(int var1, int var2) {
      if (!this.i || this.j || this.h.j() < 0.5) {
         return false;
      } else if (!this.d(var1, var2)) {
         if (this.r.d()) {
            this.r.g();
            return true;
         } else {
            return false;
         }
      } else if (this.r.d()) {
         this.r.g();
         return true;
      } else {
         return this.r.b(this.l, this.m, this.k, this.g(), var1, var2);
      }
   }

   public void c(int var1, int var2) {
      if (this.i) {
         this.r.c(var1, var2);
      }
   }

   public void a(int var1, int var2, double var3, double var5) {
      if (this.i && !this.j) {
         this.r.a(this.g(), var1, var2, var3, var5);
      }
   }

   public boolean a(float var1, int var2, int var3) {
      if (!this.i || this.j) {
         return false;
      } else if (this.d(var2, var3)) {
         this.r.a(var1, this.g());
         return true;
      } else {
         return false;
      }
   }

   public boolean d(int var1, int var2) {
      return this.i && !(this.h.j() < 0.5) ? MouseUtil.a(this.l, this.m, this.k, this.g(), (double)var1, (double)var2) : false;
   }

   public void b(float var1, float var2, float var3, float var4) {
      this.n = var1;
      this.o = var2;
      this.p = var3;
      this.q = var4;
   }

   public boolean h() {
      return this.v.c();
   }

   public boolean i() {
      return this.w.c();
   }

   public boolean j() {
      return this.x.c();
   }

   public boolean k() {
      return this.y.c();
   }

   public boolean l() {
      return this.z.c();
   }

   public void a(boolean var1) {
      this.v.a(var1);
   }

   public void b(boolean var1) {
      this.w.a(var1);
   }

   public void c(boolean var1) {
      this.x.a(var1);
   }

   public void d(boolean var1) {
      this.y.a(var1);
   }

   public void e(boolean var1) {
      this.z.a(var1);
   }
}
