package pulse.features.modules;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.hud.ArmorHudModule;
import pulse.features.modules.hud.ClientColorModule;
import pulse.features.modules.hud.CooldownsHudModule;
import pulse.features.modules.hud.EffectNotifyModule;
import pulse.features.modules.hud.HitCounterModule;
import pulse.features.modules.hud.HotkeysModule;
import pulse.features.modules.hud.InventoryHudModule;
import pulse.features.modules.hud.LowHpModule;
import pulse.features.modules.hud.PotionsModule;
import pulse.features.modules.hud.SaturationHudModule;
import pulse.features.modules.hud.TNTTimerModule;
import pulse.features.modules.hud.TargetHUDModule;
import pulse.features.modules.hud.TotemBarModule;
import pulse.features.modules.hud.WatermarkModule;
import pulse.features.modules.utilities.ArmorNotifierModule;
import pulse.features.modules.utilities.AucHelperModule;
import pulse.features.modules.utilities.AutoCommandModule;
import pulse.features.modules.utilities.AutoDuelModule;
import pulse.features.modules.utilities.AutoEatModule;
import pulse.features.modules.utilities.AutoInvestModule;
import pulse.features.modules.utilities.AutoLeaveModule;
import pulse.features.modules.utilities.AutoPotionModule;
import pulse.features.modules.utilities.AutoReconnectModule;
import pulse.features.modules.utilities.AutoRespawnModule;
import pulse.features.modules.utilities.ChatHelperModule;
import pulse.features.modules.utilities.CommandSafeModule;
import pulse.features.modules.utilities.CooldownsModule;
import pulse.features.modules.utilities.ElytraSwapModule;
import pulse.features.modules.utilities.FCHelperModule;
import pulse.features.modules.utilities.FTHelperModule;
import pulse.features.modules.utilities.FastExpModule;
import pulse.features.modules.utilities.FastSwapModule;
import pulse.features.modules.utilities.FreeLookModule;
import pulse.features.modules.utilities.FunTimeRegionsModule;
import pulse.features.modules.utilities.HWHelperModule;
import pulse.features.modules.utilities.HWJoinerModule;
import pulse.features.modules.utilities.HealingHelperModule;
import pulse.features.modules.utilities.ItemHighliterModule;
import pulse.features.modules.utilities.ItemPickupLoggerModule;
import pulse.features.modules.utilities.ItemScrollerModule;
import pulse.features.modules.utilities.ItemSwapModule;
import pulse.features.modules.utilities.LockSlotModule;
import pulse.features.modules.utilities.MaceHelperModule;
import pulse.features.modules.utilities.OptimizationModule;
import pulse.features.modules.utilities.PVPSafeModule;
import pulse.features.modules.utilities.PredictionsModule;
import pulse.features.modules.utilities.RWHelperModule;
import pulse.features.modules.utilities.RWJoinerModule;
import pulse.features.modules.utilities.ShiftTabModule;
import pulse.features.modules.utilities.ShulkerPreviewModule;
import pulse.features.modules.utilities.SoundControllerModule;
import pulse.features.modules.utilities.SprintModule;
import pulse.features.modules.utilities.StreamerModeModule;
import pulse.features.modules.utilities.TapeMouseModule;
import pulse.features.modules.utilities.TotemTrackerModule;
import pulse.features.modules.utilities.ZoomModule;
import pulse.features.modules.utilities.fakeplayer.FakePlayerModule;
import pulse.features.modules.visuals.AnimationsModule;
import pulse.features.modules.visuals.ArrowNametagModule;
import pulse.features.modules.visuals.AspectRatioModule;
import pulse.features.modules.visuals.AtmosphereModule;
import pulse.features.modules.visuals.BlockOverlayModule;
import pulse.features.modules.visuals.BodyGlowModule;
import pulse.features.modules.visuals.ChinaHatModule;
import pulse.features.modules.visuals.CrosshairModule;
import pulse.features.modules.visuals.CustomHandModule;
import pulse.features.modules.visuals.CustomSoundsModule;
import pulse.features.modules.visuals.FullBrightModule;
import pulse.features.modules.visuals.HitBubbleModule;
import pulse.features.modules.visuals.HitColorModule;
import pulse.features.modules.visuals.HitRangeModule;
import pulse.features.modules.visuals.HitboxCustomizerModule;
import pulse.features.modules.visuals.ItemPhysicModule;
import pulse.features.modules.visuals.JumpCirclesModule;
import pulse.features.modules.visuals.KillEffectModule;
import pulse.features.modules.visuals.MotionBlurModule;
import pulse.features.modules.visuals.NimbModule;
import pulse.features.modules.visuals.NoFluidModule;
import pulse.features.modules.visuals.ParticlesModule;
import pulse.features.modules.visuals.RenderTweaksModule;
import pulse.features.modules.visuals.SeeInvisibleModule;
import pulse.features.modules.visuals.SelfNametagModule;
import pulse.features.modules.visuals.TabCustomizerModule;
import pulse.features.modules.visuals.TargetESPModule;
import pulse.features.modules.visuals.TrailsModule;
import pulse.features.modules.visuals.WorldCustomizerModule;
import pulse.features.modules.visuals.WorldParticlesModule;

@Environment(EnvType.CLIENT)
public class ModuleRegistry {
   private static final List<Module> aJ = new ArrayList<>();
   public static final FullBrightModule a = new FullBrightModule();
   public static final TrailsModule b = new TrailsModule();
   public static final ParticlesModule c = new ParticlesModule();
   public static final WorldParticlesModule d = new WorldParticlesModule();
   public static final JumpCirclesModule e = new JumpCirclesModule();
   public static final CustomHandModule f = new CustomHandModule();
   public static final AspectRatioModule g = new AspectRatioModule();
   public static final RenderTweaksModule h = new RenderTweaksModule();
   public static final TargetESPModule i = new TargetESPModule();
   public static final HitboxCustomizerModule j = new HitboxCustomizerModule();
   public static final WorldCustomizerModule k = new WorldCustomizerModule();
   public static final CrosshairModule l = new CrosshairModule();
   public static final HitColorModule m = new HitColorModule();
   public static final NoFluidModule n = new NoFluidModule();
   public static final BlockOverlayModule o = new BlockOverlayModule();
   public static final HitBubbleModule p = new HitBubbleModule();
   public static final SelfNametagModule q = new SelfNametagModule();
   public static final AtmosphereModule r = new AtmosphereModule();
   public static final CustomSoundsModule s = new CustomSoundsModule();
   public static final AnimationsModule t = new AnimationsModule();
   public static final KillEffectModule u = new KillEffectModule();
   public static final ItemPhysicModule v = new ItemPhysicModule();
   public static final BodyGlowModule w = new BodyGlowModule();
   public static final MotionBlurModule x = new MotionBlurModule();
   public static final SeeInvisibleModule y = new SeeInvisibleModule();
   public static final TabCustomizerModule z = new TabCustomizerModule();
   public static final SprintModule A = new SprintModule();
   public static final ElytraSwapModule B = new ElytraSwapModule();
   public static final FTHelperModule C = new FTHelperModule();
   public static final FunTimeRegionsModule D = new FunTimeRegionsModule();
   public static final HealingHelperModule E = new HealingHelperModule();
   public static final PredictionsModule F = new PredictionsModule();
   public static final ItemSwapModule G = new ItemSwapModule();
   public static final FastSwapModule H = new FastSwapModule();
   public static final PVPSafeModule I = new PVPSafeModule();
   public static final CommandSafeModule J = new CommandSafeModule();
   public static final CooldownsModule K = new CooldownsModule();
   public static final AutoEatModule L = new AutoEatModule();
   public static final AutoInvestModule M = new AutoInvestModule();
   public static final AutoPotionModule N = new AutoPotionModule();
   public static final AutoRespawnModule O = new AutoRespawnModule();
   public static final AutoReconnectModule P = new AutoReconnectModule();
   public static final AutoLeaveModule Q = new AutoLeaveModule();
   public static final AutoCommandModule R = new AutoCommandModule();
   public static final FCHelperModule S = new FCHelperModule();
   public static final StreamerModeModule T = new StreamerModeModule();
   public static final HWHelperModule U = new HWHelperModule();
   public static final AucHelperModule V = new AucHelperModule();
   public static final OptimizationModule W = new OptimizationModule();
   public static final MaceHelperModule X = new MaceHelperModule();
   public static final HitRangeModule Y = new HitRangeModule();
   public static final ArrowNametagModule Z = new ArrowNametagModule();
   public static final TapeMouseModule aa = new TapeMouseModule();
   public static final FreeLookModule ab = new FreeLookModule();
   public static final ItemScrollerModule ac = new ItemScrollerModule();
   public static final LockSlotModule ad = new LockSlotModule();
   public static final ZoomModule ae = new ZoomModule();
   public static final TotemTrackerModule af = new TotemTrackerModule();
   public static final ItemHighliterModule ag = new ItemHighliterModule();
   public static final AutoDuelModule ah = new AutoDuelModule();
   public static final RWHelperModule ai = new RWHelperModule();
   public static final ShiftTabModule aj = new ShiftTabModule();
   public static final SoundControllerModule ak = new SoundControllerModule();
   public static final RWJoinerModule al = new RWJoinerModule();
   public static final ItemPickupLoggerModule am = new ItemPickupLoggerModule();
   public static final ChatHelperModule an = new ChatHelperModule();
   public static final FakePlayerModule ao = new FakePlayerModule();
   public static final FastExpModule ap = new FastExpModule();
   public static final ArmorNotifierModule aq = new ArmorNotifierModule();
   public static final ShulkerPreviewModule ar = new ShulkerPreviewModule();
   public static final HWJoinerModule as = new HWJoinerModule();
   public static final PotionsModule at = new PotionsModule();
   public static final TargetHUDModule au = new TargetHUDModule();
   public static final EffectNotifyModule av = new EffectNotifyModule();
   public static final ClientColorModule aw = new ClientColorModule();
   public static final ArmorHudModule ax = new ArmorHudModule();
   public static final HotkeysModule ay = new HotkeysModule();
   public static final WatermarkModule az = new WatermarkModule();
   public static final ChinaHatModule aA = new ChinaHatModule();
   public static final NimbModule aB = new NimbModule();
   public static final CooldownsHudModule aC = new CooldownsHudModule();
   public static final SaturationHudModule aD = new SaturationHudModule();
   public static final InventoryHudModule aE = new InventoryHudModule();
   public static final TotemBarModule aF = new TotemBarModule();
   public static final LowHpModule aG = new LowHpModule();
   public static final HitCounterModule aH = new HitCounterModule();
   public static final TNTTimerModule aI = new TNTTimerModule();

   public static void a() {
      a(a);
      a(b);
      a(c);
      a(d);
      a(e);
      a(f);
      a(g);
      a(h);
      a(i);
      a(j);
      a(k);
      a(l);
      a(m);
      a(n);
      a(o);
      a(p);
      a(q);
      a(r);
      a(s);
      a(t);
      a(u);
      a(v);
      a(w);
      a(x);
      a(y);
      a(z);
      a(A);
      a(B);
      a(C);
      a(D);
      a(E);
      a(F);
      a(G);
      a(H);
      a(I);
      a(J);
      a(K);
      a(L);
      a(M);
      a(N);
      a(O);
      a(P);
      a(Q);
      a(R);
      a(S);
      a(T);
      a(U);
      a(V);
      a(W);
      a(X);
      a(Y);
      a(Z);
      a(aa);
      a(ab);
      a(ac);
      a(ad);
      a(ae);
      a(af);
      a(ag);
      a(ah);
      a(ai);
      a(aj);
      a(ak);
      a(al);
      a(am);
      a(an);
      a(ap);
      a(ar);
      a(as);
      a(ao);
      a(aq);
      a(at);
      a(au);
      a(av);
      a(ax);
      a(ay);
      a(az);
      a(aA);
      a(aB);
      a(aC);
      a(aD);
      a(aE);
      a(aF);
      a(aG);
      a(aH);
      a(aI);

      for (Module var1 : aJ) {
         var1.b();
      }

      aw.b();
   }

   private static void a(Module var0) {
      aJ.add(var0);
   }

   public static List<Module> b() {
      return aJ;
   }

   public static List<Module> a(Category var0) {
      ArrayList var1 = new ArrayList();

      for (Module var3 : aJ) {
         if (var3.i() == var0) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public static Module a(String var0) {
      for (Module var2 : aJ) {
         if (var2.g().equalsIgnoreCase(var0)) {
            return var2;
         }
      }

      return null;
   }

   public static <T extends Module> T a(Class<T> var0) {
      for (Module var2 : aJ) {
         if (var0.isInstance(var2)) {
            return (T)var0.cast(var2);
         }
      }

      return null;
   }
}
