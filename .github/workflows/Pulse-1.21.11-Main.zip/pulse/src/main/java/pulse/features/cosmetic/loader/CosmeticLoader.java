package pulse.features.cosmetic.loader;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import pulse.Pulse;
import pulse.features.cosmetic.model.CosmeticModel;
import pulse.features.cosmetic.model.ModelPosition;

@Environment(EnvType.CLIENT)
public class CosmeticLoader {
   private static final float a = 0.5F;
   private static CosmeticLoader b;
   private final Map<Integer, CosmeticModel> c = new ConcurrentHashMap<>();
   private final Map<String, Identifier> d = new ConcurrentHashMap<>();

   public static CosmeticLoader a() {
      if (b == null) {
         b = new CosmeticLoader();
      }

      return b;
   }

   public CosmeticModel a(String var1) {
      return this.a(var1, null, -1);
   }

   public CosmeticModel a(String var1, Identifier var2) {
      return this.a(var1, var2, -1);
   }

   public CosmeticModel a(String var1, Identifier var2, int var3) {
      try {
         JsonObject var4 = new JsonParser().parse(var1).getAsJsonObject();
         return this.a(var4, var2, var3);
      } catch (Exception var5) {
         Pulse.m().error("Error loading cosmetic from JSON string", (Throwable)var5);
         return null;
      }
   }

   public CosmeticModel a(JsonObject var1) {
      return this.a(var1, null, -1);
   }

   public CosmeticModel a(JsonObject var1, Identifier var2, int var3) {
      try {
         if (var1.has("name") && var1.has("model")) {
            String var4 = var1.get("name").getAsString();
            int var5 = var3 > 0 ? var3 : (var1.has("id") ? var1.get("id").getAsInt() : var4.hashCode());
            int var6 = var1.has("category") ? var1.get("category").getAsInt() : 1;
            CosmeticModel var7 = new CosmeticModel(var4, var5, var6);
            JsonObject var8 = var1.getAsJsonObject("model");
            var7.a(var8.toString());
            if (var2 != null) {
               var7.a(var2);
            } else if (var1.has("texture")) {
               String var9 = var1.get("texture").getAsString();
               Identifier var10 = this.a(var4, var5, var9);
               var7.a(var10);
            }

            this.a(var1, var7);
            this.a(var7);
            if (var1.has("height")) {
               var7.h(var1.get("height").getAsFloat());
            }

            if (var1.has("scale")) {
               var7.a(var1.get("scale").getAsFloat());
            }

            if (var1.has("previewScale")) {
               var7.i(var1.get("previewScale").getAsFloat());
            }

            if (var1.has("previewY")) {
               var7.j(var1.get("previewY").getAsFloat());
            }

            if (var1.has("animation")) {
               var7.a(var1.getAsJsonObject("animation"));
            }

            if (var1.has("textureAnimation")) {
               JsonObject var12 = var1.getAsJsonObject("textureAnimation");
               if (var12.has("frameCount")) {
                  var7.a(var12.get("frameCount").getAsInt());
               }

               if (var12.has("frameHeight")) {
                  var7.b(var12.get("frameHeight").getAsInt());
               }

               if (var12.has("totalHeight")) {
                  var7.c(var12.get("totalHeight").getAsInt());
               }

               if (var12.has("frameTime")) {
                  var7.d(var12.get("frameTime").getAsInt());
               }
            }

            this.c.put(var5, var7);
            Pulse.m().info("Loaded cosmetic: " + var4 + " (id=" + var5 + "), texture=" + var7.e());
            return var7;
         } else {
            Pulse.m().error("Invalid cosmetic JSON: missing name or model");
            return null;
         }
      } catch (Exception var11) {
         Pulse.m().error("Error loading cosmetic", (Throwable)var11);
         return null;
      }
   }

   private void a(JsonObject var1, CosmeticModel var2) {
      if (var1.has("pos")) {
         var2.a(ModelPosition.a(var1.get("pos").getAsInt()));
      }

      if (var1.has("scale")) {
         var2.a(var1.get("scale").getAsFloat());
      }

      if (var1.has("x")) {
         var2.b(var1.get("x").getAsFloat());
      }

      if (var1.has("y")) {
         var2.c(var1.get("y").getAsFloat());
      }

      if (var1.has("z")) {
         var2.d(var1.get("z").getAsFloat());
      }

      if (var1.has("yaw")) {
         var2.e(var1.get("yaw").getAsFloat());
      }

      if (var1.has("pitch")) {
         var2.f(var1.get("pitch").getAsFloat());
      }

      if (var1.has("roll")) {
         var2.g(var1.get("roll").getAsFloat());
      }
   }

   private void a(CosmeticModel var1) {
      if (var1.c() == 3 && var1.f() == ModelPosition.c) {
         var1.c(var1.i() + 0.5F);
      }
   }

   private Identifier a(String var1, int var2, String var3) {
      try {
         String var4 = var1.replace(" ", "").toLowerCase() + "_" + var2;
         String var5 = "cosmetic_" + var4;
         if (this.d.containsKey(var5)) {
            return this.d.get(var5);
         } else {
            byte[] var6 = Base64.getDecoder().decode(var3);
            ByteArrayInputStream var7 = new ByteArrayInputStream(var6);
            NativeImage var8 = NativeImage.read(var7);
            Identifier var9 = Identifier.of("pulse", "cosmetic/" + var4);
            Runnable var10 = () -> {
               NativeImageBackedTexture var4x = new NativeImageBackedTexture(var9::toString, var8);
               MinecraftClient.getInstance().getTextureManager().registerTexture(var9, var4x);
               this.d.put(var5, var9);
               Pulse.m().info("Registered texture: " + var9 + " (" + var8.getWidth() + "x" + var8.getHeight() + ")");
            };
            if (MinecraftClient.getInstance().isOnThread()) {
               var10.run();
            } else {
               MinecraftClient.getInstance().execute(var10);
            }

            this.d.put(var5, var9);
            return var9;
         }
      } catch (Exception var11) {
         Pulse.m().error("Failed to load texture for cosmetic: " + var1, (Throwable)var11);
         return null;
      }
   }

   public CosmeticModel a(int var1) {
      return this.c.get(var1);
   }

   public Map<Integer, CosmeticModel> b() {
      return this.c;
   }

   public void a(InputStream var1) {
      try {
         ByteArrayOutputStream var2 = new ByteArrayOutputStream();
         byte[] var3 = new byte[1024];

         int var4;
         while ((var4 = var1.read(var3)) != -1) {
            var2.write(var3, 0, var4);
         }

         String var5 = var2.toString(StandardCharsets.UTF_8.name());
         this.a(var5);
      } catch (Exception var6) {
         Pulse.m().error("Error loading cosmetic from input stream", (Throwable)var6);
      }
   }
}
