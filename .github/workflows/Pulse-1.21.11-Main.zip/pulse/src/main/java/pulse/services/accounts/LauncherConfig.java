package pulse.services.accounts;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
final class LauncherConfig {
   private static final Gson a = new GsonBuilder().setPrettyPrinting().create();
   private static final Path b = Path.of("C:", "PulseVisuals", "launcher");
   private static Path c;

   private LauncherConfig() {
   }

   static Path a() {
      if (c != null) {
         return c;
      } else {
         Path var0 = MinecraftClient.getInstance().runDirectory.toPath().toAbsolutePath().normalize();
         Path var1 = var0.getParent();
         ArrayList<Path> var2 = new ArrayList<>();
         if (var1 != null) {
            var2.add(var1.resolve("launcher").resolve("config.json"));
         }

         var2.add(b.resolve("config.json"));

         for (Path var4 : var2) {
            if (Files.isRegularFile(var4)) {
               c = var4;
               Pulse.m().info("AltManager: конфиг лаунчера — " + var4);
               return c;
            }
         }

         for (Path var7 : var2) {
            Path var5 = var7.getParent();
            if (var5 != null && Files.isDirectory(var5)) {
               c = var7;
               Pulse.m().info("AltManager: конфиг лаунчера будет создан — " + var7);
               return c;
            }
         }

         Pulse.m().warn("AltManager: конфиг лаунчера не найден, аккаунты не сохраняются");
         return null;
      }
   }

   static JsonObject b() {
      try {
         Path var0 = a();
         if (var0 != null && Files.exists(var0)) {
            String var1 = new String(Files.readAllBytes(var0), StandardCharsets.UTF_8);
            JsonElement var2 = JsonParser.parseString(var1);
            if (var2.isJsonObject()) {
               return var2.getAsJsonObject();
            }
         }
      } catch (Exception var3) {
         Pulse.m().error("Не удалось прочитать config.json лаунчера", (Throwable)var3);
      }

      return new JsonObject();
   }

   static List<AltAccount> a(JsonObject var0) {
      ArrayList<AltAccount> var1 = new ArrayList<>();
      if (var0.has("accounts") && var0.get("accounts").isJsonArray()) {
         for (JsonElement var3 : var0.getAsJsonArray("accounts")) {
            if (var3.isJsonObject()) {
               JsonObject var4 = var3.getAsJsonObject();
               String var5 = a(var4, "name");
               if (var5 != null && !var5.isEmpty()) {
                  boolean var6 = var4.has("microsoft") && var4.get("microsoft").getAsBoolean();
                  AltAccount var7 = new AltAccount(var6 ? AltAccount.Type.b : AltAccount.Type.a, var5, a(a(var4, "uuid")), a(var4, "added"));
                  var7.d(a(a(var4, "ms_refresh")));
                  var1.add(var7);
               }
            }
         }

         return var1;
      } else {
         return var1;
      }
   }

   static int b(JsonObject var0) {
      try {
         if (var0.has("selected_account")) {
            return var0.get("selected_account").getAsInt();
         }
      } catch (Exception var2) {
      }

      return -1;
   }

   static void a(List<AltAccount> var0, int var1) {
      Path var2 = a();
      if (var2 != null) {
         try {
            JsonObject var3 = b();
            JsonArray var4 = new JsonArray();

            for (AltAccount var6 : var0) {
               if (!var6.e()) {
                  JsonObject var7 = new JsonObject();
                  var7.addProperty("added", var6.d());
                  var7.addProperty("microsoft", var6.a() == AltAccount.Type.b);
                  var7.addProperty("ms_refresh", var6.g() != null ? var6.g() : "");
                  var7.addProperty("name", var6.b());
                  var7.addProperty("uuid", var6.c() != null ? var6.c() : "");
                  var4.add(var7);
               }
            }

            var3.add("accounts", var4);
            if (var1 >= 0) {
               var3.addProperty("selected_account", var1);
            }

            Files.write(var2, a.toJson((JsonElement)var3).getBytes(StandardCharsets.UTF_8));
         } catch (Exception var8) {
            Pulse.m().error("Не удалось сохранить config.json лаунчера", (Throwable)var8);
         }
      }
   }

   private static String a(JsonObject var0, String var1) {
      try {
         if (var0.has(var1) && !var0.get(var1).isJsonNull()) {
            return var0.get(var1).getAsString();
         }
      } catch (Exception var3) {
      }

      return null;
   }

   private static String a(String var0) {
      return var0 != null && !var0.isEmpty() ? var0 : null;
   }
}
