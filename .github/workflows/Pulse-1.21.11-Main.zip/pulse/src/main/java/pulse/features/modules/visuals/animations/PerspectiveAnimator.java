package pulse.features.modules.visuals.animations;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.utils.animation.util.Easing;
import pulse.utils.animation.util.Easings;

@Environment(EnvType.CLIENT)
public class PerspectiveAnimator {
   private float a = 4.0F;
   private float b = 4.0F;
   private float c = 4.0F;
   private long d = 0L;
   private long e = 300L;
   private final Easing f;
   private boolean g = false;

   public PerspectiveAnimator() {
      this.f = Easings.C;
   }

   public void a() {
      if (this.d != 0L) {
         long var1 = System.currentTimeMillis();
         double var3 = var1 - this.d;
         double var5 = this.e;
         if (var3 >= var5) {
            this.a = this.c;
            this.d = 0L;
         } else {
            double var7 = var3 / var5;
            double var9 = this.f.ease(var7);
            this.a = (float)(this.b + (this.c - this.b) * var9);
         }
      }
   }

   public void a(boolean var1, long var2) {
      this.e = Math.max(1L, var2);
      if (var1 && !this.g) {
         this.b = 1.0F;
         this.c = 4.0F;
         this.a = 1.0F;
         this.d = System.currentTimeMillis();
      } else if (!var1 && this.g) {
         this.b = this.a;
         this.c = 1.0F;
         this.d = System.currentTimeMillis();
      }

      this.g = var1;
   }

   public float b() {
      return this.a;
   }

   public boolean c() {
      return this.d != 0L;
   }

   public void d() {
      this.a = 4.0F;
      this.b = 4.0F;
      this.c = 4.0F;
      this.d = 0L;
      this.g = false;
   }
}
