package pulse.mixin;

import java.net.URI;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.ClickEvent.OpenUrl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@Environment(EnvType.CLIENT)
@Mixin({Screen.class})
public class ScreenMixin {
   @Inject(
      method = {"handleClickEvent"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void onHandleClickEvent(ClickEvent var0, MinecraftClient var1, Screen var2, CallbackInfo var3) {
      if (var0 instanceof OpenUrl var4) {
         URI var5 = var4.uri();
         if (var5 != null) {
            String var6 = var5.toString();
            if (var6.startsWith("pulse://")) {
               try {
                  String var7 = var6.substring("pulse://".length());
                  if (var7.startsWith("friendaccept/")) {
                     int var8 = Integer.parseInt(var7.substring("friendaccept/".length()));
                     RealtimeSyncServiceV2.L().a(var8, true);
                     var3.cancel();
                  } else if (var7.startsWith("frienddecline/")) {
                     int var10 = Integer.parseInt(var7.substring("frienddecline/".length()));
                     RealtimeSyncServiceV2.L().a(var10, false);
                     var3.cancel();
                  } else if (var7.startsWith("groupaccept/")) {
                     String var11 = var7.substring("groupaccept/".length());
                     RealtimeSyncServiceV2.L().a(var11, true);
                     var3.cancel();
                  } else if (var7.startsWith("groupdecline/")) {
                     String var12 = var7.substring("groupdecline/".length());
                     RealtimeSyncServiceV2.L().a(var12, false);
                     var3.cancel();
                  }
               } catch (NumberFormatException var9) {
               }
            }
         }
      }
   }
}
