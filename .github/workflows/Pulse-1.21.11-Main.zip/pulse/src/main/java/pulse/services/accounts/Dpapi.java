package pulse.services.accounts;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
final class Dpapi {
   private static final byte[] a = new byte[]{1, 0, 0, 0, -48, -116, -99, -33, 1, 21, -47, 17, -116, 122, 0, -64, 79, -62, -105, -21};
   private static final long b = 10L;

   private Dpapi() {
   }

   static boolean a(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         try {
            byte[] var1 = Base64.getDecoder().decode(var0);
            if (var1.length < a.length) {
               return false;
            } else {
               for (int var2 = 0; var2 < a.length; var2++) {
                  if (var1[var2] != a[var2]) {
                     return false;
                  }
               }

               return true;
            }
         } catch (IllegalArgumentException var3) {
            return false;
         }
      } else {
         return false;
      }
   }

   static String b(String var0) {
      return !a(var0)
         ? null
         : a(
            "$blob = [Convert]::FromBase64String($arg); $clear = [System.Security.Cryptography.ProtectedData]::Unprotect($blob, $null, 'CurrentUser'); [Console]::Out.Write([Text.Encoding]::UTF8.GetString($clear))",
            var0
         );
   }

   static String c(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         String var1 = a(
            "$clear = [Text.Encoding]::UTF8.GetBytes($arg); $blob = [System.Security.Cryptography.ProtectedData]::Protect($clear, $null, 'CurrentUser'); [Console]::Out.Write([Convert]::ToBase64String($blob))",
            var0
         );
         return a(var1) ? var1 : null;
      } else {
         return null;
      }
   }

   private static String a(String var0, String var1) {
      if (!System.getProperty("os.name", "").toLowerCase().contains("win")) {
         return null;
      } else {
         Process var2 = null;

         Object var23;
         try {
            String var3 = "$ErrorActionPreference = 'Stop'; Add-Type -AssemblyName System.Security; $arg = [Console]::In.ReadLine(); " + var0;
            var2 = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", var3)
               .redirectErrorStream(false)
               .start();

            try (OutputStreamWriter var21 = new OutputStreamWriter(var2.getOutputStream(), StandardCharsets.UTF_8)) {
               var21.write(var1);
               var21.write(System.lineSeparator());
            }

            StringBuilder var22 = new StringBuilder();
            BufferedReader var5 = new BufferedReader(new InputStreamReader(var2.getInputStream(), StandardCharsets.UTF_8));

            int var6;
            try {
               while ((var6 = var5.read()) != -1) {
                  var22.append((char)var6);
               }
            } catch (Throwable var18) {
               try {
                  var5.close();
               } catch (Throwable var15) {
                  var18.addSuppressed(var15);
               }

               throw var18;
            }

            var5.close();
            if (!var2.waitFor(10L, TimeUnit.SECONDS)) {
               var2.destroyForcibly();
               return null;
            }

            if (var2.exitValue() == 0) {
               String var24 = var22.toString().trim();
               return var24.isEmpty() ? null : var24;
            }

            var23 = null;
         } catch (Exception var19) {
            Pulse.m().warn("DPAPI через PowerShell недоступен: " + var19.getMessage());
            return null;
         } finally {
            if (var2 != null && var2.isAlive()) {
               var2.destroyForcibly();
            }
         }

         return (String)var23;
      }
   }
}
