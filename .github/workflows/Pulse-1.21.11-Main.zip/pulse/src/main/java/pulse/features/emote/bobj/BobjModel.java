package pulse.features.emote.bobj;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class BobjModel {
   private final List<BobjModel.Bone> a;
   private final List<BobjModel.Vertex> b;
   private final Map<String, Integer> c;

   BobjModel(List<BobjModel.Bone> var1, List<BobjModel.Vertex> var2) {
      this.a = List.copyOf(var1);
      this.b = List.copyOf(var2);
      HashMap var3 = new HashMap();

      for (BobjModel.Bone var5 : this.a) {
         var3.put(var5.b, var5.a);
      }

      this.c = Map.copyOf(var3);
   }

   public List<BobjModel.Vertex> a() {
      return this.b;
   }

   public int a(String var1) {
      return this.c.getOrDefault(var1, -1);
   }

   public float[] a(int var1) {
      BobjModel.Bone var2 = this.a.get(var1);
      return new float[]{var2.f, var2.g, var2.h};
   }

   public float[][] a(BobjAction var1, float var2) {
      float[][] var3 = new float[this.a.size()][];
      float[][] var4 = new float[this.a.size()][];

      for (BobjModel.Bone var6 : this.a) {
         this.a(var6, var1, var2, var3);
         var4[var6.a] = BobjMath.a(var3[var6.a], var6.e);
      }

      return var4;
   }

   private float[] a(BobjModel.Bone var1, BobjAction var2, float var3, float[][] var4) {
      if (var4[var1.a] != null) {
         return var4[var1.a];
      } else {
         float var5 = var2.a(var1.b, "location", 0, var3, 0.0F);
         float var6 = var2.a(var1.b, "location", 1, var3, 0.0F);
         float var7 = var2.a(var1.b, "location", 2, var3, 0.0F);
         float var8 = var2.a(var1.b, "rotation", 0, var3, 0.0F);
         float var9 = var2.a(var1.b, "rotation", 1, var3, 0.0F);
         float var10 = var2.a(var1.b, "rotation", 2, var3, 0.0F);
         float var11 = var2.a(var1.b, "scale", 0, var3, 1.0F);
         float var12 = var2.a(var1.b, "scale", 1, var3, 1.0F);
         float var13 = var2.a(var1.b, "scale", 2, var3, 1.0F);
         float[] var14 = BobjMath.a(var1.d, BobjMath.a(var5, var6, var7));
         var14 = BobjMath.a(var14, BobjMath.c(var10));
         var14 = BobjMath.a(var14, BobjMath.b(var9));
         var14 = BobjMath.a(var14, BobjMath.a(var8));
         var14 = BobjMath.a(var14, BobjMath.b(var11, var12, var13));
         if (var1.c >= 0) {
            var14 = BobjMath.a(this.a(this.a.get(var1.c), var2, var3, var4), var14);
         }

         var4[var1.a] = var14;
         return var14;
      }
   }

   @Environment(EnvType.CLIENT)
   static final class Bone {
      final int a;
      final String b;
      final int c;
      final float[] d;
      final float[] e;
      final float f;
      final float g;
      final float h;

      Bone(int var1, String var2, int var3, float[] var4, float[] var5) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var5;
         this.e = BobjMath.a(var4);
         this.f = var4[3];
         this.g = var4[7];
         this.h = var4[11];
      }
   }

   @Environment(EnvType.CLIENT)
   public static final class Vertex {
      public final float a;
      public final float b;
      public final float c;
      public final float d;
      public final float e;
      public final float f;
      public final float g;
      public final float h;
      public final int[] i;
      public final float[] j;

      Vertex(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, int[] var9, float[] var10) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
         this.f = var6;
         this.g = var7;
         this.h = var8;
         this.i = var9;
         this.j = var10;
      }
   }
}
