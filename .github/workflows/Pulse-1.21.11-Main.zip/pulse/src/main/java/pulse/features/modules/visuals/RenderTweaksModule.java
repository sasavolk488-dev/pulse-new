package pulse.features.modules.visuals;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Render Tweaks",
   b = "Отключает различные элементы рендеринга",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class RenderTweaksModule extends Module {
   private static final String[] a = new String[]{
      "Погода", "Тряска урона", "Оверлей огня", "Анимация тотема", "Скорборд", "Боссбар", "Черные сердца", "Пузырьки воздуха", "Свечение игроков"
   };
   private final ModeSetting b = new ModeSetting("Твики", a, new int[]{0, 1, 2, 3, 6, 7, 8});

   public boolean n() {
      return this.k() && this.b.c("Погода");
   }

   public boolean o() {
      return this.k() && this.b.c("Тряска урона");
   }

   public boolean p() {
      return this.k() && this.b.c("Оверлей огня");
   }

   public boolean q() {
      return this.k() && this.b.c("Анимация тотема");
   }

   public boolean r() {
      return this.k() && this.b.c("Скорборд");
   }

   public boolean s() {
      return this.k() && this.b.c("Боссбар");
   }

   public boolean t() {
      return this.k() && this.b.c("Черные сердца");
   }

   public boolean v() {
      return this.k() && this.b.c("Пузырьки воздуха");
   }

   public boolean w() {
      return this.k() && this.b.c("Свечение игроков");
   }
}
