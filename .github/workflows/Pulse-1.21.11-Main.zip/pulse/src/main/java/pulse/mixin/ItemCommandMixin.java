package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import pulse.utils.render.vertex.PulseTintedItemCommand;

@Environment(EnvType.CLIENT)
@Mixin(
   targets = {"net/minecraft/client/render/command/OrderedRenderCommandQueueImpl$ItemCommand"}
)
public abstract class ItemCommandMixin implements PulseTintedItemCommand {
   @Unique
   private int pulse$tint = 0;

   @Override
   public void pulse$setTint(int var1) {
      this.pulse$tint = var1;
   }

   @Override
   public int pulse$getTint() {
      return this.pulse$tint;
   }
}
