package pulse.mixin;

import java.awt.Color;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ArmorHudModule;
import pulse.features.modules.utilities.AucHelperModule;
import pulse.features.modules.utilities.CooldownsModule;
import pulse.features.modules.utilities.HWHelperModule;
import pulse.features.modules.utilities.HealingHelperModule;
import pulse.features.modules.utilities.ItemHighliterModule;
import pulse.features.modules.utilities.MaceHelperModule;

@Environment(EnvType.CLIENT)
@Mixin({DrawContext.class})
public abstract class DrawContextMixin {
   @Inject(
      method = {"drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;III)V"},
      at = {@At("HEAD")}
   )
   private void pulse$drawMaceCharge(@Nullable LivingEntity var1, @Nullable World var2, ItemStack var3, int var4, int var5, int var6, CallbackInfo var7) {
      if (!var3.isEmpty()) {
         MaceHelperModule var8 = ModuleRegistry.X;
         if (var8 != null && var8.k() && var8.r()) {
            if (var8.o() && var8.a(var3)) {
               Color var9 = var8.a(var8.p());
               int var10 = new Color(var9.getRed(), var9.getGreen(), var9.getBlue(), 110).getRGB();
               DrawContext var11 = (DrawContext)(Object)this;
               var11.fill(RenderPipelines.GUI, var4, var5, var4 + 16, var5 + 16, var10);
            }
         }
      }
   }

   @Inject(
      method = {"drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;III)V"},
      at = {@At("HEAD")}
   )
   private void pulse$drawSpawnerHighlight(@Nullable LivingEntity var1, @Nullable World var2, ItemStack var3, int var4, int var5, int var6, CallbackInfo var7) {
      if (!var3.isEmpty()) {
         HWHelperModule var8 = ModuleRegistry.U;
         if (var8 != null) {
            int var9 = var8.c(var3);
            if (var9 != 0) {
               DrawContext var10 = (DrawContext)(Object)this;
               var10.fill(RenderPipelines.GUI, var4, var5, var4 + 16, var5 + 16, var9);
            }
         }
      }
   }

   @Inject(
      method = {"drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"},
      at = {@At("TAIL")}
   )
   private void pulse$drawHealingCooldown(TextRenderer var1, ItemStack var2, int var3, int var4, @Nullable String var5, CallbackInfo var6) {
      if (!var2.isEmpty()) {
         CooldownsModule var7 = ModuleRegistry.K;
         if (var7 != null && var7.k()) {
            if (CooldownsModule.a(var2)) {
               if (var7.b(var2.getItem())) {
                  float var8 = var7.a(var2.getItem());
                  if (!(var8 <= 0.0F)) {
                     DrawContext var9 = (DrawContext)(Object)this;
                     int var10 = var4 + MathHelper.floor(16.0F * (1.0F - var8));
                     int var11 = var10 + MathHelper.ceil(16.0F * var8);
                     var9.fill(RenderPipelines.GUI, var3, var10, var3 + 16, var11, Integer.MAX_VALUE);
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"},
      at = {@At("TAIL")}
   )
   private void pulse$drawReissueCooldown(TextRenderer var1, ItemStack var2, int var3, int var4, @Nullable String var5, CallbackInfo var6) {
      if (!var2.isEmpty()) {
         AucHelperModule var7 = ModuleRegistry.V;
         if (var7 != null && var7.k() && var7.a) {
            boolean var8 = var2.getItem() == Items.CLOCK;
            boolean var9 = var2.getItem() == Items.PAPER && var2.getName().getString().contains("Перевыставить");
            if (var8 || var9) {
               MinecraftClient var10 = MinecraftClient.getInstance();
               if (var10.currentScreen != null && var10.player != null && var10.player.currentScreenHandler != null) {
                  String var11;
                  try {
                     var11 = var10.currentScreen.getTitle().getString();
                  } catch (Exception var23) {
                     return;
                  }

                  if (var11.contains("Хранилище")) {
                     long var12 = var7.b.a(0L) ? var7.c : 0L;

                     for (int var14 = 1; var14 <= var7.c / 1000 + 1; var14++) {
                        if (!var7.b.a(var14 * 1000)) {
                           var12 = (var14 - 1) * 1000;
                           break;
                        }
                     }

                     int var24 = Math.max(0, (var7.c - (int)var12) / 1000);
                     if (var24 > 0) {
                        float var15 = Math.max(0.0F, 1.0F - (float)var12 / var7.c);
                        DrawContext var16 = (DrawContext)(Object)this;
                        byte var17 = 16;
                        int var18 = MathHelper.ceil(var17 * var15);
                        int var19 = var4 + (var17 - var18);
                        var16.fill(RenderPipelines.GUI, var3, var19, var3 + 16, var19 + var18, Integer.MAX_VALUE);
                        String var20 = String.valueOf(var24);
                        int var21 = var3 + 8 - var1.getWidth(var20) / 2;
                        int var22 = var4 + 8 - 9 / 2;
                        var16.drawText(var1, var20, var21, var22, -1, true);
                     }
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;III)V"},
      at = {@At("HEAD")}
   )
   private void pulse$drawItemHighlight(@Nullable LivingEntity var1, @Nullable World var2, ItemStack var3, int var4, int var5, int var6, CallbackInfo var7) {
      if (!var3.isEmpty()) {
         ItemHighliterModule var8 = ModuleRegistry.ag;
         if (var8 != null && var8.k() && var8.a(var3)) {
            Color var9 = var8.a(var3.getItem());
            int var10 = var8.n();
            int var11 = new Color(var9.getRed(), var9.getGreen(), var9.getBlue(), var10).getRGB();
            DrawContext var12 = (DrawContext)(Object)this;
            var12.fill(RenderPipelines.GUI, var4, var5, var4 + 16, var5 + 16, var11);
         }
      }
   }

   @Inject(
      method = {"drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"},
      at = {@At("TAIL")}
   )
   private void pulse$drawHealingHighlight(TextRenderer var1, ItemStack var2, int var3, int var4, @Nullable String var5, CallbackInfo var6) {
      if (!var2.isEmpty()) {
         HealingHelperModule var7 = ModuleRegistry.E;
         if (var7 != null && var7.k() && var7.a(var2)) {
            var var8 = var7.n();
            int var9 = var8.stream().mapToInt(var7::a).max().orElse(1);
            int var10 = var7.a(var2.getItem());
            float var11 = MathHelper.clamp((float)var10 / var9, 0.0F, 1.0F);
            int var12 = (int)(255.0F * (1.0F - var11));
            int var13 = (int)(255.0F * var11);
            int var14 = (int)((Math.sin(System.currentTimeMillis() / 100.0) * 0.5 + 0.5) * 100.0) + 50;
            int var15 = (var14 & 0xFF) << 24 | (var12 & 0xFF) << 16 | (var13 & 0xFF) << 8;
            DrawContext var16 = (DrawContext)(Object)this;
            var16.fill(RenderPipelines.GUI, var3, var4, var3 + 16, var4 + 16, var15);
         }
      }
   }

   @Inject(
      method = {"drawItemBar"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$suppressArmorBar(ItemStack var1, int var2, int var3, CallbackInfo var4) {
      if (ArmorHudModule.b) {
         var4.cancel();
      }
   }
}
