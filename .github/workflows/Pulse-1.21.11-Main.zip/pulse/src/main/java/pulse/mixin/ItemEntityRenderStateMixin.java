package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import pulse.core.api.IItemEntityState;

@Environment(EnvType.CLIENT)
@Mixin({ItemEntityRenderState.class})
public abstract class ItemEntityRenderStateMixin implements IItemEntityState {
   @Unique
   private boolean pulse$onGround;
   @Unique
   private boolean pulse$shouldScale;

   @Override
   public boolean pulse$isOnGround() {
      return this.pulse$onGround;
   }

   @Override
   public void pulse$setOnGround(boolean var1) {
      this.pulse$onGround = var1;
   }

   @Override
   public boolean pulse$isShouldScale() {
      return this.pulse$shouldScale;
   }

   @Override
   public void pulse$setShouldScale(boolean var1) {
      this.pulse$shouldScale = var1;
   }
}
