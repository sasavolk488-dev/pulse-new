package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.ui.menu.MenuState;
import pulse.ui.menu.PulseMainMenuScreen;

@Environment(EnvType.CLIENT)
@Mixin({TitleScreen.class})
public class TitleScreenMixin {
   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void onInit(CallbackInfo var1) {
      TitleScreen var2 = (TitleScreen)(Object)this;
      Screens.getButtons(var2).add(ButtonWidget.builder(Text.literal("PulseVisuals меню"), var0 -> {
         MenuState.a(true);
         MinecraftClient.getInstance().setScreen(new PulseMainMenuScreen());
      }).dimensions(var2.width - 110 - 4, 4, 110, 20).build());
   }
}
