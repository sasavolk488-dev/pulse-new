package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class AttackEvent extends Event {
   private final Entity a;

   public AttackEvent(Entity var1) {
      this.a = var1;
   }

   @Generated
   public Entity a() {
      return this.a;
   }
}
