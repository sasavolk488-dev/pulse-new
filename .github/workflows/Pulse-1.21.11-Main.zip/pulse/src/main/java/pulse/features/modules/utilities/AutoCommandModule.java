package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.ArrayDeque;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Queue;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.CommandListSetting;

@ModuleInfo(
   a = "Auto Command",
   b = "Автоотправка своих команд, у каждой свой интервал",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoCommandModule extends Module {
   private static final long a = 1000L;
   private final CommandListSetting b = new CommandListSetting("Команды");
   private final Map<CommandListSetting.Entry, Long> c = new IdentityHashMap<>();
   private final Queue<String> f = new ArrayDeque<>();
   private long g;

   @Compile
   @Override
      public void e() {
      super.e();
      this.c.clear();
      this.f.clear();
   }

   @EventHandler
   @Compile
   private void a(UpdateEvent var1) {
      var schedule = this.c;
      var queue = this.f;
      CommandListSetting commands = this.b;
      if (d.player == null || d.world == null) {
         schedule.clear();
         queue.clear();
         return;
      }
      if (d.currentScreen instanceof pulse.ui.clickgui.ClickGuiScreen) {
         return;
      }
      long now = System.currentTimeMillis();
      this.a(now);
      boolean empty;
      try {
         empty = queue.isEmpty();
      } catch (RuntimeException | Error failure) {
         if (now >= 1000L) {
            this.g = now;
         }
         throw failure;
      }
      if (!empty) {
         if (now - this.g >= 1000L) {
            this.g = now;
            this.b(queue.poll());
         }
         return;
      }
      for (CommandListSetting.Entry entry : commands.b()) {
         String command = this.a(entry.a());
         if (command == null) {
            continue;
         }
         Long last = schedule.get(entry);
         if (last != null && now - last.longValue() >= (long)entry.b() * 1000L) {
            schedule.put(entry, now);
            queue.add(command);
         }
      }
      try {
         empty = queue.isEmpty();
      } catch (RuntimeException | Error failure) {
         this.g = now;
         throw failure;
      }
      if (!empty) {
         this.g = now;
         this.b(queue.poll());
      }
   }

   private void a(long var1) {
      this.c.keySet().retainAll(this.b.b());

      for (CommandListSetting.Entry var4 : this.b.b()) {
         this.c.putIfAbsent(var4, var1);
      }
   }

   private String a(String var1) {
      if (var1 == null) {
         return null;
      } else {
         String var2 = var1.trim();
         return !var2.isEmpty() && !var2.equals("/") ? var2 : null;
      }
   }

   private void b(String var1) {
      if (d.player != null && var1 != null) {
         if (var1.startsWith("/")) {
            d.player.networkHandler.sendChatCommand(var1.substring(1));
         } else {
            d.player.networkHandler.sendChatMessage(var1);
         }
      }
   }

   static {
      NativeMethodLookup.lookup(AutoCommandModule.class, 46);
   }
}
