package pulse.features.emote;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.sound.sampled.AudioFormat.Encoding;
import javazoom.spi.mpeg.sampled.convert.MpegFormatConversionProvider;
import javazoom.spi.mpeg.sampled.file.MpegAudioFileReader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.Channel;
import net.minecraft.client.sound.OggAudioStream;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.client.sound.StaticSound;
import org.lwjgl.BufferUtils;
import pulse.Pulse;
import pulse.mixin.accessor.SoundManagerAccessor;
import pulse.mixin.accessor.SoundSystemAccessor;

@Environment(EnvType.CLIENT)
public final class EmoteAudio {
   private static final int a = 30000;
   private static final int b = 12582912;
   private static final Map<String, StaticSound> c = new ConcurrentHashMap<>();
   private static final Map<String, EmoteAudio.Encoded> d = new ConcurrentHashMap<>();
   private static volatile Channel e;
   private static volatile boolean f;

   public static void a() {
      f = true;
      Pulse.m().info("[Emote] звук перезапущен — буферы музыки пересоберём");
   }

   private static Channel c() {
      try {
         SoundSystem var0 = ((SoundManagerAccessor)MinecraftClient.getInstance().getSoundManager()).pulse$getSoundSystem();
         return var0 == null ? null : ((SoundSystemAccessor)var0).pulse$getChannel();
      } catch (Throwable var1) {
         return null;
      }
   }

   private EmoteAudio() {
   }

   public static StaticSound a(String var0) {
      if (var0 == null) {
         return null;
      } else {
         Channel var1 = c();
         if (f) {
            c.clear();
            f = false;
            e = var1;
         }

         if (var1 != e) {
            c.clear();
            e = var1;
         }

         StaticSound var2 = c.get(var0);
         if (var2 != null) {
            return var2;
         } else {
            EmoteAudio.Encoded var3 = d.get(var0);
            if (var3 == null) {
               return null;
            } else {
               try {
                  EmoteAudio.Decoded var4 = a(var3.data(), var3.ext(), "музыка " + var0);
                  if (var4 == null) {
                     return null;
                  } else {
                     c.put(var0, var4.sound());
                     return var4.sound();
                  }
               } catch (Throwable var5) {
                  Pulse.m().warn("[Emote] музыка {} не пересобралась: {}", var0, var5.toString());
                  return null;
               }
            }
         }
      }
   }

   public static void b() {
      c.clear();
      d.clear();
      e = null;
   }

   public static void a(String var0, byte[] var1, String var2) {
      if (var0 != null && var1 != null && var1.length != 0) {
         d.put(var0, new EmoteAudio.Encoded(var1, var2));

         try {
            EmoteAudio.Decoded var3 = a(var1, var2, "музыка " + var0);
            if (var3 != null) {
               c.put(var0, var3.sound());
               e = c();
            }
         } catch (Throwable var4) {
            Pulse.m().warn("[Emote] музыка {} не декодировалась ({}): {}", var0, var2, var4.toString());
         }
      }
   }

   public static EmoteAudio.Decoded a(byte[] var0, String var1, String var2) throws Exception {
      EmoteAudio.Sample var3 = a(var0, var1);
      if (var3 == null) {
         return null;
      } else {
         int var4 = var3.pcm.length / (2 * var3.format.getChannels());
         int var5 = (int)(var4 * 1000L / (long)var3.format.getSampleRate());
         if (var5 > 30000) {
            Pulse.m().warn("[Emote] {} длиной {}мс превышает лимит {}мс — пропуск", var2, var5, 30000);
            return null;
         } else {
            Pulse.m().info("{}: {} ({} мс, {} Гц) готова", var2, var1, var5, (int)var3.format.getSampleRate());
            return new EmoteAudio.Decoded(a(var3), var5);
         }
      }
   }

   private static EmoteAudio.Sample a(byte[] var0, String var1) throws Exception {
      if ("ogg".equalsIgnoreCase(var1)) {
         EmoteAudio.Sample var17;
         try (OggAudioStream var13 = new OggAudioStream(new ByteArrayInputStream(var0))) {
            ByteBuffer var14 = var13.readAll();
            byte[] var16 = new byte[var14.remaining()];
            var14.get(var16);
            var17 = new EmoteAudio.Sample(var16, var13.getFormat());
         }

         return var17;
      } else {
         AudioInputStream var2 = a(var0);
         AudioFormat var3 = var2.getFormat();
         if (var3.getEncoding() != Encoding.PCM_SIGNED || var3.getSampleSizeInBits() != 16) {
            AudioFormat var4 = new AudioFormat(
               Encoding.PCM_SIGNED, var3.getSampleRate(), 16, var3.getChannels(), var3.getChannels() * 2, var3.getSampleRate(), false
            );
            var2 = var3.getEncoding().toString().startsWith("MPEG")
               ? new MpegFormatConversionProvider().getAudioInputStream(var4, var2)
               : AudioSystem.getAudioInputStream(var4, var2);
         }

         EmoteAudio.Sample var8;
         try (AudioInputStream var15 = var2) {
            ByteArrayOutputStream var5 = new ByteArrayOutputStream(Math.min(var0.length * 8, 1048576));
            byte[] var6 = new byte[16384];

            int var7;
            while ((var7 = var15.read(var6)) > 0) {
               var5.write(var6, 0, var7);
               if (var5.size() > 12582912) {
                  throw new IllegalStateException("трек слишком длинный (PCM > 12582912 байт)");
               }
            }

            var8 = new EmoteAudio.Sample(var5.toByteArray(), var15.getFormat());
         }

         return var8;
      }
   }

   private static AudioInputStream a(byte[] var0) throws Exception {
      try {
         return AudioSystem.getAudioInputStream(new ByteArrayInputStream(var0));
      } catch (UnsupportedAudioFileException var2) {
         return new MpegAudioFileReader().getAudioInputStream(new ByteArrayInputStream(var0));
      }
   }

   private static StaticSound a(EmoteAudio.Sample var0) {
      AudioFormat var1 = var0.format;
      int var2 = Math.max(1, var1.getChannels());
      boolean var3 = var1.isBigEndian();
      byte[] var4 = var0.pcm;
      int var5 = var4.length / (2 * var2);
      ByteBuffer var6 = BufferUtils.createByteBuffer(var5 * 2).order(ByteOrder.nativeOrder());
      int var7 = 0;

      for (int var8 = 0; var8 < var5; var8++) {
         short var9 = 0;

         for (int var10 = 0; var10 < var2; var10++) {
            int var11 = var4[var7++] & 255;
            int var12 = var4[var7++] & 255;
            var9 += var3 ? (short)(var11 << 8 | var12) : (short)(var12 << 8 | var11);
         }

         var6.putShort((short)(var9 / var2));
      }

      var6.flip();
      AudioFormat var14 = new AudioFormat(Encoding.PCM_SIGNED, var1.getSampleRate(), 16, 1, 2, var1.getSampleRate(), false);
      return new StaticSound(var6, var14);
   }

   @Environment(EnvType.CLIENT)
   public record Decoded(StaticSound sound, int durationMs) {
   }

   @Environment(EnvType.CLIENT)
   private record Encoded(byte[] data, String ext) {
   }

   @Environment(EnvType.CLIENT)
   private record Sample(byte[] pcm, AudioFormat format) {
   }
}
