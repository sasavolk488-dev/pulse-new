package pulse.ui.clickgui;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum MenuType {
   a("modules", "\ue916"),
   b("markers", "\ue915"),
   c("friends", "\ue90d"),
   d("events", "\ue90a"),
   e("configs", "\ue905");

   private final String f;
   private final String g;

   private MenuType(String var3, String var4) {
      this.f = var3;
      this.g = var4;
   }

   @Generated
   public String a() {
      return this.f;
   }

   @Generated
   public String b() {
      return this.g;
   }

   private static MenuType[] c() {
      return new MenuType[]{a, b, c, d, e};
   }
}
