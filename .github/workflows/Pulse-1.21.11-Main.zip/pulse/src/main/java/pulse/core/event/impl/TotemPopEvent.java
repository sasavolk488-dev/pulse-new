package pulse.core.event.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class TotemPopEvent extends Event {
   private final LivingEntity a;
   private final ItemStack b;

   public TotemPopEvent(LivingEntity var1, ItemStack var2) {
      this.a = var1;
      this.b = var2;
   }

   public LivingEntity a() {
      return this.a;
   }

   public ItemStack b() {
      return this.b;
   }
}
