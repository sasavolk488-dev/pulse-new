package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.InputEvent;

@Environment(EnvType.CLIENT)
@Mixin({KeyboardInput.class})
public class KeyboardInputMixin extends Input {
   @Shadow
   @Final
   private GameOptions settings;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onTick(CallbackInfo var1) {
      this.playerInput = new PlayerInput(
         this.settings.forwardKey.isPressed(),
         this.settings.backKey.isPressed(),
         this.settings.leftKey.isPressed(),
         this.settings.rightKey.isPressed(),
         this.settings.jumpKey.isPressed(),
         this.settings.sneakKey.isPressed(),
         this.settings.sprintKey.isPressed()
      );
      float var2 = getMovementMultiplier(this.playerInput.forward(), this.playerInput.backward());
      float var3 = getMovementMultiplier(this.playerInput.left(), this.playerInput.right());
      InputEvent var4 = new InputEvent(var2, var3, this.playerInput.jump(), this.playerInput.sneak(), 0.3F);
      EventHandler.a.post(var4);
      if (var4.c()) {
         this.playerInput = new PlayerInput(false, false, false, false, false, false, this.playerInput.sprint());
         this.movementVector = Vec2f.ZERO;
      } else {
         float var5 = var4.d();
         float var6 = var4.e();
         this.playerInput = new PlayerInput(var5 > 0.0F, var5 < 0.0F, var6 > 0.0F, var6 < 0.0F, var4.f(), var4.g(), this.playerInput.sprint());
         this.movementVector = new Vec2f(var6, var5).normalize();
      }

      var1.cancel();
   }

   @Unique
   private static float getMovementMultiplier(boolean var0, boolean var1) {
      if (var0 == var1) {
         return 0.0F;
      } else {
         return var0 ? 1.0F : -1.0F;
      }
   }
}
