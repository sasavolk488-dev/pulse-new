package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.KeyEvent;
import pulse.core.event.impl.MouseEvent;
import pulse.core.event.impl.MouseScrollEvent;
import pulse.core.input.KeybindManager;

@Environment(EnvType.CLIENT)
@Mixin({Mouse.class})
public class MouseMixin {
   @Shadow
   @Final
   private MinecraftClient client;

   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseButton(long var1, MouseInput var3, int var4, CallbackInfo var5) {
      if (var1 == this.client.getWindow().getHandle()) {
         double var6 = this.client.mouse.getX() * this.client.getWindow().getScaledWidth() / this.client.getWindow().getWidth();
         double var8 = this.client.mouse.getY() * this.client.getWindow().getScaledHeight() / this.client.getWindow().getHeight();
         MouseEvent var10 = new MouseEvent(var3.button(), var4, var3.modifiers(), var6, var8);
         EventHandler.a.post(var10);
         if (var10.c()) {
            var5.cancel();
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseScroll(long var1, double var3, double var5, CallbackInfo var7) {
      if (var1 == this.client.getWindow().getHandle()) {
         MouseScrollEvent var8 = new MouseScrollEvent(var3, var5);
         EventHandler.a.post(var8);
         if (var8.c()) {
            var7.cancel();
         }
      }
   }

   @Inject(
      method = {"onMouseButton"},
      at = {@At("TAIL")}
   )
   private void onMouseButtonTail(long var1, MouseInput var3, int var4, CallbackInfo var5) {
      EventHandler.a.post(new KeyEvent(1450 + var3.button(), 0, var4, var3.modifiers()));
      if (var4 == 1) {
         KeybindManager.a().d(1450 + var3.button());
      }
   }
}
