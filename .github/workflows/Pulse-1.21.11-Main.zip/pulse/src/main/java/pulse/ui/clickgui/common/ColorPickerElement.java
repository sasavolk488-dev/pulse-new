package pulse.ui.clickgui.common;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class ColorPickerElement {
   private static final ColorPickerElement a = new ColorPickerElement();
   private static final float b = 84.5F;
   private static final float c = 10.5F;
   private static final float d = 7.0F;
   private static final float e = 9.5F;
   private static final float f = 63.5F;
   private static final float g = 41.5F;
   private static final float h = 7.0F;
   private static final float i = 4.0F;
   private static final float j = 2.0F;
   private static final float k = 9.0F;
   private static final float l = 1.5F;
   private static final float m = 3.0F;
   private static final float n = 7.0F;
   private static final float o = 1.0F;
   private boolean p = false;
   private final Animation q = new Animation();
   private float r;
   private float s;
   private ColorPickerElement.Direction t = ColorPickerElement.Direction.b;
   private String u = "";
   private float v = 1.0F;
   private float w;
   private float x;
   private float y;
   private Consumer<Color> z;
   private boolean A = false;
   private boolean B = false;
   private float C;
   private float D;
   private float E;
   private float F;
   private float G;
   private float H;
   private float I;
   private float J;
   private float K;
   private float L;
   private float M;
   private float N;
   private float O;
   private float P;
   private float Q;

   private ColorPickerElement() {
   }

   public static ColorPickerElement a() {
      return a;
   }

   public void a(float var1, float var2, ColorPickerElement.Direction var3, String var4, Color var5, float var6, Consumer<Color> var7) {
      if (this.p) {
         this.b();
      }

      this.r = var1;
      this.s = var2;
      this.t = var3 != null ? var3 : ColorPickerElement.Direction.b;
      this.u = var4 != null ? var4 : "";
      this.v = var6;
      this.z = var7;
      float[] var8 = Color.RGBtoHSB(var5.getRed(), var5.getGreen(), var5.getBlue(), null);
      this.w = var8[0];
      this.x = var8[1];
      this.y = var8[2];
      this.p = true;
      this.q.d(0.0);
      this.q.a(1.0, 0.20000001528133, Easings.h);
   }

   public void a(float var1, float var2, String var3, Color var4, float var5, Consumer<Color> var6) {
      this.a(var1, var2, ColorPickerElement.Direction.b, var3, var4, var5, var6);
   }

   public void b() {
      if (this.p) {
         this.p = false;
         this.q.a(0.0, 0.1500000158791239, Easings.h);
         this.A = false;
         this.B = false;
      }
   }

   public boolean c() {
      return this.p || this.q.j() > 0.01000000006592062;
   }

   public boolean d() {
      return this.p && this.q.j() > 0.5;
   }

   public Color e() {
      return Color.getHSBColor(this.w, this.x, this.y);
   }

   public float[] f() {
      if (!this.c()) {
         return null;
      } else {
         float var1 = (float)this.q.j();
         float var2 = this.E * var1;
         float var3 = this.F * var1;
         float var4 = this.G - var2 / 2.0F;
         float var5 = this.H - var3 / 2.0F;
         return new float[]{var4, var5, var2, var3};
      }
   }

   private float a(float var1, float var2, float var3) {
      return var2 + (var1 - var2) * var3;
   }

   private float a(float var1, float var2) {
      return var1 * var2;
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4, float var5) {
      this.q.a();
      float var6 = (float)this.q.j();
      this.Q = var6;
      if (!(var6 < 0.01F)) {
         FontRenderer var7 = Fonts.a[14];
         float var8 = 84.5F * this.v;
         float var9 = 10.5F * this.v;
         float var10 = 7.0F * this.v;
         float var11 = 9.5F * this.v;
         float var12 = 63.5F * this.v;
         float var13 = 41.5F * this.v;
         float var14 = 4.0F * this.v;
         float var15 = var7.b(this.u) * this.v + 2.0F * this.v;
         float var16 = var15 + var13 + var10 + var14;
         float var17 = var16 + var9 * 2.0F;
         this.E = var8;
         this.F = var17;
         this.b(var8, var17);
         this.G = this.C + var8 / 2.0F;
         this.H = this.D + var17 / 2.0F;
         float var18 = this.a(this.C, this.G, var6);
         float var19 = this.a(this.D, this.H, var6);
         float var20 = this.a(var8, var6);
         float var21 = this.a(var17, var6);
         float var22 = this.a(var11, var6);
         float var23 = this.a(var9, var6);
         float var24 = this.a(var10, var6);
         this.a(var1, var2, var6, var5);
         Color var25 = this.a(ClickGuiColors.x, var5 * var6);
         Color var26 = this.a(ClickGuiColors.x, var5 * var6);
         var2.a(
            var18 - 0.5F * this.v * var6, var19 - 0.5F * this.v * var6, var20 + this.v * var6, var21 + this.v * var6, var22, var25, var25, var26, var26, var1
         );
         Color var27 = this.a(ClickGuiColors.e, var5 * var6);
         Color var28 = this.a(ClickGuiColors.f, var5 * var6);
         var2.a(var18, var19, var20, var21, var22, var27, var27, var28, var28, var1);
         if (var6 > 0.3F) {
            float var29 = Math.min(1.0F, (var6 - 0.3F) / 0.7F);
            int var30 = (int)(255.0F * var5 * var29);
            var2.a().a(var18, var19, var20, var21, var22, var1);
            float var31 = this.C + var9;
            float var32 = this.D + var9;
            float var33 = this.a(var31, this.G, var6);
            float var34 = this.a(var32, this.H, var6);
            float var35 = this.a(var15, var6);
            float var36 = this.v * var6;
            Color var37 = ClickGuiColors.a(ClickGuiColors.a, var30);
            var1.push();
            var1.translate(var33, var34, 0.0F);
            var1.scale(var36, var36, 1.0F);
            var1.translate(-var33, -var34, 0.0F);
            var7.a(this.u, var33, var34, var37, var1);
            var1.pop();
            float var39 = var32 + var15;
            this.I = this.a(var31, this.G, var6);
            this.J = this.a(var39, this.H, var6);
            this.K = this.a(var12, var6);
            this.L = this.a(var13, var6);
            float var40 = this.a(7.0F * this.v, var6);
            this.a(var1, var2, this.I, this.J, this.K, this.L, var40, var29 * var5);
            float var41 = var31 + this.x * var12;
            float var42 = var39 + (1.0F - this.y) * var13;
            float var43 = this.a(var41, this.G, var6);
            float var44 = this.a(var42, this.H, var6);
            this.a(var1, var2, var43, var44, var6, var29 * var5);
            float var46 = var39 + var13 + var10;
            this.M = this.a(var31, this.G, var6);
            this.N = this.a(var46, this.H, var6);
            this.O = this.a(var12, var6);
            this.P = this.a(var14, var6);
            float var47 = this.a(2.0F * this.v, var6);
            this.b(var1, var2, this.M, this.N, this.O, this.P, var47, var29 * var5);
            float var48 = var31 + this.w * var12;
            float var49 = var46 + var14 / 2.0F;
            float var50 = this.a(var48, this.G, var6);
            float var51 = this.a(var49, this.H, var6);
            this.b(var1, var2, var50, var51, var6, var29 * var5);
            var2.a().a(var1);
         }

         if (this.p && var6 > 0.8F) {
            boolean var52 = MouseUtil.a(this.I, this.J, this.K, this.L, (double)var3, (double)var4);
            boolean var53 = MouseUtil.a(this.M, this.N - 4.0F * this.v * var6, this.O, this.P + 8.0F * this.v * var6, (double)var3, (double)var4);
            if (var52 || var53 || this.A || this.B) {
               MouseUtil.g();
            }
         }
      }
   }

   private void b(float var1, float var2) {
      TextureRegistry.TextureEntry var3 = TextureRegistry.b("arrow_v");
      float var4 = var3 != null ? var3.b() / 2.0F * this.v : 0.0F;
      switch (this.t) {
         case a:
            this.C = this.r - var1 / 2.0F;
            this.D = this.s - var2 - var4 - 1.0F * this.v;
            break;
         case b:
            this.C = this.r - var1 / 2.0F;
            this.D = this.s + var4 + 1.0F * this.v;
            break;
         case c:
            this.C = this.r - var1 - var4 - 1.0F * this.v;
            this.D = this.s - var2 / 2.0F;
            break;
         case d:
            this.C = this.r + var4 + 1.0F * this.v;
            this.D = this.s - var2 / 2.0F;
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4) {
      TextureRegistry.TextureEntry var5 = TextureRegistry.b("arrow_v");
      if (var5 != null) {
         Identifier var6 = var5.a();
         float var7 = var5.b() / 2.0F * this.v * var3;
         float var8 = var5.c() / 2.0F * this.v * var3;
         Color var9 = ClickGuiColors.a(ClickGuiColors.aa, var4 * var3);
         float var10 = this.a(this.C, this.G, var3);
         float var11 = this.a(this.D, this.H, var3) + 2.5F;
         float var12 = this.a(this.E, var3);
         float var13 = this.a(this.F, var3);
         float var14 = 1.0F * this.v * var3;
         float var15;
         float var16;
         float var17;
         switch (this.t) {
            case a:
               var15 = var10 + var12 / 2.0F;
               var16 = var11 + var13 + var8 / 2.0F + var14;
               var17 = 90.0F;
               break;
            case b:
               var15 = var10 + var12 / 2.0F;
               var16 = var11 - var8 / 2.0F - var14;
               var17 = -90.0F;
               break;
            case c:
               var15 = var10 + var12 + var7 / 2.0F + var14;
               var16 = var11 + var13 / 2.0F;
               var17 = 0.0F;
               break;
            case d:
            default:
               var15 = var10 - var7 / 2.0F - var14;
               var16 = var11 + var13 / 2.0F;
               var17 = 180.0F;
         }

         var1.push();
         var1.translate(var15, var16, 0.0F);
         var1.multiply(new Quaternionf().rotationZ((float)Math.toRadians(var17)));
         var1.translate(-var15, -var16, 0.0F);
         float var18 = var15 - var7 / 2.0F;
         float var19 = var16 - var8 / 2.0F;
         var2.a(var6, var18, var19, var7, var8, var9, var1);
         var1.pop();
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      Color var9 = Color.getHSBColor(this.w, 1.0F, 1.0F);
      int var10 = (int)(255.0F * var8);
      Color var11 = ClickGuiColors.a(ClickGuiColors.aa, var10);
      Color var12 = ClickGuiColors.a(var9, var10);
      Color var13 = ClickGuiColors.a(ClickGuiColors.ab, var10);
      var2.a(var3, var4, var5, var6, var7, var11, var12, var13, var13, var1);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6) {
      float var7 = 9.0F * this.v * var5;
      float var8 = 1.5F * this.v * var5;
      float var9 = var7 - var8 * 2.0F;
      int var10 = (int)(255.0F * var6);
      var2.a(var3 - var9 / 2.0F - 2.0F, var4 - var9 / 2.0F - 2.0F, 5.0F, ClickGuiColors.ad, var1);
      Color var11 = ClickGuiColors.a(ClickGuiColors.aa, var10);
      var2.a(var3 - var7 / 2.0F, var4 - var7 / 2.0F, var7, var7, var7, var11, var1);
      Color var12 = this.e();
      Color var13 = ClickGuiColors.a(var12, var10);
      var2.a(var3 - var9 / 2.0F, var4 - var9 / 2.0F, var9, var9, var9, var13, var1);
   }

   private void b(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      var2.a(var3, var4, var5, var6, var7, var8, var1);
   }

   private void b(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6) {
      float var7 = 3.0F * this.v * var5;
      float var8 = 7.0F * this.v * var5;
      Color var9 = ClickGuiColors.a(ClickGuiColors.aa, var6);
      var2.a(var3 - var7 / 2.0F, var4 - var8 / 2.0F, var7, var8, var7, var9, var1);
   }

   public boolean a(int var1, int var2) {
      if (!this.p || this.q.j() < 0.5) {
         return false;
      } else if (MouseUtil.a(this.I, this.J, this.K, this.L, (double)var1, (double)var2)) {
         this.A = true;
         this.d(var1, var2);
         return true;
      } else {
         float var3 = 4.0F * this.v * this.Q;
         if (MouseUtil.a(this.M, this.N - var3, this.O, this.P + var3 * 2.0F, (double)var1, (double)var2)) {
            this.B = true;
            this.a(var1);
            return true;
         } else {
            return this.c(var1, var2);
         }
      }
   }

   public void b(int var1, int var2) {
      this.A = false;
      this.B = false;
   }

   public void a(int var1, int var2, double var3, double var5) {
      if (this.p) {
         if (this.A) {
            this.d(var1, var2);
         }

         if (this.B) {
            this.a(var1);
         }
      }
   }

   @Compile
   private void d(int var1, int var2) {
      float top = this.J;
      this.x = Math.max(0.0F, Math.min(1.0F, ((float)var1 - this.I) / this.K));
      this.y = Math.max(0.0F, Math.min(1.0F, 1.0F - ((float)var2 - top) / this.L));
      this.g();
   }

   private void a(int var1) {
      float var2 = var1 - this.M;
      this.w = Math.max(0.0F, Math.min(1.0F, var2 / this.O));
      this.g();
   }

   private void g() {
      if (this.z != null) {
         this.z.accept(this.e());
      }
   }

   public boolean c(int var1, int var2) {
      if (!this.c()) {
         return false;
      } else {
         float var3 = (float)this.q.j();
         float var4 = this.E * var3;
         float var5 = this.F * var3;
         float var6 = this.G - var4 / 2.0F;
         float var7 = this.H - var5 / 2.0F;
         return MouseUtil.a(var6, var7, var4, var5, (double)var1, (double)var2);
      }
   }

   private Color a(Color var1, float var2) {
      return ClickGuiColors.b(var1, var2);
   }

   static {
      NativeMethodLookup.lookup(ColorPickerElement.class, 3);
   }

   @Environment(EnvType.CLIENT)
   public static enum Direction {
      a,
      b,
      c,
      d;

      private static ColorPickerElement.Direction[] a() {
         return new ColorPickerElement.Direction[]{a, b, c, d};
      }
   }
}
