package pulse.core;

import pulse.Pulse;

public final class Pulse$$Lambda$0 implements Runnable {
   private final Pulse c0;

   public Pulse$$Lambda$0(Pulse var1) {
      this.c0 = var1;
   }

   @Override
   public void run() {
      this.c0.v();
   }
}
