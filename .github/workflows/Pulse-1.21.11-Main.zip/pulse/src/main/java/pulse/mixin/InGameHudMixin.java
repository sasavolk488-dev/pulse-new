package pulse.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.hud.components.ScoreboardComponent;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ArmorHudModule;
import pulse.features.modules.hud.SaturationHudModule;
import pulse.features.modules.hud.TotemBarModule;
import pulse.features.modules.utilities.CooldownsModule;
import pulse.features.modules.utilities.FTHelperModule;
import pulse.features.modules.utilities.FastSwapModule;
import pulse.features.modules.visuals.AnimationsModule;
import pulse.features.modules.visuals.RenderTweaksModule;
import pulse.features.modules.visuals.animations.HotbarAnimator;
import pulse.features.modules.visuals.animations.PlayerListAnimator;
import pulse.utils.game.CooldownUtil;
import pulse.utils.input.KeyUtils;

@Environment(EnvType.CLIENT)
@Mixin({InGameHud.class})
public abstract class InGameHudMixin {
   @Shadow
   @Final
   private static Identifier HOTBAR_SELECTION_TEXTURE;
   @Shadow
   @Final
   private static Identifier FOOD_EMPTY_TEXTURE;
   @Shadow
   @Final
   private static Identifier FOOD_HALF_TEXTURE;
   @Shadow
   @Final
   private static Identifier FOOD_FULL_TEXTURE;
   @Shadow
   @Final
   private static Identifier FOOD_EMPTY_HUNGER_TEXTURE;
   @Shadow
   @Final
   private static Identifier FOOD_HALF_HUNGER_TEXTURE;
   @Shadow
   @Final
   private static Identifier FOOD_FULL_HUNGER_TEXTURE;
   @Shadow
   @Final
   private MinecraftClient client;
   @Shadow
   @Final
   private PlayerListHud playerListHud;
   @Unique
   private boolean pulseScoreboardMatrixPushed = false;
   @Unique
   private boolean deferHighlight = false;
   @Unique
   private int deferredHighlightY;
   @Unique
   private static final Identifier TOTEM_BAR_FULL_TEXTURE = Identifier.of("pulse", "textures/totem.png");
   @Unique
   private static final Identifier TOTEM_BAR_EMPTY_TEXTURE = Identifier.of("pulse", "textures/totem_empty.png");
   @Unique
   private boolean prevTabShown = false;

   @Shadow
   protected abstract void renderHotbarItem(DrawContext var1, int var2, int var3, RenderTickCounter var4, PlayerEntity var5, ItemStack var6, int var7);

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void pulse$renderFtHelperTimers(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      FTHelperModule var4 = ModuleRegistry.C;
      if (var4 != null && var4.k()) {
         var4.a(var1);
      }
   }

   @Inject(
      method = {"renderCrosshair"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderCrosshair(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      if (ModuleRegistry.l != null && ModuleRegistry.l.k()) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderScoreboardSidebar(DrawContext var1, ScoreboardObjective var2, CallbackInfo var3) {
      RenderTweaksModule var4 = ModuleRegistry.h;
      if (var4 != null && var4.r()) {
         var3.cancel();
      } else {
         ScoreboardComponent var5 = ScoreboardComponent.v();
         if (var5 != null && var5.w()) {
            var1.getMatrices().pushMatrix();
            var5.a(var1.getMatrices());
            this.pulseScoreboardMatrixPushed = true;
         }
      }
   }

   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("RETURN")}
   )
   private void afterRenderScoreboardSidebar(DrawContext var1, ScoreboardObjective var2, CallbackInfo var3) {
      if (this.pulseScoreboardMatrixPushed) {
         var1.getMatrices().popMatrix();
         this.pulseScoreboardMatrixPushed = false;
      }
   }

   @Unique
   private boolean isHotbarAnimationEnabled() {
      return ModuleRegistry.t != null && ModuleRegistry.t.k() && ModuleRegistry.t.g.a();
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("HEAD")}
   )
   private void onRenderHotbarHead(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      if (this.isHotbarAnimationEnabled() && this.client.player != null) {
         HotbarAnimator var4 = AnimationsModule.p();
         int var5 = this.client.player.getInventory().getSelectedSlot();
         int var6 = var1.getScaledWindowWidth() / 2;
         var4.a(var5, var6, (long)ModuleRegistry.t.h.q().floatValue());
         var4.a();
      }
   }

   @Redirect(
      method = {"renderHotbar"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIII)V",
         ordinal = 1
      )
   )
   private void redirectHotbarSelection(DrawContext var1, RenderPipeline var2, Identifier var3, int var4, int var5, int var6, int var7) {
      if (this.isHotbarAnimationEnabled()) {
         this.deferredHighlightY = var5;
         this.deferHighlight = true;
      } else {
         var1.drawGuiTexture(var2, var3, var4, var5, var6, var7);
      }
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("RETURN")}
   )
   private void renderDeferredHighlight(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      if (this.deferHighlight) {
         this.deferHighlight = false;
         int var4 = Math.round(AnimationsModule.p().b());
         var1.drawGuiTexture(RenderPipelines.GUI_TEXTURED, HOTBAR_SELECTION_TEXTURE, var4, this.deferredHighlightY, 24, 23);
      }
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("RETURN")}
   )
   private void pulse$renderCooldownTimers(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      CooldownsModule var4 = ModuleRegistry.K;
      if (var4 != null && var4.k() && var4.n()) {
         ClientPlayerEntity var5 = this.client.player;
         if (var5 != null) {
            TextRenderer var6 = this.client.textRenderer;
            int var7 = var1.getScaledWindowWidth();
            int var8 = var1.getScaledWindowHeight();
            float var9 = var4.q().q();

            for (int var10 = 0; var10 < 9; var10++) {
               ItemStack var11 = var5.getInventory().getStack(var10);
               if (!var11.isEmpty()) {
                  Item var12 = var11.getItem();
                  CooldownUtil.CooldownInfo var13 = CooldownUtil.a(var5.getItemCooldownManager(), var12);
                  boolean var14 = CooldownsModule.a(var11) && var4.b(var12);
                  if (var13.a() || var14) {
                     int var15 = var7 / 2 - 91 + var10 * 20 + 2;
                     int var16 = var8 - 16 - 3;
                     int var17;
                     int var18;
                     if (var14) {
                        float var19 = var4.a(var12);
                        var17 = (int)Math.ceil(var19 * 18.5);
                        var18 = var19 <= 0.33F ? '\uff00' : (var19 <= 0.66F ? 16776960 : 16711680);
                     } else {
                        var17 = (int)Math.ceil(var13.b());
                        float var27 = var13.c();
                        var18 = var27 <= 0.33F ? '\uff00' : (var27 <= 0.66F ? 16776960 : 16711680);
                     }

                     String var28 = String.valueOf(var17);
                     float var20 = var6.getWidth(var28);
                     float var21 = 14.0F;
                     float var22 = Math.min(1.0F, var21 / var20);
                     float var23 = var22 * var9;
                     int var24 = (int)((var15 + 2.0F) / var23);
                     int var25 = (int)((var16 + 1.0F) / var23);
                     Matrix3x2fStack var26 = var1.getMatrices();
                     var26.pushMatrix();
                     var26.scale(var23, var23);
                     var1.drawText(var6, var28, var24, var25, var18 | 0xFF000000, true);
                     var26.popMatrix();
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("RETURN")}
   )
   private void pulse$renderFastSwapBinds(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      FastSwapModule var4 = ModuleRegistry.H;
      if (var4 != null && var4.k() && var4.G().a()) {
         ClientPlayerEntity var5 = this.client.player;
         if (var5 != null) {
            CooldownsModule var6 = ModuleRegistry.K;
            boolean var7 = var6 != null && var6.k() && var6.n();
            TextRenderer var8 = this.client.textRenderer;
            int var9 = var1.getScaledWindowWidth();
            int var10 = var1.getScaledWindowHeight();
            float var11 = var4.H().q();

            for (int var12 = 0; var12 < 9; var12++) {
               ItemStack var13 = var5.getInventory().getStack(var12);
               if (!var13.isEmpty()) {
                  int var14 = -1;

                  for (FastSwapModule.Action var16 : var4.I()) {
                     int var17 = var16.a().b();
                     if (var17 > 0 && var16.b().test(var13)) {
                        var14 = var17;
                        break;
                     }
                  }

                  if (var14 > 0) {
                     if (var7) {
                        CooldownUtil.CooldownInfo var23 = CooldownUtil.a(var5.getItemCooldownManager(), var13.getItem());
                        boolean var25 = CooldownsModule.a(var13) && var6.b(var13.getItem());
                        if (var23.a() || var25) {
                           continue;
                        }
                     }

                     String var24 = KeyUtils.a(var14);
                     if (!var24.isEmpty()) {
                        int var26 = var9 / 2 - 91 + var12 * 20 + 2;
                        int var27 = var10 - 16 - 3;
                        float var18 = var8.getWidth(var24);
                        float var19 = 14.0F;
                        float var20 = Math.min(1.0F, var19 / var18);
                        float var21 = var20 * var11;
                        Matrix3x2fStack var22 = var1.getMatrices();
                        var22.pushMatrix();
                        var22.scale(var21, var21);
                        var1.drawText(var8, var24, (int)((var26 + 2.0F) / var21), (int)((var27 + 1.0F) / var21), -1, true);
                        var22.popMatrix();
                     }
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("RETURN")}
   )
   private void pulse$renderArmorHud(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      ArmorHudModule var4 = ModuleRegistry.ax;
      if (var4 != null && var4.k()) {
         ClientPlayerEntity var5 = this.client.player;
         if (var5 != null) {
            int var6 = var1.getScaledWindowWidth() / 2;
            ItemStack var7 = var5.getOffHandStack();
            Arm var8 = var5.getMainArm().getOpposite();
            int var9 = var8 == Arm.RIGHT && !var7.isEmpty() ? 24 : 0;
            boolean var10 = var4.a.b("Проценты");
            if (var10) {
               ArmorHudModule.b = true;
            }

            int var11 = var1.getScaledWindowHeight();
            EquipmentSlot[] var12 = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

            for (int var13 = 0; var13 < 4; var13++) {
               int var14 = var6 + 92 + 10 + var13 * 20 + 2 + var9;
               int var15 = var11 - 16 - 3;
               ItemStack var16 = var5.getEquippedStack(var12[var13]);
               this.renderHotbarItem(var1, var14, var15, var2, var5, var16, var13 + 1);
            }

            if (var10) {
               ArmorHudModule.b = false;
               TextRenderer var28 = this.client.textRenderer;
               Matrix3x2fStack var29 = var1.getMatrices();

               for (int var30 = 0; var30 < 4; var30++) {
                  ItemStack var31 = var5.getEquippedStack(var12[var30]);
                  if (!var31.isEmpty() && var31.getMaxDamage() != 0) {
                     int var17 = var6 + 92 + 10 + var30 * 20 + 2 + var9;
                     int var18 = var1.getScaledWindowHeight() - 16 - 3;
                     int var19 = var31.getMaxDamage();
                     int var20 = var31.getDamage();
                     int var21 = Math.round((float)(var19 - var20) / var19 * 100.0F);
                     int var22;
                     if (var21 > 50) {
                        var22 = -11141291;
                     } else if (var21 > 25) {
                        var22 = -171;
                     } else {
                        var22 = -43691;
                     }

                     String var23 = var21 + "%";
                     float var24 = 0.5F;
                     var29.pushMatrix();
                     var29.scale(var24, var24);
                     float var25 = var28.getWidth(var23);
                     float var26 = (var17 + 8.5F) / var24 - var25 / 2.0F;
                     float var27 = (var18 + 12) / var24;
                     var1.drawText(var28, var23, (int)var26, (int)var27, var22, true);
                     var29.popMatrix();
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("RETURN")}
   )
   private void pulse$renderTotemBar(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      TotemBarModule var4 = ModuleRegistry.aF;
      if (var4 != null && var4.k()) {
         ClientPlayerEntity var5 = this.client.player;
         if (var5 != null && !var5.isSpectator() && !var5.isCreative()) {
            int var6 = 0;

            for (ItemStack var8 : var5.getInventory().getMainStacks()) {
               if (var8.getItem() == Items.TOTEM_OF_UNDYING) {
                  var6 += var8.getCount();
               }
            }

            int var15 = 0;
            ItemStack var16 = var5.getOffHandStack();
            if (var16.getItem() == Items.TOTEM_OF_UNDYING) {
               var6 += var16.getCount();
               var15++;
            }

            if (var5.getMainHandStack().getItem() == Items.TOTEM_OF_UNDYING) {
               var15++;
            }

            int var9 = Math.min(var6, 10);
            if (var9 > 0) {
               int var10 = var1.getScaledWindowWidth() / 2 + 91;
               int var11 = var10 - (9 + (var9 - 1) * 8);
               int var12 = var1.getScaledWindowHeight() - 51 - pulse$totemBarVerticalOffset(var5);

               for (int var13 = 0; var13 < var9; var13++) {
                  Identifier var14 = var13 >= var9 - var15 ? TOTEM_BAR_FULL_TEXTURE : TOTEM_BAR_EMPTY_TEXTURE;
                  var1.drawTexture(RenderPipelines.GUI_TEXTURED, var14, var11 + var13 * 8, var12, 0.0F, 0.0F, 9, 9, 9, 9);
               }
            }
         }
      }
   }

   @Unique
   private static int pulse$totemBarVerticalOffset(PlayerEntity var0) {
      int var1 = 0;
      if (var0.isSubmergedInWater() || var0.getAir() < var0.getMaxAir()) {
         var1 += 10;
      }

      Entity var2 = var0.getVehicle();
      if (var2 instanceof LivingEntity var3 && var3.getMaxHealth() > 20.0F) {
         var1 += MathHelper.ceil((var3.getMaxHealth() - 20.0F) / 20.0F) * 10;
      }

      if (!(var2 instanceof LivingEntity)
         && ModuleRegistry.aD != null
         && ModuleRegistry.aD.k()
         && MathHelper.floor(var0.getHungerManager().getSaturationLevel()) > 0) {
         var1 += 10;
      }

      return var1;
   }

   @Inject(
      method = {"renderFood"},
      at = {@At("TAIL")}
   )
   private void pulse$renderSaturationHud(DrawContext var1, PlayerEntity var2, int var3, int var4, CallbackInfo var5) {
      SaturationHudModule var6 = ModuleRegistry.aD;
      if (var6 != null && var6.k()) {
         if (var2 != null) {
            HungerManager var7 = var2.getHungerManager();
            int var8 = MathHelper.floor(var7.getSaturationLevel());
            if (var8 > 0) {
               int var9 = var3 - 10;
               boolean var10 = var2.hasStatusEffect(StatusEffects.HUNGER);
               Identifier var11 = var10 ? FOOD_EMPTY_HUNGER_TEXTURE : FOOD_EMPTY_TEXTURE;
               Identifier var12 = var10 ? FOOD_FULL_HUNGER_TEXTURE : FOOD_FULL_TEXTURE;
               Identifier var13 = var10 ? FOOD_HALF_HUNGER_TEXTURE : FOOD_HALF_TEXTURE;
               int var14 = (var8 + 1) / 2;

               for (int var15 = 0; var15 < var14; var15++) {
                  int var16 = var4 - var15 * 8 - 9;
                  var1.drawGuiTexture(RenderPipelines.GUI_TEXTURED, var11, var16, var9, 9, 9);
                  if (var15 * 2 + 1 < var8) {
                     var1.drawGuiTexture(RenderPipelines.GUI_TEXTURED, var12, var16, var9, 9, 9);
                  } else if (var15 * 2 + 1 == var8) {
                     var1.drawGuiTexture(RenderPipelines.GUI_TEXTURED, var13, var16, var9, 9, 9);
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"renderPlayerList"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderPlayerList(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      if (ModuleRegistry.t != null && ModuleRegistry.t.k() && ModuleRegistry.t.a.a()) {
         var3.cancel();
         if (this.client.world != null && this.client.player != null) {
            Scoreboard var4 = this.client.world.getScoreboard();
            ScoreboardObjective var5 = var4.getObjectiveForSlot(ScoreboardDisplaySlot.LIST);
            boolean var6 = this.client.options.playerListKey.isPressed();
            boolean var7 = this.client.isInSingleplayer() && this.client.player.networkHandler.getListedPlayerListEntries().size() <= 1 && var5 == null;
            boolean var8 = var6 && !var7;
            PlayerListAnimator var9 = AnimationsModule.n();
            long var10 = (long)ModuleRegistry.t.b.q().floatValue();
            if (var8 && !this.prevTabShown) {
               var9.a(var10);
            } else if (!var8 && this.prevTabShown) {
               var9.b(var10);
            }

            this.prevTabShown = var8;
            var9.a();
            boolean var12 = var8 || var9.d();
            if (!var12) {
               this.playerListHud.setVisible(false);
            } else {
               this.playerListHud.setVisible(true);
               float var13 = var9.b();
               if (var13 < 0.001F) {
                  this.playerListHud.setVisible(false);
               } else {
                  Matrix3x2fStack var14 = var1.getMatrices();
                  var14.pushMatrix();
                  float var15 = var1.getScaledWindowWidth() / 2.0F;
                  var14.translate(var15, 0.0F);
                  var14.scale(var13, var13);
                  var14.translate(-var15, 0.0F);
                  this.playerListHud.render(var1, var1.getScaledWindowWidth(), var4, var5);
                  var14.popMatrix();
               }
            }
         }
      } else {
         this.prevTabShown = false;
      }
   }
}
