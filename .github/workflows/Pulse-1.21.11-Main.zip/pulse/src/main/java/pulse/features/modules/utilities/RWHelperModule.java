package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Arrays;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.PacketEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;

@ModuleInfo(
   a = "RW Helper",
   b = "Автоматически закрывает меню сервера или фильтрует запрещенные сообщения в чате",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class RWHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Закрывать меню", true);
   private final BooleanSetting b = new BooleanSetting("Фильтр запрещенных слов", true);
   private static final Pattern c = Pattern.compile(
      String.join(
         "|",
         Arrays.asList(
            "акриен(а|у|ом|е|чик)?",
            "рич(а|у|ом|ей|е)?",
            "ньюкод(ом|а|у|ами|ик|е)?",
            "экспенсив(ом|а|у|ами|е)?",
            "импакт(ом|а|у|ами|ик|е)?",
            "экселлент(ом|а|у|ами|ик|е)?",
            "экселент(ом|а|у|ами|ик)?",
            "катлаван(ом|а|у|ами|чик)?",
            "катлован(ом|а|у|ами|чик)?",
            "целестиал(ом|а|у|ами|е)?",
            "целк(ой|а|у|ами|очка|е)?",
            "матикс(ом|а|у|ами|е)?",
            "инерти(я|ей|ю|ями|е)?",
            "эксп(а|ой|ою|у|уличка|е)?",
            "флюгер(ом|а|у|ами)?",
            "рикер(а|у|ом|очек)?",
            "фанпе(й|ю|я|ем|е|йчик)?",
            "вексайд(ом|а|у|ами|ик|е)?",
            "нурсултан(а|у|е|ом|чик)?",
            "нурик(а|у|ом|е)?",
            "нурлан(а|у|ом|чик|е)?",
            "векс(ом|у|а|ами|ик|е)?",
            "релейк(ом|у|а|ами|е)?",
            "арбуз(ом|а|у|ами|ик|е)?",
            "вилд(ом|у|а|ами|ик|е)?",
            "фантайм(е|а|у)?",
            "холик(е|а|у)?",
            "холиворлд(а|у|е)?",
            "рокстар(ом|а|у|ами|чик|е)?",
            "рогалик(а|у|ом|е)?",
            "тандерхак(ом|у|и|ами|а|е)?",
            "ликвидбаунс(а|у|ами|е)?",
            "expensive",
            "celestial",
            "newcode",
            "arbuz",
            "akrien",
            "nursultan",
            "relake",
            "wild",
            "wurst",
            "catlovan",
            "excellent",
            "rockstar",
            "catlavan",
            "impact",
            "matix",
            "inertia",
            "wex",
            "wexside",
            "nurik",
            "nurlan",
            "rich",
            "funpay",
            "fluger",
            "riker",
            "funtime",
            "holyworld",
            "wwe",
            "hvh",
            "rogalik",
            "thunderhack",
            "liquidbounce"
         )
      )
   );

   @EventHandler
   @Compile
   private void a(PacketEvent var1) {
      Object first;
      try {
         first = var1.d();
      } catch (RuntimeException | Error failure) {
         if (var1 != null) {
            var1.d();
         }
         throw failure;
      }
      if (first instanceof net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket) {
         boolean close;
         try {
            close = (Boolean)this.a.q();
         } catch (RuntimeException | Error failure) {
            var1.d();
            throw failure;
         }
         if (close) {
            Object raw = var1.d();
            net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket packet;
            boolean menu;
            try {
               packet = (net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket)raw;
               menu = packet.getName().getString().contains("ꈁꀀꈂꌁꈂꀁ§0ꈃꄀ");
            } catch (RuntimeException | Error failure) {
               var1.d();
               throw failure;
            }
            if (menu && d.player.age <= 99) {
               d.getNetworkHandler().sendPacket(
                  new net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket(packet.getSyncId()));
               var1.b();
            }
         }
      }
      if (var1.d() instanceof net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket && (Boolean)this.b.q()) {
         var packet = (net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket)var1.d();
         String message = packet.chatMessage();
         if (c.matcher(message.toLowerCase()).find()) {
            var1.b();
            pulse.utils.game.ChatUtils.a(this.g() + ": Заблокировано сообщение с упоминанием запрещенных слов");
         }
      }
   }

   static {
      NativeMethodLookup.lookup(RWHelperModule.class, 71);
   }
}
