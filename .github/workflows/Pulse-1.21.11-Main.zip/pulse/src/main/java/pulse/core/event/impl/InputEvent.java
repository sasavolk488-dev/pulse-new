package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class InputEvent extends CancellableEvent {
   private float a;
   private float b;
   private boolean c;
   private boolean d;
   private double e;

   @Generated
   public float d() {
      return this.a;
   }

   @Generated
   public float e() {
      return this.b;
   }

   @Generated
   public boolean f() {
      return this.c;
   }

   @Generated
   public boolean g() {
      return this.d;
   }

   @Generated
   public double h() {
      return this.e;
   }

   @Generated
   public void a(float var1) {
      this.a = var1;
   }

   @Generated
   public void b(float var1) {
      this.b = var1;
   }

   @Generated
   public void b(boolean var1) {
      this.c = var1;
   }

   @Generated
   public void c(boolean var1) {
      this.d = var1;
   }

   @Generated
   public void a(double var1) {
      this.e = var1;
   }

   @Generated
   public InputEvent(float var1, float var2, boolean var3, boolean var4, double var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }
}
