package pulse.features.modules.utilities;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.ChatEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.game.ChatUtils;
import pulse.utils.time.TimeUtils;

@ModuleInfo(
   a = "Command Safe",
   b = "Подтверждение опасных команд (/suicide, /clear и др.)",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class CommandSafeModule extends Module {
   private static final Pattern a = Pattern.compile("^/(suicide|esuicide|clear|ci|eci|ыгшсшву|уыгшсшву|сдуфк|сш|усш)\\s*$", 2);
   private final Map<String, TimeUtils> b = new ConcurrentHashMap<>();

   @EventHandler
   private void a(ChatEvent var1) {
      Matcher var2 = a.matcher(var1.d());
      if (var2.find()) {
         String var3 = a(var2.group(1));
         TimeUtils var4 = this.b.remove(var3);
         if (var4 == null || var4.a(3000L)) {
            this.b.put(var3, new TimeUtils());
            boolean var5 = var3.equals("suicide") || var3.equals("esuicide");
            ChatUtils.a("&7Вы уверены? Команда &c/" + var3 + (var5 ? " &7убьет вашего персонажа!" : " &7очистит ваш инвентарь!"));
            ChatUtils.a("&fДля подтверждения команды отправьте ее еще раз.");
            var1.b();
         }
      }
   }

   private static String a(String var0) {
      String var1 = var0.toLowerCase();
      switch (var1) {
         case "ыгшсшву":
            return "suicide";
         case "уыгшсшву":
            return "esuicide";
         case "сдуфк":
            return "clear";
         case "сш":
            return "ci";
         case "усш":
            return "eci";
         default:
            return var0.toLowerCase();
      }
   }
}
