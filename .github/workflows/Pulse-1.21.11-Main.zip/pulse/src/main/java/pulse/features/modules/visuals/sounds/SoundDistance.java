package pulse.features.modules.visuals.sounds;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.Vec3d;
import pulse.core.api.IMinecraft;

@Environment(EnvType.CLIENT)
public final class SoundDistance implements IMinecraft {
   private static final double a = 4.0;
   private static final double b = 24.0;

   private SoundDistance() {
   }

   public static float a(Vec3d var0) {
      if (var0 != null && d.player != null) {
         double var1 = d.player.getEntityPos().distanceTo(var0);
         if (var1 <= 4.0) {
            return 1.0F;
         } else {
            return var1 >= 24.0 ? 0.0F : (float)(1.0 - (var1 - 4.0) / 20.0);
         }
      } else {
         return 1.0F;
      }
   }
}
