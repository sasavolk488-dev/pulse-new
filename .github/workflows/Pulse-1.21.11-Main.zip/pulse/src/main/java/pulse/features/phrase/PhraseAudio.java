package pulse.features.phrase;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.Channel;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.client.sound.Source;
import net.minecraft.client.sound.StaticSound;
import net.minecraft.client.sound.Channel.SourceManager;
import net.minecraft.client.sound.SoundEngine.RunMode;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.Vec3d;
import pulse.Pulse;
import pulse.features.emote.EmoteAudio;
import pulse.mixin.accessor.SoundManagerAccessor;
import pulse.mixin.accessor.SoundSystemAccessor;
import pulse.utils.audio.PulseSoundOptions;

@Environment(EnvType.CLIENT)
public final class PhraseAudio {
   private static final double a = 3.0;
   private static final double b = 5.0;
   private static final Map<Integer, PhraseAudio.Encoded> c = new ConcurrentHashMap<>();
   private static final Map<Integer, StaticSound> d = new ConcurrentHashMap<>();
   private static final Map<Integer, Integer> e = new ConcurrentHashMap<>();
   private static final Map<String, PhraseAudio.Voice> f = new ConcurrentHashMap<>();
   private static volatile Channel g;
   private static volatile boolean h;

   public static void a() {
      h = true;
      Pulse.m().info("[Phrase] звук перезапущен — буферы озвучки пересоберём");
   }

   private PhraseAudio() {
   }

   public static void a(int var0, byte[] var1, String var2) {
      if (var1 != null && var1.length != 0) {
         c.put(var0, new PhraseAudio.Encoded(var1, var2));

         try {
            EmoteAudio.Decoded var3 = EmoteAudio.a(var1, var2, "озвучка фразы " + var0);
            if (var3 == null) {
               return;
            }

            e.put(var0, var3.durationMs());
            d.put(var0, var3.sound());
            g = a(MinecraftClient.getInstance());
         } catch (Throwable var4) {
            Pulse.m().warn("[Phrase] озвучка id={} не разобралась: {}", var0, var4.toString());
         }
      }
   }

   private static StaticSound a(int var0, Channel var1) {
      if (h) {
         d.clear();
         h = false;
         g = var1;
      }

      if (var1 != g) {
         d.clear();
         g = var1;
      }

      StaticSound var2 = d.get(var0);
      if (var2 != null) {
         return var2;
      } else {
         PhraseAudio.Encoded var3 = c.get(var0);
         if (var3 == null) {
            return null;
         } else {
            try {
               EmoteAudio.Decoded var4 = EmoteAudio.a(var3.data(), var3.ext(), "озвучка фразы " + var0);
               if (var4 == null) {
                  return null;
               } else {
                  d.put(var0, var4.sound());
                  e.put(var0, var4.durationMs());
                  return var4.sound();
               }
            } catch (Throwable var5) {
               Pulse.m().warn("[Phrase] озвучка id={} не пересобралась: {}", var0, var5.toString());
               return null;
            }
         }
      }
   }

   public static void b() {
      c.clear();
      d.clear();
      e.clear();
      g = null;
   }

   public static void a(String var0) {
      a(f.remove(var0));
   }

   public static void c() {
      for (String var1 : f.keySet()) {
         a(f.remove(var1));
      }
   }

   private static void a(PhraseAudio.Voice var0) {
      if (var0 != null) {
         SourceManager var1;
         synchronized (var0) {
            var0.b = true;
            var1 = var0.a;
            var0.a = null;
         }

         if (var1 != null) {
            var1.run(Source::stop);
         }
      }
   }

   public static int a(int var0) {
      Integer var1 = e.get(var0);
      return var1 == null ? 0 : var1;
   }

   public static void a(String var0, int var1) {
      if (c.containsKey(var1)) {
         MinecraftClient var2 = MinecraftClient.getInstance();
         if (var2.world != null && var2.player != null) {
            boolean var3 = var0.equals(var2.player.getGameProfile().name());
            Vec3d var4;
            if (var3) {
               var4 = Vec3d.ZERO;
            } else {
               PlayerEntity var5 = a(var2, var0);
               if (var5 == null) {
                  return;
               }

               var4 = new Vec3d(var5.getX(), var5.getY() + var5.getHeight() * 0.5, var5.getZ());
               if (var2.player.getEyePos().distanceTo(var4) > 5.0) {
                  return;
               }
            }

            float var9 = a(var2, var3 ? 0.0 : var2.player.getEyePos().distanceTo(var4));
            if (var9 <= 0.0F) {
               Pulse.m().debug("[Phrase] звук id={}: громкость 0 (ползунки игры или мода)", var1);
            } else {
               Channel var6 = a(var2);
               if (var6 == null) {
                  Pulse.m().warn("[Phrase] звук id={}: канал недоступен", var1);
               } else {
                  StaticSound var7 = a(var1, var6);
                  if (var7 == null) {
                     Pulse.m().warn("[Phrase] звук id={}: буфер не собрался", var1);
                  } else {
                     Pulse.m().debug("[Phrase] звук id={}: запускаю, громкость {}", var1, String.format("%.2f", var9));
                     a(var0);
                     PhraseAudio.Voice var8 = new PhraseAudio.Voice();
                     f.put(var0, var8);
                     var6.createSource(RunMode.STATIC).thenAccept(var7x -> {
                        if (var7x == null) {
                           f.remove(var0, var8);
                           Pulse.m().warn("[Phrase] звук id={}: движок не дал источник", var1);
                        } else {
                           synchronized (var8) {
                              if (var8.b) {
                                 var7x.run(Source::stop);
                                 return;
                              }

                              var8.a = var7x;
                           }

                           var7x.run(var4xx -> {
                              var4xx.setBuffer(var7);
                              var4xx.setLooping(false);
                              var4xx.disableAttenuation();
                              var4xx.setRelative(var3);
                              var4xx.setPosition(var4);
                              var4xx.setPitch(1.0F);
                              var4xx.setVolume(var9);
                              var4xx.play();
                           });
                        }
                     });
                  }
               }
            }
         }
      }
   }

   private static float a(MinecraftClient var0, double var1) {
      float var3;
      if (var1 <= 3.0) {
         var3 = 1.0F;
      } else if (var1 >= 5.0) {
         var3 = 0.0F;
      } else {
         var3 = (float)(1.0 - (var1 - 3.0) / 2.0);
      }

      float var4 = var0.options.getSoundVolume(SoundCategory.RECORDS) * (float)PulseSoundOptions.b();
      return Math.max(0.0F, Math.min(1.0F, var3 * var4));
   }

   private static PlayerEntity a(MinecraftClient var0, String var1) {
      for (PlayerEntity var3 : var0.world.getPlayers()) {
         if (var1.equals(var3.getGameProfile().name())) {
            return var3;
         }
      }

      return null;
   }

   private static Channel a(MinecraftClient var0) {
      try {
         SoundSystem var1 = ((SoundManagerAccessor)var0.getSoundManager()).pulse$getSoundSystem();
         return var1 == null ? null : ((SoundSystemAccessor)var1).pulse$getChannel();
      } catch (Throwable var2) {
         return null;
      }
   }

   @Environment(EnvType.CLIENT)
   private record Encoded(byte[] data, String ext) {
   }

   @Environment(EnvType.CLIENT)
   private static final class Voice {
      volatile SourceManager a;
      volatile boolean b;
   }
}
