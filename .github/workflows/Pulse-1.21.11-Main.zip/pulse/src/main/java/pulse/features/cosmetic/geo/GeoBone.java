package pulse.features.cosmetic.geo;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GeoBone {
   public GeoBone a;
   public List<GeoBone> b = new ArrayList<>();
   public List<GeoCube> c = new ArrayList<>();
   public String d;
   public boolean e = false;
   public float f;
   public float g;
   public float h;
   private float i;
   private float j;
   private float k;
   private float l;
   private float m;
   private float n;
   private float o = 1.0F;
   private float p = 1.0F;
   private float q = 1.0F;

   public GeoBone(String var1) {
      this.d = var1;
   }

   public float a() {
      return this.i;
   }

   public float b() {
      return this.j;
   }

   public float c() {
      return this.k;
   }

   public void a(float var1) {
      this.i = var1;
   }

   public void b(float var1) {
      this.j = var1;
   }

   public void c(float var1) {
      this.k = var1;
   }

   public float d() {
      return this.l;
   }

   public float e() {
      return this.m;
   }

   public float f() {
      return this.n;
   }

   public void d(float var1) {
      this.l = var1;
   }

   public void e(float var1) {
      this.m = var1;
   }

   public void f(float var1) {
      this.n = var1;
   }

   public float g() {
      return this.o;
   }

   public float h() {
      return this.p;
   }

   public float i() {
      return this.q;
   }

   public void g(float var1) {
      this.o = var1;
   }

   public void h(float var1) {
      this.p = var1;
   }

   public void i(float var1) {
      this.q = var1;
   }

   public float j() {
      return this.f;
   }

   public float k() {
      return this.g;
   }

   public float l() {
      return this.h;
   }

   public void j(float var1) {
      this.f = var1;
   }

   public void k(float var1) {
      this.g = var1;
   }

   public void l(float var1) {
      this.h = var1;
   }

   public String m() {
      return this.d;
   }

   public boolean n() {
      return this.e;
   }

   public void a(boolean var1) {
      this.e = var1;
   }
}
