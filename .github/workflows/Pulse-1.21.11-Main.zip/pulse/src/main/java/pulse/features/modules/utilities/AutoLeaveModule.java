package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ModeSetting;
import pulse.utils.game.ChatUtils;
import pulse.utils.game.FriendUtils;

@ModuleInfo(
   a = "Auto Leave",
   b = "Автоматический выход при обнаружении игроков",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoLeaveModule extends Module {
   private final ModeSetting a = new ModeSetting("Режим отключения", new String[]{"Выход с сервера", "/hub"}, "Выход с сервера");
   private final Map<Integer, Long> b = new HashMap<>();
   private boolean c = false;
   private boolean f = false;
   private boolean g = false;
   private int h = -1;
   private long i = 0L;
   private long j = 0L;
   private final Pattern k = Pattern.compile("\\((.*?)\\)\\s+.*?\\s+(\\S+)\\s+[—–-]\\s+(\\d+\\.\\d+)\\s+блоков");
   private final Pattern l = Pattern.compile(".*Команда будет доступна через\\s+(\\d+)\\s+мин\\.?\\s*(\\d+)?\\s*сек\\.?");
   private final Pattern m = Pattern.compile("Вокруг вас никого нет");
   private final Pattern n = Pattern.compile("Повторите текст еще раз\\.");
   private Text o = null;
   private boolean p = false;
   private int q = -1;

   @Compile
   @Override
      public void e() {
      super.e();
      this.b.clear();
      this.c = false;
      this.f = false;
      this.g = false;
      this.h = -1;
      this.i = 0L;
      this.j = 0L;
      if (this.o()) {
         this.f = true;
         this.i = System.currentTimeMillis();
      }
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.b.clear();
      this.c = false;
      this.f = false;
      this.g = false;
      this.j = 0L;
   }

   @EventHandler
   @Compile
      private void a(WorldChangeEvent var1) {
      if (this.o()) {
         this.c = false;
         this.f = true;
         this.g = false;
         this.i = System.currentTimeMillis();
      }
   }

   @EventHandler
   @Compile
   private void a(UpdateEvent var1) {
      Map<Integer, Long> cooldowns = this.b;
      if (!this.o()) {
         return;
      }
      long now = System.currentTimeMillis();
      int server = this.n();
      if (server != -1 && server != this.h) {
         this.h = server;
         this.c = false;
         this.g = false;
      }
      if (now - this.j > 1000L) {
         this.j = now;
         this.p();
      }
      if (this.f) {
         if (this.h != -1) {
            this.f = false;
            Long deadline = cooldowns.get(this.h);
            if (deadline == null || now >= deadline) {
               this.q();
               this.g = true;
            }
         } else if (now - this.i > 5000L) {
            this.f = false;
         }
      }
      if (!this.f && !this.g && this.h != -1) {
         Long deadline = cooldowns.get(this.h);
         if (deadline == null || now >= deadline) {
            this.q();
            this.g = true;
         }
      }
   }

   private void p() {
      long var1 = System.currentTimeMillis();
      Iterator var3 = this.b.entrySet().iterator();

      while (var3.hasNext()) {
         Entry var4 = (Entry)var3.next();
         int var5 = (Integer)var4.getKey();
         long var6 = (Long)var4.getValue();
         if (var1 >= var6) {
            var3.remove();
            if (var5 == this.h && !this.g && !this.c) {
               this.q();
               this.g = true;
            }
         }
      }
   }

   @EventHandler
   @Compile
   public void a(PacketEvent var1) {
      Pattern cooldownPattern = this.l;
      Pattern emptyPattern = this.m;
      Pattern playerPattern = this.k;
      Pattern repeatPattern = this.n;
      if (!this.o()) {
         return;
      }
      Object packet = var1.d();
      if (packet instanceof net.minecraft.network.packet.s2c.play.GameMessageS2CPacket) {
         String message = Formatting.strip(((net.minecraft.network.packet.s2c.play.GameMessageS2CPacket)packet).content().getString());
         if (message.contains("[✇] Радар ›")) {
            this.c = true;
         }
         Matcher cooldown = cooldownPattern.matcher(message);
         if (cooldown.find()) {
            this.a(cooldown);
            var1.b();
            return;
         }
         if (this.c) {
            if (emptyPattern.matcher(message).find()) {
               this.c = false;
               this.g = false;
            } else if (playerPattern.matcher(message).find()) {
               this.a(message);
            } else if (repeatPattern.matcher(message).find()) {
               var1.b();
               this.q();
            }
         }
      }
   }

   private void q() {
      if (d.player != null) {
         ChatUtils.a("near max");
         this.c = true;
      }
   }

   private void a(Matcher var1) {
      this.c = false;
      this.g = false;
      int var2 = Integer.parseInt(var1.group(1));
      int var3 = var1.group(2) != null ? Integer.parseInt(var1.group(2)) : 0;
      long var4 = (var2 * 60L + var3) * 1000L;
      long var6 = System.currentTimeMillis() + var4 + 2000L;
      this.b.put(this.h, var6);
   }

   private void a(String var1) {
      Matcher var2 = this.k.matcher(var1);
      if (var2.find()) {
         String var3 = var2.group(2);
         if (FriendUtils.a(var3)) {
            this.c = false;
            this.g = false;
            return;
         }

         this.c = false;
         this.g = false;
         String var4 = var2.group(3);
         String var5 = "Обнаружен игрок " + var3 + " на расстоянии " + var4 + " блоков";
         if (d.player != null) {
            if (this.a.b("Выход с сервера")) {
               if (d.getNetworkHandler() != null) {
                  d.getNetworkHandler().getConnection().disconnect(Text.of(var5));
               }
            } else if (this.a.b("/hub")) {
               ChatUtils.a("hub");
               ChatUtils.a((Object)var5);
            }
         }
      }
   }

   public int n() {
      try {
         if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
            PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
            Text var2 = var1.getHeader();
            if (this.p && var2 == this.o) {
               return this.q;
            } else {
               this.o = var2;
               this.p = true;
               if (var2 == null) {
                  this.q = -1;
                  return -1;
               } else {
                  String var3 = Formatting.strip(var2.getString());
                  if (var3 != null && var3.contains("Анархия-")) {
                     String[] var4 = var3.split("Анархия-");
                     if (var4.length < 2) {
                        this.q = -1;
                        return -1;
                     } else {
                        String var5 = var4[1].trim();

                        try {
                           this.q = Integer.parseInt(var5);
                        } catch (NumberFormatException var7) {
                           this.q = -1;
                        }

                        return this.q;
                     }
                  } else {
                     this.q = -1;
                     return -1;
                  }
               }
            }
         } else {
            return -1;
         }
      } catch (Exception var8) {
         return -1;
      }
   }

   public boolean o() {
      return d.world != null && d.world.getRegistryKey() == World.OVERWORLD && !d.isInSingleplayer();
   }

   static {
      NativeMethodLookup.lookup(AutoLeaveModule.class, 50);
   }
}
