package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.PlayerListEntry;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.InputSetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Auto Duel",
   b = "Автоматически отправляет запросы на дуэли игрокам",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoDuelModule extends Module {
   private final ModeSetting a = new ModeSetting(
      "Набор", new String[]{"Щит", "Шипы 3", "Лук", "Тотемы", "Нодебафф", "Шары", "Классик", "Читерский рай", "Незеритка"}, "Шары"
   );
   private final BooleanSetting b = new BooleanSetting("Ставить деньги", false);
   private final InputSetting c = new InputSetting("Сумма ставки", InputSetting.InputType.e, "2000", "Введите сумму").c(this.b::q);
   private static final Pattern f = Pattern.compile("^\\w{3,16}$");
   private final Set<String> g = new HashSet<>();
   private long h = 0L;
   private long i = 0L;
   private List<String> j = new ArrayList<>();
   private long k = 0L;
   private String l = "";
   private boolean m = false;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      ModeSetting kit = this.a;
      Set<String> requested = this.g;
      BooleanSetting useMoney = this.b;
      InputSetting amount = this.c;
      if (d.player == null || d.world == null) {
         return;
      }
      if (d.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?>) {
         String title = d.currentScreen.getTitle().getString();
         boolean same;
         try {
            same = title.equals(this.l);
         } catch (RuntimeException | Error failure) {
            this.l = title;
            throw failure;
         }
         if (!same) {
            this.l = title;
            this.m = false;
         }
         if (!this.m) {
            int syncId = d.player.currentScreenHandler.syncId;
            if (title.contains("Выбор набора")) {
               int slot = (Integer)kit.q();
               d.interactionManager.clickSlot(syncId, slot, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, d.player);
               this.m = true;
            } else if (title.contains("Настройка поединка")) {
               d.interactionManager.clickSlot(syncId, 0, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, d.player);
               this.m = true;
            }
         }
      } else {
         this.l = "";
         this.m = false;
      }
      List<String> players = this.n();
      long now = System.currentTimeMillis();
      int count;
      try {
         count = players.size();
      } catch (RuntimeException | Error failure) {
         if (now - this.i < 0L && players != null) {
            players.iterator();
         }
         throw failure;
      }
      if (now - this.i >= (long)count * 800L) {
         requested.clear();
         this.i = now;
      }
      for (String name : players) {
         if (!requested.contains(name) && !name.equals(d.getSession().getUsername()) && now - this.h >= 1000L) {
            String command = "duel " + name;
            if ((Boolean)useMoney.q()) {
               command += " " + ((String)amount.q()).replace(",", "");
            }
            pulse.utils.game.ChatUtils.a(command);
            requested.add(name);
            this.h = now;
         }
      }
   }

   private List<String> n() {
      long var1 = System.currentTimeMillis();
      if (var1 - this.k < 1000L && !this.j.isEmpty()) {
         return this.j;
      } else {
         this.k = var1;
         ArrayList var3 = new ArrayList();

         for (PlayerListEntry var5 : d.player.networkHandler.getPlayerList()) {
            String var6 = var5.getProfile().name();
            if (f.matcher(var6).matches()) {
               var3.add(var6);
            }
         }

         this.j = var3;
         return var3;
      }
   }

   @EventHandler
   @Compile
   public void a(PacketEvent var1) {
      if (var1.e() == PacketEvent.EventType.b && var1.d() instanceof net.minecraft.network.packet.s2c.play.GameMessageS2CPacket) {
         String message = net.minecraft.util.Formatting.strip(((net.minecraft.network.packet.s2c.play.GameMessageS2CPacket)var1.d()).content().getString()).toLowerCase(java.util.Locale.ROOT);
         if (message.contains("начало") && message.contains("через") && message.contains("секунд!") || message.equals("дуэли » во время поединка запрещено использовать команды")) {
            this.d();
         }
      }
   }

   @EventHandler
   @Compile
      public void a(WorldChangeEvent var1) {
      this.g.clear();
      this.l = "";
      this.m = false;
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.g.clear();
      this.l = "";
      this.m = false;
   }

   static {
      NativeMethodLookup.lookup(AutoDuelModule.class, 47);
   }
}
