package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import pulse.core.event.impl.AttackEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;

@ModuleInfo(
   a = "Mace Helper",
   b = "Показывает заряд булавы при ударе и подсвечивает её текстуру",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class MaceHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Сообщение в чат", true);
   private final BooleanSetting b = new BooleanSetting("Подсветка в руке", true);
   private final BooleanSetting c = new BooleanSetting("Подсветка в хотбаре", true);
   private static final ThreadLocal<Integer> f = ThreadLocal.withInitial(() -> 0);

   public static void b(int var0) {
      f.set(var0);
   }

   public static int n() {
      return f.get();
   }

   public boolean a(ItemStack var1) {
      return var1 != null && var1.isOf(Items.MACE);
   }

   public boolean o() {
      return d.player != null && this.a(d.player.getMainHandStack());
   }

   public float p() {
      return d.player == null ? 0.0F : Math.max(0.0F, Math.min(1.0F, d.player.getAttackCooldownProgress(0.0F)));
   }

   public Color a(float var1) {
      var1 = Math.max(0.0F, Math.min(1.0F, var1));
      int var2;
      int var3;
      if (var1 < 0.5F) {
         float var4 = var1 / 0.5F;
         var2 = 255;
         var3 = (int)(255.0F * var4);
      } else {
         float var6 = (var1 - 0.5F) / 0.5F;
         var2 = (int)(255.0F * (1.0F - var6));
         var3 = 255;
      }

      return new Color(var2, var3, 0);
   }

   public boolean q() {
      return this.b.a();
   }

   public boolean r() {
      return this.c.a();
   }

   @EventHandler
   @Compile
      public void a(AttackEvent var1) {
      if (!this.a.a() || d.player == null
            || !(var1.a() instanceof net.minecraft.entity.LivingEntity) || !this.o()) {
         return;
      }
      pulse.utils.game.ChatUtils.a((Object)("Булава заряжена на &f" + Math.round(this.p() * 100.0F) + "%"));
   }

   static {
      NativeMethodLookup.lookup(MaceHelperModule.class, 67);
   }
}
