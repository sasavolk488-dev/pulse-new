package pulse.ui.clickgui.common;

import java.awt.Color;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class ClientColorElement {
   private static final float a = 16.0F;
   private float b;
   private float c;
   private float d;
   private final Animation e = new Animation();
   private boolean f = false;
   private Consumer<Void> g;

   public void a(Consumer<Void> var1) {
      this.g = var1;
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, int var6, int var7) {
      this.b = var3;
      this.c = var4;
      this.d = var5;
      this.e.a();
      boolean var8 = OverlayElement.a().b();
      boolean var9 = !var8 && MouseUtil.a(var3, var4, var5, var5, (double)var6, (double)var7);
      if (var8 && this.f) {
         this.e.a(0.0, 0.15000000122646792, Easings.h);
         this.f = false;
      } else if (!var8 && var9 != this.f) {
         this.e.a(var9 ? 1.0 : 0.0, 0.15000000122646792, Easings.h);
         this.f = var9;
      }

      float var10 = (float)this.e.j();
      this.a(var1, var2, var3, var4, var5, var10);
      if (var9 && !var8) {
         MouseUtil.g();
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6) {
      FontRenderer var7 = Fonts.d[16];
      String var8 = "\ue926";
      float var9 = var7.a(var8);
      float var10 = var7.b(var8);
      float var11 = var3 + (var5 - var9) / 2.0F;
      float var12 = var4 + (var5 - var10) / 2.0F + 4.0F;
      byte var13 = 49;
      byte var14 = 49;
      byte var15 = 69;
      int var16 = (int)(var6 * 40.0F);
      Color var17 = new Color(Math.min(255, var13 + var16), Math.min(255, var14 + var16), Math.min(255, var15 + var16));
      var7.a(var8, var11, var12, var17, var1);
   }

   public boolean a(int var1, int var2) {
      boolean var3 = OverlayElement.a().b();
      boolean var4 = MouseUtil.a(this.b, this.c, this.d, this.d, (double)var1, (double)var2);
      if (var4 && !var3) {
         if (this.g != null) {
            this.g.accept(null);
         }

         return true;
      } else {
         return false;
      }
   }

   public float a() {
      return this.b;
   }

   public float b() {
      return this.c;
   }

   public float c() {
      return this.d;
   }
}
