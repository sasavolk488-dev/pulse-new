package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.Perspective;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.KeySetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Free Look",
   b = "Позволяет поворачивать камеру независимо от игрока",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FreeLookModule extends Module {
   public final ModeSetting a = new ModeSetting("Режим активации", new String[]{"Удержание", "Переключение"}, 0);
   public final KeySetting b = new KeySetting("Кнопка FreeLook", 342);
   public static boolean c = false;
   public static float f = 0.0F;
   public static float g = 0.0F;
   private Perspective h = Perspective.FIRST_PERSON;
   private boolean i = false;
   private boolean j = false;

   @EventHandler
   @Compile
      public void a(UpdateEvent var1) {
      if (d.player == null) {
         return;
      }
      boolean pressed = false;
      if (this.b.c()) {
         d.getWindow().getHandle();
         pressed = net.minecraft.client.util.InputUtil.isKeyPressed(
               net.minecraft.client.MinecraftClient.getInstance().getWindow(), this.b.b())
            && d.currentScreen == null;
      }
      boolean active = pressed && this.k();
      if (this.a.b("Удержание")) {
         if (active && !this.i) {
            this.n();
         }
         if (!active && this.i) {
            this.o();
         }
      } else if (active && !this.i) {
         if (!this.j) {
            this.n();
            this.j = true;
         } else {
            this.o();
            this.j = false;
         }
      }
      this.i = active;
   }

   private void n() {
      this.h = d.options.getPerspective();
      f = d.player.getYaw(1.0F);
      g = d.player.getPitch(1.0F);
      d.options.setPerspective(Perspective.THIRD_PERSON_BACK);
      c = true;
   }

   private void o() {
      d.options.setPerspective(this.h);
      c = false;
   }

   @Compile
   @Override
      public void f() {
      if (c) {
         d.options.setPerspective(this.h);
         c = false;
      }
      this.i = false;
      this.j = false;
      super.f();
   }

   static {
      NativeMethodLookup.lookup(FreeLookModule.class, 61);
   }
}
