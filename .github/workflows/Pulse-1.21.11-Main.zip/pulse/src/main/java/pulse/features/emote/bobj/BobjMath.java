package pulse.features.emote.bobj;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class BobjMath {
   private BobjMath() {
   }

   static float[] a() {
      return new float[]{1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F};
   }

   static float[] a(float[] var0, float[] var1) {
      float[] var2 = new float[16];

      for (int var3 = 0; var3 < 4; var3++) {
         for (int var4 = 0; var4 < 4; var4++) {
            float var5 = 0.0F;

            for (int var6 = 0; var6 < 4; var6++) {
               var5 += var0[var3 * 4 + var6] * var1[var6 * 4 + var4];
            }

            var2[var3 * 4 + var4] = var5;
         }
      }

      return var2;
   }

   static float[] a(float[] var0) {
      double[][] var1 = new double[4][8];

      for (int var2 = 0; var2 < 4; var2++) {
         for (int var3 = 0; var3 < 4; var3++) {
            var1[var2][var3] = var0[var2 * 4 + var3];
         }

         var1[var2][var2 + 4] = 1.0;
      }

      for (int var11 = 0; var11 < 4; var11++) {
         int var13 = var11;

         for (int var4 = var11 + 1; var4 < 4; var4++) {
            if (Math.abs(var1[var4][var11]) > Math.abs(var1[var13][var11])) {
               var13 = var4;
            }
         }

         if (Math.abs(var1[var13][var11]) < 9.999996537374683E-11) {
            throw new IllegalArgumentException("Singular BOBJ matrix");
         }

         double[] var15 = var1[var11];
         var1[var11] = var1[var13];
         var1[var13] = var15;
         double var5 = var1[var11][var11];

         for (int var7 = 0; var7 < 8; var7++) {
            var1[var11][var7] = var1[var11][var7] / var5;
         }

         for (int var17 = 0; var17 < 4; var17++) {
            if (var17 != var11) {
               double var8 = var1[var17][var11];

               for (int var10 = 0; var10 < 8; var10++) {
                  var1[var17][var10] = var1[var17][var10] - var8 * var1[var11][var10];
               }
            }
         }
      }

      float[] var12 = new float[16];

      for (int var14 = 0; var14 < 4; var14++) {
         for (int var16 = 0; var16 < 4; var16++) {
            var12[var14 * 4 + var16] = (float)var1[var14][var16 + 4];
         }
      }

      return var12;
   }

   static float[] a(float var0, float var1, float var2) {
      return new float[]{1.0F, 0.0F, 0.0F, var0, 0.0F, 1.0F, 0.0F, var1, 0.0F, 0.0F, 1.0F, var2, 0.0F, 0.0F, 0.0F, 1.0F};
   }

   static float[] b(float var0, float var1, float var2) {
      return new float[]{var0, 0.0F, 0.0F, 0.0F, 0.0F, var1, 0.0F, 0.0F, 0.0F, 0.0F, var2, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F};
   }

   static float[] a(float var0) {
      float var1 = (float)Math.cos(var0);
      float var2 = (float)Math.sin(var0);
      return new float[]{1.0F, 0.0F, 0.0F, 0.0F, 0.0F, var1, -var2, 0.0F, 0.0F, var2, var1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F};
   }

   static float[] b(float var0) {
      float var1 = (float)Math.cos(var0);
      float var2 = (float)Math.sin(var0);
      return new float[]{var1, 0.0F, var2, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, -var2, 0.0F, var1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F};
   }

   static float[] c(float var0) {
      float var1 = (float)Math.cos(var0);
      float var2 = (float)Math.sin(var0);
      return new float[]{var1, -var2, 0.0F, 0.0F, var2, var1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F};
   }

   static void a(float[] var0, float var1, float var2, float var3, float[] var4) {
      var4[0] = var0[0] * var1 + var0[1] * var2 + var0[2] * var3 + var0[3];
      var4[1] = var0[4] * var1 + var0[5] * var2 + var0[6] * var3 + var0[7];
      var4[2] = var0[8] * var1 + var0[9] * var2 + var0[10] * var3 + var0[11];
   }

   static void b(float[] var0, float var1, float var2, float var3, float[] var4) {
      var4[0] = var0[0] * var1 + var0[1] * var2 + var0[2] * var3;
      var4[1] = var0[4] * var1 + var0[5] * var2 + var0[6] * var3;
      var4[2] = var0[8] * var1 + var0[9] * var2 + var0[10] * var3;
   }
}
