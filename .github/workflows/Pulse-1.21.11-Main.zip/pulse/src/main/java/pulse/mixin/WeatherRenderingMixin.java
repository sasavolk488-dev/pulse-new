package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.WeatherRendering;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.Precipitation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.AtmosphereModule;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({WeatherRendering.class})
public class WeatherRenderingMixin {
   @Redirect(
      method = {"buildPrecipitationPieces"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/World;getRainGradient(F)F"
      )
   )
   private float pulse$snowGradient(World var1, float var2) {
      AtmosphereModule var3 = ModuleRegistry.r;
      RenderTweaksModule var4 = ModuleRegistry.h;
      boolean var5 = var4 != null && var4.n();
      return var3 != null && var3.p() && !var5 ? var3.s() : var1.getRainGradient(var2);
   }

   @Inject(
      method = {"getPrecipitationAt"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void pulse$atmosphereSnow(World var1, BlockPos var2, CallbackInfoReturnable<Precipitation> var3) {
      AtmosphereModule var4 = ModuleRegistry.r;
      if (var4 != null && var4.p()) {
         if (var3.getReturnValue() == Precipitation.RAIN) {
            var3.setReturnValue(Precipitation.SNOW);
         }
      }
   }
}
