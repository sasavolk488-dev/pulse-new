package pulse.mixin;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Style;
import net.minecraft.text.PlainTextContent.Literal;
import net.minecraft.text.StringVisitable.StyledVisitor;
import net.minecraft.text.StringVisitable.Visitor;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.core.api.IMinecraft;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.StreamerModeModule;

@Environment(EnvType.CLIENT)
@Mixin({Literal.class})
public class TextMixin implements IMinecraft {
   @Shadow
   @Final
   private String string;
   @Unique
   private static final Pattern holyWorldPattern = Pattern.compile("(СолоЛайт|ДуоЛайт|ТриоЛайт|КланЛайт)\\s*#(\\d{1,2})");
   @Unique
   private static final Pattern funTimePattern = Pattern.compile("Анархия-(\\d+)");
   @Unique
   private static volatile ServerInfo cachedServerEntry;
   @Unique
   private static volatile boolean cachedSupported;

   @Redirect(
      method = {"visit(Lnet/minecraft/text/StringVisitable$Visitor;)Ljava/util/Optional;"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/text/StringVisitable$Visitor;accept(Ljava/lang/String;)Ljava/util/Optional;"
      )
   )
   private <T> Optional<T> redirectVisitor(Visitor<T> var1, String var2) {
      return var1.accept(this.getProcessedText(var2));
   }

   @Redirect(
      method = {"visit(Lnet/minecraft/text/StringVisitable$StyledVisitor;Lnet/minecraft/text/Style;)Ljava/util/Optional;"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/text/StringVisitable$StyledVisitor;accept(Lnet/minecraft/text/Style;Ljava/lang/String;)Ljava/util/Optional;"
      )
   )
   private <T> Optional<T> redirectStyledVisitor(StyledVisitor<T> var1, Style var2, String var3) {
      return var1.accept(var2, this.getProcessedText(var3));
   }

   @Unique
   private String getProcessedText(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         StreamerModeModule var2 = ModuleRegistry.T;
         if (var2 == null || !var2.k()) {
            return var1;
         } else if (StreamerModeModule.n()) {
            return var1;
         } else {
            String var3 = var1;
            boolean var4 = false;
            if (var2.a.q() && d != null && d.getSession() != null) {
               String var5 = d.getSession().getUsername();
               if (var1.contains(var5)) {
                  var3 = var1.replace(var5, "pulse");
                  var4 = true;
               }
            }

            if (var2.b.q() && isSupportedServer()) {
               String var8 = hideServerNumber(var3);
               if (var8 != var3) {
                  var3 = var8;
                  var4 = true;
               }
            }

            return var3;
         }
      } else {
         return var1;
      }
   }

   @Unique
   private static boolean isSupportedServer() {
      ServerInfo var0 = d == null ? null : d.getCurrentServerEntry();
      if (var0 == null) {
         if (cachedServerEntry != null) {
            cachedSupported = false;
            cachedServerEntry = null;
         }

         return false;
      } else if (var0 == cachedServerEntry) {
         return cachedSupported;
      } else {
         String var1 = var0.address.toLowerCase();
         boolean var2 = var1.contains("holyworld") || var1.contains("funtime");
         cachedSupported = var2;
         cachedServerEntry = var0;
         return var2;
      }
   }

   @Unique
   private static String hideServerNumber(String var0) {
      if (var0.indexOf(1051) >= 0 || var0.indexOf(35) >= 0) {
         Matcher var1 = holyWorldPattern.matcher(var0);
         if (var1.find()) {
            return var1.replaceAll("pulsevisuals.pro");
         }
      }

      if (var0.indexOf(1040) >= 0 && var0.indexOf(45) >= 0) {
         Matcher var2 = funTimePattern.matcher(var0);
         if (var2.find()) {
            return var2.replaceAll("pulsevisuals.pro");
         }
      }

      return var0;
   }
}
