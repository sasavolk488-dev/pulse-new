package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import pulse.core.event.impl.RenderEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.utils.game.EntityUtils;
import pulse.utils.game.FriendUtils;
import pulse.utils.render.RenderUtils;
import pulse.utils.game.entity.EntityFinder;
import pulse.utils.game.entity.EntityTags;

@ModuleInfo(
   a = "FC Helper",
   b = "Предпросмотр зоны действия донат-предметов",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FCHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Шаровая молния", true);
   private final BooleanSetting b = new BooleanSetting("Ком слизи", true);
   private final BooleanSetting c = new BooleanSetting("Черепаший захват", true);
   private final BooleanSetting f = new BooleanSetting("Паутина судьбы", true);
   private final BooleanSetting g = new BooleanSetting("Стан", true);
   private final BooleanSetting h = new BooleanSetting("Магнитный шар", true);

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      BooleanSetting setting_a = this.a;
      BooleanSetting setting_b = this.b;
      BooleanSetting setting_c = this.c;
      BooleanSetting setting_f = this.f;
      BooleanSetting setting_g = this.g;
      BooleanSetting setting_h = this.h;
      if (d.world == null || d.player == null) {
         return;
      }
      MatrixStack matrices = var1.a();
      float tickDelta = var1.b();
      var mainItem = d.player.getMainHandStack().getItem();
      var offItem = d.player.getOffHandStack().getItem();
      if ((Boolean)setting_a.q() && (mainItem == Items.NETHER_STAR || offItem == Items.NETHER_STAR)) {
         this.a(matrices, tickDelta);
      }
      if ((Boolean)setting_b.q() && (mainItem == Items.SLIME_BALL || offItem == Items.SLIME_BALL)) {
         this.b(matrices, tickDelta);
      }
      if ((Boolean)setting_c.q() && (mainItem == Items.TURTLE_SCUTE || offItem == Items.TURTLE_SCUTE)) {
         this.a(matrices);
      }
      if ((Boolean)setting_f.q() && (mainItem == Items.COBWEB || offItem == Items.COBWEB)) {
         this.b(matrices);
      }
      if ((Boolean)setting_g.q() && (mainItem == Items.ENDER_EYE || offItem == Items.ENDER_EYE)) {
         this.c(matrices, tickDelta);
      }
      if ((Boolean)setting_h.q() && (mainItem == Items.FIREWORK_STAR || offItem == Items.FIREWORK_STAR)) {
         this.d(matrices, tickDelta);
      }
   }

   private void a(MatrixStack var1, float var2) {
      Vec3d var3 = this.a(var2);
      Box var4 = new Box(var3.x - 10.0, var3.y - 10.0, var3.z - 10.0, var3.x + 10.0, var3.y + 10.0, var3.z + 10.0);
      int var5 = this.a(var4) ? -16711936 : -1;
      RenderUtils.b(var1, var4, var5);
   }

   private void b(MatrixStack var1, float var2) {
      Vec3d var3 = this.a(var2);
      double var4 = var3.y + 1.0;
      Box var6 = new Box(var3.x - 5.0, var4, var3.z - 5.0, var3.x + 5.0, var4, var3.z + 5.0);
      Box var7 = new Box(var3.x - 5.0, var4 - 5.0, var3.z - 5.0, var3.x + 5.0, var4 + 5.0, var3.z + 5.0);
      int var8 = this.b(var7) ? -16711936 : -1;
      RenderUtils.b(var1, var6, var8);
   }

   private void a(MatrixStack var1) {
      BlockPos var2 = d.player.getBlockPos();
      Box var3 = new Box(var2.getX() - 3, var2.getY() - 1, var2.getZ() - 3, var2.getX() + 4, var2.getY() + 5, var2.getZ() + 4);
      int var4 = this.b(var3) ? -16711936 : -1;
      RenderUtils.b(var1, var3, var4);
   }

   private void b(MatrixStack var1) {
      BlockPos var2 = d.player.getBlockPos();
      float var3 = (d.player.getYaw() % 360.0F + 360.0F) % 360.0F;
      byte var4 = 3;
      BlockPos var5;
      if (var3 >= 315.0F || var3 < 45.0F) {
         var5 = var2.add(0, 0, var4);
      } else if (var3 >= 45.0F && var3 < 135.0F) {
         var5 = var2.add(-var4, 0, 0);
      } else if (var3 >= 135.0F && var3 < 225.0F) {
         var5 = var2.add(0, 0, -var4);
      } else {
         var5 = var2.add(var4, 0, 0);
      }

      double var6 = var5.getY();
      double var8 = var5.getY() + 3;
      double var10;
      double var12;
      double var14;
      double var16;
      if (!(var3 >= 315.0F) && !(var3 < 45.0F) && (!(var3 >= 135.0F) || !(var3 < 225.0F))) {
         var10 = var5.getX();
         var14 = var5.getX() + 1;
         var12 = var5.getZ() - 1;
         var16 = var5.getZ() + 2;
      } else {
         var10 = var5.getX() - 1;
         var14 = var5.getX() + 2;
         var12 = var5.getZ();
         var16 = var5.getZ() + 1;
      }

      Box var18 = new Box(var10, var6, var12, var14, var8, var16);
      int var19 = this.b(var18) ? -16711936 : -1;
      RenderUtils.b(var1, var18, var19);
   }

   private void c(MatrixStack var1, float var2) {
      Vec3d var3 = this.a(var2);
      Box var4 = new Box(var3.x - 30.0, var3.y - 30.0, var3.z - 30.0, var3.x + 30.0, var3.y + 30.0, var3.z + 30.0);
      int var5 = this.b(var4) ? -16711936 : -1;
      RenderUtils.b(var1, var4, var5);
   }

   private void d(MatrixStack var1, float var2) {
      Vec3d var3 = this.a(var2);
      double var4 = 7.0;
      Box var6 = new Box(var3.x - var4, var3.y + 1.0, var3.z - var4, var3.x + var4, var3.y + 1.0, var3.z + var4);
      Box var7 = new Box(var3.x - var4, var3.y - 6.0, var3.z - var4, var3.x + var4, var3.y + 8.0, var3.z + var4);
      int var8 = this.b(var7) ? -16711936 : -1;
      RenderUtils.b(var1, var6, var8);
   }

   private Vec3d a(float var1) {
      return new Vec3d(
         d.player.lastRenderX + (d.player.getX() - d.player.lastRenderX) * var1,
         d.player.lastRenderY + (d.player.getY() - d.player.lastRenderY) * var1,
         d.player.lastRenderZ + (d.player.getZ() - d.player.lastRenderZ) * var1
      );
   }

   private boolean a(Box var1) {
      for (Entity var3 : EntityFinder.a(var1x -> var1x instanceof PlayerEntity && var1.contains(var1x.getLerpedPos(1.0F)), EntityTags.a)) {
         if (var3 != d.player) {
            PlayerEntity var4 = (PlayerEntity)var3;
            if (!EntityUtils.a((LivingEntity)var4)
               && !FriendUtils.a(var4.getName().getString())
               && var4.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean b(Box var1) {
      for (Entity var3 : EntityFinder.a(var1x -> var1x instanceof PlayerEntity && var1.contains(var1x.getLerpedPos(1.0F)), EntityTags.a)) {
         if (var3 != d.player) {
            PlayerEntity var4 = (PlayerEntity)var3;
            if (!EntityUtils.a((LivingEntity)var4) && !FriendUtils.a(var4.getName().getString())) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean a(List<BlockPos> var1) {
      for (Entity var3 : EntityFinder.a(var0 -> var0 instanceof PlayerEntity, EntityTags.a)) {
         if (var3 != d.player) {
            PlayerEntity var4 = (PlayerEntity)var3;
            if (!FriendUtils.a(var4.getName().getString())) {
               BlockPos var5 = var3.getBlockPos();

               for (BlockPos var7 : var1) {
                  if (var5.equals(var7)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   static {
      NativeMethodLookup.lookup(FCHelperModule.class, 57);
   }
}
