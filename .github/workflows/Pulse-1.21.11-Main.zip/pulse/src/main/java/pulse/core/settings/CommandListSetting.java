package pulse.core.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CommandListSetting extends InputSetting {
   public static final int a = 1;
   public static final int b = 3600;
   public static final int c = 60;
   public static final int d = 100;
   private final List<CommandListSetting.Entry> e = new ArrayList<>();

   public static int a(int var0) {
      return Math.max(1, Math.min(3600, var0));
   }

   public CommandListSetting(String var1) {
      super(var1, InputSetting.InputType.a, "", "");
   }

   @Override
   public void a(String var1) {
      super.a(var1);
      this.d(var1);
   }

   @Override
   public void c_() {
      super.c_();
      this.d(this.q());
   }

   public List<CommandListSetting.Entry> b() {
      return this.e;
   }

   @Override
   public boolean c() {
      return this.e.isEmpty();
   }

   public void a(String var1, int var2) {
      this.e.add(new CommandListSetting.Entry(var1, var2));
      this.d();
   }

   public void b(int var1) {
      if (var1 >= 0 && var1 < this.e.size()) {
         this.e.remove(var1);
         this.d();
      }
   }

   public void d() {
      super.a(this.s());
   }

   private String s() {
      StringBuilder var1 = new StringBuilder();

      for (CommandListSetting.Entry var3 : this.e) {
         if (var1.length() > 0) {
            var1.append(';');
         }

         var1.append(var3.b).append(',').append(c(var3.a));
      }

      return var1.toString();
   }

   private static String c(String var0) {
      return var0.replace("\\", "\\\\").replace(";", "\\;");
   }

   private void d(String var1) {
      this.e.clear();
      if (var1 != null && !var1.isEmpty()) {
         StringBuilder var2 = new StringBuilder();
         boolean var3 = false;

         for (int var4 = 0; var4 < var1.length(); var4++) {
            char var5 = var1.charAt(var4);
            if (var3) {
               var2.append(var5);
               var3 = false;
            } else if (var5 == '\\') {
               var3 = true;
            } else if (var5 == ';') {
               this.e(var2.toString());
               var2.setLength(0);
            } else {
               var2.append(var5);
            }
         }

         this.e(var2.toString());
      }
   }

   private void e(String var1) {
      int var2 = var1.indexOf(44);
      if (var2 >= 0) {
         try {
            this.e.add(new CommandListSetting.Entry(var1.substring(var2 + 1), Integer.parseInt(var1.substring(0, var2).trim())));
         } catch (NumberFormatException var4) {
         }
      }
   }

   public CommandListSetting a(Supplier<Boolean> var1) {
      super.c(var1);
      return this;
   }

   @Override
   public InputSetting c(Supplier var1) {
      return this.a(var1);
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }

   @Environment(EnvType.CLIENT)
   public static final class Entry {
      private String a;
      private int b;

      public Entry(String var1, int var2) {
         this.a = var1 == null ? "" : var1;
         this.b = CommandListSetting.a(var2);
      }

      public String a() {
         return this.a;
      }

      public int b() {
         return this.b;
      }

      public void a(String var1) {
         this.a = var1 == null ? "" : var1;
      }

      public void a(int var1) {
         this.b = CommandListSetting.a(var1);
      }
   }
}
