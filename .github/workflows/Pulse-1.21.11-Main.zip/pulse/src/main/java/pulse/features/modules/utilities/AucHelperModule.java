package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import pulse.core.event.impl.KeyEvent;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.utilities.auc.AucItem;
import pulse.features.modules.utilities.auc.AucMatcher;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.KeySetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.game.ChatUtils;
import pulse.utils.time.TimeUtils;

@ModuleInfo(
   a = "Auc Helper",
   b = "Автоматически перевыставляет предметы на аукционе",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AucHelperModule extends Module {
   private final BooleanSetting f = new BooleanSetting("Автоперевыставление", true);
   private final ModeSetting g = new ModeSetting("Режим перевыставления", new String[]{"Через меню", "Командой /ah resell"}, "Через меню").a(() -> this.f.a());
   private final BooleanSetting h = new BooleanSetting("Авто открытие аукциона", true).a(() -> this.f.a() && this.g.b("Через меню"));
   private final BooleanSetting i = new BooleanSetting("Закрывать после обновления", true).a(() -> this.f.a() && this.g.b("Через меню"));
   private final SeparatorSetting j = new SeparatorSetting("Поиск предмета");
   private final KeySetting k = new KeySetting("Поиск предмета в руке");
   private final SeparatorSetting l = new SeparatorSetting("Подсветка «Отдачи»");
   private final BooleanSetting m = new BooleanSetting("Подсветка мечей с отдачей", false);
   private final ColorSetting n = new ColorSetting("Цвет подсветки", new Color(255, 170, 60)).a(() -> this.m.a());
   public boolean a = false;
   public TimeUtils b = new TimeUtils();
   public int c = 0;
   private boolean o = false;
   private int p = -1;
   private final int q = 52;
   private boolean r = false;
   private int s = 0;
   private boolean t = false;
   private boolean u = false;
   private int v = 0;
   private final int w = 46;
   private boolean x = false;
   private int y = 0;
   private boolean z = false;
   private static final Pattern A = Pattern.compile("Подождите (\\d+) сек");

   @EventHandler
   @Compile
   public void a(PacketEvent var1) {
      BooleanSetting closeAfterRefresh = this.i;
      Object first;
      try {
         first = var1.d();
      } catch (RuntimeException | Error failure) {
         if (var1 != null) {
            var1.d();
         }
         throw failure;
      }
      if (first instanceof net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket) {
         var packet = (net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket)var1.d();
         String title = packet.getName().getString();
         boolean storage;
         try {
            storage = title.contains("Хранилище");
         } catch (RuntimeException | Error failure) {
            var1.d();
            throw failure;
         }
         if (storage) {
            try {
               this.p = packet.getSyncId();
            } catch (RuntimeException | Error failure) {
               this.p = 0;
               throw failure;
            }
            if (!this.a) {
               this.r = true;
               this.s = 0;
            }
            this.t = false;
            this.u = false;
         } else if (title.contains("Аукцион") && this.u) {
            this.v = 0;
         } else if (title.contains("Аукцион") && this.t) {
            this.t = false;
            this.u = true;
            this.v = 0;
         }
      }
      if (var1.d() instanceof net.minecraft.network.packet.s2c.play.GameMessageS2CPacket) {
         var packet = (net.minecraft.network.packet.s2c.play.GameMessageS2CPacket)var1.d();
         String message = Formatting.strip(packet.content().getString());
         var matcher = A.matcher(message);
         boolean waiting;
         try {
            waiting = matcher.find();
         } catch (RuntimeException | Error failure) {
            if (message.contains("Предметы успешно перевыставлены")) {
               this.a = true;
            }
            throw failure;
         }
         if (waiting && !this.a) {
            int seconds = Integer.parseInt(matcher.group(1));
            this.a = true;
            this.c = seconds * 1000;
            this.b.b();
            var1.b();
         }
         if (message.contains("Предметы успешно перевыставлены")) {
            if (!this.a) {
               this.a = true;
               this.c = 60000;
               this.b.b();
            }
            if ((Boolean)closeAfterRefresh.q() && d.currentScreen != null) {
               String title;
               try {
                  title = d.currentScreen.getTitle().getString();
               } catch (Exception ignored) {
                  return;
               }
               if (title.contains("Хранилище") || title.contains("Аукцион")) {
                  this.x = true;
                  this.y = 0;
               }
            }
         }
      }
   }

   @EventHandler
   @Compile
   public native void a(UpdateEvent var1);

   @EventHandler
   @Compile
   public void a(KeyEvent var1) {
      KeySetting binding = this.k;
      if (this.k() && var1.c() == 1 && binding.c() && var1.a() == binding.b() && d.currentScreen == null && d.player != null && d.world != null) {
         ItemStack stack = d.player.getMainHandStack();
         if (!stack.isEmpty()) {
            this.a(stack);
         }
      }
   }

   public void a(ItemStack var1) {
      if (var1 != null && !var1.isEmpty() && d.player != null) {
         String var2 = this.b(var1);
         if (var2 != null && !var2.isEmpty()) {
            ChatUtils.a("ah search " + var2);
         }
      }
   }

   private String b(ItemStack var1) {
      String var2 = AucMatcher.b(var1);
      if (var2 != null) {
         return this.b(var2);
      } else {
         if (!this.c(var1)) {
            AucItem var3 = AucMatcher.e(var1);
            if (var3 != null) {
               return this.b(var3.b());
            }
         }

         String var4 = AucMatcher.d(var1);
         return var4 != null ? this.b(var4) : this.b(var1.getItem().getName().getString());
      }
   }

   public void a(ItemStack var1, List<Text> var2) {
      if (this.k() && this.m.a()) {
         if (var1 != null && !var1.isEmpty() && var1.isIn(ItemTags.SWORDS)) {
            if (var2 != null && var2.size() >= 2) {
               int var3 = this.n();

               for (int var4 = 1; var4 < var2.size(); var4++) {
                  Text var5 = (Text)var2.get(var4);
                  if (var5 != null) {
                     String var6 = var5.getString();
                     if (a(var6)) {
                        var2.set(var4, Text.literal(var6).setStyle(Style.EMPTY.withColor(var3).withBold(true)));
                     }
                  }
               }
            }
         }
      }
   }

   public int n() {
      return this.n.b() & 16777215;
   }

   private static boolean a(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         String var1 = Formatting.strip(var0).toLowerCase(Locale.ROOT);
         return var1.contains("отдача") || var1.contains("отдачи") || var1.contains("knockback");
      } else {
         return false;
      }
   }

   private boolean c(ItemStack var1) {
      return var1.isOf(Items.SPLASH_POTION) || var1.isOf(Items.POTION) || var1.isOf(Items.LINGERING_POTION);
   }

   private String b(String var1) {
      return var1 == null ? "" : var1.replaceAll("§.", "").replaceAll("[§\\p{Cntrl}]", "").replace("[★]", "").replace("★", "").trim().replaceAll("\\s+", " ");
   }

   @Compile
   @Override
      public void e() {
      super.e();
      this.o = this.f.a() && this.g.b("Командой /ah resell");
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.o = false;
      this.a = false;
      this.r = false;
      this.u = false;
      this.x = false;
      this.s = 0;
      this.v = 0;
      this.y = 0;
      this.t = false;
      this.p = -1;
      this.z = false;
   }

   static {
      NativeMethodLookup.lookup(AucHelperModule.class, 45);
   }
}
