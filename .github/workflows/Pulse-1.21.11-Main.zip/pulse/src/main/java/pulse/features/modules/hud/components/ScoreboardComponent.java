package pulse.features.modules.hud.components;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.MutableText;
import org.joml.Matrix3x2fStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.config.cloud.CloudConfigManager;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.hud.DraggableManager;
import pulse.features.modules.hud.VanillaPositioned;
import pulse.features.modules.hud.snap.SnapResult;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.RenderTweaksModule;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@Environment(EnvType.CLIENT)
public class ScoreboardComponent extends DraggableComponent implements VanillaPositioned {
   private static final float m = 8.0F;
   private static final Color n = new Color(160, 160, 165);
   private static final String o = "Scoreboard";
   private static final int p = 9;
   private static final Comparator<ScoreboardEntry> q = Comparator.comparing(ScoreboardEntry::value)
      .reversed()
      .thenComparing(ScoreboardEntry::owner, String.CASE_INSENSITIVE_ORDER);
   private static ScoreboardComponent r;
   private boolean s = true;
   private boolean t = false;
   private float u;
   private float v;
   private float w;
   private float x;
   private final Animation y = new Animation().d(0.0);

   public ScoreboardComponent(float var1, float var2) {
      super(var1, var2);
      r = this;
   }

   public static ScoreboardComponent v() {
      return r;
   }

   @Override
   public boolean c() {
      if (this.a.world != null && this.a.player != null) {
         RenderTweaksModule var1 = ModuleRegistry.h;
         return var1 != null && var1.r() ? false : this.y() != null || DraggableManager.a().p();
      } else {
         return false;
      }
   }

   @Override
   public boolean b() {
      return this.s;
   }

   @Override
   public void a(boolean var1) {
      this.s = var1;
   }

   public boolean w() {
      return !this.s || !(Math.abs(this.g() - 1.0F) < 0.001F);
   }

   private ScoreboardObjective y() {
      if (this.a.world != null && this.a.player != null) {
         Scoreboard var1 = this.a.world.getScoreboard();
         ScoreboardObjective var2 = null;
         Team var3 = var1.getScoreHolderTeam(this.a.player.getNameForScoreboard());
         if (var3 != null) {
            ScoreboardDisplaySlot var4 = ScoreboardDisplaySlot.fromFormatting(var3.getColor());
            if (var4 != null) {
               var2 = var1.getObjectiveForSlot(var4);
            }
         }

         return var2 != null ? var2 : var1.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
      } else {
         return null;
      }
   }

   private float z() {
      return (float)(this.a.getWindow().getScaleFactor() / 2.0);
   }

   private void A() {
      TextRenderer var1 = this.a.textRenderer;
      int var2 = this.a.getWindow().getScaledWidth();
      int var3 = this.a.getWindow().getScaledHeight();
      ScoreboardObjective var4 = this.y();
      if (var4 == null) {
         int var15 = Math.max(var1.getWidth("Scoreboard"), 80);
         byte var16 = 81;
         int var17 = var3 / 2 + var16 / 3;
         this.w = var15 + 4;
         this.x = var16 + 10;
         this.u = var2 - var15 - 5;
         this.v = var17 - var16 - 10;
         this.t = true;
      } else {
         Scoreboard var5 = var4.getScoreboard();
         NumberFormat var6 = var4.getNumberFormatOr(StyledNumberFormat.RED);
         List<ScoreboardEntry> var7 = var5.getScoreboardEntries(var4).stream().filter(var0 -> !var0.hidden()).sorted(q).limit(15L).collect(Collectors.toList());
         int var8 = var1.getWidth(var4.getDisplayName());
         int var9 = var1.getWidth(": ");

         for (ScoreboardEntry var11 : var7) {
            Team var12 = var5.getScoreHolderTeam(var11.owner());
            MutableText var13 = Team.decorateName(var12, var11.name());
            int var14 = var1.getWidth(var11.formatted(var6));
            var8 = Math.max(var8, var1.getWidth(var13) + (var14 > 0 ? var9 + var14 : 0));
         }

         int var18 = var7.size() * 9;
         int var19 = var3 / 2 + var18 / 3;
         this.w = var8 + 4;
         this.x = var18 + 10;
         this.u = var2 - var8 - 5;
         this.v = var19 - var18 - 10;
         this.t = true;
      }
   }

   private float B() {
      return (this.u + this.w) * this.z() - this.d;
   }

   private float C() {
      return this.v * this.z();
   }

   @Override
   protected void a() {
      this.A();
      float var1 = this.z() * this.g();
      this.d = this.w * var1;
      this.e = this.x * var1;
   }

   private void c(float var1, float var2) {
      if (this.s && this.t) {
         this.b = this.B();
         this.c = this.C();
      }

      this.b = Math.max(0.0F, Math.min(this.b, var1 - this.d));
      this.c = Math.max(0.0F, Math.min(this.c, var2 - this.e));
   }

   @Override
   public boolean a(double var1, double var3, int var5) {
      if (var5 == 2 && this.a(var1, var3)) {
         this.x();
         return true;
      } else {
         return super.a(var1, var3, var5);
      }
   }

   public void x() {
      if (!this.s) {
         this.s = true;
         CloudConfigManager.a().h();
      }
   }

   @Override
   public void a(SnapResult var1, float var2, float var3) {
      super.a(var1, var2, var3);
      if (this.j()) {
         this.a(!DraggableManager.a().t(), var2, var3);
      }
   }

   private void a(boolean var1, float var2, float var3) {
      if (this.t) {
         float var4 = this.B();
         float var5 = this.C();
         boolean var6 = Math.abs(this.b - var4) <= 8.0F && Math.abs(this.c - var5) <= 8.0F;
         if (var1 && var6) {
            this.b = var4;
            this.c = var5;
            this.u().a(this.b, this.c, this.d, this.e, var2, var3);
            if (!this.s) {
               this.s = true;
               CloudConfigManager.a().h();
            }
         } else if (this.s) {
            this.s = false;
            CloudConfigManager.a().h();
         }
      }
   }

   public void a(Matrix3x2fStack var1) {
      this.A();
      float var2 = this.z();
      float var3 = this.g();
      this.d = this.w * var2 * var3;
      this.e = this.x * var2 * var3;
      float var4 = this.a.getWindow().getFramebufferWidth() / 2.0F;
      float var5 = this.a.getWindow().getFramebufferHeight() / 2.0F;
      this.c(var4, var5);
      float var6 = this.b / var2;
      float var7 = this.c / var2;
      var1.translate(var6, var7);
      var1.scale(var3, var3);
      var1.translate(-this.u, -this.v);
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (DraggableManager.a().p()) {
         this.a();
         this.c(var3, var4);
         var2.a(this.b, this.c, this.d, this.e, 0.0F, a(n, 12), var1);
         float var5 = this.j() && !this.s ? 1.0F : 0.0F;
         this.y.a(var5, 0.1500000757293233, Easings.h, true);
         this.y.a();
         float var6 = (float)this.y.j();
         if (var6 > 0.01F) {
            float var7 = this.B();
            float var8 = this.C();
            var2.a(var7, var8, this.d, this.e, 0.0F, a(n, (int)(8.0F * var6)), var1);
            var2.b(var7, var8, this.d, this.e, 1.0F, a(n, (int)(45.0F * var6)), var1);
         }

         if (this.y() == null) {
            this.a(var1);
         }
      }
   }

   static Color a(Color var0, int var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var1);
   }

   private void a(MatrixStack var1) {
      int var2 = Math.max(8, Math.min(48, Math.round(24.0F * this.g())));
      FontRenderer var3 = Fonts.a[var2];
      float var4 = var3.a("Scoreboard");
      float var5 = var3.b("Scoreboard") / 2.0F;
      var3.a("Scoreboard", this.b + (this.d - var4) / 2.0F, this.c + (this.e - var5) / 2.0F, a(n, 90), var1);
   }
}
