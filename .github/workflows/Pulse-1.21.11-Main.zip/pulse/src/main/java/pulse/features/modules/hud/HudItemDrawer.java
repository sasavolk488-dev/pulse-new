package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.joml.Matrix3x2fStack;

@Environment(EnvType.CLIENT)
public final class HudItemDrawer {
   private HudItemDrawer() {
   }

   public static void a(ItemStack var0, float var1, float var2, float var3) {
      if (var0 != null && !var0.isEmpty()) {
         DrawContext var4 = HudRenderContext.a();
         if (var4 != null) {
            MinecraftClient var5 = MinecraftClient.getInstance();
            if (var5.player != null && var5.world != null) {
               float var6 = var5.getWindow().getScaleFactor();
               if (var6 <= 0.0F) {
                  var6 = 1.0F;
               }

               float var7 = 2.0F / var6;
               float var8 = var3 / 16.0F * var7;
               Matrix3x2fStack var9 = var4.getMatrices();
               var9.pushMatrix();
               var9.translate(var1 * var7, var2 * var7);
               if (Math.abs(var8 - 1.0F) > 1.0E-4F) {
                  var9.scale(var8, var8);
               }

               try {
                  var4.drawItem(var0, 0, 0);
                  var4.drawStackOverlay(var5.textRenderer, var0, 0, 0);
               } finally {
                  var9.popMatrix();
               }
            }
         }
      }
   }

   public static void b(ItemStack var0, float var1, float var2, float var3) {
      if (var0 != null && !var0.isEmpty()) {
         DrawContext var4 = HudRenderContext.a();
         if (var4 != null) {
            MinecraftClient var5 = MinecraftClient.getInstance();
            if (var5.player != null && var5.world != null) {
               float var6 = var5.getWindow().getScaleFactor();
               if (var6 <= 0.0F) {
                  var6 = 1.0F;
               }

               float var7 = 2.0F / var6;
               float var8 = var3 / 16.0F * var7;
               Matrix3x2fStack var9 = var4.getMatrices();
               var9.pushMatrix();
               var9.translate(var1 * var7, var2 * var7);
               if (Math.abs(var8 - 1.0F) > 1.0E-4F) {
                  var9.scale(var8, var8);
               }

               try {
                  var4.drawItem(var0, 0, 0);
               } finally {
                  var9.popMatrix();
               }
            }
         }
      }
   }
}
