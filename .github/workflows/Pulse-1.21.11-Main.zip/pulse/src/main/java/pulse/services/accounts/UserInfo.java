package pulse.services.accounts;

import java.util.HashMap;
import java.util.Map;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class UserInfo {
   private final int a;
   private final String b;
   private String c;
   private final String d;
   private String e = "user";
   private final Map<String, Integer> f = new HashMap<>();
   private double g = 0.0;
   private boolean h = false;
   private long i = 0L;
   private long j = 0L;

   public void a(String var1) {
      this.c = var1;
   }

   public UserInfo(int var1, String var2, String var3) {
      this.a = var1;
      this.b = var2;
      this.d = var3;
   }

   public UserInfo(int var1, String var2, String var3, String var4) {
      this.a = var1;
      this.b = var2;
      this.d = var3;
      this.e = var4 != null ? var4 : "user";
   }

   public boolean a() {
      return "beta_tester".equals(this.e) || "admin".equals(this.e);
   }

   public void b(String var1) {
      this.e = var1 != null ? var1 : "user";
   }

   public Integer b() {
      return this.f.get("cape");
   }

   public double c() {
      return this.g;
   }

   public void a(double var1) {
      this.g = var1;
   }

   public boolean d() {
      return this.h;
   }

   public void a(boolean var1) {
      this.h = var1;
   }

   public void a(long var1) {
      this.i = var1;
      this.j = System.currentTimeMillis();
   }

   public long e() {
      if (this.i <= 0L) {
         return 0L;
      } else {
         long var1 = (System.currentTimeMillis() - this.j) / 1000L;
         return Math.max(0L, this.i - var1);
      }
   }

   public Integer c(String var1) {
      return this.f.get(var1);
   }

   public void a(Map<String, Integer> var1) {
      this.f.clear();
      if (var1 != null) {
         this.f.putAll(var1);
      }
   }

   @Override
   public String toString() {
      return "UserInfo{userId=" + this.a + ", username='" + this.b + "', sessionId='" + this.d + "', role='" + this.e + "', cosmetics=" + this.f + "}";
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         UserInfo var2 = (UserInfo)var1;
         return this.a == var2.a;
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Integer.hashCode(this.a);
   }

   @Generated
   public int f() {
      return this.a;
   }

   @Generated
   public String g() {
      return this.b;
   }

   @Generated
   public String h() {
      return this.c;
   }

   @Generated
   public String i() {
      return this.d;
   }

   @Generated
   public String j() {
      return this.e;
   }

   @Generated
   public Map<String, Integer> k() {
      return this.f;
   }

   @Generated
   public long l() {
      return this.i;
   }

   @Generated
   public long m() {
      return this.j;
   }
}
