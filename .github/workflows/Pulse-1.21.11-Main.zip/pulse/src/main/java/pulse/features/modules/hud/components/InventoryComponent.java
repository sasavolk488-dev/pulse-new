package pulse.features.modules.hud.components;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.hud.HudItemDrawer;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.ItemHighliterModule;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class InventoryComponent extends DraggableComponent {
   private static final Color m = new Color(255, 255, 255);
   private static final Color n = new Color(0, 0, 0, 80);
   private static final int o = 3;
   private static final int p = 9;
   private static final float q = 16.0F;
   private static final float r = 2.0F;
   private boolean s = false;

   public InventoryComponent(float var1, float var2) {
      super(var1, var2);
      this.a();
   }

   @Override
   public boolean c() {
      return ModuleRegistry.aE != null && ModuleRegistry.aE.k();
   }

   @Override
   protected float i() {
      return 4.0F;
   }

   private void v() {
      if (!this.s) {
         if (ModuleRegistry.aE != null) {
            this.f().a(ModuleRegistry.aE);
            this.s = true;
         }
      }
   }

   @Override
   protected void a() {
      this.v();
      float var1 = this.g();
      float var2 = 16.0F * var1;
      float var3 = 2.0F * var1;
      this.d = 9.0F * var2 + 8.0F * var3;
      this.e = 3.0F * var2 + 2.0F * var3;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (this.a.player != null) {
         this.a();
         float var5 = this.g();
         float var6 = 16.0F * var5;
         float var7 = 2.0F * var5;
         boolean var8 = ModuleRegistry.aE != null && ModuleRegistry.aE.o().a();
         boolean var9 = ModuleRegistry.aE != null && ModuleRegistry.aE.p().a();
         if (var8) {
            float var10 = 3.0F * var5;
            var2.a(this.b - var10, this.c - var10, this.d + var10 * 2.0F, this.e + var10 * 2.0F, 4.0F * var5, n, var1);
         }

         for (int var19 = 0; var19 < 3; var19++) {
            for (int var11 = 0; var11 < 9; var11++) {
               int var12 = 9 + var19 * 9 + var11;
               float var13 = this.b + var11 * (var6 + var7);
               float var14 = this.c + var19 * (var6 + var7);
               if (var9) {
                  var2.a(var13, var14, var6, var6, 2.0F * var5, n, var1);
               }

               ItemStack var15 = this.a.player.getInventory().getStack(var12);
               if (!var15.isEmpty()) {
                  ItemHighliterModule var16 = ModuleRegistry.ag;
                  if (var16 != null && var16.k() && var16.a(var15)) {
                     Color var17 = var16.b(var15);
                     Color var18 = new Color(var17.getRed(), var17.getGreen(), var17.getBlue(), var16.n());
                     var2.a(var13, var14, var6, var6, 0.0F, var18, var1);
                  }

                  this.a(var15, var13, var14, var6);
               }
            }
         }
      }
   }

   private void a(ItemStack var1, float var2, float var3, float var4) {
      HudItemDrawer.a(var1, var2, var3, var4);
   }
}
