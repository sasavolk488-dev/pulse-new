package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public final class HudRenderContext {
   private static DrawContext a;
   private static Runnable b;

   private HudRenderContext() {
   }

   public static void a(DrawContext var0) {
      a = var0;
   }

   public static DrawContext a() {
      return a;
   }

   public static void b() {
      a = null;
      b = null;
   }

   public static void a(Runnable var0) {
      b = var0;
   }

   public static void c() {
      if (b != null) {
         b.run();
      }
   }
}
