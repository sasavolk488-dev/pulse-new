package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.potion.Potion;
import net.minecraft.registry.entry.RegistryEntry;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;
import pulse.utils.game.PVPUtils;

@ModuleInfo(
   a = "Healing Helper",
   b = "Подсвечивает предмет, который нужно сейчас съесть",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class HealingHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Только в PvP", true);
   private final NumberSetting b = new NumberSetting("Порог зелья исцеления (здоровье)", 14.0F, 1.0F, 20.0F, 1.0F);
   private final NumberSetting c = new NumberSetting("Порог чарки (сек)", 30.0F, 1.0F, 60.0F, 1.0F);
   private final NumberSetting f = new NumberSetting("Порог гэпла (насыщение)", 15.0F, 1.0F, 20.0F, 1.0F);
   private final Map<Item, Integer> g;
   private List<Item> h;

   public HealingHelperModule() {
      HashMap var1 = new HashMap();
      var1.put(Items.ENCHANTED_GOLDEN_APPLE, 1);
      var1.put(Items.GOLDEN_APPLE, 2);
      var1.put(Items.GOLDEN_CARROT, 3);
      var1.put(Items.POTION, 4);
      this.g = Collections.unmodifiableMap(var1);
      this.h = Collections.emptyList();
   }

   @EventHandler
   @Compile
      public void a(UpdateEvent var1) {
      this.h = d.player == null ? java.util.Collections.emptyList() : this.v();
   }

   public boolean a(ItemStack var1) {
      if (d.player != null && (!this.a.q() || PVPUtils.a().a())) {
         boolean var2 = d.player.getItemCooldownManager().isCoolingDown(var1);
         if (var2) {
            return false;
         } else if (var1.getItem() == Items.POTION) {
            boolean var8 = false;
            if (var1.getItem() instanceof PotionItem) {
               Optional var9 = var1.getOrDefault(DataComponentTypes.POTION_CONTENTS, PotionContentsComponent.DEFAULT).potion();
               if (var9.isPresent()) {
                  for (StatusEffectInstance var6 : ((Potion)((RegistryEntry)var9.get()).value()).getEffects()) {
                     if (var6.getEffectType() == StatusEffects.INSTANT_HEALTH) {
                        var8 = true;
                        break;
                     }
                  }
               }
            }

            return var8 && d.player.getHealth() < this.b.q() && !d.player.hasStatusEffect(StatusEffects.REGENERATION);
         } else if (var1.getItem() == Items.ENCHANTED_GOLDEN_APPLE) {
            StatusEffectInstance var7 = d.player.getStatusEffect(StatusEffects.ABSORPTION);
            int var4 = (int)(this.c.q() * 20.0F);
            return var7 == null || var7.getDuration() < var4;
         } else if (var1.getItem() == Items.GOLDEN_APPLE) {
            float var3 = d.player.getHungerManager().getSaturationLevel();
            return var3 < this.f.q();
         } else {
            return var1.getItem() == Items.GOLDEN_CARROT ? d.player.getHungerManager().getFoodLevel() < 20 : false;
         }
      } else {
         return false;
      }
   }

   public List<Item> n() {
      return d.player == null ? Collections.emptyList() : this.h;
   }

   private List<Item> v() {
      return Collections.unmodifiableList(
         d.player.getInventory().getMainStacks().stream().filter(this::a).map(ItemStack::getItem).distinct().collect(Collectors.toList())
      );
   }

   public int a(Item var1) {
      return this.g.getOrDefault(var1, 0);
   }

   @Generated
   public BooleanSetting o() {
      return this.a;
   }

   @Generated
   public NumberSetting p() {
      return this.b;
   }

   @Generated
   public NumberSetting q() {
      return this.c;
   }

   @Generated
   public NumberSetting r() {
      return this.f;
   }

   @Generated
   public Map<Item, Integer> s() {
      return this.g;
   }

   @Generated
   public List<Item> t() {
      return this.h;
   }

   static {
      NativeMethodLookup.lookup(HealingHelperModule.class, 63);
   }
}
