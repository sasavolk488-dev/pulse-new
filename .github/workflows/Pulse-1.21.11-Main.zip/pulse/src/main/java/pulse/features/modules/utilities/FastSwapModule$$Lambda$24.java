package pulse.features.modules.utilities;

import java.util.function.Function;

public final class FastSwapModule$$Lambda$24 implements Function {
   @Override
   public Object apply(Object var1) {
      return FastSwapModule.a((FastSwapModule.Action)var1);
   }
}
