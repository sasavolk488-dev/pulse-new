package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.util.profiler.DummyProfiler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.utils.render.PostProcessFramebuffers;
import pulse.utils.render.world.JumpShockwave;

@Environment(EnvType.CLIENT)
@Mixin({DummyProfiler.class})
public class DummyProfilerMixin {
   @Inject(
      method = {"swap(Ljava/lang/String;)V"},
      at = {@At("HEAD")}
   )
   private void pulse$snapshotWorldDepth(String var1, CallbackInfo var2) {
      if ("submitEntities".equals(var1)) {
         if (JumpShockwave.b()) {
            PostProcessFramebuffers.b();
            Framebuffer var3 = PostProcessFramebuffers.a();
            if (var3 != null) {
               Framebuffer var4 = MinecraftClient.getInstance().getFramebuffer();
               if (var4 != null) {
                  var3.copyDepthFrom(var4);
               }
            }
         }
      }
   }
}
