package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.core.api.IMinecraft;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.StreamerModeModule;

@Environment(EnvType.CLIENT)
@Mixin({InGameHud.class})
public class ScoreboardMixin implements IMinecraft {
   @Unique
   private static final Text PULSE_TEXT = Text.literal("pulsevisuals.pro");

   @Redirect(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/scoreboard/ScoreboardObjective;getDisplayName()Lnet/minecraft/text/Text;"
      )
   )
   private Text hideScoreboardTitle(ScoreboardObjective var1) {
      StreamerModeModule var2 = ModuleRegistry.T;
      if (var2.k() && var2.b.q()) {
         if (d == null || d.getCurrentServerEntry() == null) {
            return Text.literal("pulsevisuals.pro");
         }

         String var3 = d.getCurrentServerEntry().address.toLowerCase();
         if (!var3.contains("holyworld")) {
            return PULSE_TEXT;
         }
      }

      return var1.getDisplayName();
   }
}
