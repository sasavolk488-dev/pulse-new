package pulse.core.handler.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import pulse.features.modules.utilities.auc.AucMatcher;

@Environment(EnvType.CLIENT)
public record ItemGroupKey(Item item, PotionContentsComponent potion, String variant) {
   public static ItemGroupKey a(ItemStack var0) {
      return new ItemGroupKey(var0.getItem(), var0.get(DataComponentTypes.POTION_CONTENTS), AucMatcher.c(var0));
   }
}
