package pulse.features.cosmetic.model;

import com.google.gson.JsonObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class CosmeticModel {
   private final String a;
   private final int b;
   private final int c;
   private String d;
   private Identifier e;
   private ModelPosition f = ModelPosition.c;
   private float g = 1.0F;
   private float h;
   private float i;
   private float j;
   private float k;
   private float l;
   private float m;
   private float n = 0.0F;
   private float o = 1.0F;
   private float p = 0.0F;
   private JsonObject q;
   private int r = 0;
   private int s = 0;
   private int t = 0;
   private int u = 3;

   public CosmeticModel(String var1, int var2, int var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public String a() {
      return this.a;
   }

   public int b() {
      return this.b;
   }

   public int c() {
      return this.c;
   }

   public String d() {
      return this.d;
   }

   public void a(String var1) {
      this.d = var1;
   }

   public Identifier e() {
      return this.e;
   }

   public void a(Identifier var1) {
      this.e = var1;
   }

   public ModelPosition f() {
      return this.f;
   }

   public void a(ModelPosition var1) {
      this.f = var1;
   }

   public float g() {
      return this.g;
   }

   public void a(float var1) {
      this.g = var1;
   }

   public float h() {
      return this.h;
   }

   public void b(float var1) {
      this.h = var1;
   }

   public float i() {
      return this.i;
   }

   public void c(float var1) {
      this.i = var1;
   }

   public float j() {
      return this.j;
   }

   public void d(float var1) {
      this.j = var1;
   }

   public float k() {
      return this.k;
   }

   public void e(float var1) {
      this.k = var1;
   }

   public float l() {
      return this.l;
   }

   public void f(float var1) {
      this.l = var1;
   }

   public float m() {
      return this.m;
   }

   public void g(float var1) {
      this.m = var1;
   }

   public float n() {
      return this.n;
   }

   public void h(float var1) {
      this.n = var1;
   }

   public float o() {
      return this.o;
   }

   public void i(float var1) {
      this.o = var1;
   }

   public float p() {
      return this.p;
   }

   public void j(float var1) {
      this.p = var1;
   }

   public JsonObject q() {
      return this.q;
   }

   public void a(JsonObject var1) {
      this.q = var1;
   }

   public int r() {
      return this.r;
   }

   public void a(int var1) {
      this.r = var1;
   }

   public int s() {
      return this.s;
   }

   public void b(int var1) {
      this.s = var1;
   }

   public int t() {
      return this.t;
   }

   public void c(int var1) {
      this.t = var1;
   }

   public int u() {
      return this.u;
   }

   public void d(int var1) {
      this.u = var1;
   }

   public boolean v() {
      return this.r > 1;
   }
}
