package pulse.features.modules.utilities.fakeplayer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import pulse.core.event.impl.AttackEvent;
import pulse.core.api.IMinecraft;

@Environment(EnvType.CLIENT)
public class FakePlayerAttackHandler implements IMinecraft {
   private final FakePlayerSpawner a;

   public FakePlayerAttackHandler(FakePlayerSpawner var1) {
      this.a = var1;
   }

   public void a(AttackEvent var1) {
      OtherClientPlayerEntity var2 = this.a.c();
      if (var2 != null && var1.a() == var2) {
         if (var2.hurtTime > 0) {
            d.player
               .getEntityWorld()
               .playSound(d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_NODAMAGE, d.player.getSoundCategory(), 1.0F, 1.0F);
         } else {
            var2.hurtTime = 9;
            float var3 = d.player.getAttackCooldownProgress(0.5F);
            boolean var4 = var3 > 0.9F;
            boolean var5 = d.player.getVelocity().y < 0.0;
            boolean var6 = var4
               && var5
               && !d.player.isOnGround()
               && !d.player.isClimbing()
               && !d.player.isTouchingWater()
               && !d.player.hasVehicle()
               && !d.player.isSprinting();
            boolean var7 = var4 && !var6 && d.player.isSprinting();
            boolean var8 = var4
               && !d.player.isSprinting()
               && d.player.isOnGround()
               && d.player.verticalCollision
               && d.player.getMainHandStack().isIn(ItemTags.SWORDS);
            boolean var9 = !var6 && !var7 && !var8 && !var5 && var4;
            float var10 = (float)d.player.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
            float var11 = d.player.getAttackCooldownProgress(0.5F);
            var10 *= 0.2F + var11 * var11 * 0.8F;
            d.player
               .getEntityWorld()
               .playSound(d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_HURT, d.player.getSoundCategory(), 0.5F, 1.0F);
            if (var6) {
               var10 *= 1.5F;
               d.player
                  .getEntityWorld()
                  .playSound(d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, d.player.getSoundCategory(), 1.0F, 1.0F);
            } else if (var7) {
               d.player
                  .getEntityWorld()
                  .playSound(
                     d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, d.player.getSoundCategory(), 1.0F, 1.0F
                  );
            } else if (var8) {
               d.player
                  .getEntityWorld()
                  .playSound(d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, d.player.getSoundCategory(), 1.0F, 1.0F);
            } else if (var9) {
               d.player
                  .getEntityWorld()
                  .playSound(d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, d.player.getSoundCategory(), 1.0F, 1.0F);
            } else {
               d.player
                  .getEntityWorld()
                  .playSound(d.player, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_WEAK, d.player.getSoundCategory(), 1.0F, 1.0F);
            }

            if (var2.getAbsorptionAmount() > 0.0F) {
               float var12 = var2.getAbsorptionAmount();
               float var13 = MathHelper.clamp(var12 - var10, 0.0F, 1000.0F);
               float var14 = var10 - var12;
               var2.setAbsorptionAmount(var13);
               if (var14 > 0.0F) {
                  var2.setHealth(MathHelper.clamp(var2.getHealth() - var14, 0.99F, 20.0F));
               }
            } else {
               var2.setHealth(MathHelper.clamp(var2.getHealth() - var10, 0.99F, 20.0F));
            }

            if (var2.getHealth() < 1.0F && var2.getAbsorptionAmount() == 0.0F) {
               var2.clearStatusEffects();

               for (int var20 = 0; var20 < 30; var20++) {
                  double var21 = (Math.random() - 0.5) * 0.5;
                  double var15 = Math.random() * 0.5;
                  double var17 = (Math.random() - 0.5) * 0.5;
                  d.world.addParticleClient(ParticleTypes.TOTEM_OF_UNDYING, var2.getX(), var2.getY() + 1.0, var2.getZ(), var21, var15, var17);
               }

               d.world.playSoundClient(var2.getX(), var2.getY(), var2.getZ(), SoundEvents.ITEM_TOTEM_USE, var2.getSoundCategory(), 1.0F, 1.0F, false);
               var2.setAbsorptionAmount(8.0F);
               var2.setHealth(20.0F);
            }
         }
      }
   }
}
