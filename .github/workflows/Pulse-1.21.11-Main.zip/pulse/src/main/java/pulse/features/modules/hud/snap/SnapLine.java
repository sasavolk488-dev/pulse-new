package pulse.features.modules.hud.snap;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SnapLine {
   private final SnapLine.Type a;
   private final SnapLine.Source b;
   private final float c;
   private final float d;
   private final float e;

   public SnapLine(SnapLine.Type var1, SnapLine.Source var2, float var3, float var4, float var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public SnapLine.Type a() {
      return this.a;
   }

   public SnapLine.Source b() {
      return this.b;
   }

   public float c() {
      return this.c;
   }

   public float d() {
      return this.d;
   }

   public float e() {
      return this.e;
   }

   @Environment(EnvType.CLIENT)
   public static enum Source {
      a,
      b,
      c,
      d;

      private static SnapLine.Source[] a() {
         return new SnapLine.Source[]{a, b, c, d};
      }
   }

   @Environment(EnvType.CLIENT)
   public static enum Type {
      a,
      b;

      private static SnapLine.Type[] a() {
         return new SnapLine.Type[]{a, b};
      }
   }
}
