package pulse.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.FullBrightModule;

@Environment(EnvType.CLIENT)
@Mixin({LightmapTextureManager.class})
public class LightmapTextureManagerMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$throttleLightmap(CallbackInfo var1) {
      if (ModuleRegistry.W != null && ModuleRegistry.W.p()) {
         var1.cancel();
      }
   }

   @ModifyExpressionValue(
      method = {"update"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;",
         ordinal = 2
      )}
   )
   private Object pulse$fullBrightGamma(Object var1) {
      FullBrightModule var2 = ModuleRegistry.a;
      return var2 != null && var2.k() ? 9999.0 : var1;
   }

   @Inject(
      method = {"getBrightness(Lnet/minecraft/world/dimension/DimensionType;I)F"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void onGetBrightness(CallbackInfoReturnable<Float> var0) {
      FullBrightModule var1 = ModuleRegistry.a;
      if (var1 != null && var1.k()) {
         var0.setReturnValue(1.0F);
      }
   }

   @Inject(
      method = {"getBrightness(FI)F"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void onGetBrightnessAmbient(CallbackInfoReturnable<Float> var0) {
      FullBrightModule var1 = ModuleRegistry.a;
      if (var1 != null && var1.k()) {
         var0.setReturnValue(1.0F);
      }
   }
}
