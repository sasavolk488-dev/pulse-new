package pulse.core.handler.impl;

import java.util.Map.Entry;
import java.util.function.Predicate;

public final class TargetHandler$$Lambda$17 implements Predicate {
   private final TargetHandler c0;
   private final int c1;

   public TargetHandler$$Lambda$17(TargetHandler var1, int var2) {
      this.c0 = var1;
      this.c1 = var2;
   }

   @Override
   public boolean test(Object var1) {
      return this.c0.a(this.c1, (Entry)var1);
   }
}
