package pulse.ui.clickgui.common;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.common.provider.ToggleEntry;
import pulse.ui.clickgui.common.settings.BooleanSettingElement;
import pulse.ui.clickgui.common.settings.ColorSettingElement;
import pulse.ui.clickgui.common.settings.CommandListSettingElement;
import pulse.ui.clickgui.common.settings.FolderSettingElement;
import pulse.ui.clickgui.common.settings.InputSettingElement;
import pulse.ui.clickgui.common.settings.ItemColorSettingElement;
import pulse.ui.clickgui.common.settings.KeySettingElement;
import pulse.ui.clickgui.common.settings.ModeSettingElement;
import pulse.ui.clickgui.common.settings.NumberSettingElement;
import pulse.ui.clickgui.common.settings.RegionListSettingElement;
import pulse.ui.clickgui.common.settings.SeparatorSettingElement;
import pulse.ui.clickgui.common.settings.SettingElement;
import pulse.ui.clickgui.common.settings.SettingsContainer;
import pulse.features.modules.Module;
import pulse.utils.render.Render;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.CommandListSetting;
import pulse.core.settings.FolderSetting;
import pulse.core.settings.InputSetting;
import pulse.core.settings.ItemColorSetting;
import pulse.core.settings.KeySetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.RegionListSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.core.settings.Setting;
import pulse.utils.render.LayerManager;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class ModuleSettingsPanel {
   public static final float a = 150.0F;
   public static final float b = 30.0F;
   public static final float c = 100.0F;
   public static final float d = 30.0F;
   public static final float e = 9.5F;
   public static final float f = 8.0F;
   public static final float g = 8.0F;
   public static final float h = 7.0F;
   private static final int i = 25;
   private static final float j = 5.0F;
   private final ToggleEntry k;
   private final Module l;
   private final int m;
   private final boolean n;
   private ModuleSettingsPanel.ArrowPosition o;
   private final boolean p;
   private float q;
   private float r;
   private final Animation s = new Animation();
   private boolean t = false;
   private float u;
   private float v;
   private boolean w = false;
   private float x;
   private float y;
   private boolean z = false;
   private final SettingsContainer A;
   private final BottomFadeElement B;
   private final Animation C = new Animation();
   private boolean D = true;
   private KeySettingElement E;
   private float F = 0.0F;
   private int G = 0;
   private int H = 0;

   public ModuleSettingsPanel(ToggleEntry var1, Module var2, int var3, boolean var4, float var5, float var6, ModuleSettingsPanel.ArrowPosition var7) {
      this(var1, var2, var3, var4, var5, var6, var7, false);
   }

   private ModuleSettingsPanel(
      ToggleEntry var1, Module var2, int var3, boolean var4, float var5, float var6, ModuleSettingsPanel.ArrowPosition var7, boolean var8
   ) {
      this.k = var1;
      this.l = var2;
      this.m = var3;
      this.n = var4;
      this.q = var5;
      this.r = var6;
      this.o = var7;
      this.p = var8;
      this.A = new SettingsContainer();
      this.A.b(7.0F);
      this.A.a(100.0F);
      if (var8) {
         this.y();
      } else {
         this.z();
      }

      this.B = new BottomFadeElement(25, 5.0F, 9.5F);
      this.s.d(0.0);
      this.s.a(1.0, 0.25, Easings.F);
      this.C.d(1.0);
   }

   public static ModuleSettingsPanel a(ToggleEntry var0, Module var1, int var2, boolean var3, float var4, float var5) {
      return new ModuleSettingsPanel(var0, var1, var2, var3, var4, var5, ModuleSettingsPanel.ArrowPosition.b, true);
   }

   public void a(float var1, float var2, boolean var3) {
      this.w = true;
      this.x = var1;
      this.y = var2;
      this.z = var3;
   }

   private void y() {
      int var1 = this.k != null ? this.k.f() : -1;
      this.E = new KeySettingElement("Клавиша активации", var1);
   }

   private void z() {
      if (this.l != null) {
         for (Setting var2 : this.l.m()) {
            SettingElement var3 = this.a(var2);
            if (var3 != null) {
               this.A.a(var3);
            }
         }
      }
   }

   private SettingElement a(Setting<?> var1) {
      if (var1 instanceof BooleanSetting var13) {
         return new BooleanSettingElement(var13);
      } else if (var1 instanceof NumberSetting var12) {
         return new NumberSettingElement(var12);
      } else if (var1 instanceof ModeSetting var11) {
         return new ModeSettingElement(var11);
      } else if (var1 instanceof KeySetting var10) {
         return new KeySettingElement(var10);
      } else if (var1 instanceof ColorSetting var9) {
         return new ColorSettingElement(var9);
      } else if (var1 instanceof RegionListSetting var8) {
         return new RegionListSettingElement(var8);
      } else if (var1 instanceof CommandListSetting var7) {
         return new CommandListSettingElement(var7);
      } else if (var1 instanceof InputSetting var6) {
         InputSettingElement.InputType var3 = this.a(var6.j());
         return new InputSettingElement(var6, var3);
      } else if (var1 instanceof ItemColorSetting var5) {
         return new ItemColorSettingElement(var5);
      } else if (var1 instanceof SeparatorSetting var4) {
         return new SeparatorSettingElement(var4);
      } else {
         return var1 instanceof FolderSetting var2 ? new FolderSettingElement(var2) : null;
      }
   }

   private InputSettingElement.InputType a(InputSetting.InputType var1) {
      switch (var1) {
         case b:
            return InputSettingElement.InputType.a;
         case c:
            return InputSettingElement.InputType.c;
         case d:
            return InputSettingElement.InputType.d;
         case e:
            return InputSettingElement.InputType.b;
         default:
            return InputSettingElement.InputType.a;
      }
   }

   public float a() {
      if (this.p) {
         return 30.0F;
      } else {
         float var1 = this.A.m();
         return Math.max(30.0F, Math.min(var1, 100.0F));
      }
   }

   public void a(float var1) {
      this.q = var1;
   }

   public void b() {
      if (!this.t) {
         this.t = true;
         this.A.g();
         this.s.a(0.0, 0.15000009069482587, Easings.g);
      }
   }

   public void c() {
      this.t = true;
      this.s.d(0.0);
      this.A.g();
      if (this.p && this.E != null) {
         this.E.f();
      }
   }

   public void d() {
      this.t = false;
      this.s.d(1.0);
      this.A.g();
   }

   public boolean e() {
      return this.t && this.s.d() && this.s.j() < 0.010000000495234548;
   }

   public boolean f() {
      return this.t;
   }

   public boolean g() {
      return this.p;
   }

   public boolean a(float var1, float var2) {
      if (this.w) {
         return false;
      } else {
         float var3 = this.q + this.r / 2.0F;
         return var3 < var1 || var3 > var1 + var2;
      }
   }

   private float b(float var1) {
      float var2 = this.a();
      switch (this.o) {
         case a:
            return 8.0F + var1 / 2.0F;
         case b:
         default:
            return var2 / 2.0F;
         case c:
            return var2 - 8.0F - var1 / 2.0F;
      }
   }

   public static float a(float var0, float var1, ModuleSettingsPanel.ArrowPosition var2, float var3, float var4) {
      float var5 = var0 + var1 / 2.0F;

      return var5 - switch (var2) {
         case a -> 8.0F + var3 / 2.0F;
         default -> var4 / 2.0F;
         case c -> var4 - 8.0F - var3 / 2.0F;
      };
   }

   public static boolean a(float var0, float var1, float var2, float var3) {
      float var5 = var0 + var1;
      float var7 = var2 + var3;
      return !(var5 <= var2) && !(var0 >= var7);
   }

   private LayerManager.Layer A() {
      return this.p ? LayerManager.Layer.h : LayerManager.Layer.f;
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7, float var8) {
      this.a(var1, var2, var3, var4, var5, var6, var7, var8, false);
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7, float var8, boolean var9) {
      this.s.a();
      this.C.a();
      float var10 = (float)this.s.j();
      if (!(var10 < 0.01F)) {
         this.F = var10;
         this.G = var5;
         this.H = var6;
         int var11 = var9 ? -1 : var5;
         int var12 = var9 ? -1 : var6;
         float var13 = this.a();
         float var14 = ClickGuiScreen.e();
         float var15 = Math.max(0.0F, Math.min(1.0F, var10));
         int var16 = (int)(255.0F * var15);
         if (this.w) {
            this.a(var1, var2, var3, var4, var11, var12, var13, var15, var16);
         } else {
            this.a(var1, var2, var3, var4, var11, var12, var13, var14, var15, var16);
         }

         if (!this.t && var15 > 0.5F) {
            LayerManager.a().a(this.A(), this.u, this.v, 150.0F, var13);
         }
      }
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4) {
      if (!this.p) {
         float var5 = (float)this.s.j();
         if (!(var5 < 0.1F)) {
            float var6 = Math.max(0.0F, Math.min(1.0F, var5));
            this.A.a(var1, var2, var3, var4, var6, var6);
         }
      }
   }

   public void b(MatrixStack var1, Render var2, int var3, int var4) {
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7, float var8, int var9) {
      this.u = this.x;
      this.v = this.y;
      float var10 = this.u + 75.0F;
      float var11 = this.v + var7 / 2.0F;
      float var12 = 150.0F * var8;
      float var13 = var7 * var8;
      float var14 = var10 - var12 / 2.0F;
      float var15 = var11 - var13 / 2.0F;
      Color var16 = ClickGuiColors.a(ClickGuiColors.q, var9);
      Color var17 = ClickGuiColors.a(ClickGuiColors.r, var9);
      var2.a(var14 - 0.5F * var8, var15 - 0.5F * var8, var12 + var8, var13 + var8, 9.5F * var8, var16, var16, var17, var17, var1);
      Color var18 = ClickGuiColors.a(ClickGuiColors.e, var9);
      Color var19 = ClickGuiColors.a(ClickGuiColors.f, var9);
      var2.a(var14, var15, var12, var13, 9.5F * var8, var18, var18, var19, var19, var1);
      TextureRegistry.TextureEntry var20 = TextureRegistry.b("arrow_v");
      if (var20 != null) {
         Identifier var21 = var20.a();
         float var22 = var20.b() / 2.0F * var8;
         float var23 = var20.c() / 2.0F * var8;
         float var24 = var14 + var12 / 2.0F;
         float var25 = var15 + var13 + var22 / 2.0F + 1.0F;
         Color var26 = ClickGuiColors.a(ClickGuiColors.aa, var9);
         var1.push();
         var1.translate(var24, var25, 0.0F);
         var1.multiply(new Quaternionf().rotationZ((float)Math.toRadians(90.0)));
         var1.translate(-var24, -var25, 0.0F);
         float var27 = var24 - var22 / 2.0F - 0.5F;
         float var28 = var25 - var23 / 2.0F;
         var2.a(var21, var27, var28, var22, var23, var26, var1);
         var1.pop();
      }

      if (this.p && var8 > 0.1F && this.E != null) {
         float var30 = var14 + 3.0F * var8;
         float var32 = var15 + (var13 - 20.0F * var8) / 2.0F;
         float var34 = var12 - 6.0F * var8;
         this.E.a(var1, var2, var30, var32, var34, var5, var6, var8, var8);
      } else if (!this.p && var8 > 0.1F) {
         float var29 = var15 + 7.0F * var8;
         float var31 = (var13 - 7.0F - 6.0F) * var8;
         if (var12 > 0.0F && var31 > 0.0F) {
            var2.a().a(var14, var29, var12, var31, 9.5F * var8, var1);
            this.A.a(var1, var2, var14, var15, var12, var13, var5, var6, var8, var8);
            float var33 = var15 + var13;
            boolean var35 = this.A.e(var33);
            boolean var36 = this.A.d(var13) && !var35;
            if (var36 != this.D) {
               this.C.a(var36 ? 1.0 : 0.0, 0.15000009069482587, Easings.h);
               this.D = var36;
            }

            float var37 = (float)this.C.j();
            if (var37 > 0.01F) {
               this.B.a(var1, var2, var14, var15, var12, var13, var8 * var37);
            }

            var2.a().a(var1);
         }
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7, float var8, float var9, int var10) {
      float var11 = this.q + this.r / 2.0F;
      TextureRegistry.TextureEntry var12 = TextureRegistry.b("arrow_v");
      float var13 = var12 != null ? var12.b() / 2.0F : 0.0F;
      float var14 = var12 != null ? var12.c() / 2.0F : 0.0F;
      float var15 = this.b(var14);
      this.v = var11 - var15;
      if (this.n) {
         this.u = var3 - 8.0F - var13 - 150.0F;
      } else {
         this.u = var3 + var8 + 8.0F + var13;
      }

      float var16 = this.u + 75.0F;
      float var17 = this.v + var7 / 2.0F;
      float var18 = 150.0F * var9;
      float var19 = var7 * var9;
      float var20 = var13 * var9;
      float var21 = var14 * var9;
      float var22 = var16 - var18 / 2.0F;
      float var23 = var17 - var19 / 2.0F;
      float var24 = var11 - var21 / 2.0F;
      float var25;
      if (this.n) {
         var25 = var22 + var18;
      } else {
         var25 = var22 - var20;
      }

      Color var26 = ClickGuiColors.a(ClickGuiColors.q, var10);
      Color var27 = ClickGuiColors.a(ClickGuiColors.r, var10);
      var2.a(var22 - 0.5F * var9, var23 - 0.5F * var9, var18 + var9, var19 + var9, 9.5F * var9, var26, var26, var27, var27, var1);
      Color var28 = ClickGuiColors.a(ClickGuiColors.e, var10);
      Color var29 = ClickGuiColors.a(ClickGuiColors.f, var10);
      var2.a(var22, var23, var18, var19, 9.5F * var9, var28, var28, var29, var29, var1);
      if (var12 != null) {
         Identifier var30 = var12.a();
         Color var31 = ClickGuiColors.a(ClickGuiColors.aa, var10);
         if (this.n) {
            var2.a(var30, var25, var24, var20, var21, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var31, var1);
         } else {
            var2.a(var30, var25, var24, var20, var21, 0.0F, 1.0F, 0.0F, -1.0F, 1.0F, var31, var1);
         }
      }

      if (this.p && var9 > 0.1F && this.E != null) {
         float var37 = var22 + 3.0F * var9;
         float var39 = var23 + (var19 - 20.0F * var9) / 2.0F;
         float var40 = var18 - 6.0F * var9;
         this.E.a(var1, var2, var37, var39, var40, var5, var6, var9, var9);
      } else if (!this.p && var9 > 0.1F) {
         float var36 = var23 + 7.0F * var9;
         float var38 = (var19 - 7.0F - 6.0F) * var9;
         if (var18 > 0.0F && var38 > 0.0F) {
            var2.a().a(var22, var36, var18, var38, 9.5F * var9, var1);
            this.A.a(var1, var2, var22, var23, var18, var19, var5, var6, var9, var9);
            float var32 = var23 + var19;
            boolean var33 = this.A.e(var32);
            boolean var34 = this.A.d(var19) && !var33;
            if (var34 != this.D) {
               this.C.a(var34 ? 1.0 : 0.0, 0.15000009069482587, Easings.h);
               this.D = var34;
            }

            float var35 = (float)this.C.j();
            if (var35 > 0.01F) {
               this.B.a(var1, var2, var22, var23, var18, var19, var9 * var35);
            }

            var2.a().a(var1);
         }
      }
   }

   public boolean a(int var1, int var2) {
      if (!this.t && !(this.s.j() < 0.5)) {
         boolean var3 = this.f(var1, var2);
         if (!this.d(var1, var2) && !var3) {
            if (this.A.d()) {
               this.A.g();
               return true;
            } else {
               return false;
            }
         } else if (this.p && this.E != null) {
            float var4 = this.a();
            float var5 = (float)Math.max(0.0, Math.min(1.0, this.s.j()));
            float var6 = 150.0F * var5;
            float var7 = var4 * var5;
            float var8 = this.u + 75.0F;
            float var9 = this.v + var4 / 2.0F;
            float var10 = var8 - var6 / 2.0F;
            float var11 = var9 - var7 / 2.0F;
            float var12 = var10 + 3.0F * var5;
            float var13 = var11 + (var7 - 20.0F * var5) / 2.0F;
            float var14 = var6 - 6.0F * var5;
            boolean var15 = this.E.a(var12, var13, var14, var1, var2);
            if (var15 && !this.E.a_() && this.k != null) {
               this.k.a(this.E.e());
            }

            return var15;
         } else {
            return this.A.a(this.u, this.v, 150.0F, this.a(), var1, var2);
         }
      } else {
         return false;
      }
   }

   public boolean b(int var1, int var2) {
      if (this.t || this.s.j() < 0.5) {
         return false;
      } else if (!this.p || this.E == null) {
         boolean var12 = this.f(var1, var2);
         if (!this.d(var1, var2) && !var12) {
            if (this.A.d()) {
               this.A.g();
               return true;
            } else {
               return false;
            }
         } else if (!this.A.d()) {
            return this.A.b(this.u, this.v, 150.0F, this.a(), var1, var2);
         } else if (this.A.b(var1, var2)) {
            return this.A.b(this.u, this.v, 150.0F, this.a(), var1, var2);
         } else {
            this.A.g();
            return true;
         }
      } else if (this.E.a_()) {
         float var3 = this.a();
         float var4 = (float)Math.max(0.0, Math.min(1.0, this.s.j()));
         float var5 = 150.0F * var4;
         float var6 = var3 * var4;
         float var7 = this.u + 75.0F;
         float var8 = this.v + var3 / 2.0F;
         float var9 = var7 - var5 / 2.0F;
         float var10 = var5 - 6.0F * var4;
         boolean var11 = this.E.b(var9, 0.0F, var10, var1, var2);
         if (var11 && this.k != null) {
            this.k.a(this.E.e());
         }

         return var11;
      } else {
         return false;
      }
   }

   public void c(int var1, int var2) {
      if (this.p && this.E != null) {
         this.E.a(var1, var2);
      } else {
         this.A.c(var1, var2);
      }
   }

   public void a(int var1, int var2, double var3, double var5) {
      if (!this.p) {
         this.A.a(this.a(), var1, var2, var3, var5);
      }
   }

   public void a(float var1, int var2, int var3) {
      if (!this.p && this.d(var2, var3)) {
         this.A.a(var1, this.a());
      }
   }

   public boolean a(int var1, int var2, int var3) {
      if (this.t || this.s.j() < 0.5) {
         return false;
      } else if (this.p && this.E != null) {
         boolean var4 = this.E.a(var1, var2, var3);
         if (var4 && this.k != null) {
            this.k.a(this.E.e());
         }

         return var4;
      } else {
         return this.A.a(var1, var2, var3);
      }
   }

   public boolean a(char var1, int var2) {
      if (this.t || this.s.j() < 0.5) {
         return false;
      } else {
         return this.p ? false : this.A.a(var1, var2);
      }
   }

   public boolean h() {
      if (this.t || this.s.j() < 0.5) {
         return false;
      } else {
         return this.p && this.E != null ? this.E.a_() : this.A.l();
      }
   }

   public boolean d(int var1, int var2) {
      if (this.t || this.s.j() < 0.5) {
         return false;
      } else if (this.w) {
         return MouseUtil.a(this.u, this.v, 150.0F, this.a(), (double)var1, (double)var2);
      } else {
         TextureRegistry.TextureEntry var3 = TextureRegistry.b("arrow_v");
         float var4 = var3 != null ? var3.b() / 2.0F : 0.0F;
         float var5 = 150.0F + var4;
         float var6 = this.n ? this.u : this.u - var4;
         return MouseUtil.a(var6, this.v, var5, this.a(), (double)var1, (double)var2);
      }
   }

   public boolean e(int var1, int var2) {
      return !this.t && !(this.s.j() < 0.5) ? MouseUtil.a(this.u, this.v, 150.0F, this.a(), (double)var1, (double)var2) : false;
   }

   public boolean a(ModuleSettingsPanel var1) {
      if (this.n != var1.n) {
         return false;
      } else {
         float var2 = this.v;
         float var3 = this.v + this.a();
         float var4 = var1.v;
         float var5 = var1.v + var1.a();
         return !(var3 <= var4) && !(var2 >= var5);
      }
   }

   public float i() {
      return this.w ? this.y : this.v;
   }

   public float j() {
      return this.w ? this.x : this.u;
   }

   public float k() {
      return this.a();
   }

   public ToggleEntry l() {
      return this.k;
   }

   public int m() {
      return this.m;
   }

   public boolean n() {
      return this.n;
   }

   public ModuleSettingsPanel.ArrowPosition o() {
      return this.o;
   }

   public void a(ModuleSettingsPanel.ArrowPosition var1) {
      this.o = var1;
   }

   public float p() {
      return this.q;
   }

   public SettingsContainer q() {
      return this.A;
   }

   public boolean r() {
      return this.w;
   }

   public KeySettingElement s() {
      return this.E;
   }

   public int t() {
      return this.E != null ? this.E.e() : -1;
   }

   public void a(int var1) {
      if (this.E != null) {
         this.E.a(var1);
      }
   }

   public boolean u() {
      return this.p ? false : this.A.h();
   }

   public void v() {
      if (!this.p) {
         this.A.i();
      }
   }

   public float[] w() {
      return this.p ? null : this.A.j();
   }

   public boolean x() {
      return this.A.d();
   }

   public boolean f(int var1, int var2) {
      return this.p ? false : this.A.a(var1, var2);
   }

   @Environment(EnvType.CLIENT)
   public static enum ArrowPosition {
      a,
      b,
      c;

      private static ModuleSettingsPanel.ArrowPosition[] a() {
         return new ModuleSettingsPanel.ArrowPosition[]{a, b, c};
      }
   }
}
