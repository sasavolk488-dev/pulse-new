package pulse.features.modules.hud;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Target HUD",
   b = "Show target info",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class TargetHUDModule extends Module {
   private final NumberSetting a = new NumberSetting("Масштаб", 1.0F, 0.9F, 2.0F, 0.1F);
   private final NumberSetting b = new NumberSetting("Время жизни таргета", 1.0F, 0.0F, 2.0F, 0.1F);

   public TargetHUDModule() {
      this.d();
   }

   @Generated
   public NumberSetting n() {
      return this.a;
   }

   @Generated
   public NumberSetting o() {
      return this.b;
   }
}
