package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import pulse.core.event.impl.DropItemEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Lock Slot",
   b = "Блокирует выбрасывание предметов из выбранных слотов",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class LockSlotModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Блокировать весь хотбар", false);
   private final ModeSetting b = new ModeSetting(
         "Заблокированные слоты", new String[]{"Слот 1", "Слот 2", "Слот 3", "Слот 4", "Слот 5", "Слот 6", "Слот 7", "Слот 8", "Слот 9"}, new int[0]
      )
      .a(() -> !this.a.q());
   private final BooleanSetting c = new BooleanSetting("Блокировать сферы & талисманы", false);

   @EventHandler
   @Compile
      public void a(DropItemEvent var1) {
      if (d.player == null) {
         return;
      }
      int slot = var1.d();
      if (slot == 40 && this.a(d.player.getOffHandStack())) {
         var1.b();
         return;
      }
      if (slot >= 0 && slot < 9) {
         if (this.a.q() || this.b.a(slot)) {
            var1.b();
            return;
         }
      }
      if (slot >= 0 && slot < d.player.getInventory().getMainStacks().size()
            && this.a(d.player.getInventory().getStack(slot))) {
         var1.b();
      }
   }

   private boolean a(ItemStack var1) {
      if (this.c.q() && !var1.isEmpty()) {
         if (var1.getItem() == Items.PLAYER_HEAD) {
            ProfileComponent var3 = var1.get(DataComponentTypes.PROFILE);
            return var3 != null && (var3.getName().isPresent() || !var3.getGameProfile().properties().isEmpty());
         } else if (var1.getItem() != Items.TOTEM_OF_UNDYING) {
            return false;
         } else {
            ItemEnchantmentsComponent var2 = var1.get(DataComponentTypes.ENCHANTMENTS);
            return var2 != null && !var2.isEmpty();
         }
      } else {
         return false;
      }
   }

   static {
      NativeMethodLookup.lookup(LockSlotModule.class, 66);
   }
}
