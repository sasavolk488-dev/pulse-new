package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;

@Environment(EnvType.CLIENT)
@Mixin({FogRenderer.class})
public abstract class FogRendererMixin {
   @Inject(
      method = {"getCameraSubmersionType"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$forceAtmospheric(Camera var1, CallbackInfoReturnable<CameraSubmersionType> var2) {
      if (ModuleRegistry.n != null && ModuleRegistry.n.k()) {
         CameraSubmersionType var3 = var1.getSubmersionType();
         if (var3 == CameraSubmersionType.WATER || var3 == CameraSubmersionType.LAVA) {
            var2.setReturnValue(CameraSubmersionType.ATMOSPHERIC);
         }
      }
   }
}
