package pulse.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.core.handler.impl.SplashRenderHandler;
import pulse.core.api.ISplashOverlay;

@Environment(EnvType.CLIENT)
@Mixin({SplashOverlay.class})
public abstract class SplashOverlayMixin implements ISplashOverlay {
   @Shadow
   private long reloadStartTime;
   @Shadow
   private long reloadCompleteTime;

   @Shadow
   private void renderProgressBar(DrawContext var1, int var2, int var3, int var4, int var5, float var6) {
      throw new AssertionError();
   }

   @Redirect(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V"
      )
   )
   private void pulse$noVanillaBackground(DrawContext var1, int var2, int var3, int var4, int var5, int var6) {
      if (!SplashRenderHandler.a) {
         var1.fill(var2, var3, var4, var5, var6);
      }
   }

   @Redirect(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIFFIIIIIII)V"
      )
   )
   private void pulse$noVanillaLogo(
      DrawContext var1,
      RenderPipeline var2,
      Identifier var3,
      int var4,
      int var5,
      float var6,
      float var7,
      int var8,
      int var9,
      int var10,
      int var11,
      int var12,
      int var13,
      int var14
   ) {
      if (!SplashRenderHandler.a) {
         var1.drawTexture(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14);
      }
   }

   @Redirect(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/screen/SplashOverlay;renderProgressBar(Lnet/minecraft/client/gui/DrawContext;IIIIF)V"
      )
   )
   private void pulse$noVanillaProgressBar(SplashOverlay var1, DrawContext var2, int var3, int var4, int var5, int var6, float var7) {
      if (!SplashRenderHandler.a) {
         this.renderProgressBar(var2, var3, var4, var5, var6, var7);
      }
   }

   @Override
   public long pulse$reloadStartTime() {
      return this.reloadStartTime;
   }

   @Override
   public long pulse$reloadCompleteTime() {
      return this.reloadCompleteTime;
   }
}
