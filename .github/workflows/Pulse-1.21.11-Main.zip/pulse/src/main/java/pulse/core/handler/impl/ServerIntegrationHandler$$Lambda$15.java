package pulse.core.handler.impl;

public final class ServerIntegrationHandler$$Lambda$15 implements Runnable {
   private final ServerIntegrationHandler c0;

   public ServerIntegrationHandler$$Lambda$15(ServerIntegrationHandler var1) {
      this.c0 = var1;
   }

   @Override
   public void run() {
      this.c0.d();
   }
}
