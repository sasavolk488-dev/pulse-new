package pulse.core.handler.impl.music;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import com.wmedia.AudioLevels;
import com.wmedia.MediaInfo;
import com.wmedia.MediaProvider;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class MusicHandler extends Handler {
   private static final long a = 400L;
   private static final long b = 16L;
   private final MusicState c = new MusicState();
   private static final AtomicBoolean d = new AtomicBoolean(false);
   private static final AtomicBoolean e = new AtomicBoolean(false);
   private static Thread f = null;
   private static final AtomicReference<MusicHandler.CachedMediaInfo> g = new AtomicReference<>(null);
   private static final AtomicReference<float[]> h = new AtomicReference<>(new float[]{0.0F, 0.0F, 0.0F});
   private static volatile boolean i = false;
   private static volatile boolean j = false;
   private static final int k = 6;
   private final float[] l = new float[6];
   private final float[] m = new float[6];
   private float n = 0.0F;
   private int o = 0;
   private long p = 0L;
   private long q = 0L;
   private static final long r = 50L;
   private static final long s = 16L;

   @Override
   public void a() {
      super.a();
      j();
   }

   private static synchronized void j() {
      if (f == null || !f.isAlive()) {
         if (!e.get()) {
            d.set(true);
            f = new Thread(MusicHandler::k, "WMedia-Polling");
            f.setDaemon(true);
            f.setPriority(2);
            f.start();
            System.out.println("Started WMedia polling thread");
         }
      }
   }

   private static void k() {
      long var0 = 0L;
      long var2 = 0L;

      while (d.get() && !e.get()) {
         try {
            if (!l()) {
               if (g.get() != null) {
                  g.set(null);
                  h.set(new float[]{0.0F, 0.0F, 0.0F});
               }

               Thread.sleep(500L);
            } else {
               long var4 = System.currentTimeMillis();
               if (var4 - var0 >= 400L) {
                  var0 = var4;
                  m();
               }

               if (var4 - var2 >= 16L) {
                  var2 = var4;
                  n();
               }

               Thread.sleep(8L);
            }
         } catch (InterruptedException var7) {
            Thread.currentThread().interrupt();
            break;
         } catch (Throwable var8) {
            System.err.println("Polling error: " + var8.getMessage());

            try {
               Thread.sleep(100L);
            } catch (InterruptedException var6) {
               Thread.currentThread().interrupt();
               break;
            }
         }
      }

      System.out.println("Polling thread stopped");
   }

   private static boolean l() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      return var0 != null && var0.world != null && var0.player != null;
   }

   private static void m() {
      if (!r()) {
         g.set(null);
      } else {
         try {
            Optional var0 = MediaProvider.getCurrentMedia();
            if (var0.isPresent()) {
               MediaInfo var1 = (MediaInfo)var0.get();
               String var2 = var1.getTitle().isEmpty() ? "No media" : var1.getTitle();
               String var3 = var1.getArtist();
               boolean var4 = var1.isPlaying();
               float var5 = (float)var1.getPositionMs();
               float var6 = (float)var1.getDurationMs();
               byte[] var7 = var1.getAlbumArt();
               g.set(new MusicHandler.CachedMediaInfo(var2, var3, var4, var5, var6, var7));
            } else {
               g.set(new MusicHandler.CachedMediaInfo("No media", "", false, 0.0F, 0.0F, null));
            }
         } catch (Throwable var8) {
            i = false;
            g.set(null);
         }
      }
   }

   private static void n() {
      if (!r()) {
         h.set(new float[]{0.0F, 0.0F, 0.0F});
      } else {
         try {
            Optional var0 = MediaProvider.getAudioLevels();
            if (var0.isPresent()) {
               AudioLevels var1 = (AudioLevels)var0.get();
               h.set(new float[]{var1.getMasterPeak(), var1.getLeftPeak(), var1.getRightPeak()});
            } else {
               h.set(new float[]{0.0F, 0.0F, 0.0F});
            }
         } catch (Throwable var2) {
            h.set(new float[]{0.0F, 0.0F, 0.0F});
         }
      }
   }

   @EventHandler
   @Compile
   private void a(UpdateEvent var1) {
      long now = System.currentTimeMillis();
      if (now - this.p >= 50L) {
         this.p = now;
         this.o();
      }
      if (now - this.q >= 16L) {
         this.q = now;
         this.p();
      }
   }

   private void o() {
      MusicHandler.CachedMediaInfo var1 = g.get();
      if (var1 != null) {
         this.c.a(var1.a, var1.b, var1.c, var1.d, var1.e, var1.f);
      } else {
         this.c.a("No media", "", false, 0.0F, 0.0F, null);
      }

      this.c.m();
   }

   private void p() {
      this.o++;
      float[] var1 = h.get();
      if (var1 != null && (var1[0] != 0.0F || var1[1] != 0.0F || var1[2] != 0.0F)) {
         float var2 = var1[0];
         float var3 = var1[1];
         float var4 = var1[2];
         float var5 = 0.0F;
         if (var2 > this.n + 0.15F) {
            var5 = (var2 - this.n) * 2.0F;
         }

         this.n = var2 * 0.7F + this.n * 0.3F;
         float var6 = 1.4F;
         float var7 = Math.min(var2 * var6, 1.0F);
         float var8 = Math.min(var3 * var6, 1.0F);
         float var9 = Math.min(var4 * var6, 1.0F);
         float var10 = this.o;
         float var11 = (float)(Math.sin(var10 * 0.5) * 0.08000000026935626 + 0.9199997172273399);
         float var12 = (float)(Math.sin(var10 * 0.600000004908361 + 1.0) * 0.08000000026935626 + 0.9199997172273399);
         float var13 = (float)(Math.sin(var10 * 0.7000000991896063 + 2.0) * 0.08000000026935626 + 0.9199997172273399);
         float[] var14 = new float[]{
            (var8 * 0.6F + var5 * 0.3F) * var11,
            (var8 * 0.85F + var7 * 0.3F + var5 * 0.5F) * var12,
            (var8 * 0.5F + var7 * 0.7F + var5 * 0.7F) * var13,
            (var9 * 0.5F + var7 * 0.7F + var5 * 0.7F) * var11,
            (var9 * 0.85F + var7 * 0.3F + var5 * 0.5F) * var13,
            (var9 * 0.6F + var5 * 0.3F) * var12
         };

         for (int var15 = 0; var15 < 6; var15++) {
            float var16 = Math.min(var14[var15], 1.0F);
            if (var16 > this.l[var15]) {
               this.l[var15] = this.l[var15] * 0.1F + var16 * 0.9F;
            } else {
               this.l[var15] = this.l[var15] * 0.6F + var16 * 0.4F;
            }

            if (this.l[var15] > this.m[var15]) {
               this.m[var15] = this.l[var15];
            } else {
               this.m[var15] = this.m[var15] * 0.92F;
            }

            float var17 = this.l[var15] * 0.7F + this.m[var15] * 0.3F;
            this.c.H()[var15] = Math.min(var17, 1.0F);
         }
      } else {
         this.q();
      }
   }

   private void q() {
      for (int var1 = 0; var1 < 6; var1++) {
         this.l[var1] = this.l[var1] * 0.8F;
         this.m[var1] = this.m[var1] * 0.85F;
         float var2 = this.l[var1] * 0.7F + this.m[var1] * 0.3F;
         this.c.H()[var1] = var2;
      }
   }

   public void d() {
      boolean var1 = !this.c.c();
      this.c.a(var1);
      if (!var1) {
         this.c.i();
      } else {
         this.c.j();
      }

      if (g()) {
         Thread var2 = new Thread(() -> {
            try {
               MediaProvider.playPause();
            } catch (Throwable var1x) {
            }
         }, "WMedia-PlayPause");
         var2.setDaemon(true);
         var2.start();
      }
   }

   public void e() {
      if (g()) {
         Thread var1 = new Thread(() -> {
            try {
               MediaProvider.next();
            } catch (Throwable var1x) {
            }
         }, "WMedia-Next");
         var1.setDaemon(true);
         var1.start();
      }
   }

   public void f() {
      if (g()) {
         Thread var1 = new Thread(() -> {
            try {
               MediaProvider.previous();
            } catch (Throwable var1x) {
            }
         }, "WMedia-Previous");
         var1.setDaemon(true);
         var1.start();
      }
   }

   public void a(float var1) {
      float var2 = var1 * this.c.s();
      this.c.a(var2);
   }

   public void b(float var1) {
      float var2 = var1 * this.c.s();
      this.c.b(var2);
   }

   public void c(float var1) {
      float var2 = var1 * this.c.s();
      this.c.b(var2);
      this.c.e();
      if (g() && this.c.s() > 0.0F) {
         long var3 = (long)var2;
         new Thread(() -> {
            try {
               MediaProvider.seek(var3);
            } catch (Throwable var3x) {
            }
         }, "WMedia-Seek").start();
      }
   }

   private static boolean r() {
      if (e.get()) {
         return false;
      } else {
         if (!j) {
            j = true;

            try {
               i = MediaProvider.isAvailable();
               System.out.println("WMedia library available: " + i);
            } catch (Throwable var1) {
               System.out.println("WMedia library error: " + var1.getMessage());
               i = false;
            }
         }

         return i;
      }
   }

   public static boolean g() {
      return i && !e.get();
   }

   public static synchronized void h() {
      if (!e.getAndSet(true)) {
         System.out.println("Shutting down WMedia...");
         d.set(false);
         if (f != null) {
            f.interrupt();

            try {
               f.join(1000L);
            } catch (InterruptedException var2) {
            }

            f = null;
         }

         g.set(null);
         h.set(new float[]{0.0F, 0.0F, 0.0F});
         if (i) {
            try {
               MediaProvider.shutdown();
               System.out.println("MediaProvider.shutdown() called");
            } catch (Throwable var1) {
               System.err.println("Error during shutdown: " + var1.getMessage());
            }
         }

         i = false;
         System.out.println("WMedia shutdown complete");
      }
   }

   @Generated
   public MusicState i() {
      return this.c;
   }

   static {
      NativeMethodLookup.lookup(MusicHandler.class, 34);
   }

   @Environment(EnvType.CLIENT)
   private static class CachedMediaInfo {
      final String a;
      final String b;
      final boolean c;
      final float d;
      final float e;
      final byte[] f;
      final long g;

      CachedMediaInfo(String var1, String var2, boolean var3, float var4, float var5, byte[] var6) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
         this.f = var6;
         this.g = System.currentTimeMillis();
      }
   }
}
