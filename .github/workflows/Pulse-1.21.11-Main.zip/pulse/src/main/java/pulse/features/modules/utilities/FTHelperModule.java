package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.PlaySoundEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.core.api.IMinecraft;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.features.modules.utilities.ft.FunTimeItemType;
import pulse.features.modules.utilities.ft.StructureTracker;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.WorldRenderHelper;
import pulse.utils.render.font.FontRenderer;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;
import pulse.utils.game.EntityUtils;
import pulse.utils.game.FriendUtils;
import pulse.utils.render.RenderUtils;
import pulse.utils.render.ScreenUtils;
import pulse.utils.game.entity.EntityFinder;
import pulse.utils.game.entity.EntityTags;

@ModuleInfo(
   a = "FT Helper",
   b = "Предпросмотр зоны действия донат-предметов",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FTHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Трапка", true);
   private final BooleanSetting b = new BooleanSetting("Пласт", true);
   private final BooleanSetting c = new BooleanSetting("Дезориентация", true);
   private final BooleanSetting f = new BooleanSetting("Явная пыль", true);
   private final BooleanSetting g = new BooleanSetting("Снежок заморозки", true);
   private final BooleanSetting h = new BooleanSetting("Бур хелпер", true);
   private final SeparatorSetting i = new SeparatorSetting("Настройки трапки");
   private final BooleanSetting j = new BooleanSetting("Таймер действия", true);
   private final BooleanSetting k = new BooleanSetting("Зона драконьей трапки", false);
   private final SeparatorSetting l = new SeparatorSetting("Настройки пласта");
   private final BooleanSetting m = new BooleanSetting("Таймер действия пласта", true);
   private final SeparatorSetting n = new SeparatorSetting("Таймеры структур");
   private final BooleanSetting o = new BooleanSetting("Карточка на структуре", true);
   private final NumberSetting p = new NumberSetting("Дальность таймеров", 32.0F, 8.0F, 64.0F, 1.0F).a(() -> this.o.q());
   private final ColorSetting q = new ColorSetting("Цвет таймера трапки", new Color(255, 85, 85)).a(() -> this.o.q() && this.j.q());
   private final ColorSetting r = new ColorSetting("Цвет таймера пласта", new Color(85, 255, 85)).a(() -> this.o.q() && this.m.q());
   private final SeparatorSetting s = new SeparatorSetting("Настройки снежка");
   private final NumberSetting t = new NumberSetting("Жирность линии", 2.5F, 0.5F, 10.0F);
   private final SeparatorSetting u = new SeparatorSetting("Предупреждения");
   private final BooleanSetting v = new BooleanSetting("Спец. предметы на анархии", true);
   private final SeparatorSetting w = new SeparatorSetting("Цвет");
   private final BooleanSetting x = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting y = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.x.q());
   private static final Identifier z = Identifier.ofVanilla("entity.ender_dragon.growl");
   private long A = 0L;
   private final FTHelperModule.CooldownUseTracker B = new FTHelperModule.CooldownUseTracker(Items.NETHERITE_SCRAP);
   private final FTHelperModule.CooldownUseTracker C = new FTHelperModule.CooldownUseTracker(Items.DRIED_KELP);
   private static final int D = 4;
   private final StructureTracker E = new StructureTracker();
   private static final long F = 1200L;
   private static final double G = 8.0;
   private final List<FTHelperModule.ActiveTimer> H = new CopyOnWriteArrayList<>();
   private static final int I = 200;
   private Vec3d J = null;
   private final List<Vec3d> K = new ArrayList<>(202);
   private static final double L = 2.0;
   private static final float M = 22.0F;
   private static final float N = 6.0F;
   private static final float O = 56.0F;
   private static final float P = 3.5F;
   private static final float Q = 14.0F;
   private static final float R = 4.5F;
   private static final float S = 3.5F;
   private static final float T = 0.5F;
   private static final float U = 5.0F;
   private static final float V = 1.5F;
   private static final float W = 3.0F;
   private static final float X = 4.5F;
   private static final float Y = 17.5F;
   private static final long Z = 180L;
   private static final long aa = 250L;
   private static final float ab = 5.0F;
   private static final float ac = 11.0F;

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      BooleanSetting setting_a = this.a;
      BooleanSetting setting_b = this.b;
      BooleanSetting setting_c = this.c;
      BooleanSetting setting_f = this.f;
      BooleanSetting setting_g = this.g;
      BooleanSetting setting_h = this.h;
      if (d.world == null || d.player == null) {
         return;
      }
      MatrixStack matrices = var1.a();
      float tickDelta = var1.b();
      var mainItem = d.player.getMainHandStack().getItem();
      var offItem = d.player.getOffHandStack().getItem();
      if ((Boolean)setting_a.q() && (mainItem == Items.NETHERITE_SCRAP || offItem == Items.NETHERITE_SCRAP)) {
         this.b(matrices);
      }
      if ((Boolean)setting_b.q() && (mainItem == Items.DRIED_KELP || offItem == Items.DRIED_KELP)) {
         this.c(matrices);
      }
      if ((Boolean)setting_c.q() && (mainItem == Items.ENDER_EYE || offItem == Items.ENDER_EYE)) {
         this.b(matrices, tickDelta);
      }
      if ((Boolean)setting_f.q() && (mainItem == Items.SUGAR || offItem == Items.SUGAR)) {
         this.c(matrices, tickDelta);
      }
      if ((Boolean)setting_g.q() && (mainItem == Items.SNOWBALL || offItem == Items.SNOWBALL)) {
         this.a(matrices, tickDelta);
      }
      if ((Boolean)setting_h.q()) {
         this.a(matrices);
      }
   }

   private void a(MatrixStack var1) {
      ItemStack var2 = d.player.getMainHandStack();
      if (this.a(var2.getItem())) {
         int[] var3 = this.a(var2);
         if (var3 != null) {
            int var4 = var3[0];
            int var5 = var3[1];
            if (d.crosshairTarget != null && d.crosshairTarget.getType() == Type.BLOCK) {
               BlockHitResult var6 = (BlockHitResult)d.crosshairTarget;
               BlockPos var7 = var6.getBlockPos();
               Direction var8 = var6.getSide();
               Axis var9 = var8.getAxis();
               Direction var10 = var8.getOpposite();
               BlockPos var11 = this.a(var7, var9, -var4, -var4);
               BlockPos var12 = this.a(var7.offset(var10, var5 - 1), var9, var4, var4);
               int var13 = Math.min(var11.getX(), var12.getX());
               int var14 = Math.min(var11.getY(), var12.getY());
               int var15 = Math.min(var11.getZ(), var12.getZ());
               int var16 = Math.max(var11.getX(), var12.getX());
               int var17 = Math.max(var11.getY(), var12.getY());
               int var18 = Math.max(var11.getZ(), var12.getZ());
               Box var19 = new Box(var13, var14, var15, var16 + 1, var17 + 1, var18 + 1);
               RenderUtils.a(var1, var19, this.p().getRGB());
            }
         }
      }
   }

   private BlockPos a(BlockPos var1, Axis var2, int var3, int var4) {
      switch (var2) {
         case X:
            return var1.add(0, var3, var4);
         case Y:
            return var1.add(var3, 0, var4);
         default:
            return var1.add(var3, var4, 0);
      }
   }

   private boolean a(Item var1) {
      return var1 == Items.WOODEN_PICKAXE
         || var1 == Items.STONE_PICKAXE
         || var1 == Items.IRON_PICKAXE
         || var1 == Items.GOLDEN_PICKAXE
         || var1 == Items.DIAMOND_PICKAXE
         || var1 == Items.NETHERITE_PICKAXE;
   }

   private int[] a(ItemStack var1) {
      NbtComponent var2 = var1.get(DataComponentTypes.CUSTOM_DATA);
      if (var2 != null) {
         NbtCompound var3 = var2.copyNbt();
         if (var3 != null && var3.contains("PublicBukkitValues")) {
            NbtCompound var4 = var3.getCompoundOrEmpty("PublicBukkitValues");
            if (var4.contains("minecraft:custom-enchantments")) {
               NbtList var5 = var4.getListOrEmpty("minecraft:custom-enchantments");

               for (int var6 = 0; var6 < var5.size(); var6++) {
                  NbtCompound var7 = var5.getCompoundOrEmpty(var6);
                  String var8 = var7.getString("minecraft:type", "");
                  if (!var8.isEmpty()) {
                     String var9 = var8.toLowerCase();
                     if (var9.contains("mega")) {
                        return new int[]{4, 5};
                     }

                     if (var9.contains("bulldozer")) {
                        int var10 = var7.getInt("minecraft:level", 0);
                        return new int[]{1, var10 >= 2 ? 3 : 1};
                     }
                  }
               }
            }
         }
      }

      LoreComponent var11 = var1.get(DataComponentTypes.LORE);
      if (var11 != null) {
         for (Text var13 : var11.lines()) {
            String var14 = var13.getString();
            if (var14 != null) {
               if (var14.contains("9x9x5") || var14.toLowerCase().contains("мега-бульдозер")) {
                  return new int[]{4, 5};
               }

               if (var14.contains("Бульдозер II")) {
                  return new int[]{1, 3};
               }

               if (var14.contains("Бульдозер I")) {
                  return new int[]{1, 1};
               }
            }
         }
      }

      return null;
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      BooleanSetting trap = this.j;
      var trapTracker = this.B;
      BooleanSetting plast = this.m;
      var plastTracker = this.C;
      var structures = this.E;
      var timers = this.H;
      if (d.world == null || d.player == null) {
         return;
      }
      if ((Boolean)trap.q()) {
         trapTracker.a(this::r);
      }
      if ((Boolean)plast.q()) {
         plastTracker.a(FTHelperModule::q);
      }
      structures.a((Boolean)trap.q(), (Boolean)plast.q());
      this.o();
      timers.removeIf(FTHelperModule.ActiveTimer::a);
   }

   private void o() {
      long var1 = System.currentTimeMillis();

      for (FTHelperModule.ActiveTimer var4 : this.H) {
         if (var4.i == null && var1 - var4.c <= 1200L) {
            StructureTracker.Placement var5 = this.E.a(var4.a, var4.g, 8.0, var1, 1200L);
            if (var5 != null) {
               var4.i = this.a(var5.blockPos(), var4);
               var4.j = var1;
            }
         }
      }
   }

   private Vec3d a(BlockPos var1, FTHelperModule.ActiveTimer var2) {
      double var3 = var1.getX() + 0.5;
      double var5 = var1.getY() + 0.40000003078118207;
      double var7 = var1.getZ() + 0.5;
      if (var2.a == FunTimeItemType.b) {
         if (var2.f < -45.0F) {
            var5 += 4.0;
         } else if (var2.f > 45.0F) {
            var5 -= 2.0;
         } else {
            double var9 = Math.toRadians(var2.e);
            var3 += -Math.sin(var9) * 2.0;
            var7 += Math.cos(var9) * 2.0;
         }
      }

      return new Vec3d(var3, var5, var7);
   }

   @EventHandler
   @Compile
      public void a(PacketEvent var1) {
      if (var1.e() != PacketEvent.EventType.b) {
         return;
      }
      if (!this.j.q() && !this.m.q()) {
         return;
      }
      var packet = var1.d();
      if (packet instanceof net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket sound) {
         this.E.a(sound);
      }
   }

   @EventHandler
   public void a(PlaySoundEvent var1) {
      if (z.equals(var1.d().getId())) {
         this.A = System.currentTimeMillis();
      }
   }

   @EventHandler
   public void a(WorldChangeEvent var1) {
      this.E.a();
      this.H.clear();
   }

   @Override
   public void f() {
      super.f();
      this.E.a();
      this.H.clear();
   }

   private void a(MatrixStack var1, float var2) {
      this.K.clear();
      this.J = this.a(var2);
      if (this.J != null) {
         boolean var3 = this.a(this.J, 5.0);
         if (!this.K.isEmpty()) {
            this.a(var1, var3);
         }

         int var4 = var3 ? -16711936 : this.p().getRGB();
         RenderUtils.a(var1, this.J, 5.0F, 64, var4, 0.1F);
      }
   }

   private void a(MatrixStack var1, boolean var2) {
      Vec3d var3 = d.gameRenderer.getCamera().getCameraPos();
      if (this.K.size() >= 2) {
         var1.push();
         VertexConsumer var4 = WorldRenderHelper.g();
         Entry var5 = var1.peek();
         int var6 = var2 ? -16711936 : this.p().getRGB();
         int var7 = this.K.size();

         for (int var8 = 0; var8 + 1 < var7; var8++) {
            Vec3d var9 = this.K.get(var8);
            Vec3d var10 = this.K.get(var8 + 1);
            float var11 = (float)var8 / var7;
            float var12 = (float)(var8 + 1) / var7;
            int var13 = ColorUtils.a(var6, (int)(var11 * 255.0F));
            int var14 = ColorUtils.a(var6, (int)(var12 * 255.0F));
            float var15 = (float)(var9.x - var3.x);
            float var16 = (float)(var9.y - var3.y);
            float var17 = (float)(var9.z - var3.z);
            float var18 = (float)(var10.x - var3.x);
            float var19 = (float)(var10.y - var3.y);
            float var20 = (float)(var10.z - var3.z);
            float var21 = var18 - var15;
            float var22 = var19 - var16;
            float var23 = var20 - var17;
            float var24 = (float)Math.sqrt(var21 * var21 + var22 * var22 + var23 * var23);
            if (var24 < 1.0E-6F) {
               var24 = 1.0F;
            }

            float var25 = var21 / var24;
            float var26 = var22 / var24;
            float var27 = var23 / var24;
            var4.vertex(var5, var15, var16, var17)
               .color((var13 >> 16 & 0xFF) / 255.0F, (var13 >> 8 & 0xFF) / 255.0F, (var13 & 0xFF) / 255.0F, (var13 >> 24 & 0xFF) / 255.0F)
               .normal(var5, var25, var26, var27)
               .lineWidth(2.0F);
            var4.vertex(var5, var18, var19, var20)
               .color((var14 >> 16 & 0xFF) / 255.0F, (var14 >> 8 & 0xFF) / 255.0F, (var14 & 0xFF) / 255.0F, (var14 >> 24 & 0xFF) / 255.0F)
               .normal(var5, var25, var26, var27)
               .lineWidth(2.0F);
         }

         WorldRenderHelper.e();
         var1.pop();
      }
   }

   private Vec3d a(float var1) {
      Vec3d var2 = d.player.getCameraPosVec(var1);
      Vec3d var3 = this.b(var1);
      Vec3d var4 = var2;
      short var5 = 200;
      double var6 = 0.9900000598234964;
      double var8 = 0.029999989818834755;
      this.K.add(var2);

      for (int var10 = 0; var10 < var5; var10++) {
         Vec3d var11 = var4;
         var4 = var4.add(var3);
         RaycastContext var12 = new RaycastContext(var11, var4, ShapeType.COLLIDER, FluidHandling.NONE, d.player);
         BlockHitResult var13 = d.world.raycast(var12);
         if (var13.getType() != Type.MISS) {
            this.K.add(var13.getPos());
            return var13.getPos();
         }

         if (var4.y < d.world.getBottomY()) {
            this.K.add(var4);
            return var4;
         }

         this.K.add(var4);
         var3 = var3.multiply(var6).subtract(0.0, var8, 0.0);
      }

      return null;
   }

   private Vec3d b(float var1) {
      double var2 = d.player.getVelocity().y * 0.5;
      Vec3d var4 = new Vec3d(0.0, var2, 0.0);
      Vec3d var5 = this.a(d.player.getYaw(), d.player.getPitch());
      double var6 = 1.5;
      Vec3d var8 = var5.multiply(var6);
      return var8.add(var4);
   }

   private Vec3d a(float var1, float var2) {
      float var3 = MathHelper.cos(var2 * (float) (Math.PI / 180.0));
      float var4 = MathHelper.sin(var2 * (float) (Math.PI / 180.0));
      float var5 = MathHelper.cos(var1 * (float) (Math.PI / 180.0));
      float var6 = MathHelper.sin(var1 * (float) (Math.PI / 180.0));
      float var7 = -var6 * var3;
      float var8 = -var4;
      float var9 = var5 * var3;
      return new Vec3d(var7, var8, var9).normalize();
   }

   private static float c(float var0) {
      return Math.round(var0 * 2.0F) / 2.0F;
   }

   public void a(DrawContext var1) {
      if (d.player != null && d.world != null) {
         if (!this.H.isEmpty()) {
            TextRenderer var2 = d.textRenderer;
            int var3 = var1.getScaledWindowWidth();
            int var4 = var1.getScaledWindowHeight();
            int var5 = var4 - 68;

            for (int var6 = 0; var6 < this.H.size(); var6++) {
               FTHelperModule.ActiveTimer var7 = this.H.get(var6);
               float var8 = -var6 * 11.0F;
               var7.h.a();
               if (Math.abs(var7.h.j() - var8) > 0.01000000327827366 && var7.h.d()) {
                  var7.h.a(var8, 0.25, Easings.h);
               }

               int var9 = var5 + Math.round((float)var7.h.j());
               String var10 = String.format("%s закончится через §b%.1f§f сек.", var7.b, var7.b());
               int var11 = var2.getWidth(var10);
               int var12 = (var3 - var11) / 2;
               var1.drawTextWithShadow(var2, var10, var12, var9, -1);
            }
         }
      }
   }

   @EventHandler
   public void a(RenderHudPostEvent var1) {
      if (this.o.q()) {
         if (d.player != null && d.world != null) {
            if (!this.H.isEmpty()) {
               Render var2 = Pulse.l().p();
               if (var2 != null) {
                  double var3 = this.p.b();
                  Vec3d var5 = d.player.getEntityPos();
                  ArrayList<FTHelperModule.ActiveTimer> var6 = new ArrayList<>(this.H.size());

                  for (FTHelperModule.ActiveTimer var8 : this.H) {
                     if (var8.i != null && var8.i.squaredDistanceTo(var5) <= var3 * var3) {
                        var6.add(var8);
                     }
                  }

                  if (!var6.isEmpty()) {
                     var6.sort(Comparator.<FTHelperModule.ActiveTimer>comparingDouble(var1x -> var1x.i.squaredDistanceTo(var5)).reversed());
                     long var11 = System.currentTimeMillis();

                     for (FTHelperModule.ActiveTimer var10 : var6) {
                        this.a(var1.a(), var2, var10, var11, var5, var3);
                     }
                  }
               }
            }
         }
      }
   }

   private void a(MatrixStack var1, Render var2, FTHelperModule.ActiveTimer var3, long var4, Vec3d var6, double var7) {
      Vec3d var9 = var3.i;
      Vec3d var10 = ScreenUtils.a(var9);
      if (var10 != null && ScreenUtils.b(var10)) {
         double var11 = var6.distanceTo(var9);
         float var13 = this.a(var3, var4, var11, var7);
         if (!(var13 <= 0.01F)) {
            long var14 = var4 - var3.j;
            float var16 = var14 >= 180L ? 1.0F : (float)var14 / 180.0F;
            float var17 = (1.0F - var16 * var16) * 5.0F;
            Color var18 = var3.a == FunTimeItemType.b ? this.r.q() : this.q.q();
            FontRenderer var19 = Fonts.b[12];
            FontRenderer var20 = Fonts.b[10];
            String var21 = var3.b;
            String var22 = String.format(Locale.ROOT, "%.1f сек", (float)var3.a(var4) / 1000.0F);
            float var23 = Math.max(var19.a(var21), var20.a(var22));
            float var24 = Math.max(56.0F, 21.0F + var23 + 5.0F);
            float var25 = c((float)var10.x - var24 / 2.0F);
            float var26 = c((float)var10.y - 11.0F + var17);
            Color var27 = a(ClickGuiColors.a(ClickGuiColors.m, 200), var13);
            Color var28 = a(ClickGuiColors.a(ClickGuiColors.n, 200), var13);
            var2.a(var25 - 0.5F, var26 - 0.5F, var24 + 1.0F, 23.0F, 6.0F, var27, var27, var28, var28, var1);
            Color var29 = a(ClickGuiColors.a(ClickGuiColors.e, 230), var13);
            Color var30 = a(ClickGuiColors.a(ClickGuiColors.f, 230), var13);
            var2.a(var25, var26, var24, 22.0F, 6.0F, var29, var29, var30, var30, var1);
            float var31 = c(var25 + 3.5F);
            float var32 = c(var26 + 1.75F);
            this.a(var1, var2, var31, var32, var18, var13);
            float var33 = var19.b(var21) / 2.0F;
            float var34 = var20.b(var22) / 2.0F;
            float var35 = var33 + 0.5F + var34;
            float var36 = c(var31 + 14.0F + 3.5F);
            float var37 = c(var26 + (17.5F - var35) / 2.0F);
            float var38 = c(var37 + var33 + 0.5F);
            var19.a(var21, var36, var37, a(ClickGuiColors.a, var13), var1);
            var20.a(var22, var36, var38, a(ClickGuiColors.b(var18, 40), var13), var1);
            this.a(var1, var2, var25, var26, var24, var3.b(var4), var18, var13);
         }
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, Color var5, float var6) {
      Color var7 = a(ClickGuiColors.a(ClickGuiColors.b(var5, 50), 50), var6);
      Color var8 = a(ClickGuiColors.a(ClickGuiColors.b(var5, 50), 10), var6);
      var2.a(var3 - 0.5F, var4 - 0.5F, 15.0F, 15.0F, 4.5F, var7, var7, var8, var8, var1);
      Color var9 = a(var5, var6);
      Color var10 = a(ClickGuiColors.c(var5, 150), var6);
      var2.a(var3, var4, 14.0F, 14.0F, 4.5F, var9, var9, var10, var10, var1);
      FontRenderer var11 = Fonts.d[16];
      float var12 = var11.a("\ue906");
      float var13 = var11.b("\ue906") / 2.0F;
      var11.a("\ue906", c(var3 + (14.0F - var12) / 2.0F), c(var4 + (14.0F - var13) / 2.0F), a(ClickGuiColors.aa, var6), var1);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, Color var7, float var8) {
      float var9 = var5 - 6.0F;
      float var10 = c(var3 + 3.0F);
      float var11 = c(var4 + 22.0F - 1.5F - 2.5F);
      var2.a(var10, var11, var9, 1.5F, 0.75F, a(ClickGuiColors.a(ClickGuiColors.ab, 90), var8), var1);
      float var12 = var9 * var6;
      if (!(var12 < 1.5F)) {
         Color var13 = a(ClickGuiColors.b(var7, 40), var8);
         Color var14 = a(var7, var8);
         var2.a(var10, var11, var12, 1.5F, 0.75F, var13, var14, var13, var14, var1);
      }
   }

   private float a(FTHelperModule.ActiveTimer var1, long var2, double var4, double var6) {
      float var8 = 1.0F;
      long var9 = var2 - var1.j;
      if (var9 < 180L) {
         var8 = (float)var9 / 180.0F;
      }

      long var11 = var1.a(var2);
      if (var11 < 250L) {
         var8 = Math.min(var8, (float)var11 / 250.0F);
      }

      double var13 = var6 * 0.8000000000949659;
      if (var4 > var13) {
         var8 *= (float)Math.max(0.0, 1.0 - (var4 - var13) / (var6 - var13));
      }

      return MathHelper.clamp(var8, 0.0F, 1.0F);
   }

   private static Color a(Color var0, float var1) {
      return ClickGuiColors.a(var0, (int)(var0.getAlpha() * var1));
   }

   private void b(MatrixStack var1) {
      BlockPos var2 = d.player.getBlockPos();
      boolean var3 = this.k.q();
      Box var4;
      Box var5;
      if (var3) {
         var4 = new Box(var2.getX() - 3, var2.getY(), var2.getZ() - 3, var2.getX() + 4, var2.getY() + 6, var2.getZ() + 4);
         var5 = new Box(
            var2.getX() - 3 + 0.01000000327827366,
            var2.getY() + 0.01000000327827366,
            var2.getZ() - 3 + 0.01000000327827366,
            var2.getX() + 4 - 0.01000000327827366,
            var2.getY() + 6 - 0.01000000327827366,
            var2.getZ() + 4 - 0.01000000327827366
         );
      } else {
         var4 = new Box(var2.getX() - 2, var2.getY(), var2.getZ() - 2, var2.getX() + 3, var2.getY() + 4, var2.getZ() + 3);
         var5 = new Box(
            var2.getX() - 2 + 0.01000000327827366,
            var2.getY() + 0.01000000327827366,
            var2.getZ() - 2 + 0.01000000327827366,
            var2.getX() + 3 - 0.01000000327827366,
            var2.getY() + 4 - 0.01000000327827366,
            var2.getZ() + 3 - 0.01000000327827366
         );
      }

      int var6 = this.p().getRGB();
      if (this.a(var4)) {
         var6 = -16711936;
      }

      RenderUtils.a(var1, var5, var6);
   }

   private void c(MatrixStack var1) {
      BlockPos var2 = d.player.getBlockPos();
      float var3 = d.player.getYaw();
      float var4 = d.player.getPitch();
      int var5 = this.p().getRGB();
      boolean var6 = this.k.q();
      if (Math.abs(var4) > 45.0F) {
         Box var28;
         Box var29;
         if (var4 < -45.0F) {
            if (var6) {
               var28 = new Box(var2.getX() - 3, var2.getY() + 3, var2.getZ() - 3, var2.getX() + 4, var2.getY() + 7, var2.getZ() + 4);
               var29 = new Box(
                  var2.getX() - 3 + 0.01000000327827366,
                  var2.getY() + 3 + 0.01000000327827366,
                  var2.getZ() - 3 + 0.01000000327827366,
                  var2.getX() + 4 - 0.01000000327827366,
                  var2.getY() + 7 - 0.01000000327827366,
                  var2.getZ() + 4 - 0.01000000327827366
               );
            } else {
               var28 = new Box(var2.getX() - 2, var2.getY() + 3, var2.getZ() - 2, var2.getX() + 3, var2.getY() + 5, var2.getZ() + 3);
               var29 = new Box(
                  var2.getX() - 2 + 0.01000000327827366,
                  var2.getY() + 3 + 0.01000000327827366,
                  var2.getZ() - 2 + 0.01000000327827366,
                  var2.getX() + 3 - 0.01000000327827366,
                  var2.getY() + 5 - 0.01000000327827366,
                  var2.getZ() + 3 - 0.01000000327827366
               );
            }
         } else if (var6) {
            var28 = new Box(var2.getX() - 3, var2.getY() - 3, var2.getZ() - 3, var2.getX() + 4, var2.getY() - 1, var2.getZ() + 4);
            var29 = new Box(
               var2.getX() - 3 + 0.01000000327827366,
               var2.getY() - 3 + 0.01000000327827366,
               var2.getZ() - 3 + 0.01000000327827366,
               var2.getX() + 4 - 0.01000000327827366,
               var2.getY() - 1 - 0.01000000327827366,
               var2.getZ() + 4 - 0.01000000327827366
            );
         } else {
            var28 = new Box(var2.getX() - 2, var2.getY() - 3, var2.getZ() - 2, var2.getX() + 3, var2.getY() - 1, var2.getZ() + 3);
            var29 = new Box(
               var2.getX() - 2 + 0.01000000327827366,
               var2.getY() - 3 + 0.01000000327827366,
               var2.getZ() - 2 + 0.01000000327827366,
               var2.getX() + 3 - 0.01000000327827366,
               var2.getY() - 1 - 0.01000000327827366,
               var2.getZ() + 3 - 0.01000000327827366
            );
         }

         if (this.a(var28)) {
            var5 = -16711936;
         }

         RenderUtils.a(var1, var29, var5);
      } else {
         float var7 = (var3 % 360.0F + 360.0F) % 360.0F;
         byte var8 = 22;
         boolean var9 = Math.abs(var7 - 45.0F) < var8 || Math.abs(var7 - 135.0F) < var8 || Math.abs(var7 - 225.0F) < var8 || Math.abs(var7 - 315.0F) < var8;
         byte var10 = 3;
         if (var9) {
            float var13 = Math.abs(var7 - 45.0F);
            float var14 = Math.abs(var7 - 135.0F);
            float var15 = Math.abs(var7 - 225.0F);
            float var16 = Math.abs(var7 - 315.0F);
            float var17 = Math.min(Math.min(var13, var14), Math.min(var15, var16));
            short var12;
            if (var17 == var13) {
               var12 = 45;
            } else if (var17 == var14) {
               var12 = 135;
            } else if (var17 == var15) {
               var12 = 225;
            } else {
               var12 = 315;
            }

            double var18 = Math.toRadians(var12);
            byte var20;
            byte var21;
            if (var12 == 45) {
               var20 = -3;
               var21 = 2;
            } else if (var12 == 135) {
               var20 = -3;
               var21 = -2;
            } else if (var12 == 225) {
               var20 = 2;
               var21 = -2;
            } else {
               var20 = 2;
               var21 = 2;
            }

            BlockPos var11 = var2.add(var20, -1, var21);
            ArrayList var22 = new ArrayList<>();
            int var23 = var6 ? -3 : -2;
            int var24 = var6 ? 3 : 2;
            int var25 = var6 ? 7 : 5;
            if (var12 != 45 && var12 != 225) {
               for (int var34 = var23; var34 <= var24; var34++) {
                  for (int var35 = 0; var35 < var25; var35++) {
                     var22.add(var11.add(var34, var35, -var34));
                     var22.add(var11.add(var34 + 1, var35, -var34));
                  }
               }
            } else {
               for (int var26 = var23; var26 <= var24; var26++) {
                  for (int var27 = 0; var27 < var25; var27++) {
                     var22.add(var11.add(var26, var27, var26));
                     var22.add(var11.add(var26 + 1, var27, var26));
                  }
               }
            }

            if (this.a(var22)) {
               var5 = -16711936;
            }

            RenderUtils.a(var1, var22, var5);
         } else {
            BlockPos var30;
            short var31;
            if (var7 >= 315.0F || var7 < 45.0F) {
               var31 = 0;
               var30 = var2.add(0, -1, var10);
            } else if (var7 >= 45.0F && var7 < 135.0F) {
               var31 = 90;
               var30 = var2.add(-var10, -1, 0);
            } else if (var7 >= 135.0F && var7 < 225.0F) {
               var31 = 180;
               var30 = var2.add(0, -1, -var10);
            } else {
               var31 = 270;
               var30 = var2.add(var10, -1, 0);
            }

            Box var32;
            Box var33;
            if (var31 != 0 && var31 != 180) {
               if (var6) {
                  var32 = new Box(var30.getX() - 1, var30.getY(), var30.getZ() - 3, var30.getX() + 1, var30.getY() + 7, var30.getZ() + 4);
                  var33 = new Box(
                     var30.getX() - 1 + 0.01000000327827366,
                     var30.getY() + 0.01000000327827366,
                     var30.getZ() - 3 + 0.01000000327827366,
                     var30.getX() + 1 - 0.01000000327827366,
                     var30.getY() + 7 - 0.01000000327827366,
                     var30.getZ() + 4 - 0.01000000327827366
                  );
               } else {
                  var32 = new Box(var30.getX() - 1, var30.getY(), var30.getZ() - 2, var30.getX() + 1, var30.getY() + 5, var30.getZ() + 3);
                  var33 = new Box(
                     var30.getX() - 1 + 0.01000000327827366,
                     var30.getY() + 0.01000000327827366,
                     var30.getZ() - 2 + 0.01000000327827366,
                     var30.getX() + 1 - 0.01000000327827366,
                     var30.getY() + 5 - 0.01000000327827366,
                     var30.getZ() + 3 - 0.01000000327827366
                  );
               }
            } else if (var6) {
               var32 = new Box(var30.getX() - 3, var30.getY(), var30.getZ() - 1, var30.getX() + 4, var30.getY() + 7, var30.getZ() + 1);
               var33 = new Box(
                  var30.getX() - 3 + 0.01000000327827366,
                  var30.getY() + 0.01000000327827366,
                  var30.getZ() - 1 + 0.01000000327827366,
                  var30.getX() + 4 - 0.01000000327827366,
                  var30.getY() + 7 - 0.01000000327827366,
                  var30.getZ() + 1 - 0.01000000327827366
               );
            } else {
               var32 = new Box(var30.getX() - 2, var30.getY(), var30.getZ() - 1, var30.getX() + 3, var30.getY() + 5, var30.getZ() + 1);
               var33 = new Box(
                  var30.getX() - 2 + 0.01000000327827366,
                  var30.getY() + 0.01000000327827366,
                  var30.getZ() - 1 + 0.01000000327827366,
                  var30.getX() + 3 - 0.01000000327827366,
                  var30.getY() + 5 - 0.01000000327827366,
                  var30.getZ() + 1 - 0.01000000327827366
               );
            }

            if (this.a(var32)) {
               var5 = -16711936;
            }

            RenderUtils.a(var1, var33, var5);
         }
      }
   }

   private void b(MatrixStack var1, float var2) {
      Vec3d var3 = this.d(var2);
      int var4 = this.a(var3, 10.0) ? -16711936 : -1;
      RenderUtils.a(var1, var3, 10.0F, 64, var4, 0.1F);
   }

   private void c(MatrixStack var1, float var2) {
      Vec3d var3 = this.d(var2);
      int var4 = this.a(var3, 10.0) ? -16711936 : -1;
      RenderUtils.a(var1, var3, 10.0F, 64, var4, 0.1F);
   }

   private Vec3d d(float var1) {
      return new Vec3d(
         d.player.lastRenderX + (d.player.getX() - d.player.lastRenderX) * var1,
         d.player.lastRenderY + (d.player.getY() - d.player.lastRenderY) * var1,
         d.player.lastRenderZ + (d.player.getZ() - d.player.lastRenderZ) * var1
      );
   }

   private boolean a(Box var1) {
      for (Entity var3 : EntityFinder.a(var1x -> var1x instanceof PlayerEntity && var1.contains(var1x.getLerpedPos(1.0F)), EntityTags.a)) {
         if (var3 != d.player) {
            PlayerEntity var4 = (PlayerEntity)var3;
            if (!EntityUtils.a((LivingEntity)var4) && !FriendUtils.a(var4.getName().getString())) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean a(Vec3d var1, double var2) {
      double var4 = var2 * var2;

      for (Entity var7 : EntityFinder.a(var3 -> var3 instanceof PlayerEntity && var3.squaredDistanceTo(var1) <= var4, EntityTags.a)) {
         if (var7 != d.player) {
            PlayerEntity var8 = (PlayerEntity)var7;
            if (!EntityUtils.a((LivingEntity)var8) && !FriendUtils.a(var8.getName().getString())) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean a(List<BlockPos> var1) {
      for (Entity var3 : EntityFinder.a(var0 -> var0 instanceof PlayerEntity, EntityTags.a)) {
         if (var3 != d.player) {
            PlayerEntity var4 = (PlayerEntity)var3;
            if (!FriendUtils.a(var4.getName().getString())) {
               BlockPos var5 = var3.getBlockPos();

               for (BlockPos var7 : var1) {
                  if (var5.equals(var7)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   public boolean n() {
      return this.k() && this.v.q();
   }

   private Color p() {
      if (this.x.q()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         if (var1 != null) {
            return var1.n();
         }
      }

      return this.y.q();
   }

   public static FTHelperModule.ActiveTimer q() {
      boolean var0 = Math.abs(d.player.getPitch()) > 45.0F;
      return new FTHelperModule.ActiveTimer(
         FunTimeItemType.b,
         var0 ? "Горизонтальный пласт" : "Вертикальный пласт",
         var0 ? '\uea60' : 20000,
         d.player.getYaw(),
         d.player.getPitch(),
         d.player.getEntityPos()
      );
   }

   public FTHelperModule.ActiveTimer r() {
      boolean var1 = System.currentTimeMillis() - this.A < 500L;
      return new FTHelperModule.ActiveTimer(
         FunTimeItemType.a, var1 ? "Драконья трапка" : "Трапка", var1 ? 30000 : 15000, d.player.getYaw(), d.player.getPitch(), d.player.getEntityPos()
      );
   }

   static {
      NativeMethodLookup.lookup(FTHelperModule.class, 58);
   }

   @Environment(EnvType.CLIENT)
   static final class ActiveTimer {
      final FunTimeItemType a;
      final String b;
      final long c;
      final int d;
      final float e;
      final float f;
      final Vec3d g;
      final Animation h = new Animation();
      Vec3d i;
      long j;

      ActiveTimer(FunTimeItemType var1, String var2, int var3, float var4, float var5, Vec3d var6) {
         this.a = var1;
         this.b = var2;
         this.c = System.currentTimeMillis();
         this.d = var3;
         this.e = var4;
         this.f = var5;
         this.g = var6;
      }

      public boolean a() {
         return System.currentTimeMillis() - this.c >= this.d;
      }

      long a(long var1) {
         return Math.max(0L, this.d - (var1 - this.c));
      }

      double b() {
         return this.a(System.currentTimeMillis()) / 1000.0;
      }

      float b(long var1) {
         return this.d <= 0 ? 0.0F : (float)this.a(var1) / this.d;
      }
   }

   @Environment(EnvType.CLIENT)
   private final class CooldownUseTracker {
      private final Item b;
      private boolean c;
      private int d = -1;
      private int e = 1000;
      private FTHelperModule.ActiveTimer f;
      private int g;

      CooldownUseTracker(Item var2) {
         this.b = var2;
      }

      void a(Supplier<FTHelperModule.ActiveTimer> var1) {
         int var2 = 0;

         for (int var3 = 0; var3 < IMinecraft.d.player.getInventory().size(); var3++) {
            ItemStack var4 = IMinecraft.d.player.getInventory().getStack(var3);
            if (var4.getItem() == this.b) {
               var2 += var4.getCount();
            }
         }

         if (this.d != -1 && var2 == this.d - 1) {
            this.e = 0;
         } else {
            this.e = Math.min(this.e + 1, 1000);
         }

         this.d = var2;
         boolean var5 = IMinecraft.d.player.getItemCooldownManager().isCoolingDown(this.b.getDefaultStack());
         if (var5 && !this.c) {
            if (this.e <= 4) {
               FTHelperModule.this.H.add((FTHelperModule.ActiveTimer)var1.get());
               this.f = null;
               this.g = 0;
            } else {
               this.f = (FTHelperModule.ActiveTimer)var1.get();
               this.g = 4;
            }
         } else if (this.g > 0) {
            if (this.e == 0) {
               FTHelperModule.this.H.add(this.f);
               this.f = null;
               this.g = 0;
            } else if (--this.g == 0) {
               this.f = null;
            }
         }

         this.c = var5;
      }
   }
}
