package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import pulse.Pulse;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.utils.render.AlphaFramebuffer;
import pulse.utils.render.core.Renderer2D;
import pulse.utils.render.ScaleUtils;

@Environment(EnvType.CLIENT)
public final class PulseHudRenderer {
   private static int a = 0;
   private static int b = -1;
   private static int c = -1;
   private static int d = -1;

   private PulseHudRenderer() {
   }

   public static void a(DrawContext var0, float var1) {
      try {
         Pulse.l().b();
      } catch (Throwable var59) {
         var59.printStackTrace();
         return;
      }

      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2 != null && var2.getWindow() != null) {
         int var3 = var2.getWindow().getFramebufferWidth();
         int var4 = var2.getWindow().getFramebufferHeight();
         if (var3 > 0 && var4 > 0) {
            Renderer2D var5 = Pulse.l().o();
            if (var5 != null) {
               Framebuffer var6 = var2.getFramebuffer();
               int var7 = GL11.glGetInteger(36006);
               int var8 = GL11.glGetInteger(36010);
               if (var6 != null && var6.getColorAttachment() instanceof GlTexture var10) {
                  int var61 = var10.getGlId();
                  if (a == 0) {
                     a = GL30.glGenFramebuffers();
                     b = -1;
                  }

                  if (var61 == b && var3 == c && var4 == d) {
                     GL30.glBindFramebuffer(36160, a);
                  } else {
                     GL30.glBindFramebuffer(36160, a);
                     GL30.glFramebufferTexture2D(36160, 36064, 3553, var61, 0);
                     GL11.glDrawBuffer(36064);
                     int var12 = GL30.glCheckFramebufferStatus(36160);
                     if (var12 != 36053) {
                        b = -1;
                        GL30.glBindFramebuffer(36160, var7);
                     } else {
                        b = var61;
                        c = var3;
                        d = var4;
                     }
                  }
               }

               GL11.glColorMask(true, true, true, true);
               GL11.glDisable(2929);
               GL11.glEnable(3042);

               try {
                  var5.a(var3, var4);

                  try {
                     var5.b(2.0F, 2.0F);

                     try {
                        int var60 = (int)(var2.mouse.getX() * var2.getWindow().getScaledWidth() / var2.getWindow().getWidth());
                        int var62 = (int)(var2.mouse.getY() * var2.getWindow().getScaledHeight() / var2.getWindow().getHeight());
                        MatrixStack var63 = new MatrixStack();
                        HudRenderContext.a(var0);
                        AlphaFramebuffer.a(var0);

                        try {
                           ScaleUtils.a(2.0);

                           try {
                              EventHandler.a.post(new RenderHudPostEvent(var63, var60, var62, var1));
                           } finally {
                              ScaleUtils.a();
                           }

                           DraggableManager.a().a(var63);
                           DraggableManager.a().b(var63);
                        } finally {
                           HudRenderContext.b();
                        }
                     } finally {
                        var5.h();
                     }
                  } finally {
                     var5.c();
                  }
               } catch (Throwable var57) {
                  var57.printStackTrace();
               } finally {
                  GL30.glBindFramebuffer(36009, var7);
                  GL30.glBindFramebuffer(36008, var8);
                  GL30.glBindFramebuffer(36160, var7);
               }
            }
         }
      }
   }
}
