package pulse.features.modules.visuals.animations;

import java.util.IdentityHashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.ChatHudLine.Visible;

@Environment(EnvType.CLIENT)
public final class ChatAnimationHolder {
   public static volatile float a = 0.0F;
   private static final Map<Visible, ChatMessageAnimator> b = new IdentityHashMap<>();

   public static void a(Visible var0, ChatMessageAnimator var1) {
      b.put(var0, var1);
   }

   public static ChatMessageAnimator a(Visible var0) {
      return b.get(var0);
   }

   public static boolean b(Visible var0) {
      return b.containsKey(var0);
   }

   public static void a() {
      b.values().forEach(ChatMessageAnimator::a);
      b.entrySet().removeIf(var0 -> var0.getValue().d());
   }

   public static void b() {
      b.clear();
   }

   private ChatAnimationHolder() {
   }
}
