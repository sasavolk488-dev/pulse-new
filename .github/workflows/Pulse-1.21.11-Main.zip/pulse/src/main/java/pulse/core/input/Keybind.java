package pulse.core.input;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleRegistry;

@Environment(EnvType.CLIENT)
public class Keybind {
   private final int a;
   private final KeybindActionType b;
   private final String c;

   public Keybind(int var1, KeybindActionType var2, String var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public static Keybind a(int var0, String var1) {
      return new Keybind(var0, KeybindActionType.a, var1);
   }

   public static Keybind b(int var0, String var1) {
      return new Keybind(var0, KeybindActionType.b, var1);
   }

   public int a() {
      return this.a;
   }

   public KeybindActionType b() {
      return this.b;
   }

   public String c() {
      return this.c;
   }

   public boolean d() {
      return this.b == KeybindActionType.b;
   }

   public boolean e() {
      return this.b == KeybindActionType.a;
   }

   public String f() {
      return KeyNames.a(this.a);
   }

   public Module g() {
      return !this.e() ? null : ModuleRegistry.a(this.c);
   }

   public String h() {
      return this.d() ? "/" + this.c : this.c;
   }

   public String i() {
      if (this.d()) {
         return "Команда";
      } else {
         Module var1 = this.g();
         return var1 != null ? var1.i().a() : "";
      }
   }
}
