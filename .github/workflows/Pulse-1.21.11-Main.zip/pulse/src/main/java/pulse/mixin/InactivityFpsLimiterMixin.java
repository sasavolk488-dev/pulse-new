package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.InactivityFpsLimiter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;

@Environment(EnvType.CLIENT)
@Mixin({InactivityFpsLimiter.class})
public class InactivityFpsLimiterMixin {
   @Inject(
      method = {"update"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void pulse$dynamicFps(CallbackInfoReturnable<Integer> var1) {
      var1.setReturnValue(ModuleRegistry.W.b(var1.getReturnValueI()));
   }
}
