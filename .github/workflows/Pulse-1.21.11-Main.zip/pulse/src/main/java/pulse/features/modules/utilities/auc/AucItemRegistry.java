package pulse.features.modules.utilities.auc;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;
import net.minecraft.util.Uuids;

@Environment(EnvType.CLIENT)
public final class AucItemRegistry {
   private static List<AucItem> a;

   private AucItemRegistry() {
   }

   public static List<AucItem> a() {
      if (a == null) {
         ArrayList var0 = new ArrayList();
         var0.addAll(b());
         var0.addAll(c());
         var0.addAll(d());
         var0.addAll(e());
         var0.addAll(f());
         var0.addAll(g());
         a = var0;
      }

      return a;
   }

   private static List<AucItem> b() {
      ArrayList var0 = new ArrayList();
      var0.add(new KrushItem("Шлем Крушителя", Items.NETHERITE_HELMET, KrushItems.a(), 0));
      var0.add(new KrushItem("Нагрудник Крушителя", Items.NETHERITE_CHESTPLATE, KrushItems.b(), 0));
      var0.add(new KrushItem("Поножи Крушителя", Items.NETHERITE_LEGGINGS, KrushItems.c(), 0));
      var0.add(new KrushItem("Ботинки Крушителя", Items.NETHERITE_BOOTS, KrushItems.d(), 0));
      var0.add(new KrushItem("Меч Крушителя", Items.NETHERITE_SWORD, KrushItems.e(), 0));
      var0.add(new KrushItem("Кирка Крушителя", Items.NETHERITE_PICKAXE, KrushItems.f(), 0));
      var0.add(new KrushItem("Арбалет Крушителя", Items.CROSSBOW, KrushItems.g(), 0));
      var0.add(new KrushItem("Трезубец Крушителя", Items.TRIDENT, KrushItems.h(), 0));
      var0.add(new KrushItem("Булава Крушителя", Items.MACE, KrushItems.i(), 0));
      return var0;
   }

   private static List<AucItem> c() {
      ArrayList var0 = new ArrayList();
      var0.add(
         new CustomItem(
            "[★] Талисман Раздора",
            a(
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 4.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", 0.10000000753886126, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.10000000753886126, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor", -3.0, 0, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "[★] Талисман Карателя",
            a(
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 7.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", -4.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", 0.10000000753886126, 1, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "Талисман Крушителя",
            a(
               new AucItemRegistry.Attr("minecraft:generic.max_health", 4.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 3.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor_toughness", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor", 2.0, 0, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "[★] Талисман Тирана",
            a(
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", -4.0, 0, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "[★] Талисман Ярости",
            a(
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 5.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", -4.0, 0, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "[★] Талисман Демона",
            a(
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 2.5, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.10000000753886126, 1, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "[★] Талисман Вихря",
            a(
               new AucItemRegistry.Attr("minecraft:generic.max_health", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", 0.15000007171185695, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.15000007171185695, 1, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      var0.add(
         new CustomItem(
            "[★] Талисман Мрака",
            a(
               new AucItemRegistry.Attr("minecraft:generic.armor", 1.5, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", 1.5, 0, "offhand")
            ),
            Items.TOTEM_OF_UNDYING,
            0
         )
      );
      return var0;
   }

   private static List<AucItem> d() {
      ArrayList var0 = new ArrayList();
      var0.add(
         new CustomItem(
            "[★] Сфера Хаоса",
            a(
               "e7a7ae7cdcf616e8b7a4221a621b2435753c60ed6a258ea060dae3002ffe9e28",
               new AucItemRegistry.Attr("minecraft:generic.max_health", -4.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 3.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", 0.07000000069995677, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.13000000001183076, 1, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Сатира",
            a(
               "771a9a498b4fa5ec49362f9bc88eda4f52b04de49d75aa3ca332a1fea1aa0e57",
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.15000007171185695, 1, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Бестии",
            a(
               "5411ac17381b9fce9bab3c72afdb7f198570daf4732bd811d31c227d80fa39b1",
               new AucItemRegistry.Attr("minecraft:generic.armor", 1.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", 4.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", 0.10000000753886126, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.10000000753886126, 1, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Ареса",
            a(
               "c16adc6bafcb57fd707dee7dd6a736fe126711d53a1fd6ce789da41b3be13f2a",
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 6.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor", -2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", -2.0, 0, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Гидры",
            a(
               "3e3c118d696d910e54de02ca4d807543f9b18c008c9838d2ff69377622fb1d32",
               new AucItemRegistry.Attr("minecraft:generic.max_health", 4.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor", 2.0, 0, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Икара",
            a(
               "c6803e6d5667a2d610628bc3b32f863cda495c465616de655cb329933b61af77",
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 2.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", 2.0, 0, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Эрида",
            a(
               "6e4e2f1047f3ec6e9e459184739e33b7c1fc63ad8202bdab9f024508add23e5b",
               new AucItemRegistry.Attr("minecraft:generic.luck", 1.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", 2.0, 0, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Афины",
            a(
               "93f9eeda3ba23fe1423c4036e7dd0a74461dff96badc5b2f2b9faa7cc16f382f",
               new AucItemRegistry.Attr("minecraft:generic.attack_speed", 0.15000007171185695, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", 0.15000007171185695, 1, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.attack_damage", 3.0, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.max_health", -2.0, 0, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Сфера Титана",
            a(
               "titan",
               new AucItemRegistry.Attr("minecraft:generic.armor", 2.5, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.armor_toughness", 2.5, 0, "offhand"),
               new AucItemRegistry.Attr("minecraft:generic.movement_speed", -0.15000007177376987, 1, "offhand")
            ),
            Items.PLAYER_HEAD,
            0,
            null,
            null
         )
      );
      return var0;
   }

   private static List<AucItem> e() {
      ArrayList var0 = new ArrayList();
      var0.add(a("Золотое яблоко", Items.GOLDEN_APPLE));
      var0.add(a("Зачарованное золотое яблоко", Items.ENCHANTED_GOLDEN_APPLE));
      var0.add(a("Порох", Items.GUNPOWDER));
      var0.add(a("Бирка", Items.NAME_TAG));
      var0.add(a("Трезубец", Items.TRIDENT));
      var0.add(a("Незеритовый слиток", Items.NETHERITE_INGOT));
      var0.add(a("Алмаз", Items.DIAMOND));
      var0.add(a("Алмазный блок", Items.DIAMOND_BLOCK));
      var0.add(a("Золотой слиток", Items.GOLD_INGOT));
      var0.add(a("Блок золота", Items.GOLD_BLOCK));
      var0.add(a("Маяк", Items.BEACON));
      var0.add(a("Пузырёк опыта", Items.EXPERIENCE_BOTTLE));
      var0.add(a("Звезда Незера", Items.NETHER_STAR));
      var0.add(a("Шалкеровый ящик", Items.SHULKER_BOX));
      var0.add(a("Железный слиток", Items.IRON_INGOT));
      var0.add(a("Железный блок", Items.IRON_BLOCK));
      var0.add(a("Незеритовый блок", Items.NETHERITE_BLOCK));
      var0.add(a("Спавнер", Items.SPAWNER));
      var0.add(a("Элитры", Items.ELYTRA));
      var0.add(a("Эндер жемчуг", Items.ENDER_PEARL));
      var0.add(a("Обсидиан", Items.OBSIDIAN));
      var0.add(a("Тотем бессмертия", Items.TOTEM_OF_UNDYING));
      var0.add(a("Палка ифрита", Items.BLAZE_ROD));
      var0.add(a("Динамит", Items.TNT));
      var0.add(a("Яйцо зомби-жителя", Items.ZOMBIE_VILLAGER_SPAWN_EGG));
      var0.add(a("Голова дракона", Items.DRAGON_HEAD));
      var0.add(a("Алмазная руда", Items.DIAMOND_ORE));
      var0.add(a("Изумрудная руда", Items.EMERALD_ORE));
      var0.add(a("Яблоко", Items.APPLE));
      var0.add(a("Торт", Items.CAKE));
      var0.add(a("Фейерверк", Items.FIREWORK_ROCKET));
      var0.add(a("Яйцо жителя", Items.VILLAGER_SPAWN_EGG));
      var0.add(a("Яйцо вихря", Items.PHANTOM_SPAWN_EGG));
      var0.add(a("Мешок", Items.BUNDLE));
      var0.add(a("Булава", Items.MACE));
      return var0;
   }

   private static List<AucItem> f() {
      ArrayList var0 = new ArrayList();
      var0.add(
         a(
            "[★] Явная пыль",
            Items.SUGAR,
            List.of(
               Text.literal("Каст: Световая вспышка"),
               Text.literal("Радиус: 10 блоков"),
               Text.literal("Эффекты для противников:"),
               Text.literal(" • Свечение (00:30)"),
               Text.literal(" • Слепота (00:01)"),
               Text.literal("Чем ближе цель, тем дольше длительность эффектов")
            )
         )
      );
      var0.add(a("[★] Дезориентация", Items.ENDER_EYE, List.of(Text.literal("Чем ближе цель, тем дольше длительность эффектов"))));
      var0.add(
         a(
            "[★] Трапка",
            Items.NETHERITE_SCRAP,
            List.of(Text.literal("Каст: Нерушимая клетка"), Text.literal("Длительность: 15 секунд"), Text.literal("Используйте скины: /tskins"))
         )
      );
      var0.add(
         a("Отмычка к Сферам", Items.TRIPWIRE_HOOK, List.of(Text.literal("Этой отмычкой можно"), Text.literal("Открыть хранилище"), Text.literal("С Сферами")))
      );
      var0.add(
         a(
            "[★] Пласт",
            Items.DRIED_KELP,
            List.of(
               Text.literal("Каст: Нерушимая стена"),
               Text.literal("Длительность:"),
               Text.literal("Вертикальный: 20 секунд"),
               Text.literal("Горизонтальный: 60 секунд")
            )
         )
      );
      var0.add(a("Пузырек опыта [15 ур]", Items.EXPERIENCE_BOTTLE, List.of(Text.literal("Содержит 15 ур опыта"))));
      var0.add(a("Пузырёк опыта [30 Ур.]", Items.EXPERIENCE_BOTTLE, List.of(Text.literal("Содержит: 30 Ур. опыта"))));
      var0.add(a("Пузырек опыта [50 ур]", Items.EXPERIENCE_BOTTLE, List.of(Text.literal("Содержит 50 ур опыта"))));
      var0.add(a("[★] TNT - TIER WHITE", "Таер вайт", Items.TNT, List.of(Text.literal("Этот динамит взрывается"), Text.literal("в 10 раз сильнее обычного"))));
      var0.add(
         a(
            "[★] TNT - TIER BLACK",
            "Таер блэк",
            Items.TNT,
            List.of(Text.literal("Этот динамит взрывается"), Text.literal("в 10 раз сильнее обычного"), Text.literal("и способен взорвать обсидиан"))
         )
      );
      var0.add(a("Сигнальный огонь [Случайный]", Items.CAMPFIRE, List.of(Text.literal("Уровень лута: Случайный"))));
      var0.add(a("Сигнальный огонь [Обычный]", Items.CAMPFIRE, List.of(Text.literal("Уровень лута: Обычный"))));
      var0.add(a("Сигнальный огонь [Богатый]", Items.CAMPFIRE, List.of(Text.literal("Уровень лута: Богатый"))));
      var0.add(a("Сигнальный огонь [Легендарный]", Items.CAMPFIRE, List.of(Text.literal("Уровень лута: Легендарный"))));
      var0.add(a("[★] Блок дамагер", Items.JIGSAW, List.of(Text.literal("● Каст: Нанесение урона"), Text.literal("● Радиус: 1,5 блока"))));
      var0.add(
         a(
            "Прогрузчик чанков [1x1]",
            "Блок чанкер",
            Items.STRUCTURE_BLOCK,
            List.of(
               Text.literal("Прогружает чанк, в котором"),
               Text.literal("находится этот прогрузчик."),
               Text.literal("Нажмите на него, чтобы на"),
               Text.literal("30 секунд увидеть границы")
            )
         )
      );
      var0.add(
         a(
            "Прогрузчик чанков [3x3]",
            "Блок чанкер",
            Items.STRUCTURE_BLOCK,
            List.of(
               Text.literal("Прогружает чанк, в котором"),
               Text.literal("находится этот прогрузчик."),
               Text.literal("Нажмите на него, чтобы на"),
               Text.literal("30 секунд увидеть границы")
            )
         )
      );
      var0.add(
         a(
            "Прогрузчик чанков [5x5]",
            "Блок чанкер",
            Items.STRUCTURE_BLOCK,
            List.of(
               Text.literal("Прогружает чанк, в котором"),
               Text.literal("находится этот прогрузчик."),
               Text.literal("Нажмите на него, чтобы на"),
               Text.literal("30 секунд увидеть границы")
            )
         )
      );
      var0.add(
         a(
            "Загадочный маяк",
            Items.BEACON,
            List.of(Text.literal("Маяк установит временный"), Text.literal("ивент, раздающий Монеты"), Text.literal("игрокам поблизости."))
         )
      );
      var0.add(
         a(
            "[★] Проклятая душа",
            Items.SOUL_LANTERN,
            List.of(Text.literal("Обменяй души на ценные"), Text.literal("ресурсы у Собирателя душ"), Text.literal("/warp soulcollector"))
         )
      );
      var0.add(
         a(
            "[★] Драконий скин",
            Items.PAPER,
            List.of(
               Text.literal("Используя этот предмет"),
               Text.literal("Вы его расходуете"),
               Text.literal("и получаете Драконий скин взамен"),
               Text.literal("[ПКМ] чтобы использовать x1 скин"),
               Text.literal("[SHIFT+ПКМ] чтобы использовать все скины"),
               Text.literal("Предмет нужно держать в руке")
            )
         )
      );
      var0.add(
         a(
            "[★] Огненный смерч",
            Items.FIRE_CHARGE,
            List.of(
               Text.literal("● Каст: Огненная волна"),
               Text.literal("● Радиус: 10 блоков"),
               Text.literal(""),
               Text.literal("● Эффекты для противников:"),
               Text.literal(" - Поджог (00:03)"),
               Text.literal(""),
               Text.literal("Чем ближе цель, тем дольше"),
               Text.literal("длительность эффектов")
            )
         )
      );
      var0.add(
         a(
            "[★] Снежок заморозка",
            Items.SNOWBALL,
            List.of(
               Text.literal("● Каст: Ледяная сфера"),
               Text.literal("● Радиус: 7 блоков"),
               Text.literal(""),
               Text.literal("● Эффекты для противников:"),
               Text.literal(" - Заморозка (00:01)"),
               Text.literal(" - Слабость (03:00)")
            )
         )
      );
      var0.add(
         a(
            "[★] Божья аура",
            Items.PHANTOM_MEMBRANE,
            List.of(
               Text.literal("● Каст: Божественная аура"),
               Text.literal("● Радиус: 2 блока"),
               Text.literal(""),
               Text.literal("● Эффекты для союзников:"),
               Text.literal(" - Снятие всех эффектов"),
               Text.literal(" - Невидимость (04:00)"),
               Text.literal(" - Сила II (03:00)"),
               Text.literal(" - Скорость II (03:00)")
            )
         )
      );
      var0.add(
         a(
            "[★] Серебро",
            Items.IRON_NUGGET,
            List.of(Text.literal("Это валюта для покупки"), Text.literal("отмычек к тайникам"), Text.literal("у Знахаря (/warp stash)"))
         )
      );
      var0.add(
         a(
            "[★] Божье касание",
            Items.GOLDEN_PICKAXE,
            List.of(Text.literal("Божье касание"), Text.literal(""), Text.literal("Может добыть спавнер,"), Text.literal("но только один раз"))
         )
      );
      var0.add(a("[★] Кирка мега-бульдозер", Items.NETHERITE_PICKAXE, List.of(Text.literal("Вскапывает территорию"), Text.literal("размером 9x9x5 блоков"))));
      return var0;
   }

   private static List<AucItem> g() {
      ArrayList var0 = new ArrayList();
      var0.add(
         new CustomItem(
            "[★] Святая вода",
            null,
            Items.SPLASH_POTION,
            0,
            a(
               16777215,
               List.of(
                  new StatusEffectInstance(StatusEffects.REGENERATION, 1200, 2),
                  new StatusEffectInstance(StatusEffects.INVISIBILITY, 12000, 1),
                  new StatusEffectInstance(StatusEffects.INSTANT_HEALTH, 1, 1)
               )
            ),
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Зелье Гнева",
            null,
            Items.SPLASH_POTION,
            0,
            a(10040115, List.of(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 4), new StatusEffectInstance(StatusEffects.SLOWNESS, 600, 3))),
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Зелье Палладина",
            null,
            Items.SPLASH_POTION,
            0,
            a(
               65535,
               List.of(
                  new StatusEffectInstance(StatusEffects.RESISTANCE, 12000, 0),
                  new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 12000, 0),
                  new StatusEffectInstance(StatusEffects.HEALTH_BOOST, 1200, 2),
                  new StatusEffectInstance(StatusEffects.INVISIBILITY, 18000, 2)
               )
            ),
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Зелье Ассасина",
            null,
            Items.SPLASH_POTION,
            0,
            a(
               3355443,
               List.of(
                  new StatusEffectInstance(StatusEffects.STRENGTH, 1200, 3),
                  new StatusEffectInstance(StatusEffects.SPEED, 6000, 2),
                  new StatusEffectInstance(StatusEffects.HASTE, 1200, 0),
                  new StatusEffectInstance(StatusEffects.INSTANT_DAMAGE, 1, 1)
               )
            ),
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Зелье Радиации",
            null,
            Items.SPLASH_POTION,
            0,
            a(
               4737096,
               List.of(
                  new StatusEffectInstance(StatusEffects.WEAKNESS, 1800, 1),
                  new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 1),
                  new StatusEffectInstance(StatusEffects.WITHER, 1800, 2),
                  new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0)
               )
            ),
            null
         )
      );
      var0.add(
         new CustomItem(
            "[★] Снотворное",
            null,
            Items.SPLASH_POTION,
            0,
            a(
               3329330,
               List.of(
                  new StatusEffectInstance(StatusEffects.POISON, 400, 1),
                  new StatusEffectInstance(StatusEffects.WITHER, 400, 1),
                  new StatusEffectInstance(StatusEffects.SLOWNESS, 400, 2),
                  new StatusEffectInstance(StatusEffects.HUNGER, 400, 4),
                  new StatusEffectInstance(StatusEffects.GLOWING, 400, 0)
               )
            ),
            null
         )
      );
      return var0;
   }

   private static AucItem a(String var0, Item var1) {
      return new KrushItem(var0, var1, new ItemStack(var1), 0);
   }

   private static AucItem a(String var0, Item var1, List<Text> var2) {
      return new CustomItem(var0, null, var1, 0, null, var2);
   }

   private static AucItem a(String var0, String var1, Item var2, List<Text> var3) {
      return new CustomItem(var0, var1, null, var2, 0, null, var3);
   }

   private static PotionContentsComponent a(int var0, List<StatusEffectInstance> var1) {
      return new PotionContentsComponent(Optional.empty(), Optional.of(var0), var1, Optional.empty());
   }

   private static NbtCompound a(AucItemRegistry.Attr... var0) {
      NbtCompound var1 = new NbtCompound();
      var1.put("AttributeModifiers", b(var0));
      return var1;
   }

   private static NbtCompound a(String var0, AucItemRegistry.Attr... var1) {
      NbtCompound var2 = new NbtCompound();
      var2.putInt("HideFlags", 1);
      NbtCompound var3 = new NbtCompound();
      var3.putIntArray("Id", Uuids.toIntArray(UUID.nameUUIDFromBytes(var0.getBytes())));
      NbtCompound var4 = new NbtCompound();
      NbtList var5 = new NbtList();
      NbtCompound var6 = new NbtCompound();
      var6.putString("Value", var0);
      var5.add(var6);
      var4.put("textures", var5);
      var3.put("Properties", var4);
      var2.put("SkullOwner", var3);
      var2.put("AttributeModifiers", b(var1));
      return var2;
   }

   private static NbtList b(AucItemRegistry.Attr... var0) {
      NbtList var1 = new NbtList();

      for (AucItemRegistry.Attr var5 : var0) {
         NbtCompound var6 = new NbtCompound();
         var6.putString("AttributeName", var5.a);
         var6.putDouble("Amount", var5.b);
         var6.putInt("Operation", var5.c);
         var6.putString("Slot", var5.d);
         var6.putString("Name", UUID.randomUUID().toString());
         var6.putIntArray(
            "UUID",
            new int[]{
               (int)(Math.random() * 2.147482625E9),
               (int)(Math.random() * 2.147482625E9),
               (int)(Math.random() * 2.147482625E9),
               (int)(Math.random() * 2.147482625E9)
            }
         );
         var1.add(var6);
      }

      return var1;
   }

   @Environment(EnvType.CLIENT)
   private static final class Attr {
      final String a;
      final double b;
      final int c;
      final String d;

      Attr(String var1, double var2, int var4, String var5) {
         this.a = var1;
         this.b = var2;
         this.c = var4;
         this.d = var5;
      }
   }
}
