package pulse.features.emote.bobj;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class BobjLoader {
   private BobjLoader() {
   }

   public static BobjModel a(InputStream var0) throws IOException {
      ArrayList var1 = new ArrayList<>();
      ArrayList var2 = new ArrayList<>();
      ArrayList var3 = new ArrayList<>();
      ArrayList var4 = new ArrayList<>();
      ArrayList<BobjLoader.FaceVertex> var5 = new ArrayList<>();
      BobjLoader.SourceVertex var6 = null;

      String var8;
      try (BufferedReader var7 = b(var0)) {
         while ((var8 = var7.readLine()) != null) {
            String var9 = var8.trim();
            if (!var9.isEmpty() && !var9.startsWith("#")) {
               String[] var10 = var9.split("\\s+");
               String var11 = var10[0];
               switch (var11) {
                  case "arm_bone":
                     var1.add(a(var10));
                     break;
                  case "v":
                     var6 = new BobjLoader.SourceVertex(Float.parseFloat(var10[1]), Float.parseFloat(var10[2]), Float.parseFloat(var10[3]));
                     var2.add(var6);
                     break;
                  case "vw":
                     if (var6 != null) {
                        float var35 = Float.parseFloat(var10[2]);
                        if (var35 > 0.0F) {
                           var6.d.add(new BobjLoader.NamedWeight(var10[1], var35));
                        }
                     }
                     break;
                  case "vt":
                     var3.add(new float[]{Float.parseFloat(var10[1]), 1.0F - Float.parseFloat(var10[2])});
                     break;
                  case "vn":
                     var4.add(new float[]{Float.parseFloat(var10[1]), Float.parseFloat(var10[2]), Float.parseFloat(var10[3])});
                     break;
                  case "f":
                     BobjLoader.FaceVertex var13 = a(var10[1]);

                     for (int var14 = 2; var14 < var10.length - 1; var14++) {
                        var5.add(var13);
                        var5.add(a(var10[var14]));
                        var5.add(a(var10[var14 + 1]));
                     }
               }
            }
         }
      }

      LinkedHashMap<String, Integer> var24 = new LinkedHashMap<>();

      for (int var25 = 0; var25 < var1.size(); var25++) {
         var24.put(((BobjLoader.RawBone)var1.get(var25)).name, var25);
      }

      ArrayList var26 = new ArrayList<>(var1.size());

      for (int var27 = 0; var27 < var1.size(); var27++) {
         BobjLoader.RawBone var29 = (BobjLoader.RawBone)var1.get(var27);
         int var31 = var29.parent == null ? -1 : var24.getOrDefault(var29.parent, -1);
         float[] var33 = var31 < 0 ? (float[])var29.rest.clone() : BobjMath.a(BobjMath.a(((BobjLoader.RawBone)var1.get(var31)).rest), var29.rest);
         var26.add(new BobjModel.Bone(var27, var29.name, var31, var29.rest, var33));
      }

      ArrayList var28 = new ArrayList<>(var5.size());

      for (BobjLoader.FaceVertex var32 : var5) {
         BobjLoader.SourceVertex var34 = (BobjLoader.SourceVertex)var2.get(var32.position);
         float[] var36 = var32.uv >= 0 ? (float[])var3.get(var32.uv) : new float[]{0.0F, 0.0F};
         float[] var37 = var32.normal >= 0 ? (float[])var4.get(var32.normal) : new float[]{0.0F, 1.0F, 0.0F};
         int[] var15 = new int[]{-1, -1, -1, -1};
         float[] var16 = new float[]{0.0F, 0.0F, 0.0F, 0.0F};
         var34.d.sort(Comparator.comparingDouble(BobjLoader.NamedWeight::weight).reversed());
         float var17 = 0.0F;
         int var18 = 0;

         for (BobjLoader.NamedWeight var20 : var34.d) {
            Integer var21 = (Integer)var24.get(var20.name);
            if (var21 != null && var18 < 4) {
               var15[var18] = var21;
               var16[var18] = var20.weight;
               var17 += var20.weight;
               var18++;
            }
         }

         if (var17 > 0.0F) {
            for (int var38 = 0; var38 < var18; var38++) {
               var16[var38] /= var17;
            }
         }

         var28.add(new BobjModel.Vertex(var34.a, var34.b, var34.c, var36[0], var36[1], var37[0], var37[1], var37[2], var15, var16));
      }

      return new BobjModel(var26, var28);
   }

   public static List<BobjModel.Vertex> a(String var0, BobjModel var1) {
      ArrayList var2 = new ArrayList<>();
      ArrayList var3 = new ArrayList<>();
      ArrayList var4 = new ArrayList<>();
      ArrayList<BobjLoader.FaceVertex> var5 = new ArrayList<>();
      BobjLoader.SourceVertex var6 = null;

      for (String var10 : var0.split("\\r?\\n")) {
         String var11 = var10.trim();
         if (!var11.isEmpty() && !var11.startsWith("#")) {
            String[] var12 = var11.split("\\s+");
            String var13 = var12[0];
            switch (var13) {
               case "v":
                  var6 = new BobjLoader.SourceVertex(Float.parseFloat(var12[1]), Float.parseFloat(var12[2]), Float.parseFloat(var12[3]));
                  var2.add(var6);
                  break;
               case "vw":
                  if (var6 != null) {
                     float var24 = Float.parseFloat(var12[2]);
                     if (var24 > 0.0F) {
                        var6.d.add(new BobjLoader.NamedWeight(var12[1], var24));
                     }
                  }
                  break;
               case "vt":
                  var3.add(new float[]{Float.parseFloat(var12[1]), 1.0F - Float.parseFloat(var12[2])});
                  break;
               case "vn":
                  var4.add(new float[]{Float.parseFloat(var12[1]), Float.parseFloat(var12[2]), Float.parseFloat(var12[3])});
                  break;
               case "f":
                  BobjLoader.FaceVertex var15 = a(var12[1]);

                  for (int var16 = 2; var16 < var12.length - 1; var16++) {
                     var5.add(var15);
                     var5.add(a(var12[var16]));
                     var5.add(a(var12[var16 + 1]));
                  }
            }
         }
      }

      ArrayList<BobjModel.Vertex> var17 = new ArrayList<>(var5.size());

      for (BobjLoader.FaceVertex var19 : var5) {
         BobjLoader.SourceVertex var20 = (BobjLoader.SourceVertex)var2.get(var19.position);
         float[] var21 = var19.uv >= 0 ? (float[])var3.get(var19.uv) : new float[]{0.0F, 0.0F};
         float[] var22 = var19.normal >= 0 ? (float[])var4.get(var19.normal) : new float[]{0.0F, 1.0F, 0.0F};
         int var23 = -1;
         if (!var20.d.isEmpty()) {
            var23 = var1.a(var20.d.get(0).name);
         }

         var17.add(
            new BobjModel.Vertex(
               var20.a, var20.b, var20.c, var21[0], var21[1], var22[0], var22[1], var22[2], new int[]{var23, -1, -1, -1}, new float[]{1.0F, 0.0F, 0.0F, 0.0F}
            )
         );
      }

      return var17;
   }

   public static BobjAction a(InputStream var0, String var1) throws IOException {
      BobjAction var2 = null;
      BobjAction.Channel var3 = null;
      List var4 = null;

      String var6;
      try (BufferedReader var5 = b(var0)) {
         while ((var6 = var5.readLine()) != null) {
            String var7 = var6.trim();
            if (!var7.isEmpty() && !var7.startsWith("#")) {
               String[] var8 = var7.split("\\s+");
               String var9 = var8[0];
               switch (var9) {
                  case "an":
                     if (var2 != null) {
                        return var2;
                     }

                     if (var8[1].equals(var1)) {
                        var2 = new BobjAction(var8[1]);
                     }

                     var4 = null;
                     var3 = null;
                     break;
                  case "ao":
                     if (var2 != null) {
                        var4 = var2.a(var8[1]);
                     }

                     var3 = null;
                     break;
                  case "ag":
                     if (var2 != null && var4 != null) {
                        var3 = new BobjAction.Channel(var8[1], Integer.parseInt(var8[2]));
                        var4.add(var3);
                     }
                     break;
                  case "kf":
                     if (var2 != null && var3 != null) {
                        BobjAction.Keyframe var11 = new BobjAction.Keyframe(var8);
                        var3.c.add(var11);
                        var2.a(var11.a);
                     }
               }
            }
         }
      }

      if (var2 == null) {
         throw new IOException("BOBJ action not found: " + var1);
      } else {
         return var2;
      }
   }

   private static BufferedReader b(InputStream var0) {
      if (var0 == null) {
         throw new IllegalArgumentException("BOBJ input stream is null");
      } else {
         return new BufferedReader(new InputStreamReader(var0, StandardCharsets.UTF_8));
      }
   }

   private static BobjLoader.RawBone a(String[] var0) {
      boolean var1 = !b(var0[2]);
      String var2 = var1 ? var0[2] : null;
      int var3 = var1 ? 3 : 2;
      float[] var4 = new float[19];

      for (int var5 = 0; var5 < var4.length; var5++) {
         var4[var5] = Float.parseFloat(var0[var3 + var5]);
      }

      float[] var6 = new float[16];
      System.arraycopy(var4, 3, var6, 0, 16);
      return new BobjLoader.RawBone(var0[1], var2, var6);
   }

   private static BobjLoader.FaceVertex a(String var0) {
      String[] var1 = var0.split("/", -1);
      int var2 = a(var1, 0);
      int var3 = a(var1, 1);
      int var4 = a(var1, 2);
      return new BobjLoader.FaceVertex(var2, var3, var4);
   }

   private static int a(String[] var0, int var1) {
      return var1 < var0.length && !var0[var1].isEmpty() ? Integer.parseInt(var0[var1]) - 1 : -1;
   }

   private static boolean b(String var0) {
      try {
         Float.parseFloat(var0);
         return true;
      } catch (NumberFormatException var2) {
         return false;
      }
   }

   @Environment(EnvType.CLIENT)
   private record FaceVertex(int position, int uv, int normal) {
   }

   @Environment(EnvType.CLIENT)
   private record NamedWeight(String name, float weight) {
   }

   @Environment(EnvType.CLIENT)
   private record RawBone(String name, String parent, float[] rest) {
   }

   @Environment(EnvType.CLIENT)
   private static final class SourceVertex {
      final float a;
      final float b;
      final float c;
      final List<BobjLoader.NamedWeight> d = new ArrayList<>();

      SourceVertex(float var1, float var2, float var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
