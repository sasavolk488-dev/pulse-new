package pulse.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.json.JSONArray;
import org.json.JSONObject;

@Environment(EnvType.CLIENT)
public class ConfigSerializer {
   private static final int a = 2;

   private ConfigSerializer() {
   }

   public static String a(ConfigData var0) {
      JSONObject var1 = new JSONObject();
      var1.put("version", var0.a());
      var1.put("metadata", a(var0.b()));
      var1.put("modules", a(var0.c()));
      var1.put("friends", a(var0.d()));
      var1.put("markers", b(var0.e()));
      var1.put("markerSettings", a(var0.f()));
      var1.put("hudPositions", c(var0.g()));
      var1.put("categoriesPosition", var0.h());
      var1.put("watermarkSettings", a(var0.i()));
      var1.put("clientColor", a(var0.j()));
      var1.put("keybindCommands", d(var0.k()));
      return var1.toString(2);
   }

   private static JSONObject a(ConfigMetadata var0) {
      JSONObject var1 = new JSONObject();
      if (var0 == null) {
         return var1;
      } else {
         var1.put("name", var0.i());
         var1.put("author", var0.c());
         var1.put("authorId", var0.d());
         var1.put("signature", var0.e());
         var1.put("createdAt", var0.f());
         var1.put("description", var0.j());
         var1.put("updatedAt", var0.k());
         return var1;
      }
   }

   private static JSONObject a(Map<String, ConfigData.ModuleData> var0) {
      JSONObject var1 = new JSONObject();

      for (Entry var3 : var0.entrySet()) {
         var1.put((String)var3.getKey(), a((ConfigData.ModuleData)var3.getValue()));
      }

      return var1;
   }

   private static JSONObject a(ConfigData.ModuleData var0) {
      JSONObject var1 = new JSONObject();
      var1.put("enabled", var0.a());
      var1.put("key", var0.b());
      var1.put("settings", b(var0.c()));
      return var1;
   }

   private static JSONObject b(Map<String, ConfigData.SettingData> var0) {
      JSONObject var1 = new JSONObject();

      for (Entry var3 : var0.entrySet()) {
         var1.put((String)var3.getKey(), a((ConfigData.SettingData)var3.getValue()));
      }

      return var1;
   }

   private static JSONObject a(ConfigData.SettingData var0) {
      JSONObject var1 = new JSONObject();
      var1.put("type", var0.a());
      String var2 = var0.a();
      switch (var2) {
         case "boolean":
         case "number":
         case "key":
         case "input":
         case "folder":
            var1.put("value", var0.b());
            break;
         case "color":
            var1.put("hue", var0.c());
            var1.put("saturation", var0.d());
            var1.put("brightness", var0.e());
            break;
         case "mode":
            var1.put("value", var0.b());
            if (var0.f() != null && var0.f().length > 0) {
               var1.put("selectedIndices", new JSONArray(var0.f()));
            }
            break;
         case "itemColor":
            var1.put("enabled", var0.g());
            var1.put("colorRgb", var0.h());
      }

      return var1;
   }

   private static JSONArray a(List<ConfigData.FriendData> var0) {
      JSONArray var1 = new JSONArray();

      for (ConfigData.FriendData var3 : var0) {
         JSONObject var4 = new JSONObject();
         var4.put("name", var3.a());
         var4.put("addedDate", var3.b());
         var1.put(var4);
      }

      return var1;
   }

   private static JSONArray b(List<ConfigData.MarkerData> var0) {
      JSONArray var1 = new JSONArray();

      for (ConfigData.MarkerData var3 : var0) {
         JSONObject var4 = new JSONObject();
         var4.put("name", var3.a());
         var4.put("x", var3.b());
         var4.put("y", var3.c());
         var4.put("z", var3.d());
         var4.put("colorRgb", var3.e());
         var4.put("iconType", var3.f());
         var4.put("autoCreated", var3.g());
         var4.put("creationTime", var3.h());
         var4.put("serverNumber", var3.i());
         var4.put("expirationTime", var3.j());
         var1.put(var4);
      }

      return var1;
   }

   private static JSONObject a(ConfigData.MarkerSettingsData var0) {
      JSONObject var1 = new JSONObject();
      var1.put("quickMarkerEnabled", var0.a());
      var1.put("quickMarkerKey", var0.b());
      var1.put("deathMarkerEnabled", var0.c());
      var1.put("autoMarkersEnabled", var0.d());
      var1.put("mysteriousBeaconEnabled", var0.e());
      var1.put("playerPingEnabled", var0.f());
      var1.put("playerPingKey", var0.g());
      var1.put("pingSoundEnabled", var0.h());
      var1.put("pingOffscreenArrowEnabled", var0.i());
      var1.put("partyHealthEnabled", var0.j());
      var1.put("partyInventoryEnabled", var0.k());
      var1.put("partyShareInventory", var0.l());
      return var1;
   }

   private static JSONObject c(Map<String, ConfigData.HudPositionData> var0) {
      JSONObject var1 = new JSONObject();

      for (Entry var3 : var0.entrySet()) {
         JSONObject var4 = new JSONObject();
         var4.put("percentX", ((ConfigData.HudPositionData)var3.getValue()).a());
         var4.put("percentY", ((ConfigData.HudPositionData)var3.getValue()).b());
         var4.put("scale", ((ConfigData.HudPositionData)var3.getValue()).c());
         var4.put("atDefault", ((ConfigData.HudPositionData)var3.getValue()).d());
         var1.put((String)var3.getKey(), var4);
      }

      return var1;
   }

   private static JSONObject a(ConfigData.WatermarkSettingsData var0) {
      JSONObject var1 = new JSONObject();
      var1.put("notificationsEnabled", var0.a());
      var1.put("musicEnabled", var0.b());
      var1.put("fpsAndPingEnabled", var0.c());
      var1.put("eventsEnabled", var0.d());
      var1.put("modulesEnabled", var0.e());
      return var1;
   }

   private static JSONObject a(ConfigData.ClientColorData var0) {
      JSONObject var1 = new JSONObject();
      if (var0 == null) {
         return var1;
      } else {
         var1.put("mode", var0.a());
         var1.put("staticHue", var0.b());
         var1.put("staticSaturation", var0.c());
         var1.put("staticBrightness", var0.d());
         var1.put("gradient1Hue", var0.e());
         var1.put("gradient1Saturation", var0.f());
         var1.put("gradient1Brightness", var0.g());
         var1.put("gradient2Hue", var0.h());
         var1.put("gradient2Saturation", var0.i());
         var1.put("gradient2Brightness", var0.j());
         return var1;
      }
   }

   public static ConfigData a(String var0) {
      JSONObject var1 = new JSONObject(var0);
      ConfigData var2 = new ConfigData();
      var2.a(var1.optInt("version", 1));
      var2.a(b(var1.optJSONObject("metadata")));
      var2.a(c(var1.optJSONObject("modules")));
      var2.a(a(var1.optJSONArray("friends")));
      var2.b(b(var1.optJSONArray("markers")));
      var2.a(g(var1.optJSONObject("markerSettings")));
      var2.b(h(var1.optJSONObject("hudPositions")));
      var2.a(var1.optString("categoriesPosition", "BOTTOM"));
      var2.a(i(var1.optJSONObject("watermarkSettings")));
      var2.a(j(var1.optJSONObject("clientColor")));
      var2.c(a(var1.optJSONObject("keybindCommands")));
      return var2;
   }

   private static JSONObject d(Map<String, String> var0) {
      JSONObject var1 = new JSONObject();
      if (var0 == null) {
         return var1;
      } else {
         for (Entry var3 : var0.entrySet()) {
            var1.put((String)var3.getKey(), var3.getValue());
         }

         return var1;
      }
   }

   private static Map<String, String> a(JSONObject var0) {
      HashMap var1 = new HashMap();
      if (var0 == null) {
         return var1;
      } else {
         for (String var3 : var0.keySet()) {
            String var4 = var0.optString(var3, "");
            if (!var4.isEmpty()) {
               var1.put(var3, var4);
            }
         }

         return var1;
      }
   }

   private static ConfigMetadata b(JSONObject var0) {
      return var0 == null
         ? ConfigMetadata.a("Unnamed")
         : ConfigMetadata.a(
            var0.optString("name", "Unnamed"),
            var0.optString("author", "Unknown"),
            var0.optInt("authorId", 0),
            var0.optString("signature", ""),
            var0.optLong("createdAt", System.currentTimeMillis()),
            var0.optString("description", ""),
            var0.optLong("updatedAt", System.currentTimeMillis())
         );
   }

   private static Map<String, ConfigData.ModuleData> c(JSONObject var0) {
      HashMap var1 = new HashMap();
      if (var0 == null) {
         return var1;
      } else {
         for (String var3 : var0.keySet()) {
            JSONObject var4 = var0.optJSONObject(var3);
            if (var4 != null) {
               var1.put(var3, d(var4));
            }
         }

         return var1;
      }
   }

   private static ConfigData.ModuleData d(JSONObject var0) {
      ConfigData.ModuleData var1 = new ConfigData.ModuleData();
      var1.a(var0.optBoolean("enabled", false));
      var1.a(var0.optInt("key", 0));
      var1.a(e(var0.optJSONObject("settings")));
      return var1;
   }

   private static Map<String, ConfigData.SettingData> e(JSONObject var0) {
      HashMap var1 = new HashMap();
      if (var0 == null) {
         return var1;
      } else {
         for (String var3 : var0.keySet()) {
            JSONObject var4 = var0.optJSONObject(var3);
            if (var4 != null) {
               var1.put(var3, f(var4));
            }
         }

         return var1;
      }
   }

   private static ConfigData.SettingData f(JSONObject var0) {
      ConfigData.SettingData var1 = new ConfigData.SettingData();
      String var2 = var0.optString("type", "unknown");
      var1.a(var2);
      switch (var2) {
         case "boolean":
            var1.a(var0.optBoolean("value", false));
            break;
         case "number":
            var1.a((float)var0.optDouble("value", 0.0));
            break;
         case "key":
            var1.a(var0.optInt("value", -1));
            break;
         case "input":
         case "folder":
            var1.a(var0.optString("value", ""));
            break;
         case "color":
            var1.a((float)var0.optDouble("hue", 0.0));
            var1.b((float)var0.optDouble("saturation", 1.0));
            var1.c((float)var0.optDouble("brightness", 1.0));
            break;
         case "mode":
            var1.a(var0.optInt("value", 0));
            JSONArray var5 = var0.optJSONArray("selectedIndices");
            if (var5 != null) {
               int[] var6 = new int[var5.length()];

               for (int var7 = 0; var7 < var5.length(); var7++) {
                  var6[var7] = var5.optInt(var7, 0);
               }

               var1.a(var6);
            }
            break;
         case "itemColor":
            var1.a(var0.optBoolean("enabled", false));
            var1.a(var0.optInt("colorRgb", -1));
      }

      return var1;
   }

   private static List<ConfigData.FriendData> a(JSONArray var0) {
      ArrayList var1 = new ArrayList();
      if (var0 == null) {
         return var1;
      } else {
         for (int var2 = 0; var2 < var0.length(); var2++) {
            JSONObject var3 = var0.optJSONObject(var2);
            if (var3 != null) {
               ConfigData.FriendData var4 = new ConfigData.FriendData();
               var4.a(var3.optString("name", ""));
               var4.b(var3.optString("addedDate", ""));
               var1.add(var4);
            }
         }

         return var1;
      }
   }

   private static List<ConfigData.MarkerData> b(JSONArray var0) {
      ArrayList var1 = new ArrayList();
      if (var0 == null) {
         return var1;
      } else {
         for (int var2 = 0; var2 < var0.length(); var2++) {
            JSONObject var3 = var0.optJSONObject(var2);
            if (var3 != null) {
               ConfigData.MarkerData var4 = new ConfigData.MarkerData();
               var4.a(var3.optString("name", ""));
               var4.a(var3.optInt("x", 0));
               var4.b(var3.optInt("y", 0));
               var4.c(var3.optInt("z", 0));
               var4.d(var3.optInt("colorRgb", -1));
               var4.b(var3.optString("iconType", "HOME"));
               var4.a(var3.optBoolean("autoCreated", false));
               var4.a(var3.optLong("creationTime", 0L));
               var4.e(var3.optInt("serverNumber", -1));
               var4.b(var3.optLong("expirationTime", 0L));
               var1.add(var4);
            }
         }

         return var1;
      }
   }

   private static ConfigData.MarkerSettingsData g(JSONObject var0) {
      ConfigData.MarkerSettingsData var1 = new ConfigData.MarkerSettingsData();
      if (var0 == null) {
         return var1;
      } else {
         var1.a(var0.optBoolean("quickMarkerEnabled", true));
         var1.a(var0.optInt("quickMarkerKey", 0));
         var1.b(var0.optBoolean("deathMarkerEnabled", false));
         var1.c(var0.optBoolean("autoMarkersEnabled", true));
         var1.d(var0.optBoolean("mysteriousBeaconEnabled", false));
         var1.e(var0.optBoolean("playerPingEnabled", true));
         var1.b(var0.optInt("playerPingKey", 1452));
         var1.f(var0.optBoolean("pingSoundEnabled", true));
         var1.g(var0.optBoolean("pingOffscreenArrowEnabled", true));
         var1.h(var0.optBoolean("partyHealthEnabled", true));
         var1.i(var0.optBoolean("partyInventoryEnabled", true));
         var1.j(var0.optBoolean("partyShareInventory", true));
         return var1;
      }
   }

   private static Map<String, ConfigData.HudPositionData> h(JSONObject var0) {
      HashMap var1 = new HashMap();
      if (var0 == null) {
         return var1;
      } else {
         for (String var3 : var0.keySet()) {
            JSONObject var4 = var0.optJSONObject(var3);
            if (var4 != null) {
               ConfigData.HudPositionData var5 = new ConfigData.HudPositionData();
               var5.a((float)var4.optDouble("percentX", 0.0));
               var5.b((float)var4.optDouble("percentY", 0.0));
               var5.c((float)var4.optDouble("scale", 1.0));
               var5.a(var4.optBoolean("atDefault", true));
               var1.put(var3, var5);
            }
         }

         return var1;
      }
   }

   private static ConfigData.WatermarkSettingsData i(JSONObject var0) {
      ConfigData.WatermarkSettingsData var1 = new ConfigData.WatermarkSettingsData();
      if (var0 == null) {
         return var1;
      } else {
         var1.a(var0.optBoolean("notificationsEnabled", true));
         var1.b(var0.optBoolean("musicEnabled", true));
         var1.c(var0.optBoolean("fpsAndPingEnabled", true));
         var1.d(var0.optBoolean("eventsEnabled", true));
         var1.e(var0.optBoolean("modulesEnabled", true));
         return var1;
      }
   }

   private static ConfigData.ClientColorData j(JSONObject var0) {
      ConfigData.ClientColorData var1 = new ConfigData.ClientColorData();
      if (var0 == null) {
         return var1;
      } else {
         var1.a(var0.optString("mode", "Статичный"));
         var1.a((float)var0.optDouble("staticHue", 0.75));
         var1.b((float)var0.optDouble("staticSaturation", 0.8100001239824359));
         var1.c((float)var0.optDouble("staticBrightness", 0.8900002396145686));
         var1.d((float)var0.optDouble("gradient1Hue", 0.0));
         var1.e((float)var0.optDouble("gradient1Saturation", 0.0));
         var1.f((float)var0.optDouble("gradient1Brightness", 1.0));
         var1.g((float)var0.optDouble("gradient2Hue", 0.5800000941073783));
         var1.h((float)var0.optDouble("gradient2Saturation", 0.5100000000222933));
         var1.i((float)var0.optDouble("gradient2Brightness", 0.960000022397332));
         return var1;
      }
   }
}
