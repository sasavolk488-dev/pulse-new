package pulse.features.modules.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.IdentityHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.features.modules.hud.components.BossBarComponent;
import pulse.features.modules.hud.components.CooldownsComponent;
import pulse.features.modules.hud.components.HotKeysComponent;
import pulse.features.modules.hud.components.InventoryComponent;
import pulse.features.modules.hud.components.PotionsComponent;
import pulse.features.modules.hud.components.ScoreboardComponent;
import pulse.features.modules.hud.components.TargetHudComponent;
import pulse.features.modules.hud.components.WatermarkComponent;
import pulse.features.modules.hud.snap.PositionState;
import pulse.features.modules.hud.snap.SnapEngine;
import pulse.features.modules.hud.snap.SnapLine;
import pulse.features.modules.hud.snap.SnapResult;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.core.Renderer2D;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.ScaleUtils;

@Environment(EnvType.CLIENT)
public class DraggableManager {
   private static final DraggableManager a = new DraggableManager();
   private final MinecraftClient b = MinecraftClient.getInstance();
   private final List<DraggableComponent> c = new ArrayList<>();
   private WatermarkComponent d;
   private PotionsComponent e;
   private HotKeysComponent f;
   private CooldownsComponent g;
   private TargetHudComponent h;
   private InventoryComponent i;
   private ScoreboardComponent j;
   private BossBarComponent k;
   private boolean l = false;
   private DraggableComponent m = null;
   private int n = 0;
   private final IdentityHashMap<Object, Animation> o = new IdentityHashMap<>();
   private static final double p = 0.20000000606295493;
   private List<SnapLine> q = new ArrayList<>();
   private static final Color r = new Color(100, 180, 255, 180);
   private static final Color s = new Color(200, 100, 255, 180);
   private static final Color t = new Color(255, 150, 80, 180);
   private final Deque<PositionState> u = new LinkedList<>();
   private final Deque<PositionState> v = new LinkedList<>();
   private static final int w = 50;
   private float x = -1.0F;
   private float y = -1.0F;
   private boolean z = false;

   private DraggableManager() {
   }

   public static DraggableManager a() {
      return a;
   }

   public void b() {
      this.c.clear();
      this.n = 0;
      this.u.clear();
      this.v.clear();
      this.d = new WatermarkComponent();
      this.e = new PotionsComponent(0.0F, 0.0F);
      this.f = new HotKeysComponent(0.0F, 0.0F);
      this.g = new CooldownsComponent(0.0F, 0.0F);
      this.h = new TargetHudComponent(0.0F, 0.0F);
      this.i = new InventoryComponent(0.0F, 0.0F);
      this.j = new ScoreboardComponent(0.0F, 0.0F);
      this.k = new BossBarComponent(0.0F, 0.0F);
      this.c(this.e);
      this.c(this.f);
      this.c(this.g);
      this.c(this.h);
      this.c(this.i);
      this.c(this.j);
      this.c(this.k);
   }

   public void c() {
      float var1 = (float)(this.b.getWindow().getFramebufferWidth() / 2.0);
      float var2 = (float)(this.b.getWindow().getFramebufferHeight() / 2.0);
      float var3 = 10.0F;
      float var4 = 8.0F;
      this.e.b_();
      this.f.b_();
      this.g.b_();
      this.h.b_();
      this.e.a(var3);
      this.e.b(var3);
      this.f.a(var3);
      this.f.b(var3 + this.e.p() + var4);
      this.g.a(var3);
      this.g.b(var3 + this.e.p() + var4 + this.f.p() + var4);
      this.h.a(var1 - this.h.o() - var3);
      this.h.b(var2 / 2.0F - this.h.p() / 2.0F);
      this.j.b_();
      this.k.b_();
   }

   private void c(DraggableComponent var1) {
      var1.a(this.n++);
      this.c.add(var1);
   }

   private void d(DraggableComponent var1) {
      var1.a(this.n++);
      this.u();
   }

   private void u() {
      this.c.sort(Comparator.comparingInt(DraggableComponent::q));
   }

   private List<DraggableComponent> v() {
      var var1 = new ArrayList<>(this.c);
      var1.sort((var0, var1x) -> Integer.compare(var1x.q(), var0.q()));
      return var1;
   }

   private float a(Object var1, boolean var2) {
      Animation var3 = this.o.get(var1);
      if (var3 == null) {
         var3 = new Animation();
         var3.d(var2 ? 1.0 : 0.0);
         this.o.put(var1, var3);
      }

      double var4 = var2 ? 1.0 : 0.0;
      if (Math.abs(var3.i() - var4) > 9.999994270847362E-4) {
         var3.a(var4, 0.20000000606295493, Easings.h);
      }

      var3.a();
      return (float)var3.j();
   }

   private boolean e(DraggableComponent var1) {
      if (var1 == this.e) {
         return ModuleRegistry.at.k();
      } else if (var1 == this.f) {
         return ModuleRegistry.ay.k();
      } else if (var1 == this.g) {
         return ModuleRegistry.aC.k();
      } else {
         return var1 == this.h ? ModuleRegistry.au.k() : var1.c();
      }
   }

   private List<DraggableComponent> w() {
      return this.c.stream().filter(this::e).collect(Collectors.toList());
   }

   public void a(MatrixStack var1) {
      if (this.b.world != null && this.b.player != null) {
         Render var2 = Pulse.l().p();
         if (var2 != null) {
            ScaleUtils.a(2.0);
            float var3 = (float)(this.b.getWindow().getFramebufferWidth() / 2.0);
            float var4 = (float)(this.b.getWindow().getFramebufferHeight() / 2.0);
            if (this.x > 0.0F && this.y > 0.0F && (Math.abs(var3 - this.x) > 1.0F || Math.abs(var4 - this.y) > 1.0F)) {
               this.a(var3, var4);
            }

            this.x = var3;
            this.y = var4;
            Renderer2D var5 = Pulse.l().o();
            if (this.d != null) {
               float var6 = this.a(this.d, ModuleRegistry.az.k());
               if (var6 > 0.001F) {
                  if (var5 != null) {
                     var5.d(var6);
                  }

                  try {
                     this.d.a(var1, var2);
                  } finally {
                     if (var5 != null) {
                        var5.i();
                     }
                  }
               }
            }

            for (DraggableComponent var7 : this.c) {
               float var8 = this.a(var7, this.e(var7));
               if (!(var8 < 0.001F)) {
                  var7.e();
                  if (var5 != null) {
                     var5.d(var8);
                  }

                  try {
                     var7.a(var1, var2, var3, var4);
                     var7.a(var2, var1);
                  } finally {
                     if (var5 != null) {
                        var5.i();
                     }
                  }
               }
            }

            if (this.m != null && !this.q.isEmpty()) {
               this.a(var1, var2);
            }

            if (this.m != null && !this.z) {
               this.a(var1, var2, var3, var4);
            }

            int var19 = (int)(this.b.mouse.getX() * this.b.getWindow().getScaleFactor() / 2.0 / this.b.getWindow().getScaleFactor());
            int var20 = (int)(this.b.mouse.getY() * this.b.getWindow().getScaleFactor() / 2.0 / this.b.getWindow().getScaleFactor());
            int var21 = (int)(var19 * this.b.getWindow().getScaleFactor() / 2.0);
            int var9 = (int)(var20 * this.b.getWindow().getScaleFactor() / 2.0);

            for (DraggableComponent var11 : this.c) {
               if (this.e(var11)) {
                  var11.a(var1, var2, var21, var9);
               }
            }

            ScaleUtils.a();
         }
      }
   }

   private void a(MatrixStack var1, Render var2) {
      for (SnapLine var4 : this.q) {
         Color var5 = switch (var4.b()) {
            case b -> s;
            case c, d -> t;
            default -> r;
         };
         if (var4.a() == SnapLine.Type.b) {
            var2.a(var4.c() - 0.5F, var4.d(), 1.0F, var4.e() - var4.d(), 0.0F, var5, var1);
         } else {
            var2.a(var4.d(), var4.c() - 0.5F, var4.e() - var4.d(), 1.0F, 0.0F, var5, var1);
         }
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4) {
      FontRenderer var5 = Fonts.a[24];
      String var6 = "Удерживайте ALT для свободного перемещения";
      float var7 = var5.a(var6);
      float var8 = var3 / 2.0F - var7 / 2.0F;
      float var9 = var4 - 65.0F;
      Color var10 = new Color(255, 255, 255, 200);
      var5.a(var6, var8, var9, var10, var1);
   }

   private void a(float var1, float var2) {
      for (DraggableComponent var4 : this.c) {
         var4.a(var1, var2);
      }
   }

   public void d() {
      float var1 = (float)(this.b.getWindow().getFramebufferWidth() / 2.0);
      float var2 = (float)(this.b.getWindow().getFramebufferHeight() / 2.0);

      for (DraggableComponent var4 : this.c) {
         var4.b(var1, var2);
      }

      this.x = var1;
      this.y = var2;
   }

   private void f(DraggableComponent var1) {
      this.u.push(new PositionState(var1));
      if (this.u.size() > 50) {
         this.u.removeLast();
      }

      this.v.clear();
   }

   public void e() {
      if (!this.u.isEmpty()) {
         PositionState var1 = this.u.pop();
         this.v.push(new PositionState(var1.b()));
         var1.a();
      }
   }

   public void f() {
      if (!this.v.isEmpty()) {
         PositionState var1 = this.v.pop();
         this.u.push(new PositionState(var1.b()));
         var1.a();
      }
   }

   public boolean a(int var1, int var2) {
      boolean var3 = (var2 & 2) != 0;
      if (var3 && var1 == 90) {
         this.e();
         return true;
      } else if (var3 && var1 == 89) {
         this.f();
         return true;
      } else {
         return false;
      }
   }

   public void g() {
      long var1 = this.b.getWindow().getHandle();
      this.z = GLFW.glfwGetKey(var1, 342) == 1 || GLFW.glfwGetKey(var1, 346) == 1;
   }

   public WatermarkComponent h() {
      return this.d;
   }

   public PotionsComponent i() {
      return this.e;
   }

   public HotKeysComponent j() {
      return this.f;
   }

   public CooldownsComponent k() {
      return this.g;
   }

   public TargetHudComponent l() {
      return this.h;
   }

   public InventoryComponent m() {
      return this.i;
   }

   public ScoreboardComponent n() {
      return this.j;
   }

   public BossBarComponent o() {
      return this.k;
   }

   public void b(MatrixStack var1) {
   }

   public void a(double var1, double var3) {
      if (this.l) {
         this.g();
         if (!this.b.isWindowFocused()) {
            for (DraggableComponent var6 : this.c) {
               if (this.e(var6)) {
                  var6.a(0.0, 0.0, false);
               }
            }
         } else {
            double var5 = var1 * this.b.getWindow().getScaleFactor() / 2.0;
            double var7 = var3 * this.b.getWindow().getScaleFactor() / 2.0;
            if (this.m != null) {
               for (DraggableComponent var18 : this.c) {
                  if (this.e(var18)) {
                     boolean var22 = var18 == this.m;
                     var18.a(var5, var7, var22);
                  }
               }

               MouseUtil.g();
            } else {
               boolean var9 = false;

               for (DraggableComponent var11 : this.c) {
                  if (this.e(var11) && var11.f().c() && var11.f().c((int)var5, (int)var7)) {
                     var9 = true;
                     break;
                  }
               }

               if (var9) {
                  for (DraggableComponent var21 : this.c) {
                     if (this.e(var21)) {
                        var21.a(var5, var7, false);
                     }
                  }
               } else {
                  DraggableComponent var16 = null;

                  for (DraggableComponent var12 : this.v()) {
                     if (this.e(var12) && var12.a(var5, var7)) {
                        var16 = var12;
                        break;
                     }
                  }

                  for (DraggableComponent var23 : this.c) {
                     if (this.e(var23)) {
                        boolean var13 = var23 == var16;
                        var23.a(var5, var7, var13);
                     }
                  }

                  if (var16 != null) {
                     MouseUtil.g();
                  }
               }
            }
         }
      }
   }

   public boolean a(double var1, double var3, int var5) {
      double var6 = var1 * this.b.getWindow().getScaleFactor() / 2.0;
      double var8 = var3 * this.b.getWindow().getScaleFactor() / 2.0;

      for (DraggableComponent var11 : this.v()) {
         if (this.e(var11) && var11.f().c() && var11.f().a((int)var6, (int)var8)) {
            return true;
         }
      }

      DraggableComponent var14 = null;

      for (DraggableComponent var12 : this.v()) {
         if (this.e(var12) && var12.a(var6, var8)) {
            var14 = var12;
            break;
         }
      }

      for (DraggableComponent var18 : this.c) {
         if (this.e(var18) && var18.f().c() && var18.f().c((int)var6, (int)var8)) {
            return true;
         }
      }

      boolean var17 = false;

      for (DraggableComponent var13 : this.c) {
         if (this.e(var13) && var13.f().c()) {
            var13.f().a();
            var17 = true;
         }
      }

      if (var14 == null && this.d != null && ModuleRegistry.az.k() && this.d.a(var6, var8, var5)) {
         return true;
      } else {
         if (var14 != null) {
            if (var5 == 2) {
               return var14.a(var6, var8, var5);
            }

            if (var5 == 1) {
               if (this.m != null) {
                  return true;
               }

               var14.f().a(var14.m(), var14.n(), var14.o(), var14.p());
               return true;
            }

            if (var5 == 0) {
               for (DraggableComponent var21 : this.c) {
                  if (this.e(var21) && var21.f().c()) {
                     var21.f().b();
                  }
               }

               this.f(var14);
               var14.a(var6, var8, var5);
               if (var14.j()) {
                  this.m = var14;
                  this.d(var14);
                  return true;
               }
            }
         }

         return var17;
      }
   }

   public boolean b(double var1, double var3, int var5) {
      double var6 = var1 * this.b.getWindow().getScaleFactor() / 2.0;
      double var8 = var3 * this.b.getWindow().getScaleFactor() / 2.0;

      for (DraggableComponent var11 : this.c) {
         if (this.e(var11)) {
            var11.f().b((int)var6, (int)var8);
         }
      }

      if (this.d != null && ModuleRegistry.az.k()) {
         this.d.b(var6, var8, var5);
      }

      if (this.m == null) {
         return false;
      } else {
         this.m.b(var6, var8, var5);
         this.m = null;
         this.q.clear();
         DraggableComponent var14 = null;

         for (DraggableComponent var12 : this.v()) {
            if (this.e(var12) && var12.a(var6, var8)) {
               var14 = var12;
               break;
            }
         }

         for (DraggableComponent var17 : this.c) {
            if (this.e(var17)) {
               boolean var13 = var17 == var14;
               var17.a(var6, var8, var13);
            }
         }

         return true;
      }
   }

   public boolean a(double var1, double var3, double var5) {
      double var7 = var1 * this.b.getWindow().getScaleFactor() / 2.0;
      double var9 = var3 * this.b.getWindow().getScaleFactor() / 2.0;
      if (this.m == null) {
         for (DraggableComponent var12 : this.c) {
            if (this.e(var12) && var12.f().e() && var12.a(var7, var9, var5)) {
               return true;
            }
         }
      }

      return this.d != null && ModuleRegistry.az.k() && this.d.a(var7, var9, var5);
   }

   public void a(double var1, double var3, double var5, double var7) {
      double var9 = var1 * this.b.getWindow().getScaleFactor() / 2.0;
      double var11 = var3 * this.b.getWindow().getScaleFactor() / 2.0;
      if (this.m == null) {
         for (DraggableComponent var14 : this.c) {
            if (this.e(var14) && var14.f().e()) {
               var14.a(var9, var11, var5, var7);
            }
         }
      }

      if (this.d != null && ModuleRegistry.az.k()) {
         this.d.a(var9, var11, var5, var7);
      }

      if (this.m != null) {
         this.g();
         float var18 = (float)(this.b.getWindow().getFramebufferWidth() / 2.0);
         float var19 = (float)(this.b.getWindow().getFramebufferHeight() / 2.0);
         float var15 = (float)var9 - this.m.s();
         float var16 = (float)var11 - this.m.t();
         SnapResult var17 = SnapEngine.a(this.m, var15, var16, var18, var19, this.w(), this.z);
         this.m.a(var17, var18, var19);
         this.q = var17.c();
      }
   }

   public boolean b(double var1, double var3) {
      if (this.m == null) {
         return false;
      } else {
         double var5 = var1 * this.b.getWindow().getScaleFactor() / 2.0;
         double var7 = var3 * this.b.getWindow().getScaleFactor() / 2.0;
         float var9 = (float)(this.b.getWindow().getFramebufferWidth() / 2.0);
         float var10 = (float)(this.b.getWindow().getFramebufferHeight() / 2.0);
         this.g();
         float var11 = (float)var5 - this.m.s();
         float var12 = (float)var7 - this.m.t();
         SnapResult var13 = SnapEngine.a(this.m, var11, var12, var9, var10, this.w(), this.z);
         this.m.a(var13, var9, var10);
         this.q = var13.c();
         return true;
      }
   }

   public boolean p() {
      return this.l;
   }

   public void a(boolean var1) {
      boolean var2 = this.l;
      this.l = var1;
      if (var2 && !var1) {
         this.m = null;
         this.q.clear();

         for (DraggableComponent var4 : this.c) {
            var4.d();
         }
      }
   }

   public void q() {
      this.a(!this.l);
   }

   public List<DraggableComponent> r() {
      return this.c;
   }

   public void a(DraggableComponent var1) {
      this.c(var1);
   }

   public void b(DraggableComponent var1) {
      this.c.remove(var1);
   }

   public boolean s() {
      return this.m != null;
   }

   public boolean t() {
      return this.z;
   }
}
