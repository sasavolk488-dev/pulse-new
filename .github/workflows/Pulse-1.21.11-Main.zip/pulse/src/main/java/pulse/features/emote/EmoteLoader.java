package pulse.features.emote;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.features.emote.bobj.BobjAction;
import pulse.features.emote.bobj.BobjLoader;

@Environment(EnvType.CLIENT)
public final class EmoteLoader {
   private static final String a = "/assets/pulse/emotes/bobj/";

   private EmoteLoader() {
   }

   public static void a() {
      EmoteManager var0 = EmoteManager.a();
      var0.d();

      try (
         InputStream var1 = b("default.bobj");
         InputStream var2 = b("slim.bobj");
      ) {
         var0.a(BobjLoader.a(var1), BobjLoader.a(var2));
      } catch (Throwable var21) {
         var0.d();
         Pulse.m().error("[Emote] failed to load BOBJ player models", var21);
         return;
      }

      int var22 = 0;
      ArrayList var23 = new ArrayList();

      try (InputStream var3 = b("index.json")) {
         JSONArray var4 = new JSONArray(new String(var3.readAllBytes(), StandardCharsets.UTF_8));

         for (int var5 = 0; var5 < var4.length(); var5++) {
            JSONObject var6 = var4.getJSONObject(var5);
            String var7 = var6.getString("name");

            try (InputStream var8 = b("actions/" + var6.getString("file"))) {
               BobjAction var9 = BobjLoader.a(var8, var6.getString("action"));
               int var10 = var6.optInt("duration", 0);
               if (var10 <= 0) {
                  var10 = Math.max(1, Math.round(var9.b()));
               }

               var0.a(var7, var9, var10, var6.optBoolean("looping", false));
               var0.a(var7, a(var7));
               var23.add(var7);
               var22++;
            } catch (Throwable var18) {
               Pulse.m().warn("[Emote] skip '{}': {}", var7, var18.toString());
            }
         }
      } catch (Throwable var20) {
         Pulse.m().error("[Emote] failed to read local emote index", var20);
      }

      var0.a(var23);
      Pulse.m().info("[Emote] loaded {} local BOBJ emote(s)", var22);
   }

   private static String a(String var0) {
      StringBuilder var1 = new StringBuilder(var0.length());

      for (String var5 : var0.split("_")) {
         if (!var5.isEmpty()) {
            if (var1.length() > 0) {
               var1.append(' ');
            }

            var1.append(Character.toUpperCase(var5.charAt(0))).append(var5.substring(1));
         }
      }

      return var1.length() > 0 ? var1.toString() : var0;
   }

   private static InputStream b(String var0) {
      InputStream var1 = EmoteLoader.class.getResourceAsStream("/assets/pulse/emotes/bobj/" + var0);
      if (var1 == null) {
         throw new IllegalStateException("Missing local BOBJ resource: " + var0);
      } else {
         return var1;
      }
   }
}
