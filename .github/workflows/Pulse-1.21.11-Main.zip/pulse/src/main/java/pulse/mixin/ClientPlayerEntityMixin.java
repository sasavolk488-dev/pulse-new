package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.ClientPlayerTickEvent;
import pulse.core.event.impl.DropItemEvent;
import pulse.core.event.impl.UpdateEvent;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayerEntity.class})
public class ClientPlayerEntityMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onTick(CallbackInfo var1) {
      EventHandler.a.post(new UpdateEvent());
   }

   @Inject(
      method = {"dropSelectedItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onDropSelectedItem(boolean var1, CallbackInfoReturnable<Boolean> var2) {
      ClientPlayerEntity var3 = (ClientPlayerEntity)(Object)this;
      DropItemEvent var4 = new DropItemEvent(var3.getInventory().getSelectedSlot(), var1);
      EventHandler.a.post(var4);
      if (var4.c()) {
         var2.setReturnValue(false);
      }
   }

   @Inject(
      method = {"tick"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V",
         shift = Shift.BEFORE
      )}
   )
   private void onPlayerTickPre(CallbackInfo var1) {
      EventHandler.a.post(new ClientPlayerTickEvent(ClientPlayerTickEvent.State.a));
   }

   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void onPlayerTickPost(CallbackInfo var1) {
      EventHandler.a.post(new ClientPlayerTickEvent(ClientPlayerTickEvent.State.b));
   }
}
