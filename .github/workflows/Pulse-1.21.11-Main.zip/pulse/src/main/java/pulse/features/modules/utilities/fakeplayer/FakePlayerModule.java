package pulse.features.modules.utilities.fakeplayer;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.game.ChatUtils;
import pulse.utils.game.PVPUtils;

@ModuleInfo(
   a = "Fake Player",
   b = "Спавнит фейк-игрока для тестирования",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FakePlayerModule extends Module {
   private final FakePlayerSpawner a = new FakePlayerSpawner();
   private final FakePlayerAttackHandler b = new FakePlayerAttackHandler(this.a);

   @Override
   public void b(boolean var1) {
      if (var1 && PVPUtils.a().a()) {
         ChatUtils.a("Fake Player нельзя включить в КТ/PVP");
      } else {
         super.b(var1);
      }
   }

   @Compile
   @Override
   public void e() {
      super.e();
      this.a.a();
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.a.b();
   }

   @EventHandler
   @Compile
   private void a(AttackEvent var1) {
      this.b.a(var1);
   }

   @EventHandler
   @Compile
   private void a(WorldChangeEvent var1) {
      this.d();
   }

   public boolean a(Entity var1) {
      return var1 != null && this.a.c() != null && var1 == this.a.c();
   }

   static {
      NativeMethodLookup.lookup(FakePlayerModule.class, 79);
   }
}
