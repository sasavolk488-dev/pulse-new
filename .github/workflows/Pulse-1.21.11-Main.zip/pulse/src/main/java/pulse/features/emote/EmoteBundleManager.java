package pulse.features.emote;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.GZIPInputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.features.emote.bobj.BobjAction;
import pulse.features.emote.bobj.BobjLoader;
import pulse.features.emote.bobj.BobjModel;
import pulse.features.emote.bobj.BobjProp;
import pulse.utils.net.ApiRouter;

@Environment(EnvType.CLIENT)
public final class EmoteBundleManager {
   private static final String a = "/assets/pulse/emotes/bobj/";
   private static final int b = 6;
   private static final int c = 5000;
   private static BobjModel d;

   private EmoteBundleManager() {
   }

   public static void a() {
      new Thread(EmoteBundleManager::b, "Emote-Bundle-Loader").start();
   }

   private static void b() {
      EmoteManager var0 = EmoteManager.a();

      try (
         InputStream var1 = c("default.bobj");
         InputStream var2 = c("slim.bobj");
      ) {
         BobjModel var3 = BobjLoader.a(var1);
         d = var3;
         var0.a(var3, BobjLoader.a(var2));
      } catch (Throwable var21) {
         Pulse.m().error("[Emote] failed to load BOBJ player models", var21);
         return;
      }

      Pulse.m().info("[Emote] загрузка emote-bundle, хосты: {}", ApiRouter.a());
      int var22 = 0;

      for (int var23 = 0; var23 < 6; var23++) {
         String var25 = ApiRouter.a().get(var22) + "/cosmetics/emote-bundle";

         try {
            URL var4 = new URL(var25);
            HttpURLConnection var5 = (HttpURLConnection)var4.openConnection();
            var5.setRequestMethod("GET");
            var5.setConnectTimeout(15000);
            var5.setReadTimeout(60000);
            var5.setRequestProperty("Accept-Encoding", "gzip");
            String var6 = f();
            if (var6 != null && !var6.isEmpty()) {
               var5.setRequestProperty("If-None-Match", var6);
            }

            int var7 = var5.getResponseCode();
            String var8 = var5.getHeaderField("ETag");
            String var9;
            if (var7 == 304) {
               var9 = g();
               if (var9 == null) {
                  Pulse.m().warn("[Emote] 304, но локальный кэш отсутствует — перезапрос без ETag");
                  var5.disconnect();

                  try {
                     Files.deleteIfExists(e());
                  } catch (Exception var16) {
                  }
                  continue;
               }

               Pulse.m().info("[Emote] bundle: кэш актуален (304), читаю с диска");
            } else if (var7 == 200) {
               var9 = a(var5);
               b(var9, var8);
               Pulse.m().info("[Emote] bundle: свежий ответ ({} KB), кэш обновлён{}", var9.length() / 1024, var8 != null ? " (etag=" + var8 + ")" : "");
            } else {
               Pulse.m().warn("[Emote] bundle: HTTP {}", var7);
               var9 = g();
               if (var9 == null) {
                  return;
               }

               Pulse.m().info("[Emote] bundle: использую stale-кэш");
            }

            b(var9);
            return;
         } catch (SocketTimeoutException var19) {
            Pulse.m().warn("[Emote] таймаут bundle (попытка {}/{}, {})", var23 + 1, 6, var25);
            var22 = (var22 + 1) % ApiRouter.a().size();
            if (var23 < 5) {
               try {
                  Thread.sleep(5000L);
               } catch (InterruptedException var15) {
                  Thread.currentThread().interrupt();
                  return;
               }
            }
         } catch (Exception var20) {
            Pulse.m().error("[Emote] ошибка загрузки emote-bundle (попытка {}/{}, {}): {}", var23 + 1, 6, var25, var20.toString());
            var22 = (var22 + 1) % ApiRouter.a().size();
            if (var23 < 5) {
               try {
                  Thread.sleep(5000L);
               } catch (InterruptedException var14) {
                  Thread.currentThread().interrupt();
                  return;
               }
            }
         }
      }

      String var24 = g();
      if (var24 != null) {
         Pulse.m().info("[Emote] bundle: попытки исчерпаны, использую кэш");

         try {
            b(var24);
         } catch (Exception var13) {
         }
      } else {
         Pulse.m().error("[Emote] не удалось загрузить emote-bundle после {} попыток", 6);
      }
   }

   private static void b(String var0) {
      JSONObject var1 = new JSONObject(var0);
      if (!var1.optBoolean("success", false)) {
         Pulse.m().warn("[Emote] bundle: сервер вернул ошибку");
      } else {
         JSONArray var2 = var1.optJSONArray("data");
         if (var2 != null) {
            EmoteManager var3 = EmoteManager.a();
            var3.c();
            int var4 = 0;

            for (int var5 = 0; var5 < var2.length(); var5++) {
               JSONObject var6 = var2.getJSONObject(var5);
               String var7 = String.valueOf(var6.getInt("id"));

               try {
                  String var8 = var6.getString("bobj");
                  String var9 = var6.getString("action");
                  BobjAction var10 = BobjLoader.a(new ByteArrayInputStream(var8.getBytes(StandardCharsets.UTF_8)), var9);
                  int var11 = var6.optInt("duration", 0);
                  if (var11 <= 0) {
                     var11 = Math.max(1, Math.round(var10.b()));
                  }

                  var var12 = a(var7, var6.optJSONArray("props"));
                  var3.a(var7, var10, var11, var6.optBoolean("looping", false), var12);
                  var3.a(var7, var6.optString("name", "Emote " + var7));
                  if (!var6.isNull("icon_base64")) {
                     a(var7, var6.getString("icon_base64"));
                  }

                  if (!var6.isNull("audio_base64")) {
                     EmoteAudio.a(var7, Base64.getDecoder().decode(var6.getString("audio_base64")), var6.optString("audio_ext", "mp3"));
                  }

                  var4++;
               } catch (Throwable var13) {
                  Pulse.m().warn("[Emote] bundle: skip id={}: {}", var7, var13.toString());
               }
            }

            Pulse.m().info("[Emote] bundle: загружено {} эмоций (из {})", var4, var2.length());
         }
      }
   }

   private static List<BobjProp> a(String var0, JSONArray var1) {
      if (var1 != null && var1.length() != 0 && d != null) {
         ArrayList<BobjProp> var2 = new ArrayList<>();

         for (int var3 = 0; var3 < var1.length(); var3++) {
            try {
               JSONObject var4 = var1.getJSONObject(var3);
               String var5 = var4.getString("obj");
               var var6 = BobjLoader.a(var5, d);
               if (!var6.isEmpty()) {
                  Identifier var7 = Identifier.of("pulse", "emote_prop/" + var0 + "_" + var3);
                  byte[] var8 = Base64.getDecoder().decode(var4.getString("texture"));
                  NativeImage var9 = NativeImage.read(new ByteArrayInputStream(var8));
                  Runnable var10 = () -> MinecraftClient.getInstance()
                     .getTextureManager()
                     .registerTexture(var7, new NativeImageBackedTexture(var7::toString, var9));
                  MinecraftClient var11 = MinecraftClient.getInstance();
                  if (var11.isOnThread()) {
                     var10.run();
                  } else {
                     var11.execute(var10);
                  }

                  var2.add(new BobjProp(var6, var7));
               }
            } catch (Exception var12) {
               Pulse.m().warn("[Emote] bundle: проп {}#{} не загрузился: {}", var0, var3, var12.toString());
            }
         }

         return var2;
      } else {
         return List.of();
      }
   }

   private static void a(String var0, String var1) {
      try {
         byte[] var2 = Base64.getDecoder().decode(var1);
         NativeImage var3 = NativeImage.read(new ByteArrayInputStream(var2));
         Identifier var4 = Identifier.of("pulse", "emote_icon/" + var0);
         Runnable var5 = () -> {
            MinecraftClient.getInstance().getTextureManager().registerTexture(var4, new NativeImageBackedTexture(var4::toString, var3));
            EmoteManager.a().a(var0, var4);
         };
         MinecraftClient var6 = MinecraftClient.getInstance();
         if (var6.isOnThread()) {
            var5.run();
         } else {
            var6.execute(var5);
         }
      } catch (Exception var7) {
         Pulse.m().warn("[Emote] bundle: иконка id={} не загрузилась: {}", var0, var7.toString());
      }
   }

   private static String a(HttpURLConnection var0) throws Exception {
      InputStream var1 = var0.getInputStream();
      if ("gzip".equalsIgnoreCase(var0.getContentEncoding())) {
         var1 = new GZIPInputStream((InputStream)var1);
      }

      String var6;
      try (InputStream var2 = var1) {
         ByteArrayOutputStream var3 = new ByteArrayOutputStream();
         byte[] var4 = new byte[8192];

         int var5;
         while ((var5 = var2.read(var4)) != -1) {
            var3.write(var4, 0, var5);
         }

         var6 = var3.toString(StandardCharsets.UTF_8);
      }

      return var6;
   }

   private static Path c() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cache");
   }

   private static Path d() {
      return c().resolve("emote_bundle.json");
   }

   private static Path e() {
      return c().resolve("emote_bundle.etag");
   }

   private static String f() {
      try {
         Path var0 = e();
         if (Files.exists(var0)) {
            return new String(Files.readAllBytes(var0), StandardCharsets.UTF_8).trim();
         }
      } catch (Exception var1) {
      }

      return null;
   }

   private static String g() {
      try {
         Path var0 = d();
         if (Files.exists(var0)) {
            return new String(Files.readAllBytes(var0), StandardCharsets.UTF_8);
         }
      } catch (Exception var1) {
      }

      return null;
   }

   private static void b(String var0, String var1) {
      try {
         Files.createDirectories(c());
         Files.write(d(), var0.getBytes(StandardCharsets.UTF_8));
         if (var1 != null) {
            Files.write(e(), var1.getBytes(StandardCharsets.UTF_8));
         }
      } catch (Exception var3) {
         Pulse.m().warn("[Emote] не удалось сохранить кэш bundle: {}", var3.getMessage());
      }
   }

   private static InputStream c(String var0) {
      InputStream var1 = EmoteBundleManager.class.getResourceAsStream("/assets/pulse/emotes/bobj/" + var0);
      if (var1 == null) {
         throw new IllegalStateException("Missing local BOBJ resource: " + var0);
      } else {
         return var1;
      }
   }

   public static BobjModel a(String var0) throws Exception {
      BobjModel var2;
      try (InputStream var1 = c(var0)) {
         var2 = BobjLoader.a(var1);
      }

      return var2;
   }
}
