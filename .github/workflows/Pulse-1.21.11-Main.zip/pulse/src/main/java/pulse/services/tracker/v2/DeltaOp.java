package pulse.services.tracker.v2;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class DeltaOp {
   public final String a;
   public final String b;

   public DeltaOp(String var1, String var2) {
      this.a = var1;
      this.b = var2;
   }
}
