package pulse.features.modules.utilities.fakeplayer;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.OtherClientPlayerEntity;
import pulse.core.api.IMinecraft;
import pulse.mixin.accessor.ClientWorldAccessor;

@Environment(EnvType.CLIENT)
public class FakePlayerSpawner implements IMinecraft {
   public static final int a = -121258123;
   private OtherClientPlayerEntity b;

   public void a() {
      if (d.player != null && d.world != null) {
         GameProfile var1 = new GameProfile(UUID.randomUUID(), d.player.getGameProfile().name());

         for (Property var3 : d.player.getGameProfile().properties().values()) {
            var1.properties().put(var3.name(), var3);
         }

         this.b = new OtherClientPlayerEntity(d.world, var1);
         this.b.getInventory().clone(d.player.getInventory());
         this.b.setHealth(20.0F);
         this.b.setId(-121258123);
         this.b.refreshPositionAndAngles(d.player.getX(), d.player.getY(), d.player.getZ(), d.player.getYaw(), d.player.getPitch());
         this.b.setHeadYaw(d.player.getHeadYaw());
         this.b.setBodyYaw(d.player.getBodyYaw());
         this.b.lastHeadYaw = d.player.getHeadYaw();
         this.b.lastBodyYaw = d.player.getBodyYaw();
         d.world.addEntity(this.b);
         ((ClientWorldAccessor)d.world).getPlayers().add(this.b);
      }
   }

   public void b() {
      if (this.b != null) {
         ((ClientWorldAccessor)d.world).getPlayers().remove(this.b);
         this.b.discard();
      }

      this.b = null;
   }

   public OtherClientPlayerEntity c() {
      return this.b;
   }
}
