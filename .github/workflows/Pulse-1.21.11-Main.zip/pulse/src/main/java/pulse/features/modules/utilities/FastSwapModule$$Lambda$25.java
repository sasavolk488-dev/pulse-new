package pulse.features.modules.utilities;

import java.util.function.Consumer;

public final class FastSwapModule$$Lambda$25 implements Consumer {
   @Override
   public void accept(Object var1) {
      FastSwapModule.a((Integer)var1);
   }
}
