package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import pulse.core.event.impl.PacketEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;

@ModuleInfo(
   a = "Item Pickup Logger",
   b = "Логирует поднятые предметы в чат",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ItemPickupLoggerModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Только донат предметы", false);

   @EventHandler
   @Compile
   public void a(PacketEvent var1) {
      BooleanSetting donationsOnly = this.a;
      if (var1.e() != PacketEvent.EventType.b || d.player == null || d.world == null) {
         return;
      }
      if (!(var1.d() instanceof net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket)) {
         return;
      }
      var packet = (net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket)var1.d();
      if (packet.getCollectorEntityId() != d.player.getId()) {
         return;
      }
      var entity = d.world.getEntityById(packet.getEntityId());
      if (!(entity instanceof net.minecraft.entity.ItemEntity)) {
         return;
      }
      ItemStack stack = ((net.minecraft.entity.ItemEntity)entity).getStack();
      if (stack.isEmpty()) {
         return;
      }
      boolean donation = this.a(stack);
      if ((Boolean)donationsOnly.q() && !donation) {
         return;
      }
      Text name = stack.getName();
      int count = stack.getCount();
      MutableText message = Text.literal(donation ? "§7Поднят донат предмет: " : "§7Поднят: ").append(name);
      if (count > 1) {
         message.append(Text.literal(" §7x" + count));
      }
      pulse.utils.game.ChatUtils.b(message);
   }

   private boolean a(ItemStack var1) {
      Text var2 = var1.getName();
      String var3 = var2.getString();
      if (var3.contains("★")) {
         return true;
      } else {
         if (var2 instanceof MutableText var4) {
            if (var4.getStyle().isObfuscated()) {
               return true;
            }

            for (Text var6 : var4.getSiblings()) {
               if (var6.getStyle().isObfuscated()) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   @Generated
   public BooleanSetting n() {
      return this.a;
   }

   static {
      NativeMethodLookup.lookup(ItemPickupLoggerModule.class, 64);
   }
}
