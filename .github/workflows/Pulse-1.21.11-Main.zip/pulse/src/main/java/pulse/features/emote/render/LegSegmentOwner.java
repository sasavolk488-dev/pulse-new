package pulse.features.emote.render;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class LegSegmentOwner {
   private static final Set<Integer> a = ConcurrentHashMap.newKeySet();

   private LegSegmentOwner() {
   }

   public static void a(int var0) {
      a.add(var0);
   }

   public static void b(int var0) {
      a.remove(var0);
   }

   public static boolean c(int var0) {
      return a.contains(var0);
   }
}
