package pulse.core.handler.impl.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum PhysicsMode {
   a("Реалистичная"),
   b("Без коллизий"),
   c("Без физики"),
   d("Притяжение"),
   e("Отталкивание"),
   f("Орбита"),
   g("Турбулентность"),
   h("Спираль");

   private final String i;

   private PhysicsMode(String var3) {
      this.i = var3;
   }

   public String a() {
      return this.i;
   }

   public static PhysicsMode a(String var0) {
      for (PhysicsMode var4 : values()) {
         if (var4.i.equals(var0)) {
            return var4;
         }
      }

      return a;
   }

   public static String[] b() {
      PhysicsMode[] var0 = values();
      String[] var1 = new String[var0.length];

      for (int var2 = 0; var2 < var0.length; var2++) {
         var1[var2] = var0[var2].i;
      }

      return var1;
   }

   private static PhysicsMode[] c() {
      return new PhysicsMode[]{a, b, c, d, e, f, g, h};
   }
}
