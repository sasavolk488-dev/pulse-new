package pulse.features.emote.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import org.joml.Quaternionf;
import pulse.features.emote.bobj.BobjModel;
import pulse.features.emote.bobj.BobjSkinning;

@Environment(EnvType.CLIENT)
public final class BobjLegSegments {
   private static final BobjLegSegments.SegmentSet a = a(new Dilation(0.5F));
   private static final BobjLegSegments.SegmentSet b = a(new Dilation(1.0F));
   private static final float c = 0.1F;
   private static final BobjLegSegments.SegmentSet d = a(new Dilation(0.6F));
   private static final BobjLegSegments.SegmentSet e = a(new Dilation(1.1F));
   private static boolean f;
   private static boolean g;
   private static boolean h;
   private static final MatrixStack i = new MatrixStack();

   private BobjLegSegments() {
   }

   public static boolean a() {
      return f;
   }

   public static void b() {
      f = false;
   }

   public static void a(boolean var0, boolean var1) {
      g = var0;
      h = var1;
   }

   public static boolean c() {
      return h;
   }

   public static void a(PlayerEntityModel var0, BobjModel var1, float[][] var2) {
      boolean var3 = a(
         var0.rightLeg,
         var1,
         var2,
         "right_leg",
         "low_leg_right",
         a.rightThigh,
         a.rightCalf,
         b.rightThigh,
         b.rightCalf,
         d.rightThigh,
         d.rightCalf,
         e.rightThigh,
         e.rightCalf
      );
      boolean var4 = a(
         var0.leftLeg,
         var1,
         var2,
         "left_leg",
         "low_left_leg",
         a.leftThigh,
         a.leftCalf,
         b.leftThigh,
         b.leftCalf,
         d.leftThigh,
         d.leftCalf,
         e.leftThigh,
         e.leftCalf
      );
      f = var3 && var4;
   }

   private static boolean a(
      ModelPart var0,
      BobjModel var1,
      float[][] var2,
      String var3,
      String var4,
      ModelPart var5,
      ModelPart var6,
      ModelPart var7,
      ModelPart var8,
      ModelPart var9,
      ModelPart var10,
      ModelPart var11,
      ModelPart var12
   ) {
      int var13 = var1.a(var3);
      int var14 = var1.a(var4);
      if (var13 >= 0 && var14 >= 0 && var13 < var2.length && var14 < var2.length) {
         float[] var15 = var2[var13];
         float[] var16 = var2[var14];
         ModelTransform var17 = var0.getDefaultTransform();
         float var18 = var17.x() / 16.0F;
         float var19 = (24.0F - var17.y()) / 16.0F;
         float var20 = -var17.z() / 16.0F;
         float[] var21 = var1.a(var14);
         float[] var22 = new float[3];
         BobjSkinning.a(var15, var18, var19, var20, var22);
         a(var22, var15, var5, var7, var9, var11);
         BobjSkinning.a(var16, var21[0], var21[1], var21[2], var22);
         a(var22, var16, var6, var8, var10, var12);
         return true;
      } else {
         return false;
      }
   }

   private static void a(float[] var0, float[] var1, ModelPart... var2) {
      float var3 = var0[0] * 16.0F;
      float var4 = 24.0F - var0[1] * 16.0F;
      float var5 = -var0[2] * 16.0F;
      Quaternionf var6 = BobjVanillaPose.a(var1);

      for (ModelPart var10 : var2) {
         var10.originX = var3;
         var10.originY = var4;
         var10.originZ = var5;
         BobjVanillaPose.a(var10, var6);
      }
   }

   public static void a(Entry var0, VertexConsumer var1, int var2, int var3, int var4, boolean var5, boolean var6) {
      i.push();
      i.peek().copy(var0);
      a(i, var1, var2, var3, var4, var5, var6, true, true);
      i.pop();
   }

   public static boolean d() {
      return g;
   }

   public static float[] e() {
      float[] var0 = new float[96];
      int var1 = 0;

      for (BobjLegSegments.SegmentSet var5 : new BobjLegSegments.SegmentSet[]{a, b, d, e}) {
         for (ModelPart var9 : new ModelPart[]{var5.rightThigh(), var5.rightCalf(), var5.leftThigh(), var5.leftCalf()}) {
            var0[var1++] = var9.originX;
            var0[var1++] = var9.originY;
            var0[var1++] = var9.originZ;
            var0[var1++] = var9.pitch;
            var0[var1++] = var9.yaw;
            var0[var1++] = var9.roll;
         }
      }

      return var0;
   }

   public static void a(float[] var0) {
      if (var0 != null) {
         int var1 = 0;

         for (BobjLegSegments.SegmentSet var5 : new BobjLegSegments.SegmentSet[]{a, b, d, e}) {
            for (ModelPart var9 : new ModelPart[]{var5.rightThigh(), var5.rightCalf(), var5.leftThigh(), var5.leftCalf()}) {
               var9.originX = var0[var1++];
               var9.originY = var0[var1++];
               var9.originZ = var0[var1++];
               var9.pitch = var0[var1++];
               var9.yaw = var0[var1++];
               var9.roll = var0[var1++];
            }
         }
      }
   }

   public static void a(MatrixStack var0, VertexConsumer var1, int var2, int var3, int var4, boolean var5, boolean var6) {
      a(var0, var1, var2, var3, var4, g, false, var5, var6);
   }

   private static void a(MatrixStack var0, VertexConsumer var1, int var2, int var3, int var4, boolean var5, boolean var6, boolean var7, boolean var8) {
      BobjLegSegments.SegmentSet var9 = var6 ? (var5 ? d : e) : (var5 ? a : b);
      if (var7) {
         var9.rightThigh.render(var0, var1, var2, var3, var4);
         var9.rightCalf.render(var0, var1, var2, var3, var4);
      }

      if (var8) {
         var9.leftThigh.render(var0, var1, var2, var3, var4);
         var9.leftCalf.render(var0, var1, var2, var3, var4);
      }
   }

   private static BobjLegSegments.SegmentSet a(Dilation var0) {
      Dilation var1 = var0.add(0.05F);
      ModelData var2 = new ModelData();
      ModelPartData var3 = var2.getRoot();
      var3.addChild("right_thigh", ModelPartBuilder.create().uv(0, 16).cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 7.0F, 4.0F, var0), ModelTransform.NONE);
      var3.addChild("right_calf", ModelPartBuilder.create().uv(0, 21).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 7.0F, 4.0F, var1), ModelTransform.NONE);
      var3.addChild("left_thigh", ModelPartBuilder.create().uv(0, 16).mirrored().cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 7.0F, 4.0F, var0), ModelTransform.NONE);
      var3.addChild("left_calf", ModelPartBuilder.create().uv(0, 21).mirrored().cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 7.0F, 4.0F, var1), ModelTransform.NONE);
      ModelPart var4 = TexturedModelData.of(var2, 64, 32).createModel();
      return new BobjLegSegments.SegmentSet(var4.getChild("right_thigh"), var4.getChild("right_calf"), var4.getChild("left_thigh"), var4.getChild("left_calf"));
   }

   @Environment(EnvType.CLIENT)
   private record SegmentSet(ModelPart rightThigh, ModelPart rightCalf, ModelPart leftThigh, ModelPart leftCalf) {
   }
}
