package pulse.mixin;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.option.GameOptions;
import net.minecraft.resource.ResourcePackManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({GameOptions.class})
public class GameOptionsResourcePackMixin {
   @Shadow
   public List<String> resourcePacks;
   @Unique
   private List<String> pulse$savedRpIds;

   @Inject(
      method = {"addResourcePackProfilesToManager"},
      at = {@At("HEAD")}
   )
   private void pulse$capture(ResourcePackManager var1, CallbackInfo var2) {
      this.pulse$savedRpIds = new ArrayList<>();

      for (String var4 : this.resourcePacks) {
         if (var4 != null && var4.startsWith("pulse_rp/")) {
            this.pulse$savedRpIds.add(var4);
         }
      }
   }

   @Inject(
      method = {"addResourcePackProfilesToManager"},
      at = {@At("RETURN")}
   )
   private void pulse$restore(ResourcePackManager var1, CallbackInfo var2) {
      if (this.pulse$savedRpIds != null) {
         for (String var4 : this.pulse$savedRpIds) {
            if (!this.resourcePacks.contains(var4)) {
               this.resourcePacks.add(var4);
            }
         }

         this.pulse$savedRpIds = null;
      }
   }
}
