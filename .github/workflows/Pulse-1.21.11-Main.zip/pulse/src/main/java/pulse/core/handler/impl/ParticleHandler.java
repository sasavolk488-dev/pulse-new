package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Vector3fc;
import pulse.core.event.impl.FrameEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.handler.impl.particle.ParticleShape;
import pulse.core.handler.impl.particle.ParticleTextures;
import pulse.core.handler.impl.particle.PhysicsMode;
import pulse.core.api.IMinecraft;
import pulse.utils.render.world.ParticleLayers;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class ParticleHandler extends Handler implements IMinecraft {
   private static final int a = 2000;
   private static final double b = 64.0;
   private static final double c = 16.0;
   private static final double f = 4096.0;
   private static final double g = 48.0;
   private static final float h = 0.2F;
   private static final float i = 0.98F;
   private static final float j = 0.2F;
   private static final float k = 0.35F;
   private static final float l = 0.55F;
   private static final float m = 0.75F;
   private static final float n = 0.62F;
   private static final float o = 1.25F;
   private static final float p = 1.5F;
   private static final int[][] q = new int[][]{{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
   private static final int[][] r = new int[][]{{2, 0}, {2, 4}, {2, 1}, {2, 5}, {3, 0}, {3, 4}, {3, 1}, {3, 5}, {0, 4}, {4, 1}, {1, 5}, {5, 0}};
   private static final Comparator<ParticleHandler.RenderItem> s = (var0, var1) -> Double.compare(var1.l, var0.l);
   private final Deque<ParticleHandler.Particle> t = new ArrayDeque<>();
   private final Object u = new Object();
   private long v = -1L;
   private final Map<Identifier, List<ParticleHandler.RenderItem>> w = new HashMap<>();
   private final Map<Identifier, List<ParticleHandler.RenderItem>> x = new HashMap<>();
   private final Set<RenderLayer> y = new HashSet<>();
   private final List<ParticleHandler.RenderItem> z = new ArrayList<>();
   private final float[] A = new float[24];
   private final float[] B = new float[8];
   private final int[] C = new int[8];
   private ParticleHandler.RenderItem[] D = new ParticleHandler.RenderItem[2000];
   private int E = 0;

   public ParticleHandler.Builder d() {
      return new ParticleHandler.Builder();
   }

   public void a(Vec3d var1, Vec3d var2, int var3, float var4, Identifier var5, int var6, double var7, String var9) {
      this.d().a(var1).b(var2).a(var3).a(var4).a(var5).b(var6).a(var7).a(PhysicsMode.a(var9)).a();
   }

   public void a(Vec3d var1, Vec3d var2, int var3, float var4, Identifier var5, int var6, String var7) {
      this.a(var1, var2, var3, var4, var5, var6, 0.020000007458859343, var7);
   }

   public void a(Vec3d var1, Vec3d var2, int var3, float var4, Identifier var5, int var6, double var7) {
      this.a(var1, var2, var3, var4, var5, var6, var7, "Реалистичная");
   }

   public void a(Vec3d var1, Vec3d var2, int var3, float var4, Identifier var5, int var6) {
      this.a(var1, var2, var3, var4, var5, var6, 0.020000007458859343, "Реалистичная");
   }

   public int e() {
      synchronized (this.u) {
         return this.t.size();
      }
   }

   public void f() {
      synchronized (this.u) {
         this.t.clear();
      }
   }

   private void a(ParticleHandler.Particle var1) {
      synchronized (this.u) {
         while (this.t.size() >= 2000) {
            this.t.pollFirst();
         }

         this.t.addLast(var1);
      }
   }

   @EventHandler
   @Compile
   public void a(FrameEvent var1) {
      Object lock = this.u;
      var particles = this.t;
      if (d.world == null) {
         return;
      }
      long tick = d.world.getTime();
      if (tick == this.v) {
         return;
      }
      this.v = tick;
      synchronized (lock) {
         var iterator = particles.iterator();
         while (iterator.hasNext()) {
            ParticleHandler.Particle particle = iterator.next();
            particle.a();
            if (particle.A) {
               iterator.remove();
            }
         }
      }
   }

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      Object lock = this.u;
      var particles = this.t;
      if (d.gameRenderer == null || d.gameRenderer.getCamera() == null) {
         return;
      }
      synchronized (lock) {
         boolean empty;
         try {
            empty = particles.isEmpty();
         } catch (RuntimeException | Error failure) {
            if (var1 != null) {
               var1.a();
            }
            throw failure;
         }
         if (empty) {
            return;
         }
         this.a(var1.a(), d.gameRenderer.getCamera());
      }
   }

   private void a(MatrixStack var1, Camera var2) {
      Vec3d var3 = var2.getCameraPos();
      float var4 = d.getRenderTickCounter().getTickProgress(false);
      Vector3fc var5 = var2.getDiagonalPlane();
      Vector3fc var6 = var2.getVerticalPlane();
      float var7 = -var5.x();
      float var8 = -var5.y();
      float var9 = -var5.z();
      float var10 = var6.x();
      float var11 = var6.y();
      float var12 = var6.z();
      Matrix4f var13 = var1.peek().getPositionMatrix();
      this.w.clear();
      this.x.clear();
      this.y.clear();
      this.z.clear();
      this.E = 0;

      for (ParticleHandler.Particle var15 : this.t) {
         ParticleHandler.RenderItem var16 = this.g();
         if (var15.a(var4, var3, var16)) {
            if (var15.p.b()) {
               this.z.add(var16);
            } else {
               (var16.k < 0.2F ? this.w : this.x).computeIfAbsent(var15.c, var0 -> new ArrayList<>()).add(var16);
            }
         }
      }

      if (!this.w.isEmpty() || !this.x.isEmpty() || !this.z.isEmpty()) {
         Immediate var19 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();

         for (Entry var23 : this.w.entrySet()) {
            List var17 = (List)var23.getValue();
            var17.sort(s);
            RenderLayer var18 = ParticleLayers.a((Identifier)var23.getKey(), false);
            a(var19.getBuffer(var18), var13, var17, var7, var8, var9, var10, var11, var12);
            this.y.add(var18);
         }

         for (Entry var24 : this.x.entrySet()) {
            RenderLayer var26 = ParticleLayers.a((Identifier)var24.getKey(), true);
            a(var19.getBuffer(var26), var13, (List<ParticleHandler.RenderItem>)var24.getValue(), var7, var8, var9, var10, var11, var12);
            this.y.add(var26);
         }

         if (!this.z.isEmpty()) {
            this.a(var19.getBuffer(ParticleLayers.n), var1.peek());
            this.y.add(ParticleLayers.n);
         }

         for (RenderLayer var25 : this.y) {
            var19.draw(var25);
         }
      }
   }

   private void a(VertexConsumer var1, net.minecraft.client.util.math.MatrixStack.Entry var2) {
      for (ParticleHandler.RenderItem var4 : this.z) {
         boolean var5 = var4.m == ParticleShape.b;
         this.a(var4, var5);
         this.a(var4, var5 ? 8 : 6);
         this.a(var1, var2, var5 ? q : r);
      }
   }

   private void a(ParticleHandler.RenderItem var1, boolean var2) {
      float var3 = var1.d;
      if (var2) {
         float var9 = 0.75F * var3;

         for (int var10 = 0; var10 < 8; var10++) {
            float var6 = (var10 & 1) != 0 ? var9 : -var9;
            float var7 = (var10 & 2) != 0 ? var9 : -var9;
            float var8 = (var10 & 4) != 0 ? var9 : -var9;
            this.A[var10 * 3] = var1.a + var1.n * var6 + var1.q * var7 + var1.t * var8;
            this.A[var10 * 3 + 1] = var1.b + var1.o * var6 + var1.r * var7 + var1.u * var8;
            this.A[var10 * 3 + 2] = var1.c + var1.p * var6 + var1.s * var7 + var1.v * var8;
         }
      } else {
         float var4 = 0.62F * var3;
         float var5 = 1.25F * var3;
         this.a(0, var1, var1.n * var4, var1.o * var4, var1.p * var4);
         this.a(1, var1, -var1.n * var4, -var1.o * var4, -var1.p * var4);
         this.a(2, var1, var1.q * var5, var1.r * var5, var1.s * var5);
         this.a(3, var1, -var1.q * var5, -var1.r * var5, -var1.s * var5);
         this.a(4, var1, var1.t * var4, var1.u * var4, var1.v * var4);
         this.a(5, var1, -var1.t * var4, -var1.u * var4, -var1.v * var4);
      }
   }

   private void a(int var1, ParticleHandler.RenderItem var2, float var3, float var4, float var5) {
      this.A[var1 * 3] = var2.a + var3;
      this.A[var1 * 3 + 1] = var2.b + var4;
      this.A[var1 * 3 + 2] = var2.c + var5;
   }

   private void a(ParticleHandler.RenderItem var1, int var2) {
      float var3 = (float)Math.sqrt(var1.a * var1.a + var1.b * var1.b + var1.c * var1.c);
      float var4 = 0.0F;
      float var5 = 0.0F;
      float var6 = 1.0F;
      if (var3 > 1.0E-4F) {
         var4 = var1.a / var3;
         var5 = var1.b / var3;
         var6 = var1.c / var3;
      }

      float var7 = 1.0E-4F;

      for (int var8 = 0; var8 < var2; var8++) {
         float var9 = (this.A[var8 * 3] - var1.a) * var4 + (this.A[var8 * 3 + 1] - var1.b) * var5 + (this.A[var8 * 3 + 2] - var1.c) * var6;
         this.B[var8] = var9;
         var7 = Math.max(var7, Math.abs(var9));
      }

      int var14 = a(var1.g);
      int var15 = a(var1.h);
      int var10 = a(var1.i);

      for (int var11 = 0; var11 < var2; var11++) {
         float var12 = 0.5F + 0.5F * this.B[var11] / var7;
         float var13 = 1.0F - 0.55F * var12;
         this.C[var11] = var1.j << 24 | Math.round(var14 * var13) << 16 | Math.round(var15 * var13) << 8 | Math.round(var10 * var13);
      }
   }

   private void a(VertexConsumer var1, net.minecraft.client.util.math.MatrixStack.Entry var2, int[][] var3) {
      for (int[] var7 : var3) {
         int var8 = var7[0] * 3;
         int var9 = var7[1] * 3;
         float var10 = this.A[var9] - this.A[var8];
         float var11 = this.A[var9 + 1] - this.A[var8 + 1];
         float var12 = this.A[var9 + 2] - this.A[var8 + 2];
         float var13 = (float)Math.sqrt(var10 * var10 + var11 * var11 + var12 * var12);
         if (!(var13 < 1.0E-6F)) {
            var10 /= var13;
            var11 /= var13;
            var12 /= var13;
            this.a(var1, var2, var7[0], var10, var11, var12);
            this.a(var1, var2, var7[1], var10, var11, var12);
         }
      }
   }

   private void a(VertexConsumer var1, net.minecraft.client.util.math.MatrixStack.Entry var2, int var3, float var4, float var5, float var6) {
      int var7 = var3 * 3;
      var1.vertex(var2, this.A[var7], this.A[var7 + 1], this.A[var7 + 2]).color(this.C[var3]).normal(var2, var4, var5, var6).lineWidth(1.5F);
   }

   private static int a(int var0) {
      return var0 + Math.round((255 - var0) * 0.35F);
   }

   private ParticleHandler.RenderItem g() {
      if (this.E >= this.D.length) {
         ParticleHandler.RenderItem[] var1 = new ParticleHandler.RenderItem[this.D.length * 2];
         System.arraycopy(this.D, 0, var1, 0, this.D.length);
         this.D = var1;
      }

      ParticleHandler.RenderItem var2 = this.D[this.E];
      if (var2 == null) {
         var2 = new ParticleHandler.RenderItem();
         this.D[this.E] = var2;
      }

      this.E++;
      return var2;
   }

   private static void a(
      VertexConsumer var0, Matrix4f var1, List<ParticleHandler.RenderItem> var2, float var3, float var4, float var5, float var6, float var7, float var8
   ) {
      for (ParticleHandler.RenderItem var10 : var2) {
         float var11;
         float var12;
         float var13;
         float var14;
         float var15;
         float var16;
         if (var10.f == 0.0F) {
            var11 = var3;
            var12 = var4;
            var13 = var5;
            var14 = var6;
            var15 = var7;
            var16 = var8;
         } else {
            float var17 = var10.e;
            float var18 = var10.f;
            var11 = var3 * var17 + var6 * var18;
            var12 = var4 * var17 + var7 * var18;
            var13 = var5 * var17 + var8 * var18;
            var14 = -var3 * var18 + var6 * var17;
            var15 = -var4 * var18 + var7 * var17;
            var16 = -var5 * var18 + var8 * var17;
         }

         float var33 = var10.d;
         float var34 = var10.a;
         float var19 = var10.b;
         float var20 = var10.c;
         float var21 = var34 + (-var11 - var14) * var33;
         float var22 = var19 + (-var12 - var15) * var33;
         float var23 = var20 + (-var13 - var16) * var33;
         float var24 = var34 + (var11 - var14) * var33;
         float var25 = var19 + (var12 - var15) * var33;
         float var26 = var20 + (var13 - var16) * var33;
         float var27 = var34 + (var11 + var14) * var33;
         float var28 = var19 + (var12 + var15) * var33;
         float var29 = var20 + (var13 + var16) * var33;
         float var30 = var34 + (-var11 + var14) * var33;
         float var31 = var19 + (-var12 + var15) * var33;
         float var32 = var20 + (-var13 + var16) * var33;
         var0.vertex(var1, var21, var22, var23).texture(0.0F, 0.0F).color(var10.g, var10.h, var10.i, var10.j);
         var0.vertex(var1, var24, var25, var26).texture(1.0F, 0.0F).color(var10.g, var10.h, var10.i, var10.j);
         var0.vertex(var1, var27, var28, var29).texture(1.0F, 1.0F).color(var10.g, var10.h, var10.i, var10.j);
         var0.vertex(var1, var30, var31, var32).texture(0.0F, 1.0F).color(var10.g, var10.h, var10.i, var10.j);
      }
   }

   private static int a(int var0, int var1, float var2) {
      int var3 = var0 >>> 24 & 0xFF;
      int var4 = var0 >> 16 & 0xFF;
      int var5 = var0 >> 8 & 0xFF;
      int var6 = var0 & 0xFF;
      int var7 = var1 >>> 24 & 0xFF;
      int var8 = var1 >> 16 & 0xFF;
      int var9 = var1 >> 8 & 0xFF;
      int var10 = var1 & 0xFF;
      int var11 = var3 + Math.round((var7 - var3) * var2);
      int var12 = var4 + Math.round((var8 - var4) * var2);
      int var13 = var5 + Math.round((var9 - var5) * var2);
      int var14 = var6 + Math.round((var10 - var6) * var2);
      return var11 << 24 | var12 << 16 | var13 << 8 | var14;
   }

   static {
      NativeMethodLookup.lookup(ParticleHandler.class, 28);
   }

   @Environment(EnvType.CLIENT)
   public final class Builder {
      private Vec3d b = Vec3d.ZERO;
      private Vec3d c = Vec3d.ZERO;
      private Identifier d = ParticleTextures.a;
      private int e = 20;
      private float f = 0.3F;
      private float g = 1.0F;
      private float h = 1.0F;
      private float i = 1.0F;
      private int j = -1;
      private int k = -1;
      private boolean l = false;
      private double m = 0.02000000756791522;
      private PhysicsMode n = PhysicsMode.a;
      private ParticleShape o = ParticleShape.a;
      private float p = 1.0F;

      public ParticleHandler.Builder a(Vec3d var1) {
         this.b = var1;
         return this;
      }

      public ParticleHandler.Builder a(double var1, double var3, double var5) {
         this.b = new Vec3d(var1, var3, var5);
         return this;
      }

      public ParticleHandler.Builder b(Vec3d var1) {
         this.c = var1;
         return this;
      }

      public ParticleHandler.Builder b(double var1, double var3, double var5) {
         this.c = new Vec3d(var1, var3, var5);
         return this;
      }

      public ParticleHandler.Builder a(Identifier var1) {
         this.d = var1;
         return this;
      }

      public ParticleHandler.Builder a(int var1) {
         this.e = Math.max(1, var1);
         return this;
      }

      public ParticleHandler.Builder a(float var1) {
         this.f = var1;
         return this;
      }

      public ParticleHandler.Builder a(float var1, float var2, float var3) {
         this.g = var1;
         this.h = var2;
         this.i = var3;
         return this;
      }

      public ParticleHandler.Builder b(int var1) {
         this.j = var1;
         this.k = var1;
         this.l = false;
         return this;
      }

      public ParticleHandler.Builder a(int var1, int var2) {
         this.j = var1;
         this.k = var2;
         this.l = true;
         return this;
      }

      public ParticleHandler.Builder a(double var1) {
         this.m = var1;
         return this;
      }

      public ParticleHandler.Builder a(PhysicsMode var1) {
         this.n = var1;
         return this;
      }

      public ParticleHandler.Builder a(ParticleShape var1) {
         this.o = var1;
         return this;
      }

      public ParticleHandler.Builder b(float var1) {
         this.p = Math.max(0.0F, var1);
         return this;
      }

      public void a() {
         ParticleHandler.this.a(ParticleHandler.this.new Particle(this));
      }
   }

   @Environment(EnvType.CLIENT)
   final class Particle {
      final int a;
      final float b;
      final Identifier c;
      final int d;
      final int e;
      final boolean f;
      final double g;
      final PhysicsMode h;
      final float i;
      final float j;
      final float k;
      final float l;
      final float m;
      final Vec3d n;
      final float o;
      final ParticleShape p;
      final float q;
      final float r;
      final float s;
      final float t;
      final float u;
      Vec3d v;
      Vec3d w;
      Vec3d x;
      int y = 0;
      float z = 0.0F;
      boolean A = false;

      Particle(ParticleHandler.Builder var2) {
         this.a = var2.e;
         this.b = var2.f;
         this.c = var2.d;
         this.d = var2.j;
         this.e = var2.k;
         this.f = var2.l;
         this.g = var2.m;
         this.h = var2.n;
         this.i = var2.g;
         this.j = var2.h;
         this.k = var2.i;
         this.w = var2.b;
         this.v = var2.b;
         this.n = var2.b;
         this.x = var2.c;
         this.p = var2.o;
         ThreadLocalRandom var3 = ThreadLocalRandom.current();
         float var4 = var3.nextFloat() * (float) (Math.PI * 2);
         this.l = (float)Math.cos(var4);
         this.m = (float)Math.sin(var4);
         this.o = var3.nextFloat() * 100.0F;
         float var5 = var3.nextFloat() * 2.0F - 1.0F;
         float var6 = var3.nextFloat() * (float) (Math.PI * 2);
         float var7 = (float)Math.sqrt(Math.max(0.0F, 1.0F - var5 * var5));
         this.q = var7 * (float)Math.cos(var6);
         this.r = var5;
         this.s = var7 * (float)Math.sin(var6);
         this.t = (var3.nextBoolean() ? 1.0F : -1.0F) * (0.025F + var3.nextFloat() * 0.045F) * var2.p;
         this.u = var3.nextFloat() * (float) (Math.PI * 2);
      }

      void a() {
         this.y++;
         if (this.y <= this.a && IMinecraft.d.world != null && IMinecraft.d.player != null) {
            float var1 = 0.2F * this.a;
            if (this.y <= var1) {
               this.z = this.y / var1;
            } else if (this.y >= this.a - var1) {
               this.z = (this.a - this.y) / var1;
            } else {
               this.z = 1.0F;
            }

            switch (this.h) {
               case a:
                  this.c();
                  break;
               case b:
                  this.d();
                  break;
               case c:
                  this.e();
                  break;
               case d:
                  this.f();
                  break;
               case e:
                  this.g();
                  break;
               case f:
                  this.h();
                  break;
               case g:
                  this.i();
                  break;
               case h:
                  this.j();
            }
         } else {
            this.A = true;
         }
      }

      private void b() {
         this.x = this.x.multiply(0.98F);
         this.x = this.x.add(0.0, -this.g, 0.0);
      }

      private void c() {
         this.b();
         ThreadLocalRandom var1 = ThreadLocalRandom.current();
         this.x = this.x
            .add(
               var1.nextDouble(-0.010000004220056776, 0.010000003758468665),
               var1.nextDouble(-0.010000004220056776, 0.010000003758468665),
               var1.nextDouble(-0.010000004220056776, 0.010000003758468665)
            );
         Vec3d var2 = this.w.add(this.x);
         BlockHitResult var3 = IMinecraft.d.world.raycast(new RaycastContext(this.w, var2, ShapeType.COLLIDER, FluidHandling.NONE, IMinecraft.d.player));
         if (var3.getType() == Type.BLOCK) {
            var2 = var3.getPos();
            Direction var4 = var3.getSide();
            Vec3d var5 = new Vec3d(var4.getOffsetX(), var4.getOffsetY(), var4.getOffsetZ());
            double var6 = this.x.dotProduct(var5);
            Vec3d var8 = this.x.subtract(var5.multiply(2.0 * var6));
            if (var8.length() < 0.09999998908607069) {
               this.x = Vec3d.ZERO;
            } else {
               this.x = var8.multiply(0.5);
               var2 = var2.add(this.x.normalize().multiply(9.999996399076031E-4));
            }
         }

         this.v = this.w;
         this.w = var2;
      }

      private void d() {
         this.b();
         ThreadLocalRandom var1 = ThreadLocalRandom.current();
         this.x = this.x
            .add(
               var1.nextDouble(-0.010000004220056776, 0.010000003758468665),
               var1.nextDouble(-0.010000004220056776, 0.010000003758468665),
               var1.nextDouble(-0.010000004220056776, 0.010000003758468665)
            );
         this.v = this.w;
         this.w = this.w.add(this.x);
         if (this.k()) {
            this.A = true;
         }
      }

      private void e() {
         this.v = this.w;
         this.w = this.w.add(this.x);
         if (this.k()) {
            this.A = true;
         }
      }

      private void f() {
         Vec3d var1 = IMinecraft.d.player.getLerpedPos(1.0F).add(0.0, IMinecraft.d.player.getEyeHeight(IMinecraft.d.player.getPose()), 0.0);
         Vec3d var2 = var1.subtract(this.w);
         double var3 = var2.length();
         if (var3 > 0.09999998908607069) {
            this.x = this.x.add(var2.normalize().multiply(0.02000000657837629 / Math.max(var3, 1.0)));
         }

         this.b();
         this.v = this.w;
         this.w = this.w.add(this.x);
      }

      private void g() {
         Vec3d var1 = IMinecraft.d.player.getLerpedPos(1.0F).add(0.0, IMinecraft.d.player.getEyeHeight(IMinecraft.d.player.getPose()), 0.0);
         Vec3d var2 = this.w.subtract(var1);
         double var3 = var2.length();
         if (var3 > 0.05000000213094617 && var3 < 8.0) {
            double var5 = 0.04000001498854381 / (var3 * var3);
            this.x = this.x.add(var2.normalize().multiply(var5));
         }

         this.b();
         this.v = this.w;
         this.w = this.w.add(this.x);
      }

      private void h() {
         Vec3d var1 = IMinecraft.d.player.getLerpedPos(1.0F).add(0.0, IMinecraft.d.player.getEyeHeight(IMinecraft.d.player.getPose()), 0.0);
         Vec3d var2 = this.w.subtract(var1);
         double var3 = Math.sqrt(var2.x * var2.x + var2.z * var2.z);
         if (var3 > 0.05000000213094617) {
            double var5 = 1.0 / var3;
            Vec3d var7 = new Vec3d(var2.z * var5, 0.0, -var2.x * var5);
            this.x = this.x.add(var7.multiply(0.04000001498854381));
            this.x = this.x.add(var2.normalize().multiply(-0.005000000242154533));
         }

         this.x = this.x.multiply(0.9500001049285249);
         this.v = this.w;
         this.w = this.w.add(this.x);
      }

      private void i() {
         double var1 = ((float)ParticleHandler.this.v + this.o) * 0.05000000213094617;
         double var3 = this.w.x * 0.5;
         double var5 = this.w.y * 0.5;
         double var7 = this.w.z * 0.5;
         double var9 = Math.sin(var5 + var1) + Math.cos(var7 + var1 * 1.299999434353443);
         double var11 = Math.sin(var7 + var1 * 0.7000001566460121) + Math.cos(var3 + var1 * 1.1000001232450018);
         double var13 = Math.sin(var3 + var1 * 1.5) + Math.cos(var5 + var1 * 0.9000000316827171);
         this.x = this.x.add(var9 * 0.012000000932687823, var11 * 0.012000000932687823, var13 * 0.012000000932687823);
         this.x = this.x.multiply(0.9599996167157423);
         this.x = this.x.add(0.0, -this.g * 0.30000000198670057, 0.0);
         this.v = this.w;
         this.w = this.w.add(this.x);
      }

      private void j() {
         double var1 = this.w.x - this.n.x;
         double var3 = this.w.z - this.n.z;
         double var5 = Math.sqrt(var1 * var1 + var3 * var3);
         double var7 = 0.05000000213094617 + (double)this.y / this.a * 0.6000000526206352;
         Vec3d var9;
         if (var5 < 9.999995862465328E-5) {
            var9 = new Vec3d(Math.cos(this.o) * 0.04000001498854381, 0.0, Math.sin(this.o) * 0.04000001498854381);
         } else {
            double var10 = 1.0 / var5;
            Vec3d var12 = new Vec3d(var3 * var10, 0.0, -var1 * var10).multiply(0.08000000016007121);
            double var13 = (var7 - var5) * 0.05000000213094617;
            Vec3d var15 = new Vec3d(var1 * var10, 0.0, var3 * var10).multiply(var13);
            var9 = var12.add(var15);
         }

         this.x = this.x.multiply(0.9000000316827171).add(var9);
         this.x = this.x.add(0.0, 0.012000000932687823 - this.g * 0.5, 0.0);
         this.v = this.w;
         this.w = this.w.add(this.x);
      }

      private boolean k() {
         BlockPos var1 = BlockPos.ofFloored(this.w);
         if (!IMinecraft.d.world.getBlockState(var1).isSolidBlock(IMinecraft.d.world, var1)) {
            return false;
         } else {
            double var2 = this.b * 0.5;
            double var4 = this.w.x - var1.getX();
            double var6 = this.w.y - var1.getY();
            double var8 = this.w.z - var1.getZ();
            return var4 > var2 && var4 < 1.0 - var2 && var6 > var2 && var6 < 1.0 - var2 && var8 > var2 && var8 < 1.0 - var2;
         }
      }

      boolean a(float var1, Vec3d var2, ParticleHandler.RenderItem var3) {
         if (this.z <= 0.0F) {
            return false;
         } else {
            double var4 = var1;
            double var6 = this.v.x + (this.w.x - this.v.x) * var4;
            double var8 = this.v.y + (this.w.y - this.v.y) * var4 + 0.25;
            double var10 = this.v.z + (this.w.z - this.v.z) * var4;
            double var12 = var6 - var2.x;
            double var14 = var8 - var2.y;
            double var16 = var10 - var2.z;
            double var18 = var12 * var12 + var14 * var14 + var16 * var16;
            if (var18 > 4096.0) {
               return false;
            } else {
               float var20 = this.z;
               if (var18 > 2304.0) {
                  double var21 = Math.sqrt(var18);
                  var20 *= (float)Math.max(0.0, (64.0 - var21) / 16.0);
                  if (var20 <= 0.0F) {
                     return false;
                  }
               }

               float var30 = Math.min(1.0F, (float)this.y / this.a);
               float var22 = this.a(var30);
               if (var22 <= 0.0F) {
                  return false;
               } else {
                  int var23 = this.f ? ParticleHandler.a(this.d, this.e, var30) : this.d;
                  int var24 = var23 >>> 24 & 0xFF;
                  int var25 = Math.max(0, Math.min(255, Math.round(var24 * var20)));
                  if (var25 == 0) {
                     return false;
                  } else {
                     int var26 = var23 >> 16 & 0xFF;
                     int var27 = var23 >> 8 & 0xFF;
                     int var28 = var23 & 0xFF;
                     float var29 = (var26 + var27 + var28) / 765.0F;
                     var3.a = (float)var12;
                     var3.b = (float)var14;
                     var3.c = (float)var16;
                     var3.d = this.b * var22;
                     var3.e = this.l;
                     var3.f = this.m;
                     var3.g = var26;
                     var3.h = var27;
                     var3.i = var28;
                     var3.j = var25;
                     var3.k = var29;
                     var3.l = var18;
                     var3.m = this.p;
                     if (this.p.b()) {
                        var3.a(this.q, this.r, this.s, (this.y + var1) * this.t + this.u);
                     }

                     return true;
                  }
               }
            }
         }
      }

      private float a(float var1) {
         if (var1 < 0.5F) {
            float var3 = var1 * 2.0F;
            return this.i + (this.j - this.i) * var3;
         } else {
            float var2 = (var1 - 0.5F) * 2.0F;
            return this.j + (this.k - this.j) * var2;
         }
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class RenderItem {
      float a;
      float b;
      float c;
      float d;
      float e;
      float f;
      int g;
      int h;
      int i;
      int j;
      float k;
      double l;
      ParticleShape m = ParticleShape.a;
      float n;
      float o;
      float p;
      float q;
      float r;
      float s;
      float t;
      float u;
      float v;

      void a(float var1, float var2, float var3, float var4) {
         float var5 = (float)Math.cos(var4);
         float var6 = (float)Math.sin(var4);
         float var7 = 1.0F - var5;
         this.n = var7 * var1 * var1 + var5;
         this.q = var7 * var1 * var2 - var6 * var3;
         this.t = var7 * var1 * var3 + var6 * var2;
         this.o = var7 * var1 * var2 + var6 * var3;
         this.r = var7 * var2 * var2 + var5;
         this.u = var7 * var2 * var3 - var6 * var1;
         this.p = var7 * var1 * var3 - var6 * var2;
         this.s = var7 * var2 * var3 + var6 * var1;
         this.v = var7 * var3 * var3 + var5;
      }
   }
}
