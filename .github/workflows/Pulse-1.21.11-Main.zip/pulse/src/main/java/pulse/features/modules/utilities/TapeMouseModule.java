package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Tape Mouse",
   b = "Автокликер",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class TapeMouseModule extends Module {
   private final NumberSetting a = new NumberSetting("Задержка (тики)", 10.0F, 1.0F, 100.0F, 1.0F);
   private final ModeSetting b = new ModeSetting("Кнопка мыши", new String[]{"Левая", "Правая"}, "Левая");
   private int c = 0;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      ModeSetting button = this.b;
      NumberSetting delay = this.a;
      if (d.player == null || d.world == null || d.player.isUsingItem()) {
         return;
      }
      if (this.c > 0) {
         this.c--;
         return;
      }
      if (button.b("Левая")) {
         ((pulse.mixin.accessor.MinecraftClientAccessor)d).invokeDoAttack();
      } else {
         ((pulse.mixin.accessor.MinecraftClientAccessor)d).invokeDoItemUse();
      }
      try {
         this.c = delay.c();
      } catch (RuntimeException | Error error) {
         this.c = 0;
         throw error;
      }
   }

   @Compile
   @Override
   public void e() {
      this.c = 0;
      super.e();
   }

   @Compile
   @Override
   public void f() {
      this.c = 0;
      super.f();
   }

   static {
      NativeMethodLookup.lookup(TapeMouseModule.class, 76);
   }
}
