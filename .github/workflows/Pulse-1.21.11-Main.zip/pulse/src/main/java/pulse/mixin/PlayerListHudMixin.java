package pulse.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.ClientConnection;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.StreamerModeModule;
import pulse.features.modules.visuals.TabCustomizerModule;
import pulse.services.tracker.v2.ModUserTrackerV2;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
@Mixin({PlayerListHud.class})
public class PlayerListHudMixin {
   @Shadow
   @Final
   private MinecraftClient client;
   @Shadow
   private Text header;
   @Shadow
   private Text footer;
   @Unique
   private static final int PULSE$ICON_SIZE = 8;
   @Unique
   private static final int PULSE$ICON_PADDING = 2;
   @Unique
   private static final Pattern PULSE$ANARCHY = Pattern.compile("Анархия-\\d+");
   @Unique
   private Text pulse$lastHeader;
   @Unique
   private Text pulse$lastResult;
   @Unique
   private int pulse$rowIndex;
   @Unique
   private List<PlayerListEntry> pulse$rowEntries;

   @Redirect(
      method = {"render"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/gui/hud/PlayerListHud;header:Lnet/minecraft/text/Text;",
         opcode = 180
      )
   )
   private Text pulse$maskAnarchyNumber(PlayerListHud var1) {
      TabCustomizerModule var2 = ModuleRegistry.z;
      if (var2 != null && var2.k() && var2.q()) {
         return null;
      } else {
         StreamerModeModule var3 = ModuleRegistry.T;
         Text var4 = this.header;
         if (var3 == null || !var3.k() || !var3.b.q() || var4 == null) {
            return var4;
         } else if (var4 == this.pulse$lastHeader) {
            return this.pulse$lastResult;
         } else {
            String var6 = var4.getString();
            Object var5;
            if (!var6.contains("Анархия-")) {
               var5 = var4;
            } else {
               var5 = Text.literal(PULSE$ANARCHY.matcher(var6).replaceAll("Анархия-***"));
            }

            this.pulse$lastHeader = var4;
            this.pulse$lastResult = (Text)var5;
            return (Text)var5;
         }
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void pulse$captureRowEntries(DrawContext var1, int var2, Scoreboard var3, ScoreboardObjective var4, CallbackInfo var5) {
      this.pulse$rowIndex = 0;
      TabCustomizerModule var6 = ModuleRegistry.z;
      this.pulse$rowEntries = var6 != null && var6.k() && var6.n() ? ((PlayerListHudAccessor)(Object)this).invokeCollectPlayerEntries() : null;
   }

   @ModifyArg(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V",
         ordinal = 2
      ),
      index = 4
   )
   private int pulse$highlightRow(int var1) {
      var var2 = this.pulse$rowEntries;
      if (var2 == null) {
         return var1;
      } else {
         int var3 = this.pulse$rowIndex++;
         if (var3 >= var2.size()) {
            return var1;
         } else {
            Integer var4 = ModuleRegistry.z.a((PlayerListEntry)var2.get(var3));
            return var4 != null ? var4 : var1;
         }
      }
   }

   @WrapOperation(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/MinecraftClient;isInSingleplayer()Z"
      )}
   )
   private boolean pulse$headsSingleplayer(MinecraftClient var1, Operation<Boolean> var2) {
      return ModuleRegistry.z.k() ? false : (Boolean)var2.call(var1);
   }

   @WrapOperation(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/network/ClientConnection;isEncrypted()Z"
      )}
   )
   private boolean pulse$headsToggle(ClientConnection var1, Operation<Boolean> var2) {
      TabCustomizerModule var3 = ModuleRegistry.z;
      return var3.k() ? var3.p() : (Boolean)var2.call(var1);
   }

   @Inject(
      method = {"renderLatencyIcon"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$pingRender(DrawContext var1, int var2, int var3, int var4, PlayerListEntry var5, CallbackInfo var6) {
      TabCustomizerModule var7 = ModuleRegistry.z;
      if (var7 != null && var7.k()) {
         if (var7.s()) {
            var6.cancel();
         } else if (var7.t()) {
            int var8 = var5.getLatency();
            String var9 = var8 < 0 ? "?" : String.valueOf(var8);
            int var10 = this.client.textRenderer.getWidth(var9);
            var1.drawTextWithShadow(this.client.textRenderer, var9, var3 + var2 - var10, var4, var7.b(var8));
            var6.cancel();
         }
      }
   }

   @Inject(
      method = {"collectPlayerEntries"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void pulse$friendsFirst(CallbackInfoReturnable<List<PlayerListEntry>> var1) {
      TabCustomizerModule var2 = ModuleRegistry.z;
      if (var2 != null && var2.k() && var2.o()) {
         ArrayList<PlayerListEntry> var3 = new ArrayList<>((Collection)var1.getReturnValue());
         var3.sort(Comparator.comparingInt(var2::b));
         var1.setReturnValue(var3);
      }
   }

   @Redirect(
      method = {"render"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/gui/hud/PlayerListHud;footer:Lnet/minecraft/text/Text;",
         opcode = 180
      )
   )
   private Text pulse$hideFooter(PlayerListHud var1) {
      TabCustomizerModule var2 = ModuleRegistry.z;
      return var2 != null && var2.k() && var2.r() ? null : this.footer;
   }

   @Redirect(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)V"
      )
   )
   private void pulse$drawTrackedPlayerName(DrawContext var1, TextRenderer var2, Text var3, int var4, int var5, int var6) {
      if (!ModUserTrackerV2.d().c()) {
         var1.drawTextWithShadow(var2, var3, var4, var5, var6);
      } else {
         String var7 = this.pulse$extractPlayerName(var3.getString());
         if (var7 != null && ModUserTrackerV2.d().a(var7)) {
            this.pulse$renderTrackerIcon(var1, var4, var5, ModUserTrackerV2.d().c(var7));
            var1.drawTextWithShadow(var2, var3, var4 + 8 + 2, var5, var6);
         } else {
            var1.drawTextWithShadow(var2, var3, var4, var5, var6);
         }
      }
   }

   @Unique
   private String pulse$extractPlayerName(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         if (this.client.player != null && this.client.player.networkHandler != null) {
            for (PlayerListEntry var4 : this.client.player.networkHandler.getListedPlayerListEntries()) {
               if (var4.getProfile() != null && var4.getProfile().name() != null) {
                  String var5 = var4.getProfile().name();
                  if (var1.contains(var5)) {
                     return var5;
                  }
               }
            }

            return null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   @Unique
   private void pulse$renderTrackerIcon(DrawContext var1, int var2, int var3, int var4) {
      Identifier var5 = TextureRegistry.a(var4 == 1 ? "logo_free" : "logo");
      var1.drawTexture(RenderPipelines.GUI_TEXTURED, var5, var2, var3, 0.0F, 0.0F, 8, 8, 8, 8);
   }
}
