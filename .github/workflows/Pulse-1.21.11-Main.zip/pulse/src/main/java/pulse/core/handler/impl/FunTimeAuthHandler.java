package pulse.core.handler.impl;

import java.nio.charset.StandardCharsets;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.core.event.impl.GameJoinEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;
import pulse.utils.net.FunTimeDomains;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class FunTimeAuthHandler extends Handler implements IMinecraft {
   private static final Identifier a = Identifier.of("pulse", "ftauth");

   @Override
   public void a() {
      super.a();

      try {
         PayloadTypeRegistry.playC2S().register(FunTimeAuthHandler.FtAuthPayload.a, FunTimeAuthHandler.FtAuthPayload.b);
         PayloadTypeRegistry.playS2C().register(FunTimeAuthHandler.FtAuthPayload.a, FunTimeAuthHandler.FtAuthPayload.b);
         ClientPlayNetworking.registerGlobalReceiver(FunTimeAuthHandler.FtAuthPayload.a, (var1, var2x) -> {
            String var3 = var1.a();
            var2x.client().execute(() -> this.a(var3));
         });
         Pulse.m().info("FunTimeAuthHandler инициализирован");
      } catch (Exception var2) {
         Pulse.m().error("Ошибка инициализации FunTimeAuthHandler", (Throwable)var2);
      }
   }

   @EventHandler
   public void a(GameJoinEvent var1) {
      String var2 = this.f();
      if (FunTimeDomains.a(var2)) {
         new Thread(() -> {
            try {
               Thread.sleep(3000L);
            } catch (InterruptedException var2x) {
               return;
            }

            d.execute(this::d);
         }, "ftauth-probe").start();
      }
   }

   private void d() {
      try {
         if (d == null || d.player == null || d.getNetworkHandler() == null) {
            return;
         }

         if (!ClientPlayNetworking.canSend(FunTimeAuthHandler.FtAuthPayload.a)) {
            return;
         }

         JSONObject var1 = new JSONObject();
         var1.put("t", "hello");
         var1.put("v", 1);
         a(var1);
      } catch (Exception var2) {
         Pulse.m().warn("FtAuth probe failed: {}", var2.getMessage());
      }
   }

   private void a(String var1) {
      try {
         JSONObject var2 = new JSONObject(var1);
         String var3 = var2.optString("t", "");
         switch (var3) {
            case "hello_ack":
               this.e();
               break;
            case "auth_ok":
               Pulse.m().info("FtAuth: verified by FunTime");
               break;
            case "auth_err":
               Pulse.m().warn("FtAuth: rejected by FunTime: {}", var2.optString("reason", "?"));
         }
      } catch (Exception var6) {
         Pulse.m().warn("FtAuth: bad incoming message: {}", var6.getMessage());
      }
   }

   private void e() {
      String var1 = this.f();
      String var2 = d != null && d.getSession() != null ? d.getSession().getUsername() : null;
      new Thread(() -> {
         RealtimeSyncServiceV2 var2x = RealtimeSyncServiceV2.L();
         String var3 = null;

         for (int var4 = 0; var4 < 3 && var3 == null; var4++) {
            var3 = var2x.b(var1, var2);
            if (var3 == null) {
               try {
                  Thread.sleep(1000L);
               } catch (InterruptedException var6) {
                  return;
               }
            }
         }

         if (var3 == null) {
            Pulse.m().warn("FtAuth: no ticket available, skipping auth");
         } else {
            String var7 = var3;
            d.execute(() -> {
               JSONObject var1xx = new JSONObject();
               var1xx.put("t", "auth");
               var1xx.put("v", 1);
               var1xx.put("ticket", var7);
               a(var1xx);
            });
         }
      }, "ftauth-ticket").start();
   }

   private static void a(JSONObject var0) {
      try {
         ClientPlayNetworking.send(new FunTimeAuthHandler.FtAuthPayload(var0.toString()));
      } catch (Exception var2) {
         Pulse.m().error("FtAuth send failed", (Throwable)var2);
      }
   }

   private String f() {
      return d != null && d.getCurrentServerEntry() != null ? d.getCurrentServerEntry().address : null;
   }

   @Environment(EnvType.CLIENT)
   public static class FtAuthPayload implements CustomPayload {
      public static final Id<FunTimeAuthHandler.FtAuthPayload> a = new Id<>(FunTimeAuthHandler.a);
      public static final PacketCodec<RegistryByteBuf, FunTimeAuthHandler.FtAuthPayload> b = PacketCodec.of(
         (var0, var1) -> var1.writeBytes(var0.c.getBytes(StandardCharsets.UTF_8)), var0 -> {
            byte[] var1 = new byte[var0.readableBytes()];
            var0.readBytes(var1);
            return new FunTimeAuthHandler.FtAuthPayload(new String(var1, StandardCharsets.UTF_8));
         }
      );
      private final String c;

      public FtAuthPayload(String var1) {
         this.c = var1;
      }

      public String a() {
         return this.c;
      }

      @Override
      public Id<? extends CustomPayload> getId() {
         return a;
      }
   }
}
