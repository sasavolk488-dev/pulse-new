package pulse.features.modules.visuals.sounds;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.BiConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import pulse.core.api.IMinecraft;
import pulse.features.modules.utilities.ft.DetectedSound;
import pulse.features.modules.utilities.ft.FunTimeItemType;
import pulse.features.modules.utilities.ft.SoundSignature;
import pulse.features.modules.utilities.ft.StructureSignature;
import pulse.features.modules.utilities.ft.StructureSignatures;

@Environment(EnvType.CLIENT)
public final class StructureSoundReplacer implements IMinecraft {
   private static final long a = 300L;
   private static final long b = 1500L;
   private final Queue<DetectedSound> c = new ConcurrentLinkedQueue<>();
   private final Map<BlockPos, StructureSoundReplacer.Burst> f = new HashMap<>();

   public boolean a(PlaySoundS2CPacket var1) {
      if (var1.getCategory() != SoundCategory.RECORDS) {
         return false;
      } else {
         Identifier var2 = a(var1.getSound());
         if (var2 == null) {
            return false;
         } else {
            Vec3d var3 = new Vec3d(var1.getX(), var1.getY(), var1.getZ());
            DetectedSound var4 = new DetectedSound(
               var2, var1.getCategory(), var1.getVolume(), var1.getPitch(), var3, BlockPos.ofFloored(var3), System.currentTimeMillis()
            );
            if (a(var4).isEmpty()) {
               return false;
            } else {
               this.c.add(var4);
               return true;
            }
         }
      }
   }

   public void a(BiConsumer<FunTimeItemType, Float> var1) {
      long var2 = System.currentTimeMillis();
      if (d.player != null && d.world != null) {
         DetectedSound var4;
         while ((var4 = this.c.poll()) != null) {
            StructureSoundReplacer.Burst var5 = this.f.computeIfAbsent(var4.blockPos(), var0 -> new StructureSoundReplacer.Burst());
            if (!var5.d) {
               var5.a.add(var4);
            }

            var5.b = var4.pos();
            var5.c = var2;
         }

         Iterator var9 = this.f.entrySet().iterator();

         while (var9.hasNext()) {
            StructureSoundReplacer.Burst var6 = (StructureSoundReplacer.Burst)((Entry)var9.next()).getValue();
            if (var2 - var6.c > 1500L) {
               var9.remove();
            } else if (!var6.d) {
               FunTimeItemType var7 = a(var6.a);
               if (var7 != FunTimeItemType.c || var2 - var6.c >= 300L) {
                  if (var7 == FunTimeItemType.c) {
                     var7 = b(var6.a);
                  }

                  var6.d = true;
                  if (var7 != FunTimeItemType.c) {
                     float var8 = SoundDistance.a(var6.b);
                     if (var8 > 0.0F) {
                        var1.accept(var7, var8);
                     }
                  }
               }
            }
         }
      } else {
         this.a();
      }
   }

   public void a() {
      this.c.clear();
      this.f.clear();
   }

   private static FunTimeItemType a(List<DetectedSound> var0) {
      for (StructureSignature var2 : StructureSignatures.a()) {
         if (a(var0, var2)) {
            return var2.type();
         }
      }

      return FunTimeItemType.c;
   }

   private static boolean a(List<DetectedSound> var0, StructureSignature var1) {
      ArrayList<DetectedSound> var2 = new ArrayList<>(var0);

      for (SoundSignature var4 : var1.sounds()) {
         DetectedSound var5 = null;

         for (DetectedSound var7 : var2) {
            if (var4.a(var7)) {
               var5 = var7;
               break;
            }
         }

         if (var5 == null) {
            return false;
         }

         var2.remove(var5);
      }

      return true;
   }

   private static FunTimeItemType b(List<DetectedSound> var0) {
      boolean var1 = false;
      boolean var2 = false;
      EnumSet var3 = EnumSet.noneOf(FunTimeItemType.class);

      for (DetectedSound var5 : var0) {
         EnumSet var6 = a(var5);
         var3.addAll(var6);
         if (var6.size() == 1) {
            if (var6.contains(FunTimeItemType.a)) {
               var1 = true;
            } else if (var6.contains(FunTimeItemType.b)) {
               var2 = true;
            }
         }
      }

      if (var1 != var2) {
         return var1 ? FunTimeItemType.a : FunTimeItemType.b;
      } else if (var3.contains(FunTimeItemType.a)) {
         return FunTimeItemType.a;
      } else {
         return var3.contains(FunTimeItemType.b) ? FunTimeItemType.b : FunTimeItemType.c;
      }
   }

   private static EnumSet<FunTimeItemType> a(DetectedSound var0) {
      EnumSet var1 = EnumSet.noneOf(FunTimeItemType.class);

      for (StructureSignature var3 : StructureSignatures.a()) {
         if (!var1.contains(var3.type())) {
            for (SoundSignature var5 : var3.sounds()) {
               if (var5.a(var0)) {
                  var1.add(var3.type());
                  break;
               }
            }
         }
      }

      return var1;
   }

   private static Identifier a(RegistryEntry<SoundEvent> var0) {
      return var0.getKey().map(var0x -> var0x.getValue()).orElse(null);
   }

   @Environment(EnvType.CLIENT)
   private static final class Burst {
      private final List<DetectedSound> a = new ArrayList<>(4);
      private Vec3d b;
      private long c;
      private boolean d;
   }
}
