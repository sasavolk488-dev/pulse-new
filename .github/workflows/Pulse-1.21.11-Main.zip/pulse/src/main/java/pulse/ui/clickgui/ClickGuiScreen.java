package pulse.ui.clickgui;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.common.BackgroundElement;
import pulse.ui.clickgui.common.CategoriesElement;
import pulse.ui.clickgui.common.HeaderElement;
import pulse.ui.clickgui.common.OverlayElement;
import pulse.ui.clickgui.common.SettingsPanelElement;
import pulse.ui.clickgui.common.settings.InputSettingElement;
import pulse.ui.clickgui.common.settings.ItemIconRenderQueue;
import pulse.ui.clickgui.menu.configs.ConfigsMenu;
import pulse.ui.clickgui.menu.events.EventsMenu;
import pulse.ui.clickgui.menu.friends.FriendsMenu;
import pulse.ui.clickgui.menu.markers.MarkersMenu;
import pulse.ui.clickgui.menu.modules.ModulesMenu;
import pulse.core.api.IMinecraft;
import pulse.utils.render.AlphaFramebuffer;
import pulse.utils.render.Render;
import pulse.utils.render.core.Renderer2D;
import pulse.utils.render.LayerManager;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.ScaleUtils;
import pulse.utils.render.TextureRegistry;
import pulse.utils.math.Vec2i;

@Environment(EnvType.CLIENT)
public class ClickGuiScreen extends Screen {
   private static final float a = 411.0F;
   private static final float b = 243.5F;
   private static final float c = 9.5F;
   private static final float d = 26.0F;
   private static final double e = 0.35000005980848903;
   private final BackgroundElement f;
   private final HeaderElement g;
   private final CategoriesElement h;
   private final SettingsPanelElement i;
   private final Map<MenuType, Menu> j;
   private MenuType k = MenuType.a;
   private MenuType l = null;
   private final Animation m = new Animation();
   private boolean n = false;
   private int o = 1;
   private int p = 0;
   private int q = 0;
   private MatrixStack r = new MatrixStack();

   public ClickGuiScreen() {
      super(Text.literal("ClickGui"));
      this.f = new BackgroundElement();
      this.g = new HeaderElement();
      this.j = new HashMap<>();
      this.j.put(MenuType.a, new ModulesMenu());
      this.j.put(MenuType.b, new MarkersMenu());
      this.j.put(MenuType.c, new FriendsMenu());
      this.j.put(MenuType.d, new EventsMenu());
      this.j.put(MenuType.e, new ConfigsMenu());
      this.h = new CategoriesElement(this);
      this.i = new SettingsPanelElement(this);
      this.m.d(1.0);
   }

   @Override
   protected void init() {
      super.init();
      Pulse.l().a(this);
      GuiOverlay.a().b();
   }

   public void a() {
      if (!GuiOverlay.a().g()) {
         this.p();
         OverlayElement.a().f();
         InputSettingElement.o();
         MouseUtil.l();
         MouseUtil.a();
         GuiOverlay.a().c();
         IMinecraft.d.setScreen(null);
      }
   }

   public void a(MenuType var1) {
      if (this.k != var1) {
         Menu var2 = this.b();
         if (var2 instanceof ModulesMenu) {
            ((ModulesMenu)var2).k();
         }

         if (var2 instanceof MarkersMenu) {
            ((MarkersMenu)var2).e();
         }

         this.l = this.k;
         this.k = var1;
         this.o = this.a(this.l, var1);
         this.n = true;
         this.m.d(0.0);
         this.m.a(1.0, 0.35000005980848903, Easings.n);
      }
   }

   public void a(MenuType var1, int var2) {
      if (this.k != var1) {
         Menu var3 = this.b();
         if (var3 instanceof ModulesMenu) {
            ((ModulesMenu)var3).k();
         }

         if (var3 instanceof MarkersMenu) {
            ((MarkersMenu)var3).e();
         }

         this.l = this.k;
         this.k = var1;
         this.o = var2;
         this.n = true;
         this.m.d(0.0);
         this.m.a(1.0, 0.35000005980848903, Easings.n);
      }
   }

   private int a(MenuType var1, MenuType var2) {
      int var3 = var1.ordinal();
      int var4 = var2.ordinal();
      return var4 > var3 ? 1 : -1;
   }

   public Menu b() {
      return this.j.get(this.k);
   }

   public Menu c() {
      return this.l != null ? this.j.get(this.l) : null;
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   public void a(int var1, int var2, float var3) {
      this.a(var1, var2, var3, -1.0F);
   }

   public void a(int var1, int var2, float var3, float var4) {
      if (!this.r.isEmpty()) {
         this.r = new MatrixStack();
      }

      this.r.loadIdentity();
      MouseUtil.h();
      float var5 = var4 >= 0.0F ? var4 : GuiOverlay.a().d();
      ScaleUtils.a(2.0);
      Vec2i var6 = ScaleUtils.a((double)var1, (double)var2);
      int var7 = var6.a();
      int var8 = var6.b();
      this.p = var7;
      this.q = var8;
      LayerManager.a().b();
      LayerManager.a().a(var7, var8);
      float var9 = IMinecraft.u().getWidth() / 2.0F;
      float var10 = IMinecraft.u().getHeight() / 2.0F;
      Render var11 = Pulse.l().p();
      ItemIconRenderQueue.b();
      float var12 = IMinecraft.u().getWidth() / 4.0F - 205.5F;
      float var13 = IMinecraft.u().getHeight() / 4.0F - 121.75F;
      Renderer2D var14 = Pulse.l().o();
      MinecraftClient var15 = MinecraftClient.getInstance();
      int var16 = var15.getWindow().getFramebufferWidth();
      int var17 = var15.getWindow().getFramebufferHeight();

      try {
         var14.a(var16, var17);

         try {
            var14.b(2.0F, 2.0F);

            try {
               AlphaFramebuffer.a(0.0F, 0.0F, var9, var10);
               var11.a(TextureRegistry.a("shadow"), 0.0F, 0.0F, var9, var10, Color.WHITE, this.r);
               this.a(this.r, var11, var12, var13);
               var14.a();
            } finally {
               var14.h();
            }

            AlphaFramebuffer.a(var11, var5, this.r);
         } finally {
            var14.c();
         }
      } catch (Throwable var28) {
         var28.printStackTrace();
      }

      if (var4 < 0.0F) {
         ItemIconRenderQueue.a();
      } else {
         ItemIconRenderQueue.b();
      }

      MouseUtil.i();
      ScaleUtils.a();
   }

   @Compile
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      int mouseX = this.p;
      int mouseY = this.q;
      this.g.a(var1, var2, var3, var4, this.p, this.q);
      this.m.a();
      if (this.n && this.m.d()) {
         this.n = false;
         this.l = null;
      }
      float progress = (float)this.m.j();
      boolean horizontal = this.h.a() == CategoriesElement.Position.a;
      float horizontalDistance = IMinecraft.u().getWidth() * 0.25F + 205.5F + 50.0F;
      float verticalDistance = IMinecraft.u().getHeight() * 0.25F + 121.75F + 50.0F;
      if (this.n && this.l != null) {
         Menu previous = this.c();
         if (previous != null) {
            float offsetX = 0.0F;
            float offsetY = 0.0F;
            if (horizontal) {
               offsetX = progress * horizontalDistance * -this.o;
            } else {
               offsetY = progress * verticalDistance * -this.o;
            }
            this.a(var1, var2, offsetX + var3, offsetY + var4, mouseX, mouseY, previous);
         }
      }
      Menu current = this.b();
      if (current != null) {
         if (this.n) {
            float offsetX = 0.0F;
            float offsetY = 0.0F;
            float remaining = 1.0F - progress;
            if (horizontal) {
               offsetX = remaining * horizontalDistance * this.o;
            } else {
               offsetY = remaining * verticalDistance * this.o;
            }
            this.a(var1, var2, offsetX + var3, offsetY + var4, mouseX, mouseY, current);
         } else {
            this.a(var1, var2, var3, var4, mouseX, mouseY, current);
         }
      }
      if (this.h.d()) {
         this.i.a(var1, var2, var3, var4, mouseX, mouseY);
         if (current instanceof ModulesMenu) {
            ((ModulesMenu)current).a(var1, var2, mouseX, mouseY);
         }
         OverlayElement.a().a(var1, var2);
         this.h.b(var1, var2, var3, var4, mouseX, mouseY);
         this.h.a(var1, var2, var3, var4, mouseX, mouseY);
         this.i.a(var1, var2, mouseX, mouseY);
         return;
      }
      this.h.a(var1, var2, var3, var4, mouseX, mouseY);
      this.i.a(var1, var2, var3, var4, mouseX, mouseY);
      OverlayElement.a().a(var1, var2);
      if (current instanceof ModulesMenu) {
         ((ModulesMenu)current).a(var1, var2, mouseX, mouseY);
      }
      if (current instanceof MarkersMenu) {
         ((MarkersMenu)current).a(var1, var2, mouseX, mouseY);
      }
      if (current instanceof ConfigsMenu) {
         ((ConfigsMenu)current).a(var1, var2);
      }
      if (current instanceof FriendsMenu) {
         ((FriendsMenu)current).a(var1, var2);
      }
      this.i.a(var1, var2, mouseX, mouseY);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, Menu var7) {
      this.f.a(var1, var2, var3, var4, var5, var6);
      this.f.b(var1, var2, var3, var4, var5, var6);
      if (var7 != null) {
         var7.a(var1, var2, var3, var4, var5, var6);
      }
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      double var3 = click.x();
      double var5 = click.y();
      int var7 = click.button();
      Vec2i var8 = ScaleUtils.a(var3, var5);
      int var9 = var8.a();
      int var10 = var8.b();
      float var11 = IMinecraft.u().getWidth() / 4.0F - 205.5F;
      float var12 = IMinecraft.u().getHeight() / 4.0F - 121.75F;
      if (var7 == 0) {
         this.h.a(var11, var12, var9, var10);
         if (!this.n && !this.h.d()) {
            Menu var13 = this.b();
            if (var13 != null) {
               var13.a(var11, var12, var9, var10);
            }
         }
      } else if (var7 == 1 && !this.n && !this.h.d()) {
         Menu var15 = this.b();
         if (var15 != null) {
            var15.b(var11, var12, var9, var10);
         }
      } else if (var7 >= 2) {
         Menu var14 = this.b();
         if (var14 != null && var14.b()) {
            var14.a(1450 + var7, 0, 0);
            return true;
         }
      }

      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseReleased(Click click) {
      double var2 = click.x();
      double var4 = click.y();
      int var6 = click.button();
      if (var6 != 0) {
         return super.mouseReleased(click);
      } else {
         Vec2i var7 = ScaleUtils.a(var2, var4);
         int var8 = var7.a();
         int var9 = var7.b();
         float var10 = IMinecraft.u().getWidth() / 4.0F - 205.5F;
         float var11 = IMinecraft.u().getHeight() / 4.0F - 121.75F;
         this.h.c(var10, var11, var8, var9);
         Menu var12 = this.b();
         if (var12 != null) {
            var12.c(var10, var11, var8, var9);
         }

         return super.mouseReleased(click);
      }
   }

   @Override
   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      double var6 = click.x();
      double var8 = click.y();
      int var10 = click.button();
      if (var10 != 0) {
         return super.mouseDragged(click, offsetX, offsetY);
      } else {
         Vec2i var11 = ScaleUtils.a(var6, var8);
         int var12 = var11.a();
         int var13 = var11.b();
         float var14 = IMinecraft.u().getWidth() / 4.0F - 205.5F;
         float var15 = IMinecraft.u().getHeight() / 4.0F - 121.75F;
         this.h.a(var14, var15, var12, var13, offsetX, offsetY);
         if (!this.n && !this.h.d()) {
            Menu var16 = this.b();
            if (var16 != null) {
               var16.a(var14, var15, var12, var13, offsetX, offsetY);
            }
         }

         return super.mouseDragged(click, offsetX, offsetY);
      }
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (!this.n && !this.h.d()) {
         Menu var9 = this.b();
         if (var9 != null) {
            var9.a((float)verticalAmount);
         }

         return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
      } else {
         return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      int var2 = input.key();
      int var3 = input.scancode();
      int var4 = input.modifiers();
      Menu var5 = this.b();
      if (var5 != null && var5.b() && var5.a(var2, var3, var4)) {
         return true;
      } else if (var2 == 256) {
         if (OverlayElement.a().b()) {
            this.d();
            return true;
         } else {
            this.a();
            return true;
         }
      } else if (this.h.d()) {
         return super.keyPressed(input);
      } else if (var2 == 262) {
         this.n();
         return true;
      } else if (var2 == 263) {
         this.o();
         return true;
      } else {
         if (!this.n) {
            if (var2 == 265) {
               if (var5 != null) {
                  var5.a(1.0F);
               }

               return true;
            }

            if (var2 == 264) {
               if (var5 != null) {
                  var5.a(-1.0F);
               }

               return true;
            }
         }

         return super.keyPressed(input);
      }
   }

   @Override
   public boolean charTyped(CharInput input) {
      char var2 = (char)input.codepoint();
      int var3 = input.modifiers();
      Menu var4 = this.b();
      if (var4 instanceof ModulesMenu var5 && var5.a(var2, var3)) {
         return true;
      } else if (var4 instanceof MarkersMenu var6 && var6.a(var2, var3)) {
         return true;
      } else if (var4 instanceof FriendsMenu var7 && var7.a(var2, var3)) {
         return true;
      } else if (var4 instanceof EventsMenu var8 && var8.a(var2, var3)) {
         return true;
      } else {
         return var4 instanceof ConfigsMenu var9 && var9.a(var2, var3) ? true : super.charTyped(input);
      }
   }

   private void n() {
      MenuType[] var1 = MenuType.values();
      int var2 = this.k.ordinal();
      int var3 = (var2 + 1) % var1.length;
      this.a(var1[var3], 1);
   }

   private void o() {
      MenuType[] var1 = MenuType.values();
      int var2 = this.k.ordinal();
      int var3 = (var2 - 1 + var1.length) % var1.length;
      this.a(var1[var3], -1);
   }

   public void d() {
      Menu var1 = this.b();
      if (var1 instanceof ModulesMenu var2) {
         var2.m();
         var2.n();
      }

      if (var1 instanceof MarkersMenu) {
         ((MarkersMenu)var1).e();
         ((MarkersMenu)var1).f();
      }

      if (this.h.d()) {
         this.h.e();
      }

      OverlayElement.a().a(false);
      OverlayElement.a().c(false);
      MouseUtil.a();
   }

   private void p() {
      Menu var1 = this.b();
      if (var1 instanceof ModulesMenu) {
         ((ModulesMenu)var1).o();
      }

      if (var1 instanceof MarkersMenu) {
         ((MarkersMenu)var1).e();
         ((MarkersMenu)var1).f();
      }

      if (this.h.d()) {
         this.h.e();
      }
   }

   @Override
   public void close() {
      if (GuiOverlay.a().f() && !GuiOverlay.a().g()) {
         this.a();
      }
   }

   @Override
   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   public static float e() {
      return 411.0F;
   }

   public static float f() {
      return 243.5F;
   }

   public static float g() {
      return 9.5F;
   }

   public static float h() {
      return 26.0F;
   }

   public FriendsMenu i() {
      Menu var1 = this.j.get(MenuType.c);
      return var1 instanceof FriendsMenu ? (FriendsMenu)var1 : null;
   }

   public ConfigsMenu j() {
      Menu var1 = this.j.get(MenuType.e);
      return var1 instanceof ConfigsMenu ? (ConfigsMenu)var1 : null;
   }

   public CategoriesElement k() {
      return this.h;
   }

   @Generated
   public MenuType l() {
      return this.k;
   }

   @Generated
   public boolean m() {
      return this.n;
   }

   static {
      NativeMethodLookup.lookup(ClickGuiScreen.class, 1);
   }
}
