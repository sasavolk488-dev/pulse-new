package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.ui.clickgui.keybind.KeybindManagerScreen;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.PVPSafeModule;
import pulse.utils.game.PVPUtils;

@Environment(EnvType.CLIENT)
@Mixin({GameMenuScreen.class})
public abstract class GameMenuScreenMixin extends Screen {
   @Shadow
   @Nullable
   private ButtonWidget exitButton;

   protected GameMenuScreenMixin(Text var1) {
      super(var1);
   }

   @Inject(
      method = {"initWidgets"},
      at = {@At("TAIL")}
   )
   private void pulse$wrapExitButton(CallbackInfo var1) {
      if (this.exitButton != null) {
         ButtonWidget var2 = this.exitButton;
         Text var3 = var2.getMessage();
         int var4 = var2.getX();
         int var5 = var2.getY();
         int var6 = var2.getWidth();
         int var7 = var2.getHeight();
         this.remove(var2);
         ButtonWidget var8 = ButtonWidget.builder(var3, var1x -> {
            MinecraftClient var2x = MinecraftClient.getInstance();
            PVPSafeModule var3x = ModuleRegistry.I;
            if (var3x != null && var3x.k() && PVPUtils.a().a()) {
               var2x.setScreen(new ConfirmScreen(var2xx -> {
                  if (var2xx) {
                     var2x.disconnect(ClientWorld.QUITTING_MULTIPLAYER_TEXT);
                  } else {
                     var2x.setScreen(this);
                  }
               }, Text.literal("Вы уверены что хотите выйти с сервера в режиме PvP?"), Text.empty()));
            } else {
               var2x.disconnect(ClientWorld.QUITTING_MULTIPLAYER_TEXT);
            }
         }).dimensions(var4, var5, var6, var7).build();
         this.exitButton = var8;
         this.addDrawableChild(var8);
         int var9 = var7 + 4;
         int var10 = Integer.MIN_VALUE;

         for (Element var12 : this.children()) {
            if (var12 instanceof ButtonWidget var13 && var13 != this.exitButton) {
               int var14 = var13.getY();
               if (var14 < var5 && var14 > var10) {
                  var10 = var14;
               }
            }
         }

         int var15;
         if (var10 != Integer.MIN_VALUE) {
            for (Element var18 : this.children()) {
               if (var18 instanceof ButtonWidget var19 && var19.getY() >= var10) {
                  var19.setY(var19.getY() + var9);
               }
            }

            var15 = var10;
         } else {
            var15 = var5 + var9;
         }

         ButtonWidget var17 = ButtonWidget.builder(
               Text.literal("Кейбинд менеджер"), var0 -> MinecraftClient.getInstance().setScreen(new KeybindManagerScreen())
            )
            .dimensions(var4, var15, var6, var7)
            .build();
         this.addDrawableChild(var17);
      }
   }
}
