package pulse.core.settings;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Util;

@Environment(EnvType.CLIENT)
public class FolderSetting extends Setting<String> {
   private static final long a = 1000L;
   private final String b;
   private final String[] c;
   private List<File> d = new ArrayList<>();
   private long e;

   public FolderSetting(String var1, String var2, String var3, String... var4) {
      super(var1, var2, "");
      this.b = var3;
      this.c = var4;
   }

   public File b() {
      File var1 = new File(MinecraftClient.getInstance().runDirectory, this.b);
      if (!var1.exists()) {
         var1.mkdirs();
      }

      return var1;
   }

   public void c() {
      Util.getOperatingSystem().open(this.b().toURI());
   }

   public List<File> d() {
      long var1 = System.currentTimeMillis();
      if (var1 - this.e >= 1000L) {
         this.e = var1;
         this.d = this.h();
      }

      return this.d;
   }

   public List<String> e() {
      ArrayList<String> var1 = new ArrayList<>();

      for (File var3 : this.d()) {
         var1.add(var3.getName());
      }

      return var1;
   }

   public File f() {
      List<File> var1 = this.d();
      if (var1.isEmpty()) {
         return null;
      } else {
         String var2 = this.q();
         if (var2 != null && !var2.isEmpty()) {
            for (File var4 : var1) {
               if (var4.getName().equals(var2)) {
                  return var4;
               }
            }
         }

         return (File)var1.get(0);
      }
   }

   public String g() {
      File var1 = this.f();
      return var1 == null ? null : var1.getName();
   }

   public void a(String var1) {
      this.a((String)var1);
   }

   private List<File> h() {
      File[] var1 = this.b().listFiles(File::isFile);
      ArrayList<File> var2 = new ArrayList<>();
      if (var1 == null) {
         return var2;
      } else {
         for (File var6 : var1) {
            if (this.b(var6.getName())) {
               var2.add(var6);
            }
         }

         var2.sort(Comparator.comparing(var0 -> var0.getName().toLowerCase(Locale.ROOT)));
         return var2;
      }
   }

   private boolean b(String var1) {
      if (this.c.length == 0) {
         return true;
      } else {
         String var2 = var1.toLowerCase(Locale.ROOT);

         for (String var6 : this.c) {
            if (var2.endsWith("." + var6)) {
               return true;
            }
         }

         return false;
      }
   }

   public FolderSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
