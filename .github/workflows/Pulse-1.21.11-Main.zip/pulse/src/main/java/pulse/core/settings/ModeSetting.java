package pulse.core.settings;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ModeSetting extends Setting<Integer> {
   private final String[] a;
   private final boolean b;
   private final Set<Integer> c;

   public ModeSetting(String var1, String var2, String[] var3, int var4) {
      super(var1, var2, var4);
      this.a = var3;
      this.b = false;
      this.c = new HashSet<>();
   }

   public ModeSetting(String var1, String[] var2, int var3) {
      this(var1, "", var2, var3);
   }

   public ModeSetting(String var1, String[] var2, String var3) {
      this(var1, "", var2, a(var2, var3));
   }

   public ModeSetting(String var1, String var2, String[] var3, int[] var4) {
      super(var1, var2, var4.length > 0 ? var4[0] : 0);
      this.a = var3;
      this.b = true;
      this.c = new HashSet<>();

      for (int var8 : var4) {
         if (var8 >= 0 && var8 < var3.length) {
            this.c.add(var8);
         }
      }
   }

   public ModeSetting(String var1, String[] var2, int[] var3) {
      this(var1, "", var2, var3);
   }

   private static int a(String[] var0, String var1) {
      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var0[var2].equals(var1)) {
            return var2;
         }
      }

      return 0;
   }

   public String[] b() {
      return this.a;
   }

   public List<String> c() {
      return Arrays.asList(this.a);
   }

   public boolean d() {
      return this.b;
   }

   public String e() {
      int var1 = this.q();
      if (var1 < 0 || var1 >= this.a.length) {
         var1 = 0;
         this.a(Integer.valueOf(0));
      }

      return this.a[var1];
   }

   public void a(String var1) {
      for (int var2 = 0; var2 < this.a.length; var2++) {
         if (this.a[var2].equals(var1)) {
            this.a(Integer.valueOf(var2));
            break;
         }
      }
   }

   public Set<Integer> f() {
      if (this.b) {
         return new HashSet<>(this.c);
      } else {
         HashSet var1 = new HashSet();
         var1.add(this.q());
         return var1;
      }
   }

   public boolean a(int var1) {
      return this.b ? this.c.contains(var1) : var1 == this.q();
   }

   public void b(int var1) {
      if (this.b && var1 >= 0 && var1 < this.a.length) {
         if (this.c.contains(var1)) {
            this.c.remove(var1);
         } else {
            this.c.add(var1);
         }

         if (!this.c.isEmpty()) {
            this.a(this.c.iterator().next());
         }
      }
   }

   public void a(Set<Integer> var1) {
      this.c.clear();

      for (int var3 : var1) {
         if (var3 >= 0 && var3 < this.a.length) {
            this.c.add(var3);
         }
      }

      if (!this.c.isEmpty()) {
         this.a(this.c.iterator().next());
      }
   }

   public boolean b(String var1) {
      return this.b ? this.c(var1) : this.e().equals(var1);
   }

   public boolean c(int var1) {
      return this.b ? this.a(var1) : this.q() == var1;
   }

   public boolean c(String var1) {
      for (int var2 = 0; var2 < this.a.length; var2++) {
         if (this.a[var2].equals(var1) && this.a(var2)) {
            return true;
         }
      }

      return false;
   }

   public ModeSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
