package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.client.sound.SoundSystem.PlayResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.emote.EmoteAudio;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.PlaySoundEvent;
import pulse.mixin.accessor.AbstractSoundInstanceAccessor;
import pulse.features.phrase.PhraseAudio;

@Environment(EnvType.CLIENT)
@Mixin({SoundSystem.class})
public class SoundSystemMixin {
   private static final float EPS = 1.0E-6F;

   @Inject(
      method = {"reloadSounds"},
      at = {@At("TAIL")}
   )
   private void pulse$onSoundEngineReload(CallbackInfo var1) {
      PhraseAudio.a();
      EmoteAudio.a();
   }

   @Inject(
      method = {"play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$onPlaySound(SoundInstance var1, CallbackInfoReturnable<PlayResult> var2) {
      if (var1 != null) {
         PlaySoundEvent var3 = new PlaySoundEvent(var1);
         EventHandler.a.post(var3);
         if (var3.c()) {
            var2.setReturnValue(PlayResult.NOT_STARTED);
         } else {
            if (var1 instanceof AbstractSoundInstance) {
               AbstractSoundInstanceAccessor var4 = (AbstractSoundInstanceAccessor)var1;
               if (var3.g() != var3.e()) {
                  float var5 = var3.e();
                  if (var5 > 1.0E-6F) {
                     var4.pulse$setVolume(var4.pulse$getVolume() * (var3.g() / var5));
                  } else {
                     var4.pulse$setVolume(var3.g());
                  }
               }

               if (var3.h() != var3.f()) {
                  float var6 = var3.f();
                  if (var6 > 1.0E-6F) {
                     var4.pulse$setPitch(var4.pulse$getPitch() * (var3.h() / var6));
                  } else {
                     var4.pulse$setPitch(var3.h());
                  }
               }
            }
         }
      }
   }
}
