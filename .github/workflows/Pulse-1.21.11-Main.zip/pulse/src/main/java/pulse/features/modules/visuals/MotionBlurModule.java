package pulse.features.modules.visuals;

import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.render.world.MotionBlur;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Motion Blur",
   b = "Размытие мира при движении камеры",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class MotionBlurModule extends Module {
   private final NumberSetting a = new NumberSetting("Сила", "Интенсивность размытия", 50.0F, 1.0F, 100.0F, 1.0F);

   public float n() {
      return this.a.b();
   }

   @Override
   public void f() {
      MotionBlur.a();
   }

   @EventHandler
   public void a(WorldChangeEvent var1) {
      MotionBlur.a();
   }
}
