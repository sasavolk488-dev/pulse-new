package pulse.features.modules.utilities.ft;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public record StructureSignature(String id, FunTimeItemType type, long durationMs, List<SoundSignature> sounds) {
   public int a() {
      return this.sounds.size();
   }
}
