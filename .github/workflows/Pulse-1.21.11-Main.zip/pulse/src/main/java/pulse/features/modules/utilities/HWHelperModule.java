package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.menu.markers.MarkerEntry;
import pulse.ui.clickgui.menu.markers.MarkerManager;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;
import pulse.utils.game.ChatUtils;
import pulse.utils.game.EntityUtils;
import pulse.utils.game.FriendUtils;
import pulse.utils.render.RenderUtils;
import pulse.utils.game.entity.EntityFinder;
import pulse.utils.game.entity.EntityTags;

@ModuleInfo(
   a = "HW Helper",
   b = "ESP на стан и взрывную трапку",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class HWHelperModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Стан", true);
   private final BooleanSetting b = new BooleanSetting("Взрывная трапка", true);
   private final BooleanSetting c = new BooleanSetting("Трапка", true);
   private final BooleanSetting f = new BooleanSetting("Бур хелпер", true);
   private final BooleanSetting g = new BooleanSetting("Светильник Джейка", true);
   private final SeparatorSetting h = new SeparatorSetting("Настройки трапок");
   private final BooleanSetting i = new BooleanSetting("Таймер действия", true);
   private final SeparatorSetting j = new SeparatorSetting("Особый компас");
   private final BooleanSetting k = new BooleanSetting("Таймер компаса", true);
   private final BooleanSetting l = new BooleanSetting("Координаты цели", true);
   private final BooleanSetting m = new BooleanSetting("Метка сокровища", true);
   private final SeparatorSetting n = new SeparatorSetting("Аукцион");
   private final BooleanSetting o = new BooleanSetting("Цена в коинах", true);
   private final SeparatorSetting p = new SeparatorSetting("Золотые спавнеры");
   private final BooleanSetting q = new BooleanSetting("Данные спавнера", true);
   private final BooleanSetting r = new BooleanSetting("Подсветка (фармер=зелёный)", true);
   private final SeparatorSetting s = new SeparatorSetting("Биржа коинов");
   private final BooleanSetting t = new BooleanSetting("Инфо по заявкам", true);
   private boolean u = false;
   private static final Pattern v = Pattern.compile("([0-9][0-9\\s\\u00a0]*)\\s*¤");
   private static final Pattern w = Pattern.compile("([0-9][0-9\\s\\u00a0,]*)");
   private static final String x = "mob-farmer-enchant";
   private static final int y = 1714683733;
   private static final int z = 1728000819;
   private static final IdentityHashMap<NbtComponent, Integer> A = new IdentityHashMap<>();
   private static final int B = 11962111;
   private boolean C = false;
   private long D = 0L;
   private int E = 0;
   private boolean F = false;
   private long G = 0L;
   private int H = 0;
   private static final Pattern I = Pattern.compile("по координатам:\\s*(-?\\d+)\\s*,\\s*(-?\\d+)");

   public HWHelperModule() {
      this.p();
   }

   private void p() {
      if (!this.u) {
         this.u = true;
         ItemTooltipCallback.EVENT.register((var1, var2, var3, var4) -> {
            if (this.k()) {
               if (this.o.q()) {
                  this.b(var4);
               }

               if (this.t.q() && a(var4)) {
                  this.c(var4);
               }

               if (this.q.q()) {
                  this.a(var1, var4);
               }

               NbtCompound var5 = d(var1);
               if (var5 != null) {
                  if (this.k.q()) {
                     Optional var6 = var5.getLong("delay");
                     if (var6.isPresent()) {
                        long var7 = (Long)var6.get() - System.currentTimeMillis();
                        if (var7 <= 0L) {
                           var4.add(Text.literal("§aКомпас готов к использованию"));
                        } else {
                           var4.add(Text.literal("§7Перезарядка: §b" + b(var7)));
                        }
                     }
                  }

                  if (this.l.q()) {
                     Optional var12 = var5.getCompound("target");
                     if (var12.isPresent()) {
                        NbtCompound var13 = (NbtCompound)var12.get();
                        int var8 = var13.getInt("x", 0);
                        int var9 = var13.getInt("z", 0);
                        int var10 = var13.getInt("y", 0);
                        String var11 = var10 != 0 ? var8 + ", " + var10 + ", " + var9 : var8 + ", " + var9;
                        var4.add(Text.literal("§7Прошлая цель: §b" + var11));
                     }
                  }
               }
            }
         });
      }
   }

   public static List<HWHelperModule.PriceLine> a(ItemStack var0) {
      ArrayList var1 = new ArrayList();
      if (var0 != null && !var0.isEmpty()) {
         LoreComponent var2 = var0.get(DataComponentTypes.LORE);
         if (var2 == null) {
            return var1;
         } else {
            for (Text var4 : var2.lines()) {
               String var5 = var4.getString();
               int var6 = var5.indexOf("Цена");
               if (var6 >= 0 && var5.contains("¤")) {
                  Matcher var7 = v.matcher(var5);
                  if (var7.find()) {
                     String var8 = var7.group(1).replaceAll("[^0-9]", "");
                     if (!var8.isEmpty()) {
                        try {
                           long var9 = Long.parseLong(var8);
                           int var11 = var5.indexOf(58, var6);
                           String var12 = var5.substring(var6, var11 >= 0 ? var11 : var5.length()).trim();
                           var1.add(new HWHelperModule.PriceLine(var12, var9));
                        } catch (NumberFormatException var13) {
                        }
                     }
                  }
               }
            }

            return var1;
         }
      } else {
         return var1;
      }
   }

   public boolean n() {
      return this.k() && this.o.q();
   }

   public static String a(long var0) {
      return String.format("%,d", var0).replace(',', ' ').replace(' ', ' ');
   }

   private void b(List<Text> var1) {
      double var2 = RealtimeSyncServiceV2.L().h();
      if (!(var2 <= 0.0)) {
         boolean var4 = false;

         for (int var5 = 0; var5 < var1.size(); var5++) {
            String var6 = ((Text)var1.get(var5)).getString();
            long var7 = a(var6);
            if (var6.indexOf("Цена") >= 0 && var7 >= 0L) {
               long var9 = Math.round(var7 / var2);
               MutableText var11 = ((Text)var1.get(var5))
                  .copy()
                  .append(Text.literal(" (" + var9 + " ").formatted(Formatting.GRAY))
                  .append(q())
                  .append(Text.literal(")").formatted(Formatting.GRAY));
               var1.set(var5, var11);
               var4 = true;
            }
         }

         if (var4) {
            var1.add(Text.literal(""));
            var1.add(Text.literal("Курс: " + a(Math.round(var2)) + " ").formatted(Formatting.GRAY).append(q()));
         }
      }
   }

   private static long a(String var0) {
      Matcher var1 = v.matcher(var0);
      if (!var1.find()) {
         return -1L;
      } else {
         String var2 = var1.group(1).replaceAll("[^0-9]", "");
         if (var2.isEmpty()) {
            return -1L;
         } else {
            try {
               return Long.parseLong(var2);
            } catch (NumberFormatException var4) {
               return -1L;
            }
         }
      }
   }

   private static MutableText q() {
      Style var0 = Style.EMPTY.withColor(TextColor.fromRgb(12634624));
      Style var1 = Style.EMPTY.withColor(TextColor.fromRgb(15924992)).withBold(true);
      return Text.literal("|").setStyle(var0).append(Text.literal("❘").setStyle(var1)).append(Text.literal("|").setStyle(var0));
   }

   public static boolean a(List<Text> var0) {
      for (Text var2 : var0) {
         if (var2.getString().contains("за 1 коин")) {
            return true;
         }
      }

      return false;
   }

   private static long a(List<Text> var0, String var1) {
      for (Text var3 : var0) {
         String var4 = var3.getString();
         int var5 = var4.indexOf(var1);
         if (var5 >= 0) {
            Matcher var6 = w.matcher(var4.substring(var5 + var1.length()));
            if (var6.find()) {
               String var7 = var6.group(1).replaceAll("[^0-9]", "");
               if (!var7.isEmpty()) {
                  try {
                     return Long.parseLong(var7);
                  } catch (NumberFormatException var9) {
                  }
               }
            }
         }
      }

      return -1L;
   }

   public static long b(ItemStack var0) {
      if (var0 != null && !var0.isEmpty()) {
         LoreComponent var1 = var0.get(DataComponentTypes.LORE);
         return var1 != null && a(var1.lines()) ? a(var1.lines(), "Курс:") : -1L;
      } else {
         return -1L;
      }
   }

   public boolean o() {
      return this.k() && this.t.q();
   }

   private void c(List<Text> var1) {
      double var2 = RealtimeSyncServiceV2.L().h();
      if (!(var2 <= 0.0)) {
         long var4 = a(var1, "Курс:");
         if (var4 > 0L) {
            long var6 = a(var1, "Ожидается:");
            long var8 = a(var1, "Доступно:");
            double var10 = (var4 - var2) / var2 * 100.0;
            Formatting var12 = var10 > 0.0 ? Formatting.GREEN : Formatting.RED;
            String var13 = String.format("%+.1f%%", var10);

            for (int var14 = 0; var14 < var1.size(); var14++) {
               String var15 = ((Text)var1.get(var14)).getString();
               if (var15.contains("Курс") && var15.contains("за 1 коин")) {
                  var1.set(
                     var14,
                     ((Text)var1.get(var14))
                        .copy()
                        .append(Text.literal("  (").formatted(Formatting.GRAY))
                        .append(Text.literal(var13 + " от среднего").formatted(var12))
                        .append(Text.literal(")").formatted(Formatting.GRAY))
                  );
                  break;
               }
            }

            if (var6 > 0L && var8 > 0L) {
               var1.add(Text.literal("Получишь ≈ " + a(var8) + " ¤ за " + var6 + " ").formatted(Formatting.GRAY).append(q()));
            }

            var1.add(Text.literal(""));
            var1.add(Text.literal("Средний курс: " + a(Math.round(var2)) + " ").formatted(Formatting.GRAY).append(q()));
         }
      }
   }

   public int c(ItemStack var1) {
      if (this.k() && this.r.q()) {
         if (var1 != null && !var1.isEmpty() && var1.getItem() == Items.SPAWNER) {
            NbtComponent var2 = var1.get(DataComponentTypes.CUSTOM_DATA);
            if (var2 == null) {
               return 0;
            } else {
               Integer var3 = A.get(var2);
               if (var3 != null) {
                  return var3;
               } else {
                  if (A.size() > 512) {
                     A.clear();
                  }

                  int var4 = a(var2.copyNbt());
                  A.put(var2, var4);
                  return var4;
               }
            }
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }

   private static int a(NbtCompound var0) {
      if (var0 != null && var0.contains("gs_marker")) {
         String var1 = var0.getString("gs_sword_item", "");
         if (var1.isBlank()) {
            return 0;
         } else {
            try {
               JsonObject var2 = JsonParser.parseString(var1).getAsJsonObject();
               if (var2.has("enchants") && var2.get("enchants").isJsonObject()) {
                  for (String var4 : var2.getAsJsonObject("enchants").keySet()) {
                     if ("mob-farmer-enchant".equals(e(var4))) {
                        return 1714683733;
                     }
                  }
               }
            } catch (Exception var5) {
            }

            return 1728000819;
         }
      } else {
         return 0;
      }
   }

   private static MutableText a(String var0, boolean var1) {
      return Text.literal(var0).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(11962111)).withBold(var1));
   }

   private static MutableText b(String var0) {
      return a("▸ ", false).append(Text.literal(var0));
   }

   private void a(ItemStack var1, List<Text> var2) {
      if (var1 != null && !var1.isEmpty() && var1.getItem() == Items.SPAWNER) {
         NbtComponent var3 = var1.get(DataComponentTypes.CUSTOM_DATA);
         if (var3 != null) {
            NbtCompound var4 = var3.copyNbt();
            if (var4 != null && var4.contains("gs_marker")) {
               var2.add(Text.literal(""));
               var2.add(a("▍ ", true).append(Text.literal("§f§lЗолотой спавнер")));
               if (var4.contains("gs_mob_type")) {
                  var2.add(b("§7Моб: §f" + g(var4.getString("gs_mob_type", ""))));
               }

               long var5 = var4.getLong("gs_kills_total", 0L);
               long var7 = var4.getLong("gs_kills_remaining", 0L);
               if (var5 > 0L) {
                  long var9 = Math.max(0L, Math.min(var5, var5 - var7));
                  int var11 = (int)Math.round(var9 * 100.0 / var5);
                  String var12 = var11 < 25 ? "§a" : (var11 < 60 ? "§e" : "§c");
                  var2.add(b("§7Убито: §f" + a(var9) + " §7из §f" + a(var5) + " §8— " + var12 + "износ " + var11 + "%"));
               }

               if (var4.contains("gs_total_eggs")) {
                  var2.add(b("§7Яйца: §f" + var4.getInt("gs_total_eggs", 0)));
               }

               String var13 = var4.getString("gs_sword_item", "");
               if (var13.isBlank()) {
                  var2.add(b("§7Меч: §8не вставлен"));
               } else {
                  a(var13, var2);
               }
            }
         }
      }
   }

   private static void a(String var0, List<Text> var1) {
      JsonObject var2;
      try {
         var2 = JsonParser.parseString(var0).getAsJsonObject();
      } catch (Exception var12) {
         var1.add(b("§7Меч: §cне удалось прочитать"));
         return;
      }

      String var3 = var2.has("type") && var2.get("type").isJsonPrimitive() ? var2.get("type").getAsString() : "";
      String var4 = a(var2);
      String var5;
      if (var4 != null) {
         String var6 = d(var3);
         var5 = "§f" + var4 + (var6 != null ? " §8(" + var6 + ")" : "");
      } else {
         var5 = "§f" + c(var3);
      }

      var1.add(b("§7Меч: " + var5));
      if (var2.has("enchants") && var2.get("enchants").isJsonObject()) {
         ArrayList var14 = new ArrayList();

         for (Entry var8 : var2.getAsJsonObject("enchants").entrySet()) {
            int var9;
            try {
               var9 = ((JsonElement)var8.getValue()).getAsInt();
            } catch (Exception var13) {
               continue;
            }

            String var10 = e((String)var8.getKey());
            String var11 = "mob-farmer-enchant".equals(var10) ? "§a" : ("looting".equals(var10) ? "§b" : "§7");
            var14.add(var11 + f(var10) + " " + b(var9));
         }

         if (!var14.isEmpty()) {
            var14.sort(
               Comparator.<String>comparingInt(var0x -> var0x.startsWith("§a") ? 0 : (var0x.startsWith("§b") ? 1 : 2)).thenComparing(Comparator.naturalOrder())
            );

            for (byte var15 = 0; var15 < var14.size(); var15 += 3) {
               var1.add(Text.literal("   " + String.join("§8 · ", var14.subList(var15, Math.min(var15 + 3, var14.size())))));
            }
         }
      }
   }

   private static String a(JsonObject var0) {
      try {
         if (var0.has("name") && var0.get("name").isJsonPrimitive()) {
            String var1 = Formatting.strip(var0.get("name").getAsString());
            if (var1 != null && !var1.isBlank()) {
               return var1.trim();
            }
         }
      } catch (Exception var2) {
      }

      return null;
   }

   private static String c(String var0) {
      return switch (var0) {
         case "minecraft:netherite_sword" -> "Незеритовый меч";
         case "minecraft:diamond_sword" -> "Алмазный меч";
         case "minecraft:iron_sword" -> "Железный меч";
         case "minecraft:golden_sword" -> "Золотой меч";
         case "minecraft:stone_sword" -> "Каменный меч";
         case "minecraft:wooden_sword" -> "Деревянный меч";
         default -> "Меч";
      };
   }

   private static String d(String var0) {
      return switch (var0) {
         case "minecraft:netherite_sword" -> "незерит";
         case "minecraft:diamond_sword" -> "алмаз";
         case "minecraft:iron_sword" -> "железо";
         case "minecraft:golden_sword" -> "золото";
         case "minecraft:stone_sword" -> "камень";
         case "minecraft:wooden_sword" -> "дерево";
         default -> null;
      };
   }

   private static String e(String var0) {
      int var1 = var0.indexOf(58);
      return var1 >= 0 ? var0.substring(var1 + 1) : var0;
   }

   private static String f(String var0) {
      return switch (var0) {
         case "sharpness" -> "Острота";
         case "smite" -> "Небесная кара";
         case "bane_of_arthropods" -> "Бич членистоногих";
         case "knockback" -> "Отдача";
         case "fire_aspect" -> "Заговор огня";
         case "looting" -> "Добыча";
         case "sweeping", "sweeping_edge" -> "Разящий клинок";
         case "unbreaking" -> "Прочность";
         case "mending" -> "Починка";
         case "vanishing_curse" -> "Проклятие утраты";
         case "binding_curse" -> "Проклятие несъёмности";
         case "efficiency" -> "Эффективность";
         case "fortune" -> "Удача";
         case "silk_touch" -> "Шёлковое касание";
         case "critical-enchant-custom" -> "Критический";
         case "destroyer-enchant-custom" -> "Разрушитель";
         case "rich-enchant-custom" -> "Богач";
         case "exp-enchant-custom" -> "Опытный";
         case "drill-enchant-custom" -> "Бур";
         case "foundry-enchant-custom" -> "Автоплавка";
         case "internal-enchant-custom" -> "Неразрушимость";
         case "mob-farmer-enchant" -> "Фармер";
         default -> h(var0.replace("-enchant-custom", ""));
      };
   }

   private static String g(String var0) {
      return switch (var0) {
         case "ZOMBIE" -> "Зомби";
         case "SKELETON" -> "Скелет";
         case "CREEPER" -> "Крипер";
         case "SPIDER" -> "Паук";
         case "CAVE_SPIDER" -> "Пещерный паук";
         case "ENDERMAN" -> "Эндермен";
         case "BLAZE" -> "Блейз";
         case "MAGMA_CUBE" -> "Магма-куб";
         case "SLIME" -> "Слизень";
         case "WITCH" -> "Ведьма";
         case "PIGLIN" -> "Пиглин";
         case "PIGLIN_BRUTE" -> "Брутальный пиглин";
         case "WITHER_SKELETON" -> "Визер-скелет";
         case "PHANTOM" -> "Фантом";
         case "DROWNED" -> "Утопленник";
         case "EVOKER" -> "Вызыватель";
         case "VINDICATOR" -> "Поборник";
         case "HOGLIN" -> "Хоглин";
         case "GHAST" -> "Гаст";
         case "CHICKEN" -> "Курица";
         case "PIG" -> "Свинья";
         case "COW" -> "Корова";
         default -> h(var0);
      };
   }

   private static String h(String var0) {
      String var1 = var0.toLowerCase(Locale.ROOT).replace('-', ' ').replace('_', ' ').trim();
      return var1.isEmpty() ? var0 : Character.toUpperCase(var1.charAt(0)) + var1.substring(1);
   }

   private static String b(int var0) {
      String[] var1 = new String[]{
         "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX"
      };
      return var0 >= 1 && var0 <= 20 ? var1[var0 - 1] : String.valueOf(var0);
   }

   private static NbtCompound d(ItemStack var0) {
      if (var0 != null && !var0.isEmpty() && var0.getItem() == Items.COMPASS) {
         NbtComponent var1 = var0.get(DataComponentTypes.CUSTOM_DATA);
         if (var1 == null) {
            return null;
         } else {
            NbtCompound var2 = var1.copyNbt();
            return var2 == null ? null : var2.getCompound("region-radar").orElse(null);
         }
      } else {
         return null;
      }
   }

   private static String b(long var0) {
      long var2 = var0 / 1000L;
      long var4 = var2 / 3600L;
      long var6 = var2 % 3600L / 60L;
      long var8 = var2 % 60L;
      if (var4 > 0L) {
         return String.format("%dч %02dмин %02dсек", var4, var6, var8);
      } else {
         return var6 > 0L ? String.format("%dмин %02dсек", var6, var8) : String.format("%dсек", var8);
      }
   }

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      BooleanSetting setting_a = this.a;
      BooleanSetting setting_b = this.b;
      BooleanSetting setting_c = this.c;
      BooleanSetting setting_f = this.f;
      BooleanSetting setting_g = this.g;
      if (d.world == null || d.player == null) {
         return;
      }
      MatrixStack matrices = var1.a();
      float tickDelta = var1.b();
      var mainItem = d.player.getMainHandStack().getItem();
      var offItem = d.player.getOffHandStack().getItem();
      if ((Boolean)setting_a.q() && (mainItem == Items.NETHER_STAR || offItem == Items.NETHER_STAR)) {
         this.b(matrices, tickDelta);
      }
      if ((Boolean)setting_b.q() && (mainItem == Items.PRISMARINE_SHARD || offItem == Items.PRISMARINE_SHARD)) {
         this.b(matrices);
      }
      if ((Boolean)setting_c.q() && (mainItem == Items.POPPED_CHORUS_FRUIT || offItem == Items.POPPED_CHORUS_FRUIT)) {
         this.c(matrices);
      }
      if ((Boolean)setting_f.q()) {
         this.a(matrices);
      }
      if ((Boolean)setting_g.q() && (e(d.player.getMainHandStack()) || e(d.player.getOffHandStack()))) {
         this.a(matrices, tickDelta);
      }
   }

   private void a(MatrixStack var1, float var2) {
      Vec3d var3 = this.a(var2);
      int var4 = this.a(var3, 15.0) ? -16711936 : -1;
      RenderUtils.a(var1, var3, 15.0F, 64, var4, 0.1F);
   }

   private static boolean e(ItemStack var0) {
      if (var0 != null && !var0.isEmpty() && var0.getItem() == Items.JACK_O_LANTERN) {
         NbtComponent var1 = var0.get(DataComponentTypes.CUSTOM_DATA);
         if (var1 == null) {
            return false;
         } else {
            NbtCompound var2 = var1.copyNbt();
            if (var2 == null) {
               return false;
            } else {
               Optional var3 = var2.getCompound("kringeItems");
               return var3.isEmpty() ? false : "JakeLuminaire".equals(((NbtCompound)var3.get()).getString("type", ""));
            }
         }
      } else {
         return false;
      }
   }

   private boolean a(Vec3d var1, double var2) {
      double var4 = var2 * var2;

      for (Entity var7 : EntityFinder.a(var3 -> var3 instanceof PlayerEntity && var3.squaredDistanceTo(var1) <= var4, EntityTags.a)) {
         if (var7 != d.player) {
            PlayerEntity var8 = (PlayerEntity)var7;
            if (!EntityUtils.a((LivingEntity)var8) && !FriendUtils.a(var8.getName().getString())) {
               return true;
            }
         }
      }

      return false;
   }

   private void a(MatrixStack var1) {
      ItemStack var2 = d.player.getMainHandStack();
      if (this.a(var2.getItem())) {
         int var3 = this.f(var2);
         if (var3 > 0) {
            byte var4 = 1;
            if (d.crosshairTarget != null && d.crosshairTarget.getType() == Type.BLOCK) {
               BlockHitResult var5 = (BlockHitResult)d.crosshairTarget;
               BlockPos var6 = var5.getBlockPos();
               Direction var7 = var5.getSide();
               Axis var8 = var7.getAxis();
               Direction var9 = var7.getOpposite();
               BlockPos var10 = this.a(var6, var8, -var4, -var4);
               BlockPos var11 = this.a(var6.offset(var9, var3 - 1), var8, var4, var4);
               int var12 = Math.min(var10.getX(), var11.getX());
               int var13 = Math.min(var10.getY(), var11.getY());
               int var14 = Math.min(var10.getZ(), var11.getZ());
               int var15 = Math.max(var10.getX(), var11.getX());
               int var16 = Math.max(var10.getY(), var11.getY());
               int var17 = Math.max(var10.getZ(), var11.getZ());
               Box var18 = new Box(var12, var13, var14, var15 + 1, var16 + 1, var17 + 1);
               RenderUtils.a(var1, var18, -1);
            }
         }
      }
   }

   private BlockPos a(BlockPos var1, Axis var2, int var3, int var4) {
      switch (var2) {
         case X:
            return var1.add(0, var3, var4);
         case Y:
            return var1.add(var3, 0, var4);
         default:
            return var1.add(var3, var4, 0);
      }
   }

   private boolean a(Item var1) {
      return var1 == Items.WOODEN_PICKAXE
         || var1 == Items.STONE_PICKAXE
         || var1 == Items.IRON_PICKAXE
         || var1 == Items.GOLDEN_PICKAXE
         || var1 == Items.DIAMOND_PICKAXE
         || var1 == Items.NETHERITE_PICKAXE;
   }

   private int f(ItemStack var1) {
      NbtComponent var2 = var1.get(DataComponentTypes.CUSTOM_DATA);
      if (var2 != null) {
         NbtCompound var3 = var2.copyNbt();
         if (var3 != null && var3.getCompound("PublicBukkitValues").isPresent()) {
            NbtCompound var4 = var3.getCompoundOrEmpty("PublicBukkitValues");
            if (var4.getList("minecraft:custom-enchantments").isPresent()) {
               NbtList var5 = var4.getListOrEmpty("minecraft:custom-enchantments");

               for (int var6 = 0; var6 < var5.size(); var6++) {
                  NbtCompound var7 = var5.getCompoundOrEmpty(var6);
                  String var8 = var7.getString("minecraft:type", "");
                  if (!var8.isEmpty() && var8.toLowerCase().contains("drill")) {
                     return var7.getInt("minecraft:level", 0) >= 2 ? 2 : 1;
                  }
               }
            }
         }
      }

      LoreComponent var9 = var1.get(DataComponentTypes.LORE);
      if (var9 != null) {
         for (Text var11 : var9.lines()) {
            String var12 = var11.getString();
            if (var12 != null) {
               if (var12.contains("Бур II")) {
                  return 2;
               }

               if (var12.contains("Бур I")) {
                  return 1;
               }
            }
         }
      }

      return 0;
   }

   @EventHandler
   public void a(PacketEvent var1) {
      if (this.m.q()) {
         if (d.player != null) {
            if (var1.e() == PacketEvent.EventType.b) {
               if (var1.d() instanceof GameMessageS2CPacket var2) {
                  if (!var2.overlay()) {
                     String var7 = Formatting.strip(var2.content().getString());
                     if (var7 != null) {
                        if (var7.contains("сокровище по координатам") || var7.contains("Стрелка компаса")) {
                           Matcher var4 = I.matcher(var7);
                           if (var4.find()) {
                              try {
                                 this.a(Integer.parseInt(var4.group(1)), Integer.parseInt(var4.group(2)));
                              } catch (NumberFormatException var6) {
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void a(int var1, int var2) {
      for (MarkerEntry var4 : MarkerManager.a()) {
         if ("Сокровище".equals(var4.a())) {
            if (var4.b() == var1 && var4.d() == var2) {
               return;
            }

            MarkerManager.b(var4);
         }
      }

      int var5 = (int)Math.floor(d.player.getY());
      MarkerEntry var6 = new MarkerEntry("Сокровище", var1, var5, var2, ClickGuiColors.Y, MarkerEntry.IconType.f);
      MarkerManager.a(var6);
      ChatUtils.a("§b[HW]§f Метка «Сокровище» поставлена: §b" + var1 + ", " + var2);
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      BooleanSetting timers = this.i;
      if (d.world == null || d.player == null) {
         return;
      }
      if ((Boolean)timers.q()) {
         int explosiveCount = this.b(Items.PRISMARINE_SHARD);
         boolean explosiveCooldown = d.player.getItemCooldownManager().isCoolingDown(Items.PRISMARINE_SHARD.getDefaultStack());
         if (explosiveCooldown && explosiveCount < this.E) {
            this.C = true;
            try {
               this.D = System.currentTimeMillis();
            } catch (RuntimeException | Error failure) {
               this.D = 0L;
               throw failure;
            }
         }
         this.E = explosiveCount;
         int trapCount = this.b(Items.POPPED_CHORUS_FRUIT);
         boolean trapCooldown = d.player.getItemCooldownManager().isCoolingDown(Items.POPPED_CHORUS_FRUIT.getDefaultStack());
         if (trapCooldown && trapCount < this.H) {
            this.F = true;
            try {
               this.G = System.currentTimeMillis();
            } catch (RuntimeException | Error failure) {
               this.G = 0L;
               throw failure;
            }
         }
         this.H = trapCount;
      }
      if ((this.C || this.F) && (Boolean)timers.q()) {
         this.r();
      }
   }

   private int b(Item var1) {
      int var2 = 0;

      for (int var3 = 0; var3 < d.player.getInventory().size(); var3++) {
         ItemStack var4 = d.player.getInventory().getStack(var3);
         if (var4.getItem() == var1) {
            var2 += var4.getCount();
         }
      }

      return var2;
   }

   private void r() {
      short var1 = 11000;
      long var2 = System.currentTimeMillis();
      String var4 = null;
      if (this.C) {
         long var5 = var2 - this.D;
         if (var5 >= var1) {
            this.C = false;
         } else {
            double var7 = (var1 - var5) / 1000.0;
            var4 = String.format("Взрывная трапка закончится через §b%.1f§f сек.", var7);
         }
      }

      if (this.F) {
         long var9 = var2 - this.G;
         if (var9 >= var1) {
            this.F = false;
         } else {
            double var10 = (var1 - var9) / 1000.0;
            if (var4 != null) {
               var4 = String.format("Взрывная: §b%.1f§f | Обычная: §b%.1f§f сек.", (var1 - (var2 - this.D)) / 1000.0, var10);
            } else {
               var4 = String.format("Трапка закончится через §b%.1f§f сек.", var10);
            }
         }
      }

      if (var4 != null) {
         d.inGameHud.setOverlayMessage(Text.of(var4), false);
      }
   }

   private void b(MatrixStack var1, float var2) {
      Vec3d var3 = this.a(var2);
      Box var4 = new Box(var3.x - 15.0, var3.y - 15.0, var3.z - 15.0, var3.x + 15.0, var3.y + 15.0, var3.z + 15.0);
      int var5 = this.a(var4) ? -16711936 : -1;
      RenderUtils.b(var1, var4, var5);
   }

   private void b(MatrixStack var1) {
      BlockPos var2 = d.player.getBlockPos();
      Box var3 = new Box(var2.getX() - 3, var2.getY() - 3, var2.getZ() - 3, var2.getX() + 4, var2.getY(), var2.getZ() + 4);
      Box var4 = new Box(var2.getX() - 3, var2.getY() - 3, var2.getZ() - 3, var2.getX() + 4, var2.getY() + 4, var2.getZ() + 4);
      int var5 = this.a(var4) ? -16711936 : -1;
      RenderUtils.b(var1, var3, var5);
   }

   private void c(MatrixStack var1) {
      BlockPos var2 = d.player.getBlockPos();
      Box var3 = new Box(var2.getX() - 2, var2.getY(), var2.getZ() - 2, var2.getX() + 3, var2.getY() + 4, var2.getZ() + 3);
      int var4 = this.a(var3) ? -16711936 : -1;
      RenderUtils.b(var1, var3, var4);
   }

   private Vec3d a(float var1) {
      return new Vec3d(
         d.player.lastRenderX + (d.player.getX() - d.player.lastRenderX) * var1,
         d.player.lastRenderY + (d.player.getY() - d.player.lastRenderY) * var1,
         d.player.lastRenderZ + (d.player.getZ() - d.player.lastRenderZ) * var1
      );
   }

   private boolean a(Box var1) {
      for (Entity var3 : EntityFinder.a(var1x -> var1x instanceof PlayerEntity && var1.contains(var1x.getLerpedPos(1.0F)), EntityTags.a)) {
         if (var3 != d.player) {
            PlayerEntity var4 = (PlayerEntity)var3;
            if (!EntityUtils.a((LivingEntity)var4) && !FriendUtils.a(var4.getName().getString())) {
               return true;
            }
         }
      }

      return false;
   }

   static {
      NativeMethodLookup.lookup(HWHelperModule.class, 62);
   }

   @Environment(EnvType.CLIENT)
   public record PriceLine(String label, long amount) {
   }
}
