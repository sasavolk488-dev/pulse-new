package pulse.core.handler.impl.autoevent.parser;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Formatting;
import pulse.core.handler.impl.autoevent.AutoEventHandler;
import pulse.core.handler.impl.autoevent.EventConfig;
import pulse.core.handler.impl.autoevent.ServerEventParser;
import pulse.core.api.IMinecraft;
import pulse.utils.game.ChatUtils;

@Environment(EnvType.CLIENT)
public class HolyWorldEventParser implements IMinecraft, ServerEventParser {
   private static final Set<String> a = Collections.unmodifiableSet(
      new HashSet<>(
         Arrays.asList(
            "ценный груз", "опытный тыпо", "цветочная поляна", "смертельная шахта", "контейнер", "золотая лихорадка", "таинственный корабль", "посылка"
         )
      )
   );
   private static final Map<String, EventConfig> b;
   private static final Pattern[] c = new Pattern[]{
      Pattern.compile("находится на координатах\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)"),
      Pattern.compile("находится на\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)"),
      Pattern.compile("на координатах\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)"),
      Pattern.compile("уже на координатах\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)"),
      Pattern.compile("координатах\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)"),
      Pattern.compile("на\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)")
   };

   @Override
   public boolean a(String var1) {
      return var1 == null ? false : var1.toLowerCase().contains("holyworld");
   }

   @Override
   public boolean a(String var1, String var2, AutoEventHandler var3) {
      boolean var4 = false;
      if (var1.startsWith("▶ ") || var1.contains("▶ ")) {
         boolean var5 = this.a(var2, var3);
         if (!var5) {
            this.b(var2, var3);
         }

         var4 = true;
      }

      if (var1.contains("▍")) {
         this.b(var1);
      }

      return var4;
   }

   private void b(String var1) {
      String var2 = var1.toLowerCase().trim();
      if (var2.contains("▍")) {
         for (String var4 : a) {
            if (var2.contains(var4)) {
               if (d.player != null) {
                  ChatUtils.a("event active");
               }
               break;
            }
         }
      }
   }

   private boolean a(String var1, AutoEventHandler var2) {
      String var3 = Formatting.strip(var1);
      if (!var3.contains("▶")) {
         return false;
      } else {
         String[] var4 = var3.split("▶", 2);
         if (var4.length < 2) {
            return false;
         } else {
            String var5 = var4[1].trim();
            String var6 = null;
            int[] var7 = null;
            int var8 = 0;

            for (String var10 : a) {
               if (var5.toLowerCase().contains(var10)) {
                  var6 = var10;
                  break;
               }
            }

            if (var6 == null) {
               return false;
            } else {
               for (Pattern var12 : c) {
                  Matcher var13 = var12.matcher(var5);
                  if (var13.find()) {
                     int var14 = Integer.parseInt(var13.group(1));
                     int var15 = Integer.parseInt(var13.group(2));
                     int var16 = Integer.parseInt(var13.group(3));
                     var7 = new int[]{var14, var15, var16};
                     break;
                  }
               }

               if (var5.contains("взорвется через")) {
                  Pattern var18 = Pattern.compile("взорвется через\\s+(\\d+)\\s+секунд");
                  Matcher var21 = var18.matcher(var5);
                  if (var21.find()) {
                     var8 = Integer.parseInt(var21.group(1));
                  }
               } else if (var5.contains("уже") && var5.contains("секунд")) {
                  Pattern var19 = Pattern.compile("уже\\s+(\\d+)\\s+секунд");
                  Matcher var22 = var19.matcher(var5);
                  if (var22.find()) {
                     int var23 = Integer.parseInt(var22.group(1));
                     var8 = Math.max(0, 600 - var23);
                  }
               }

               if (var6 != null && var7 != null) {
                  var2.a(var6, var7, var8);
                  var2.a(this.c(var6), null);
                  return true;
               } else {
                  return false;
               }
            }
         }
      }
   }

   private void b(String var1, AutoEventHandler var2) {
      String var3 = Formatting.strip(var1);
      if (var3.contains("голосование") && var3.contains("через")) {
         Pattern var4 = Pattern.compile("через\\s+(?:(\\d+)\\s*мин\\.?)?\\s*,?\\s*(?:(\\d+)\\s*сек\\.?)?");
         Matcher var5 = var4.matcher(var3);
         if (var5.find()) {
            int var6 = 0;
            String var7 = var5.group(1);
            String var8 = var5.group(2);
            if (var7 != null) {
               var6 += Integer.parseInt(var7) * 60;
            }

            if (var8 != null) {
               var6 += Integer.parseInt(var8);
            }

            if (var6 > 0) {
               var2.b(var6);
            }
         }
      }
   }

   private String c(String var1) {
      return var1 != null && !var1.isEmpty() ? var1.substring(0, 1).toUpperCase() + var1.substring(1) : var1;
   }

   @Override
   public Set<String> a() {
      return a;
   }

   @Override
   public Map<String, EventConfig> b() {
      return b;
   }

   @Override
   public String c() {
      return "/event active";
   }

   static {
      HashMap var0 = new HashMap();
      var0.put("ценный груз", new EventConfig(new Color(255, 140, 0)));
      var0.put("опытный тыпо", new EventConfig(new Color(148, 0, 211)));
      var0.put("цветочная поляна", new EventConfig(new Color(255, 182, 193)));
      var0.put("смертельная шахта", new EventConfig(new Color(139, 0, 0)));
      var0.put("контейнер", new EventConfig(new Color(70, 130, 180)));
      var0.put("золотая лихорадка", new EventConfig(new Color(255, 215, 0)));
      var0.put("таинственный корабль", new EventConfig(new Color(95, 158, 160)));
      var0.put("посылка", new EventConfig(new Color(160, 82, 45)));
      b = Collections.unmodifiableMap(var0);
   }
}
