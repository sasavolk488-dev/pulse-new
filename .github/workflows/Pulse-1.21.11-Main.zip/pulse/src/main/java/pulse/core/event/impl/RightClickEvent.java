package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class RightClickEvent extends CancellableEvent {
   private final PlayerEntity a;
   private final World b;
   private final Hand c;

   @Generated
   public PlayerEntity d() {
      return this.a;
   }

   @Generated
   public World e() {
      return this.b;
   }

   @Generated
   public Hand f() {
      return this.c;
   }

   @Generated
   public RightClickEvent(PlayerEntity var1, World var2, Hand var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
