package pulse.mixin;

import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.SoundOptionsScreen;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.option.SimpleOption.DoubleSliderCallbacks;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.utils.audio.PulseSoundOptions;

@Environment(EnvType.CLIENT)
@Mixin({SoundOptionsScreen.class})
public abstract class SoundOptionsScreenMixin extends GameOptionsScreen {
   protected SoundOptionsScreenMixin(Screen var1, GameOptions var2, Text var3) {
      super(var1, var2, var3);
   }

   @Inject(
      method = {"addOptions"},
      at = {@At("TAIL")}
   )
   private void pulse$addVolumeSliders(CallbackInfo var1) {
      this.body
         .addAll(
            pulse$slider("Музыка эмоций", PulseSoundOptions.a(), PulseSoundOptions::a),
            pulse$slider("Озвучка фраз", PulseSoundOptions.b(), PulseSoundOptions::b)
         );
   }

   @Unique
   private static SimpleOption<Double> pulse$slider(String var0, double var1, Consumer<Double> var3) {
      return new SimpleOption<>(
         var0,
         SimpleOption.emptyTooltip(),
         (var1x, var2) -> var2 <= 0.0 ? Text.literal(var0 + ": ВЫКЛ.") : Text.literal(var0 + ": " + (int)(var2 * 100.0) + "%"),
         DoubleSliderCallbacks.INSTANCE,
         var1,
         var3::accept
      );
   }
}
