package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.ChatEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.time.TimeUtils;

@ModuleInfo(
   a = "PVP Safe",
   b = "Блокирует опасные команды в PVP режиме",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class PVPSafeModule extends Module {
   private final Pattern a = Pattern.compile("^/(hub|an|grief|limbo|logout|lobby|рги|фт|пкшуа|дшьищ|дщпщге|дщиин)(\\S*)", 2);
   private final Map<String, TimeUtils> b = new ConcurrentHashMap<>();

   @EventHandler
   @Compile
   private native void a(ChatEvent var1);

   @EventHandler
   @Compile
      private void a(UpdateEvent var1) {
      this.b.values().removeIf(PVPSafeModule::a);
   }

   public static boolean a(TimeUtils var0) {
      return var0.a(3000L);
   }

   static {
      NativeMethodLookup.lookup(PVPSafeModule.class, 69);
   }
}
