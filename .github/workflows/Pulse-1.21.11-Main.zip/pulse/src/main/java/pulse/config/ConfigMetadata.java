package pulse.config;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;
import pulse.services.accounts.UserInfo;

@Environment(EnvType.CLIENT)
public class ConfigMetadata {
   private static final DateTimeFormatter a = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
   private static final String b = "pulse_config_v1";
   private final String c;
   private final int d;
   private final String e;
   private final long f;
   private String g;
   private String h;
   private long i;

   private ConfigMetadata(String var1, String var2, int var3, String var4, long var5, String var7, long var8) {
      this.g = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
      this.f = var5;
      this.h = var7;
      this.i = var8;
   }

   public static ConfigMetadata a(String var0) {
      String var1 = "Unknown";
      int var2 = 0;
      UserInfo var3 = Pulse.n();
      if (var3 != null) {
         var1 = var3.g();
         var2 = var3.f();
      }

      long var4 = System.currentTimeMillis();
      String var6 = a(var2, var4);
      return new ConfigMetadata(var0, var1, var2, var6, var4, "", var4);
   }

   public static ConfigMetadata a(String var0, String var1) {
      ConfigMetadata var2 = a(var0);
      var2.h = var1;
      return var2;
   }

   public static ConfigMetadata a(String var0, String var1, int var2, String var3, long var4, String var6, long var7) {
      return new ConfigMetadata(var0, var1, var2, var3, var4, var6, var7);
   }

   private static String a(int var0, long var1) {
      try {
         String var3 = "pulse_config_v1:" + var0 + ":" + var1;
         MessageDigest var4 = MessageDigest.getInstance("SHA-256");
         byte[] var5 = var4.digest(var3.getBytes(StandardCharsets.UTF_8));
         StringBuilder var6 = new StringBuilder();

         for (int var7 = 0; var7 < Math.min(16, var5.length); var7++) {
            String var8 = Integer.toHexString(255 & var5[var7]);
            if (var8.length() == 1) {
               var6.append('0');
            }

            var6.append(var8);
         }

         return var6.toString();
      } catch (NoSuchAlgorithmException var9) {
         return String.valueOf(var0 + var1);
      }
   }

   public boolean a() {
      String var1 = a(this.d, this.f);
      return var1.equals(this.e);
   }

   public void b() {
      this.i = System.currentTimeMillis();
   }

   public String c() {
      return this.c;
   }

   public int d() {
      return this.d;
   }

   public String e() {
      return this.e;
   }

   public long f() {
      return this.f;
   }

   public LocalDateTime g() {
      return LocalDateTime.ofInstant(Instant.ofEpochMilli(this.f), ZoneId.systemDefault());
   }

   public String h() {
      return this.g().format(a);
   }

   public String i() {
      return this.g;
   }

   public void b(String var1) {
      this.g = var1;
      this.b();
   }

   public String j() {
      return this.h;
   }

   public void c(String var1) {
      this.h = var1;
      this.b();
   }

   public long k() {
      return this.i;
   }

   public LocalDateTime l() {
      return LocalDateTime.ofInstant(Instant.ofEpochMilli(this.i), ZoneId.systemDefault());
   }

   public String m() {
      return this.l().format(a);
   }
}
