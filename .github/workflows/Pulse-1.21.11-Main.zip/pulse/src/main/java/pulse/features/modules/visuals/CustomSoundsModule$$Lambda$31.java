package pulse.features.modules.visuals;

import java.util.function.BiConsumer;
import pulse.features.modules.utilities.ft.FunTimeItemType;

public final class CustomSoundsModule$$Lambda$31 implements BiConsumer {
   private final CustomSoundsModule c0;

   public CustomSoundsModule$$Lambda$31(CustomSoundsModule var1) {
      this.c0 = var1;
   }

   @Override
   public void accept(Object var1, Object var2) {
      this.c0.a((FunTimeItemType)var1, (Float)var2);
   }
}
