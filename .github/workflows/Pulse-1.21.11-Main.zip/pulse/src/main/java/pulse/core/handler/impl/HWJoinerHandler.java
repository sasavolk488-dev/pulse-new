package pulse.core.handler.impl;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.sync.ItemStackHash;
import net.minecraft.screen.sync.ComponentChangesHash.ComponentHasher;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.mixin.accessor.CloseScreenS2CPacketAccessor;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.utilities.StreamerModeModule;
import pulse.utils.game.ChatUtils;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class HWJoinerHandler extends Handler implements IMinecraft {
   private static final Logger a = LogManager.getLogger("HWJoiner");
   private static final DateTimeFormatter b = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
   private static final DateTimeFormatter c = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
   private static final String[] f = new String[]{"СолоЛайт", "ДуоЛайт", "ТриоЛайт", "КланЛайт"};
   private static final long g = 500L;
   private static final long h = 8000L;
   private static final long i = 5000L;
   private static final long j = 3000L;
   private volatile boolean k = false;
   private HWJoinerHandler.HWMode l = HWJoinerHandler.HWMode.a;
   private int m = 1;
   private Consumer<Boolean> n;
   private int o = -1;
   private String p = "";
   private List<ItemStack> q;
   private int r = 0;
   private int s = -1;
   private int t = -1;
   private boolean u = false;
   private boolean v = false;
   private boolean w = false;
   private volatile boolean x = true;
   private long y = 0L;
   private long z = 0L;
   private long A = 0L;
   private long B = 0L;
   private PrintWriter C;
   private File D;
   private String E = "";

   public boolean d() {
      return this.k;
   }

   public boolean a(HWJoinerHandler.HWMode var1, int var2) {
      return this.a(var1, var2, false, null);
   }

   public boolean a(HWJoinerHandler.HWMode var1, int var2, boolean var3, Consumer<Boolean> var4) {
      if (d.player == null || d.world == null) {
         return false;
      } else if (d.getCurrentServerEntry() != null && d.getCurrentServerEntry().address.contains("holyworld")) {
         this.e();
         this.l = var1;
         this.m = var2;
         this.n = var4;
         this.a(0L);
         this.v = false;
         this.w = false;
         this.x = true;
         this.k = true;
         if (var3) {
            this.k();
         }

         this.b("Захожу: " + var1.a() + " #" + var2);
         this.e("Старт: режим=" + var1.a() + " номер=" + var2);
         return true;
      } else {
         this.b("Работает только на HolyWorld");
         return false;
      }
   }

   public void e() {
      if (!this.k) {
         this.l();
      } else {
         this.k = false;
         this.n = null;
         this.a(0L);
         this.u = false;
         this.v = false;
         this.e("Заход отменён");
         this.l();
      }
   }

   private void b(boolean var1) {
      if (this.k) {
         this.k = false;
         Consumer var2 = this.n;
         this.n = null;
         this.a(0L);
         this.u = false;
         this.v = false;
         this.l();
         if (var2 != null) {
            d.execute(() -> var2.accept(var1));
         }
      }
   }

   @EventHandler
   public void a(UpdateEvent var1) {
      if (this.k) {
         if (d.player != null && d.world != null) {
            long var2 = System.currentTimeMillis();
            if (var2 >= this.B) {
               if (this.u) {
                  if (var2 - this.A > 8000L) {
                     this.e("Таймаут подключения, пробую заново");
                     this.a(0L);
                  }
               } else if (this.o != -1) {
                  if (var2 - this.A > 8000L) {
                     this.e("Меню зависло, начинаю заново");
                     this.a(0L);
                  }
               } else if (!this.j()) {
                  if (!this.v) {
                     this.e("Не в лобби, отправляю /hub");
                     this.x = false;
                     ChatUtils.a("hub");
                     this.v = true;
                     this.A = var2;
                  } else if (var2 - this.A > 8000L) {
                     this.c("Не удалось попасть в лобби");
                  }
               } else {
                  this.v = false;
                  if (!this.x) {
                     if (var2 - this.A <= 8000L) {
                        return;
                     }

                     this.x = true;
                  }

                  if (var2 - this.z >= 500L) {
                     int var4 = this.f();
                     if (var4 != -1) {
                        d.player.getInventory().setSelectedSlot(var4);
                        d.interactionManager.interactItem(d.player, Hand.MAIN_HAND);
                        this.z = var2;
                        this.A = var2;
                        this.e("Использовал компас");
                     }
                  }
               }
            }
         }
      }
   }

   private int f() {
      for (int var1 = 0; var1 < 9; var1++) {
         ItemStack var2 = d.player.getInventory().getStack(var1);
         if (!var2.isEmpty() && var2.getItem() == Items.COMPASS) {
            return var1;
         }
      }

      return -1;
   }

   private boolean a(String var1) {
      return var1.contains("Выберите режим") || var1.contains("Выбор Лайт анархии") || var1.contains("Выберите сервер");
   }

   @EventHandler
   public void a(PacketEvent var1) {
      if (this.k) {
         this.b(var1);
         Packet var2 = var1.d();
         if (var1.e() == PacketEvent.EventType.b) {
            if (var2 instanceof OpenScreenS2CPacket var3) {
               String var8 = this.b(var3.getName());
               if (this.a(var8)) {
                  this.o = var3.getSyncId();
                  this.p = var8;
                  this.q = null;
                  this.A = System.currentTimeMillis();
                  var1.b();
               }
            } else if (var2 instanceof InventoryS2CPacket var4) {
               if (var4.syncId() == this.o && this.o != -1) {
                  this.q = new ArrayList<>(var4.contents());
                  this.A = System.currentTimeMillis();
                  var1.b();
                  this.c(true);
               }
            } else if (var2 instanceof ScreenHandlerSlotUpdateS2CPacket var5) {
               if (var5.getSyncId() == this.o && this.o != -1) {
                  if (this.q != null && var5.getSlot() >= 0 && var5.getSlot() < this.q.size()) {
                     this.q.set(var5.getSlot(), var5.getStack());
                     this.c(false);
                  }

                  var1.b();
               }
            } else if (var2 instanceof CloseScreenS2CPacket var6) {
               if (((CloseScreenS2CPacketAccessor)var6).getSyncId() == this.o && this.o != -1) {
                  this.i();
                  var1.b();
               }
            } else if (var2 instanceof PlayerPositionLookS2CPacket) {
               if (!this.x) {
                  this.x = true;
                  this.e("Мир прогрузился (PositionLook), можно кликать компас");
               }
            } else if (var2 instanceof GameMessageS2CPacket var7) {
               String var9 = this.b(var7.content());
               if (var9.contains("Выполняется подключение")) {
                  this.u = true;
                  this.A = System.currentTimeMillis();
               } else if (var9.contains("Не удалось подключиться") || var9.contains("переполнен") || var9.contains("Подождите")) {
                  this.e("Сервер отказал: " + var9);
                  this.a(5000L);
               }
            }
         }
      }
   }

   private void c(boolean var1) {
      if (this.q != null && !this.u) {
         int var2 = this.q.size() - 36;
         if (this.p.contains("Выберите режим")) {
            if (this.o == this.s) {
               return;
            }

            int var3 = this.g();
            if (var3 != -1) {
               this.s = this.o;
               this.a(var3, "режим " + this.l.a());
            } else if (var1 && this.h()) {
               this.c("Не нашёл режим «" + this.l.a() + "» в меню");
            }
         } else if (this.p.contains("Выбор Лайт анархии") && var2 <= 9) {
            if (this.o == this.t) {
               return;
            }

            if (this.a(this.r) != -1) {
               this.t = this.o;
               this.a(this.r, "категория " + f[this.r]);
            }
         } else if (this.p.contains("Выбор Лайт анархии")) {
            this.a(true, var1);
         } else if (this.p.contains("Выберите сервер")) {
            this.a(false, var1);
         }
      }
   }

   private void a(boolean var1, boolean var2) {
      int var3 = this.m;
      int var4 = this.b(var3);
      if (var4 != -1) {
         if (this.c(var4)) {
            if (!this.w) {
               this.w = true;
               d.execute(() -> this.b("Анархия #" + var3 + " на тех. работах, жду её запуска..."));
            }

            long var5 = System.currentTimeMillis();
            if (var5 >= this.y) {
               this.y = var5 + 3000L;
               this.a(var4, "обновить статус #" + var3);
            }
         } else {
            this.u = true;
            this.a(var4, "подключение к #" + var3);
         }
      } else if (var2) {
         if (var1) {
            if (!this.d(this.r)) {
               return;
            }

            if (this.r < f.length - 1) {
               this.r++;
               this.a(this.r, "категория " + f[this.r]);
            } else {
               this.c("Анархия #" + var3 + " не найдена ни в одной категории");
            }
         } else if (this.h()) {
            this.c("Анархия #" + var3 + " не найдена в списке");
         }
      }
   }

   private void a(int var1, String var2) {
      ItemStack var3 = this.q != null && var1 >= 0 && var1 < this.q.size() ? this.q.get(var1).copy() : ItemStack.EMPTY;
      ComponentHasher var4 = d.player.networkHandler.getComponentHasher();
      Int2ObjectArrayMap var5 = new Int2ObjectArrayMap();
      var5.put(var1, ItemStackHash.EMPTY);
      d.player
         .networkHandler
         .sendPacket(new ClickSlotC2SPacket(this.o, 0, (short)var1, (byte)0, SlotActionType.PICKUP, var5, ItemStackHash.fromItemStack(var3, var4)));
      this.A = System.currentTimeMillis();
      this.e("Клик slot=" + var1 + " syncId=" + this.o + " (" + var2 + ")");
   }

   private String a(ItemStack var1) {
      LoreComponent var2 = var1.get(DataComponentTypes.LORE);
      if (var2 != null && !var2.lines().isEmpty()) {
         StringBuilder var3 = new StringBuilder();

         for (Text var5 : var2.lines()) {
            var3.append(this.b(var5)).append('\n');
         }

         return var3.toString();
      } else {
         return "";
      }
   }

   private int g() {
      int var1 = this.q.size() - 36;

      for (int var2 = 0; var2 < var1; var2++) {
         ItemStack var3 = this.q.get(var2);
         if (!var3.isEmpty() && var3.getItem() == Items.PLAYER_HEAD) {
            String var4 = this.a(var3);
            if (this.l == HWJoinerHandler.HWMode.a && var4.contains("Анархия 1.16") && var4.contains("Лайт")) {
               return var2;
            }

            if (this.l == HWJoinerHandler.HWMode.b && var4.contains("Анархия 1.2")) {
               return var2;
            }
         }
      }

      return -1;
   }

   private int a(int var1) {
      if (var1 >= this.q.size() - 36) {
         return -1;
      } else {
         ItemStack var2 = this.q.get(var1);
         return !var2.isEmpty() && var2.getItem() == Items.ARMOR_STAND ? var1 : -1;
      }
   }

   private int b(int var1) {
      int var2 = this.q.size() - 36;
      String var3 = "#" + var1;

      for (int var4 = 0; var4 < var2; var4++) {
         ItemStack var5 = this.q.get(var4);
         if (!var5.isEmpty() && var5.getItem() == Items.PLAYER_HEAD) {
            String var6 = this.a(var5);

            for (int var7 = var6.indexOf(var3); var7 != -1; var7 = var6.indexOf(var3, var7 + 1)) {
               int var8 = var7 + var3.length();
               if (var8 >= var6.length() || !Character.isDigit(var6.charAt(var8))) {
                  return var4;
               }
            }
         }
      }

      return -1;
   }

   private boolean c(int var1) {
      String var2 = this.a(this.q.get(var1));
      return var2.contains("Обновить статус") || var2.contains("перезагружается");
   }

   private boolean d(int var1) {
      int var2 = this.q.size() - 36;
      String var3 = f[var1] + " #";

      for (int var4 = 0; var4 < var2; var4++) {
         ItemStack var5 = this.q.get(var4);
         if (!var5.isEmpty() && var5.getItem() == Items.PLAYER_HEAD && this.a(var5).contains(var3)) {
            return true;
         }
      }

      return false;
   }

   private boolean h() {
      int var1 = this.q.size() - 36;

      for (int var2 = 0; var2 < var1; var2++) {
         ItemStack var3 = this.q.get(var2);
         if (!var3.isEmpty() && (var3.getItem() == Items.PLAYER_HEAD || var3.getItem() == Items.ARMOR_STAND) && !this.a(var3).isEmpty()) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   public void a(WorldChangeEvent var1) {
      if (this.k) {
         this.e("WORLD_CHANGE, connecting=" + this.u);
         this.E = "";
         if (this.u) {
            this.b("Успешно подключено: " + this.l.a() + " #" + this.m);
            this.b(true);
         } else {
            this.i();
            this.z = 0L;
         }
      }
   }

   private void i() {
      this.o = -1;
      this.p = "";
      this.q = null;
   }

   private void a(long var1) {
      this.i();
      this.u = false;
      this.r = 0;
      this.s = -1;
      this.t = -1;
      this.z = 0L;
      this.y = 0L;
      this.A = System.currentTimeMillis();
      this.B = var1 > 0L ? System.currentTimeMillis() + var1 : 0L;
   }

   private boolean j() {
      if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
         try {
            PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
            Text var2 = var1.getHeader();
            return var2 == null ? false : this.a(var2).contains("Лобби");
         } catch (Exception var3) {
            return false;
         }
      } else {
         return false;
      }
   }

   private void b(String var1) {
      ChatUtils.a("HW Joiner: " + var1);
   }

   private void c(String var1) {
      d.execute(() -> {
         if (this.k) {
            this.b(var1);
            this.b(false);
         }
      });
   }

   private void k() {
      try {
         File var1 = new File(System.getProperty("user.home"), "Desktop");
         File var2 = var1.isDirectory() ? var1 : d.runDirectory;
         this.D = new File(var2, "HWJoiner-debug_" + LocalDateTime.now().format(b) + ".txt");
         this.C = new PrintWriter(new FileWriter(this.D, true));
         this.d("=== HWJoiner DEBUG SESSION START ===");
         if (d.getCurrentServerEntry() != null) {
            this.d("SERVER | " + d.getCurrentServerEntry().address);
         }

         if (d.player != null) {
            this.d("PLAYER | " + d.player.getGameProfile().name());
         }
      } catch (Exception var3) {
         a.error("[HWJoiner] Не удалось создать файл дебага", (Throwable)var3);
         this.C = null;
      }
   }

   private void l() {
      if (this.C != null) {
         this.d("=== HWJoiner DEBUG SESSION END ===");
         this.C.close();
         this.C = null;
         if (this.D != null) {
            this.b("Дебаг сохранён: " + this.D.getAbsolutePath());
         }
      }
   }

   private synchronized void d(String var1) {
      a.info("[HWJoiner] {}", var1);
      if (this.C != null) {
         this.C.println("[" + LocalTime.now().format(c) + "] " + var1);
         this.C.flush();
      }
   }

   private void e(String var1) {
      this.d("ACTION | " + var1);
   }

   private String a(Text var1) {
      if (var1 == null) {
         return "null";
      } else {
         StreamerModeModule.o();

         String var2;
         try {
            var2 = var1.getString();
         } finally {
            StreamerModeModule.p();
         }

         return var2;
      }
   }

   private String b(Text var1) {
      String var2 = Formatting.strip(this.a(var1));
      return var2 == null ? "null" : var2;
   }

   private String a(ItemStack var1, boolean var2) {
      if (var1 != null && !var1.isEmpty()) {
         StringBuilder var3 = new StringBuilder();
         var3.append(Registries.ITEM.getId(var1.getItem())).append(" x").append(var1.getCount());
         var3.append(" name='").append(this.b(var1.getName())).append("'");
         if (var2) {
            String var4 = this.a(var1);
            if (!var4.isEmpty()) {
               var3.append(" lore=[").append(var4.replace("\n", " || ")).append("]");
            }
         }

         return var3.toString();
      } else {
         return "empty";
      }
   }

   private void b(PacketEvent var1) {
      if (this.C != null) {
         Packet var2 = var1.d();
         if (var1.e() == PacketEvent.EventType.b) {
            if (var2 instanceof OpenScreenS2CPacket var3) {
               this.d("OPEN_SCREEN | syncId=" + var3.getSyncId() + " title='" + this.b(var3.getName()) + "'");
            } else if (var2 instanceof InventoryS2CPacket var4) {
               if (var4.syncId() != 0) {
                  this.d("INVENTORY | syncId=" + var4.syncId() + " slots=" + var4.contents().size());

                  for (int var8 = 0; var8 < var4.contents().size(); var8++) {
                     ItemStack var9 = var4.contents().get(var8);
                     if (!var9.isEmpty()) {
                        this.d("  SLOT " + var8 + " | " + this.a(var9, true));
                     }
                  }
               }
            } else if (var2 instanceof ScreenHandlerSlotUpdateS2CPacket var5) {
               if (var5.getSyncId() != 0) {
                  this.d("SLOT_UPDATE | syncId=" + var5.getSyncId() + " slot=" + var5.getSlot() + " item=" + this.a(var5.getStack(), true));
               }
            } else if (var2 instanceof CloseScreenS2CPacket var6) {
               this.d("CLOSE_SCREEN | syncId=" + ((CloseScreenS2CPacketAccessor)var6).getSyncId());
            } else if (var2 instanceof GameMessageS2CPacket var7) {
               String var14 = this.b(var7.content());
               if (var7.overlay()) {
                  if (!var14.equals(this.E)) {
                     this.E = var14;
                     this.d("ACTIONBAR | '" + var14 + "'");
                  }
               } else {
                  this.d("CHAT | '" + var14 + "'");
               }
            }
         } else if (var2 instanceof ClickSlotC2SPacket var10) {
            this.d("CLICK_SLOT | syncId=" + var10.syncId() + " slot=" + var10.slot() + " button=" + var10.button() + " action=" + var10.actionType());
         } else if (var2 instanceof PlayerInteractItemC2SPacket var11) {
            ItemStack var13 = d.player != null ? d.player.getStackInHand(var11.getHand()) : ItemStack.EMPTY;
            this.d("USE_ITEM | hand=" + var11.getHand() + " item=" + this.a(var13, false));
         } else if (var2 instanceof CommandExecutionC2SPacket var12) {
            this.d("COMMAND | /" + var12.command());
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public static enum HWMode {
      a("Лайт 1.16"),
      b("Лайт 1.20");

      private final String c;

      private HWMode(String var3) {
         this.c = var3;
      }

      public String a() {
         return this.c;
      }

      private static HWJoinerHandler.HWMode[] b() {
         return new HWJoinerHandler.HWMode[]{a, b};
      }
   }
}
