package pulse.ui.clickgui.common;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.ui.clickgui.common.panel.SettingsPanelManager;
import pulse.ui.clickgui.common.provider.ToggleEntry;
import pulse.ui.clickgui.common.provider.ToggleListProvider;
import pulse.ui.clickgui.common.toggle.ModuleEntryRenderer;
import pulse.features.modules.Module;
import pulse.utils.render.Render;
import pulse.utils.render.LayerManager;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class ToggleListElement implements GuiElement {
   private final ToggleListProvider a;
   private static final float b = 19.0F;
   private static final float c = 48.0F;
   private static final float d = 26.0F;
   private static final float e = 6.5F;
   private static final float f = 8.0F;
   private static final float g = 2.0F;
   private final ScrollElement h;
   private final SettingsPanelManager i;
   private final ModuleEntryRenderer j;
   private float k;
   private float l;
   private float m;
   private float n;
   private int o;
   private int p;
   private boolean q = false;

   public ToggleListElement(ToggleListProvider var1) {
      this.a = var1;
      this.h = new ScrollElement(2.0F, 25.0F);
      this.i = new SettingsPanelManager();
      this.j = new ModuleEntryRenderer();
   }

   public List<ModuleSettingsPanel> a() {
      return this.i.a();
   }

   private float k() {
      int var1 = this.a.f();
      float var2 = ClickGuiScreen.e();
      float var3 = var2 - 38.0F;
      return var1 == 1 ? var3 - 2.0F : (var3 - 6.5F) / 2.0F - 1.0F;
   }

   private float c(int var1, int var2) {
      int var3 = (int)Math.ceil((double)var1 / var2);
      return var3 * 34.0F - 8.0F;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      this.h.a();
      this.b();
      this.o = var5;
      this.p = var6;
      float var7 = ClickGuiScreen.e();
      float var8 = ClickGuiScreen.f();
      float var9 = var3 + 19.0F;
      float var10 = var4 + 48.0F;
      float var11 = var7 - 38.0F;
      float var12 = var8 - 48.0F - 5.0F;
      this.k = var3;
      this.l = var4;
      this.m = var10;
      this.n = var12;
      LayerManager.a().a(LayerManager.Layer.d, var9, var10, var11, var12);
      List var13 = this.a.e();
      int var14 = this.a.f();
      float var15 = this.c(var13.size(), var14);
      this.i.a(var10, var12, this.h.b(), var14, 26.0F, 8.0F);
      var2.a().a(var9, var10, var11, var12, var1);
      if (!var13.isEmpty()) {
         this.a(var1, var2, var13, var9, var10, var12, var5, var6);
      }

      var2.a().a(var1);
      ModuleSettingsPanel var16 = this.i.a(var5, var6);
      boolean var17 = var16 != null;
      boolean var18 = this.i.d();
      boolean var19 = this.a(var13, var9, var10, var12, var5, var6);
      if (var19 && !this.h.c() && !var17 && !var18 && MouseUtil.a(LayerManager.Layer.d, var5, var6)) {
         MouseUtil.g();
      }

      float var20 = var3 + var7 - 1.0F;
      float var21 = var4 + 48.0F;
      float var22 = var8 - 48.0F - 18.0F;
      this.h.a(var1, var2, var20, var21, var22, var15, var12 - 13.0F, var5, var6, false);
      this.i.a(var1, var2, var3, var4, var5, var6, var10, var12);
      this.q = MouseUtil.m() || OverlayElement.a().b();
   }

   private void a(MatrixStack var1, Render var2, List<? extends ToggleEntry> var3, float var4, float var5, float var6, int var7, int var8) {
      int var9 = this.a.f();
      float var10 = this.k();
      float var11 = var5 - this.h.b();
      boolean var12 = !MouseUtil.a(LayerManager.Layer.d, var7, var8);
      boolean var13 = OverlayElement.a().b();
      boolean var14 = this.i.d();
      boolean var15 = MouseUtil.m() || var13 || var12 || var14;
      ToggleEntry var16 = this.i.e();

      for (int var17 = 0; var17 < var3.size(); var17++) {
         int var18 = var17 % var9;
         int var19 = var17 / var9;
         float var20 = var4 + var18 * (var10 + 6.5F) + 1.0F;
         float var21 = var11 + var19 * 34.0F + 1.0F;
         if (!(var21 + 26.0F < var5) && !(var21 > var5 + var6)) {
            ToggleEntry var22 = (ToggleEntry)var3.get(var17);
            boolean var23 = var16 == var22;
            boolean var24 = var12 || var13 && !var23 || MouseUtil.m() && !var23 || var14;
            boolean var25 = var8 >= var5 && var8 <= var5 + var6;
            this.j.a(var1, var2, var22, var20, var21, var10, 26.0F, var25 ? var7 : -1, var25 ? var8 : -1, var24, var23, this.q, var15);
         }
      }
   }

   private boolean a(List<? extends ToggleEntry> var1, float var2, float var3, float var4, int var5, int var6) {
      if (!(var6 < var3) && !(var6 > var3 + var4)) {
         int var7 = this.a.f();
         float var8 = this.k();
         float var9 = var3 - this.h.b();

         for (int var10 = 0; var10 < var1.size(); var10++) {
            int var11 = var10 % var7;
            int var12 = var10 / var7;
            float var13 = var2 + var11 * (var8 + 6.5F) + 1.0F;
            float var14 = var9 + var12 * 34.0F + 1.0F;
            if (MouseUtil.a(var13, var14, var8, 26.0F, (double)var5, (double)var6)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4) {
      this.i.b(var1, var2, this.k, this.l, var3, var4, this.m, this.n);
   }

   public void b() {
      this.i.b();
   }

   public void a(MatrixStack var1, Render var2) {
   }

   @Override
   public void a(float var1, float var2, int var3, int var4) {
      if (!this.i.c(var3, var4)) {
         if (!OverlayElement.a().b() || this.i.c()) {
            if (MouseUtil.a(LayerManager.Layer.d, var3, var4)) {
               float var5 = ClickGuiScreen.e();
               float var6 = ClickGuiScreen.f();
               float var7 = var2 + 48.0F;
               float var8 = var6 - 48.0F - 5.0F;
               List var9 = this.a.e();
               int var10 = this.a.f();
               float var11 = this.c(var9.size(), var10);
               float var12 = var1 + var5 - 1.0F;
               float var13 = var2 + 48.0F;
               float var14 = var6 - 48.0F - 18.0F;
               if (!this.h.a(var12, var13, var14, var11, var8 - 13.0F, var3, var4)) {
                  if (!(var4 < var7) && !(var4 > var7 + var8)) {
                     float var15 = var1 + 19.0F;
                     float var16 = this.k();
                     float var17 = var7 - this.h.b();

                     for (int var18 = 0; var18 < var9.size(); var18++) {
                        int var19 = var18 % var10;
                        int var20 = var18 / var10;
                        float var21 = var15 + var19 * (var16 + 6.5F);
                        float var22 = var17 + var20 * 34.0F;
                        if (MouseUtil.a(var21, var22, var16, 26.0F, (double)var3, (double)var4)) {
                           ToggleEntry var23 = (ToggleEntry)var9.get(var18);
                           if (var23.d()) {
                              float var24 = var21 + var16 - ModuleEntryRenderer.b() - ModuleEntryRenderer.a();
                              float var25 = var24 - ModuleEntryRenderer.d() - ModuleEntryRenderer.c();
                              float var26 = var22 + 13.0F - ModuleEntryRenderer.c() / 2.0F;
                              if (MouseUtil.a(var25, var26, ModuleEntryRenderer.c(), ModuleEntryRenderer.c(), (double)var3, (double)var4)) {
                                 this.i.a(var23, var18, var19 == 0, var21, var22, var16, 26.0F, var25, var26);
                                 return;
                              }
                           }

                           var23.a(!var23.b());
                           break;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void b(float var1, float var2, int var3, int var4) {
      if (!this.i.d(var3, var4)) {
         if (!OverlayElement.a().b()) {
            if (MouseUtil.a(LayerManager.Layer.d, var3, var4)) {
               float var5 = ClickGuiScreen.f();
               float var6 = var2 + 48.0F;
               float var7 = var5 - 48.0F - 5.0F;
               if (!(var4 < var6) && !(var4 > var6 + var7)) {
                  List var8 = this.a.e();
                  int var9 = this.a.f();
                  float var10 = var1 + 19.0F;
                  float var11 = this.k();
                  float var12 = var6 - this.h.b();

                  for (int var13 = 0; var13 < var8.size(); var13++) {
                     int var14 = var13 % var9;
                     int var15 = var13 / var9;
                     float var16 = var10 + var14 * (var11 + 6.5F);
                     float var17 = var12 + var15 * 34.0F;
                     if (MouseUtil.a(var16, var17, var11, 26.0F, (double)var3, (double)var4)) {
                        ToggleEntry var18 = (ToggleEntry)var8.get(var13);
                        if (var18.d()) {
                           float var19 = var16 + var11 - ModuleEntryRenderer.b() - ModuleEntryRenderer.a();
                           float var20 = var19 - ModuleEntryRenderer.d() - ModuleEntryRenderer.c();
                           float var21 = var17 + 13.0F - ModuleEntryRenderer.c() / 2.0F;
                           boolean var22 = var18.g() && MouseUtil.a(var20, var21, ModuleEntryRenderer.c(), ModuleEntryRenderer.c(), (double)var3, (double)var4);
                           if (var22) {
                              this.i.a(var18, var13, var14 == 0, var16, var17, var11, 26.0F, var20, var21);
                              return;
                           }

                           if (!var18.g()) {
                              this.i.a(var18, var13, var14 == 0, var16, var17, var11, 26.0F, var3, var4);
                              return;
                           }
                        }

                        this.i.a(var18, var13, var14 == 0, var17, 26.0F);
                        break;
                     }
                  }
               }
            }
         }
      }
   }

   public void c(float var1, float var2, int var3, int var4) {
      this.h.d();
      this.i.e(var3, var4);
   }

   public void a(float var1, float var2, int var3, int var4, double var5, double var7) {
      this.i.a(var3, var4, var5, var7);
      if (this.h.c()) {
         List var9 = this.a.e();
         int var10 = this.a.f();
         float var11 = this.c(var9.size(), var10);
         float var12 = ClickGuiScreen.f();
         float var13 = var12 - 48.0F - 18.0F;
         this.h.a(var4, var11, var13);
      }
   }

   public void a(float var1) {
      if (!this.i.a(var1, this.o, this.p)) {
         if (!this.h.c()) {
            float var2 = ClickGuiScreen.e();
            float var3 = ClickGuiScreen.f();
            if (MouseUtil.a(this.k, this.l, var2, var3, (double)this.o, (double)this.p)) {
               List var4 = this.a.e();
               int var5 = this.a.f();
               float var6 = this.c(var4.size(), var5);
               float var7 = var3 - 48.0F - 19.0F;
               this.h.a(var1, var6, var7);
            }
         }
      }
   }

   public boolean a(int var1, int var2, int var3) {
      return this.i.a(var1, var2, var3);
   }

   public boolean a(char var1, int var2) {
      return this.i.a(var1, var2);
   }

   public boolean c() {
      return this.i.l();
   }

   public void d() {
      this.h.e();
      this.i.i();
   }

   public void e() {
      this.i.i();
   }

   public void f() {
      this.i.j();
   }

   public void g() {
      this.i.g();
   }

   public void h() {
      this.i.h();
   }

   public void i() {
      this.i.k();
   }

   public boolean j() {
      return this.i.c();
   }

   public boolean a(int var1, int var2) {
      return this.i.b(var1, var2);
   }

   public ModuleSettingsPanel b(int var1, int var2) {
      return this.i.a(var1, var2);
   }

   public void a(Module var1) {
      this.i.a(var1);
   }
}
