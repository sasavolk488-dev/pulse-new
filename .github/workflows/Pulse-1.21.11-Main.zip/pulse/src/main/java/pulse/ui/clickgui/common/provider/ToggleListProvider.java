package pulse.ui.clickgui.common.provider;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface ToggleListProvider {
   List<? extends ToggleEntry> e();

   int f();
}
