package pulse.features.modules.utilities;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;

@ModuleInfo(
   a = "Streamer Mode",
   b = "Скрывает имя игрока и другую личную информацию",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class StreamerModeModule extends Module {
   public final BooleanSetting a = new BooleanSetting("Скрыть ник", false);
   public final BooleanSetting b = new BooleanSetting("Скрыть номер анархии", false);
   public final BooleanSetting c = new BooleanSetting("Скрыть координаты", false);
   private static final ThreadLocal<Integer> f = ThreadLocal.withInitial(() -> 0);

   public static boolean n() {
      return f.get() > 0;
   }

   public static void o() {
      f.set(f.get() + 1);
   }

   public static void p() {
      f.set(Math.max(0, f.get() - 1));
   }
}
