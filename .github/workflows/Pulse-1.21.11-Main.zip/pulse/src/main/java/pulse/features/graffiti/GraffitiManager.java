package pulse.features.graffiti;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import pulse.Pulse;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@Environment(EnvType.CLIENT)
public final class GraffitiManager {
   private static final GraffitiManager b = new GraffitiManager();
   private static final int c = 16;
   private static final int d = 16;
   private static final int e = 64;
   private static final int f = 50;
   public static final long a = 90000L;
   private final List<GraffitiDecal> g = new CopyOnWriteArrayList<>();
   private final Map<String, Integer> h = new ConcurrentHashMap<>();
   private final Map<Integer, Integer> i = new ConcurrentHashMap<>();
   private volatile String j;
   private volatile List<Integer> k = List.of();

   private GraffitiManager() {
   }

   public static GraffitiManager a() {
      return b;
   }

   public void a(List<Integer> var1, Map<Integer, Integer> var2) {
      this.k = var1 != null ? List.copyOf(var1) : List.of();
      if (var2 != null) {
         this.i.clear();
         this.i.putAll(var2);
      }
   }

   public void a(int var1, int var2) {
      this.i.put(var1, Math.max(0, var2));
   }

   public List<GraffitiEntry> b() {
      ArrayList<GraffitiEntry> var1 = new ArrayList<>();
      var var2 = this.k;

      for (GraffitiEntry var4 : GraffitiBundleManager.a()) {
         if (var2.contains(var4.a())) {
            var1.add(var4);
         }
      }

      return var1;
   }

   public GraffitiEntry c() {
      List<GraffitiEntry> var1 = this.b();
      if (var1.isEmpty()) {
         return null;
      } else {
         String var2 = this.j;
         if (var2 != null) {
            for (GraffitiEntry var4 : var1) {
               if (var4.b().equals(var2)) {
                  return var4;
               }
            }
         }

         return (GraffitiEntry)var1.get(0);
      }
   }

   public void a(GraffitiEntry var1) {
      if (var1 != null) {
         this.j = var1.b();
      }
   }

   public int b(GraffitiEntry var1) {
      return var1.a() >= 0 ? this.i.getOrDefault(var1.a(), 0) : this.h.getOrDefault(var1.b(), 50);
   }

   public List<GraffitiDecal> d() {
      return this.g;
   }

   public void a(BlockPos var1, Direction var2, Direction var3) {
      GraffitiEntry var4 = this.c();
      if (var4 != null) {
         int var5 = this.b(var4);
         if (var5 > 0) {
            String var6 = this.f();
            if (var6 != null) {
               if (var4.a() >= 0) {
                  this.i.put(var4.a(), var5 - 1);
               } else {
                  this.h.put(var4.b(), var5 - 1);
               }

               this.g.removeIf(var3x -> var3x.worldKey().equals(var6) && var3x.a(var1, var2));
               this.g.add(new GraffitiDecal(var6, var1.toImmutable(), var2, var3, var4, System.currentTimeMillis(), null));

               while (this.g() > 16) {
                  this.c(null);
               }

               Pulse.m().info("[Graffiti] нанесено '{}' на {} грань {}", var4.c(), var1.toShortString(), var2);
               if (var4.a() >= 0) {
                  MinecraftClient var7 = MinecraftClient.getInstance();
                  String var8 = var7.world != null ? var7.world.getRegistryKey().getValue().toString() : null;
                  if (var8 != null) {
                     try {
                        RealtimeSyncServiceV2.L()
                           .a(var4.a(), var1.getX(), var1.getY(), var1.getZ(), var2.getIndex(), var3 != null ? var3.getIndex() : -1, var8);
                     } catch (Exception var10) {
                     }
                  }
               }
            }
         }
      }
   }

   public void a(String var1, int var2, BlockPos var3, int var4, int var5, String var6) {
      MinecraftClient var7 = MinecraftClient.getInstance();
      if (var7.world != null && var1 != null && !var1.isEmpty()) {
         if (var7.world.getRegistryKey().getValue().toString().equals(var6)) {
            GraffitiEntry var8 = GraffitiBundleManager.a(var2);
            if (var8 != null) {
               Direction var9 = Direction.byIndex(var4);
               Direction var10 = var5 >= 0 ? Direction.byIndex(var5) : null;
               String var11 = this.f();
               if (var11 != null) {
                  this.g.removeIf(var3x -> var3x.worldKey().equals(var11) && var3x.a(var3, var9));
                  this.g.add(new GraffitiDecal(var11, var3.toImmutable(), var9, var10, var8, System.currentTimeMillis(), var1));

                  while (this.b(var1) > 16) {
                     this.c(var1);
                  }

                  while (this.h() > 64) {
                     this.i();
                  }
               }
            }
         }
      }
   }

   public void a(String var1) {
      if (var1 != null) {
         this.g.removeIf(var1x -> var1.equalsIgnoreCase(var1x.owner()));
      }
   }

   private int g() {
      int var1 = 0;

      for (GraffitiDecal var3 : this.g) {
         if (var3.owner() == null) {
            var1++;
         }
      }

      return var1;
   }

   private int h() {
      int var1 = 0;

      for (GraffitiDecal var3 : this.g) {
         if (var3.owner() != null) {
            var1++;
         }
      }

      return var1;
   }

   private int b(String var1) {
      int var2 = 0;

      for (GraffitiDecal var4 : this.g) {
         if (var1.equalsIgnoreCase(var4.owner())) {
            var2++;
         }
      }

      return var2;
   }

   private void c(String var1) {
      for (GraffitiDecal var3 : this.g) {
         boolean var4 = var1 == null ? var3.owner() == null : var1.equalsIgnoreCase(var3.owner());
         if (var4) {
            this.g.remove(var3);
            return;
         }
      }
   }

   private void i() {
      for (GraffitiDecal var2 : this.g) {
         if (var2.owner() != null) {
            this.g.remove(var2);
            return;
         }
      }
   }

   public void e() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.world != null) {
         String var2 = this.f();
         if (var2 != null) {
            long var3 = System.currentTimeMillis();

            for (GraffitiDecal var6 : this.g) {
               if (var3 - var6.placedAt() > 90000L) {
                  this.g.remove(var6);
               } else if (var6.worldKey().equals(var2)
                  && var1.world.isChunkLoaded(var6.pos().getX() >> 4, var6.pos().getZ() >> 4)
                  && var1.world.getBlockState(var6.pos()).isAir()) {
                  this.g.remove(var6);
               }
            }
         }
      }
   }

   public String f() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.world == null) {
         return null;
      } else {
         String var2 = var1.getCurrentServerEntry() != null ? var1.getCurrentServerEntry().address : "singleplayer";
         return var2 + "|" + var1.world.getRegistryKey().getValue();
      }
   }
}
