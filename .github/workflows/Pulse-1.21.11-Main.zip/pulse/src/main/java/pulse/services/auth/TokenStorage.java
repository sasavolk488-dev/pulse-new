package pulse.services.auth;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermissions;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public class TokenStorage {
   private static final String a = "C:\\PulseVisuals\\launcher\\token.dat";

   public static String a() {
      return "C:\\PulseVisuals\\launcher\\token.dat";
   }

   public static boolean b() {
      return Files.exists(Paths.get(a()));
   }

   public static String c() {
      try {
         Path var0 = Paths.get(a());
         if (!Files.exists(var0)) {
            return null;
         } else {
            byte[] var1 = Files.readAllBytes(var0);
            String var2 = new String(var1, StandardCharsets.UTF_8).trim();
            return var2.isEmpty() ? null : var2;
         }
      } catch (IOException var3) {
         Pulse.m().error("Ошибка чтения токена", (Throwable)var3);
         return null;
      }
   }

   public static void a(String var0) throws IOException {
      Path var1 = Paths.get("C:\\PulseVisuals\\launcher\\token.dat");
      Files.createDirectories(var1.getParent());
      Files.write(var1, var0.getBytes(StandardCharsets.UTF_8));
      if (!System.getProperty("os.name").toLowerCase().contains("win")) {
         try {
            Files.setPosixFilePermissions(var1, PosixFilePermissions.fromString("rw-------"));
         } catch (Exception var3) {
         }
      }

      Pulse.m().info("Токен сохранен: " + var1);
   }

   public static void d() {
      try {
         Files.deleteIfExists(Paths.get(a()));
         Pulse.m().info("Токен удален");
      } catch (IOException var1) {
         Pulse.m().error("Ошибка удаления токена", (Throwable)var1);
      }
   }
}
