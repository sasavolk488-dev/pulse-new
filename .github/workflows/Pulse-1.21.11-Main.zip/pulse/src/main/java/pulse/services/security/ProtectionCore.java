package pulse.services.security;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import aethereal.api.Mutation;
import java.security.KeyPair;
import java.security.PublicKey;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ProtectionCore implements Runnable {
   private static final int a = 2;
   private static volatile byte[] b = null;
   private static volatile long c = 0L;
   private static volatile int d = 0;
   private static volatile long e = 0L;
   private static volatile int f = 0;
   private static volatile Thread g = null;
   private static volatile boolean h = false;
   private static volatile KeyPair i = null;
   private static volatile PublicKey j = null;
   private static volatile boolean k = false;
   private static volatile String l = null;
   private static volatile String m = null;

   private static String a(String var0) {
      String var1 = m;
      if (var1 != null) {
         return var1;
      } else {
         String var2 = SystemInfoCollector.b(var0);
         m = var2;
         return var2;
      }
   }

   @Compile
   private static String c(int var0) {
      if (var0 == 1) {
         String override = pulse.Pulse.c();
         if (override != null && override.length() != 0) {
            return override;
         }
      }
      int[] prefix = new int[]{102, 114, 101, 97, 107};
      int[] suffix = new int[]{46, 112, 117, 108, 115, 101, 118, 105, 115, 117, 97, 108, 115, 46, 112, 114, 111};
      int extra = var0 >= 2 ? 1 : 0;
      char[] characters = new char[prefix.length + suffix.length + extra];
      int position = 0;
      for (int index = 0; index < prefix.length; index++) {
         characters[position++] = (char)prefix[index];
      }
      if (var0 >= 2) {
         characters[position++] = (char)(var0 + 48);
      }
      for (int index = 0; index < suffix.length; index++) {
         characters[position++] = (char)suffix[index];
      }
      return new String(characters);
   }

   @Compile
   private static int d(int var0) {
      return new int[]{0x8b2, 0x8b2, 0x8b4, 0x8b2}[var0];
   }

   public static byte[] a() {
      return new byte[0];
   }

   private static byte[] e(int var0) {
      return new byte[0];
   }

   private static void f() {
   }

   @Compile
   @Override
   public native void run();

   private static boolean f(int var0) {
      return false;
   }

   @Mutation
   public static native byte[] a(byte[] var0, int var1);

   public static boolean a(int var0) {
      return false;
   }

   public static void b(int var0) {
   }

   public static boolean b() {
      return false;
   }

   public static void c() {
      if (b == null || System.currentTimeMillis() - c >= 600000L) {
         e();
      }
   }

   public static void d() {
   }

   public static void e() {
   }

   private static String b(String var0) {
      return "";
   }

   private static String c(String var0) {
      return "";
   }

   static {
      NativeMethodLookup.lookup(ProtectionCore.class, 92);
   }
}
