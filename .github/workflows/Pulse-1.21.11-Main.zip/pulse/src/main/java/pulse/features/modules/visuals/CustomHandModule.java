package pulse.features.modules.visuals;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Custom Hand",
   b = "Настраивает отображение руки игрока",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class CustomHandModule extends Module {
   public final ModeSetting a = new ModeSetting(
      "Анимация", new String[]{"Обычная", "Без анимации", "Наклон", "Взмах", "Вращение", "Увеличение", "Уменьшение", "Растяжение"}, "Обычная"
   );
   public final NumberSetting b = new NumberSetting("Скорость анимации", 6.0F, 1.0F, 20.0F, 1.0F);
   public final NumberSetting c = new NumberSetting("Сила взмаха", 5.0F, 1.0F, 10.0F, 0.5F);
   private final SeparatorSetting y = new SeparatorSetting("Шейдер");
   public final BooleanSetting f = new BooleanSetting("Шейдер", false);
   public final BooleanSetting g = new BooleanSetting("Обводка", false);
   public final ModeSetting h = new ModeSetting("Тип шейдера", new String[]{"Небула", "Звёзды", "Паутина", "Плазма"}, "Небула").a(() -> this.f.a());
   public final BooleanSetting i = new BooleanSetting("След руки", false);
   public final NumberSetting j = new NumberSetting("Длина следа", 0.9F, 0.5F, 0.97F, 0.01F).a(() -> this.i.a());
   public final NumberSetting k = new NumberSetting("Плотность следа", 0.8F, 0.1F, 2.0F, 0.05F).a(() -> this.i.a());
   public final NumberSetting l = new NumberSetting("Скорость шейдера", 1.0F, 0.1F, 3.0F, 0.1F).a(() -> this.f.a() || this.g.a() || this.i.a());
   public final NumberSetting m = new NumberSetting("Прозрачность шейдера", 0.5F, 0.1F, 1.0F, 0.05F).a(() -> this.f.a() || this.g.a());
   public final BooleanSetting n = new BooleanSetting("Только шейдер", false).a(() -> this.f.a() || this.g.a());
   public final BooleanSetting o = new BooleanSetting("Цвет клиента", true).a(() -> this.f.a() || this.g.a() || this.i.a());
   public final ColorSetting p = new ColorSetting("Цвет шейдера", Color.WHITE).a(() -> (this.f.a() || this.g.a() || this.i.a()) && !this.o.a());
   private final SeparatorSetting z = new SeparatorSetting("Основная рука");
   public final NumberSetting q = new NumberSetting("Размер", 1.0F, 0.5F, 1.5F, 0.05F);
   public final NumberSetting r = new NumberSetting("X смещение", 0.0F, -2.0F, 2.0F, 0.05F);
   public final NumberSetting s = new NumberSetting("Y смещение", 0.0F, -2.0F, 2.0F, 0.05F);
   public final NumberSetting t = new NumberSetting("Z смещение", 0.0F, -2.0F, 2.0F, 0.05F);
   private final SeparatorSetting A = new SeparatorSetting("Вторая рука");
   public final NumberSetting u = new NumberSetting("Размер ", 1.0F, 0.5F, 1.5F, 0.05F);
   public final NumberSetting v = new NumberSetting("X смещение ", 0.0F, -2.0F, 2.0F, 0.05F);
   public final NumberSetting w = new NumberSetting("Y смещение ", 0.0F, -2.0F, 2.0F, 0.05F);
   public final NumberSetting x = new NumberSetting("Z смещение ", 0.0F, -2.0F, 2.0F, 0.05F);

   public void a(MatrixStack var1, float var2, Runnable var3, boolean var4) {
      float var5 = (float)Math.sin(var2 * 1.5707964293589551 * 2.0);
      float var6 = var4 ? -1.0F : 1.0F;
      float var7 = var4 ? this.v.b() * var6 : this.r.b();
      float var8 = var4 ? this.w.b() : this.s.b();
      float var9 = var4 ? this.x.b() : this.t.b();
      float var10 = var4 ? this.u.b() : this.q.b();
      String var11 = this.a.e();
      switch (var11) {
         case "Без анимации":
            var3.run();
            break;
         case "Наклон":
            var1.scale(var10, var10, var10);
            var1.translate(var7, var8, var9);
            var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90.0F * var6));
            var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-60.0F * var6));
            var1.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F - this.c.b() * 10.0F * var5));
            break;
         case "Взмах":
            var1.scale(var10, var10, var10);
            var1.translate(var7, var8, var9);
            var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90.0F * var6));
            var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-30.0F * var6));
            var1.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F - this.c.b() * 10.0F * var5));
            break;
         case "Вращение":
            var1.scale(var10, var10, var10);
            var1.translate(var7, var8, var9);
            var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(360.0F * var2 * var6));
            var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-90.0F * var6));
            var1.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F - this.c.b() * 10.0F * var5));
            break;
         case "Увеличение":
            float var13 = 1.0F + this.c.b() / 10.0F * var5;
            var1.scale(var10 * var13, var10 * var13, var10 * var13);
            var1.translate(var7, var8, var9);
            var3.run();
            break;
         case "Уменьшение":
            float var14 = 1.0F - this.c.b() / 10.0F * var5;
            var1.scale(var10 * var14, var10 * var14, var10 * var14);
            var1.translate(var7, var8, var9);
            var3.run();
            break;
         case "Растяжение":
            float var15 = 1.0F;
            if (var2 > 0.0F) {
               if (var2 < 0.5F) {
                  var15 = 1.0F + var2 * 2.0F * (this.c.b() / 5.0F);
               } else {
                  var15 = 1.0F + (1.0F - (var2 - 0.5F) * 2.0F) * (this.c.b() / 5.0F);
               }
            }

            var1.scale(var10 / var15, var10 * var15, var10);
            var1.translate(var7, var8, var9);
            break;
         default:
            var1.scale(var10, var10, var10);
            var1.translate(var7, var8, var9);
            var3.run();
      }
   }

   public boolean n() {
      return !this.a.b("Без анимации");
   }

   public int o() {
      String var1 = this.h.e();
      switch (var1) {
         case "Звёзды":
            return 1;
         case "Паутина":
            return 2;
         case "Плазма":
            return 3;
         default:
            return 0;
      }
   }

   public Color p() {
      if (this.o.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         if (var1 != null) {
            return var1.n();
         }
      }

      return this.p.a();
   }
}
