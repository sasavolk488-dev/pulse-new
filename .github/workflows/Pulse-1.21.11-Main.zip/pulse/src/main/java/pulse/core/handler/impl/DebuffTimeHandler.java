package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.registry.entry.RegistryEntry;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class DebuffTimeHandler extends Handler {
   private static final MinecraftClient a = MinecraftClient.getInstance();
   private final List<DebuffTimeHandler.ComboPotionInfo> b = Arrays.asList(
      new DebuffTimeHandler.ComboPotionInfo(
         "Зелье Радиации",
         Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.POISON, 1), new DebuffTimeHandler.EffectRequirement(StatusEffects.SLOWNESS, 2)),
         StatusEffects.POISON,
         true
      ),
      new DebuffTimeHandler.ComboPotionInfo(
         "Снотворное",
         Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.WEAKNESS, 1), new DebuffTimeHandler.EffectRequirement(StatusEffects.WITHER, 2)),
         StatusEffects.WITHER,
         true
      ),
      new DebuffTimeHandler.ComboPotionInfo(
         "Хлопушка", Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.SPEED, 4)), StatusEffects.SPEED, false
      ),
      new DebuffTimeHandler.ComboPotionInfo(
         "Святая вода", Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.REGENERATION, 2)), StatusEffects.REGENERATION, false
      ),
      new DebuffTimeHandler.ComboPotionInfo(
         "Зелье гнева", Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.STRENGTH, 4)), StatusEffects.STRENGTH, false
      ),
      new DebuffTimeHandler.ComboPotionInfo(
         "Зелье Палладина", Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.HEALTH_BOOST, 2)), StatusEffects.HEALTH_BOOST, false
      ),
      new DebuffTimeHandler.ComboPotionInfo(
         "Зелье Ассасина", Arrays.asList(new DebuffTimeHandler.EffectRequirement(StatusEffects.STRENGTH, 3)), StatusEffects.STRENGTH, false
      )
   );
   private List<DebuffTimeHandler.ActiveDebuff> c = new ArrayList<>();
   private DebuffTimeHandler.ActiveDebuff d = null;
   private long e = 0L;
   private int f = 0;
   private static final long g = 1000L;
   private boolean h = false;
   private boolean i = false;
   private boolean j = false;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      if (a.player == null || a.world == null) {
         if (this.j) {
            this.i = true;
            this.j = false;
         }
         this.c.clear();
         this.d = null;
         return;
      }
      var detected = this.k();
      boolean present;
      try {
         present = !detected.isEmpty();
      } catch (RuntimeException | Error failure) {
         this.h = true;
         throw failure;
      }
      if (present && !this.j) {
         this.h = true;
      } else if (!present && this.j) {
         this.i = true;
      }
      this.j = present;
      this.c = detected;
      boolean empty;
      try {
         empty = this.c.isEmpty();
      } catch (RuntimeException | Error failure) {
         this.f = 0;
         throw failure;
      }
      if (empty) {
         this.d = null;
         return;
      }
      int size;
      try {
         size = this.c.size();
      } catch (RuntimeException | Error failure) {
         this.f = 0;
         throw failure;
      }
      if (size == 1) {
         this.f = 0;
      } else {
         int current = this.f;
         int count;
         try {
            count = this.c.size();
         } catch (RuntimeException | Error failure) {
            if (current >= 0) {
               this.f = 0;
            } else {
               System.currentTimeMillis();
            }
            throw failure;
         }
         if (current >= count) {
            this.f = 0;
         }
         long now = System.currentTimeMillis();
         if (now - this.e >= 1000L) {
            try {
               this.f = (this.f + 1) % this.c.size();
            } catch (RuntimeException | Error failure) {
               this.f = 0;
               throw failure;
            }
            this.e = now;
         }
      }
      try {
         this.d = this.c.get(this.f);
      } catch (RuntimeException | Error failure) {
         this.d = null;
         throw failure;
      }
   }

   public boolean d() {
      if (this.h) {
         this.h = false;
         return true;
      } else {
         return false;
      }
   }

   public boolean e() {
      if (this.i) {
         this.i = false;
         return true;
      } else {
         return false;
      }
   }

   public boolean f() {
      return !this.c.isEmpty();
   }

   private List<DebuffTimeHandler.ActiveDebuff> k() {
      ArrayList var1 = new ArrayList();
      if (a.player == null) {
         return var1;
      } else {
         HashSet var2 = new HashSet();

         for (DebuffTimeHandler.ComboPotionInfo var4 : this.b) {
            if (!var2.contains(var4.a)) {
               if (this.a(var4)) {
                  var4.e = true;
               }

               if (var4.e) {
                  StatusEffectInstance var5 = a.player.getStatusEffect(var4.c);
                  if (var5 != null) {
                     boolean var6 = false;
                     int var7 = var5.getDuration();

                     for (DebuffTimeHandler.EffectRequirement var9 : var4.b) {
                        StatusEffectInstance var10 = a.player.getStatusEffect(var9.a);
                        if (var10 != null && var10.getAmplifier() == var9.b) {
                           var6 = true;
                           var7 = Math.min(var7, var10.getDuration());
                        }
                     }

                     if (var6) {
                        var1.add(new DebuffTimeHandler.ActiveDebuff(var4.a, var4.c, var7, var4.d));
                        var2.add(var4.a);
                     } else {
                        var4.e = false;
                     }
                  } else {
                     var4.e = false;
                  }
               }
            }
         }

         return var1;
      }
   }

   private boolean a(DebuffTimeHandler.ComboPotionInfo var1) {
      if (a.player == null) {
         return false;
      } else {
         for (DebuffTimeHandler.EffectRequirement var3 : var1.b) {
            StatusEffectInstance var4 = a.player.getStatusEffect(var3.a);
            if (var4 == null || var4.getAmplifier() != var3.b) {
               return false;
            }
         }

         return true;
      }
   }

   @Generated
   public List<DebuffTimeHandler.ActiveDebuff> g() {
      return this.c;
   }

   @Generated
   public DebuffTimeHandler.ActiveDebuff h() {
      return this.d;
   }

   @Generated
   public boolean i() {
      return this.h;
   }

   @Generated
   public boolean j() {
      return this.i;
   }

   static {
      NativeMethodLookup.lookup(DebuffTimeHandler.class, 23);
   }

   @Environment(EnvType.CLIENT)
   public static class ActiveDebuff {
      private final String a;
      private final Item b;
      private final RegistryEntry<StatusEffect> c;
      private final boolean d;
      private final int e;
      private final String f;
      private final String g;
      private final boolean h;

      public ActiveDebuff(String var1, Item var2, int var3, boolean var4) {
         this.a = var1;
         this.b = var2;
         this.c = null;
         this.d = false;
         this.e = var3;
         this.h = var4;
         this.f = a(var3 / 20);
         this.g = var1 + " закончится через: " + this.f;
      }

      public ActiveDebuff(String var1, RegistryEntry<StatusEffect> var2, int var3, boolean var4) {
         this.a = var1;
         this.b = null;
         this.c = var2;
         this.d = true;
         this.e = var3;
         this.h = var4;
         this.f = a(var3 / 20);
         this.g = var1 + " закончится через: " + this.f;
      }

      private static String a(int var0) {
         if (var0 < 60) {
            return var0 + "с";
         } else {
            int var1 = var0 / 60;
            int var2 = var0 % 60;
            return var2 == 0 ? var1 + "м" : var1 + "м " + var2 + "с";
         }
      }

      @Generated
      public String a() {
         return this.a;
      }

      @Generated
      public Item b() {
         return this.b;
      }

      @Generated
      public RegistryEntry<StatusEffect> c() {
         return this.c;
      }

      @Generated
      public boolean d() {
         return this.d;
      }

      @Generated
      public int e() {
         return this.e;
      }

      @Generated
      public String f() {
         return this.f;
      }

      @Generated
      public String g() {
         return this.g;
      }

      @Generated
      public boolean h() {
         return this.h;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class ComboPotionInfo {
      final String a;
      final List<DebuffTimeHandler.EffectRequirement> b;
      final RegistryEntry<StatusEffect> c;
      final boolean d;
      boolean e = false;

      ComboPotionInfo(String var1, List<DebuffTimeHandler.EffectRequirement> var2, RegistryEntry<StatusEffect> var3, boolean var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class EffectRequirement {
      final RegistryEntry<StatusEffect> a;
      final int b;

      EffectRequirement(RegistryEntry<StatusEffect> var1, int var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
