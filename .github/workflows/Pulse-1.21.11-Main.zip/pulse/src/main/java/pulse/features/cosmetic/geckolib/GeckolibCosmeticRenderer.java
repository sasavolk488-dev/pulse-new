package pulse.features.cosmetic.geckolib;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import pulse.Pulse;
import pulse.features.cosmetic.geo.GeoBone;
import pulse.features.cosmetic.geo.GeoCube;
import pulse.features.cosmetic.geo.GeoModel;
import pulse.features.cosmetic.geo.GeoQuad;
import pulse.features.cosmetic.geo.GeoVertex;
import pulse.features.cosmetic.model.CosmeticModel;

@Environment(EnvType.CLIENT)
public class GeckolibCosmeticRenderer {
   private static GeckolibCosmeticRenderer a;
   private final Map<Integer, GeoModel> b = new ConcurrentHashMap<>();
   private final Map<Integer, GeckolibCosmeticRenderer.AllAnimationsData> c = new ConcurrentHashMap<>();
   private final Set<Integer> d = ConcurrentHashMap.newKeySet();
   private final Map<Long, Long> e = new ConcurrentHashMap<>();
   private final Map<Integer, GeckolibCosmeticRenderer.AnimState> f = new ConcurrentHashMap<>();
   private final Map<Integer, Map<String, float[]>> g = new ConcurrentHashMap<>();
   private final Map<Integer, Map<String, GeoBone>> h = new ConcurrentHashMap<>();
   private final Map<Integer, Map<String, float[]>> i = new ConcurrentHashMap<>();
   private final Map<Integer, Long> j = new ConcurrentHashMap<>();
   private static final float k = 0.5F;
   private static final float[] l = new float[]{0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F};
   private final GeckolibModelParser m = new GeckolibModelParser();
   private final float[] n = new float[3];
   private static final MatrixStack o = new MatrixStack();

   public static GeckolibCosmeticRenderer a() {
      if (a == null) {
         a = new GeckolibCosmeticRenderer();
      }

      return a;
   }

   public void a(CosmeticModel var1, MatrixStack var2, OrderedRenderCommandQueue var3, int var4, GeckolibCosmeticRenderer.AnimState var5) {
      if (var1 != null && var1.e() != null) {
         Identifier var6 = var1.e();
         RenderLayer var7 = RenderLayers.entityCutoutNoCull(var6);
         var3.submitCustom(var2, var7, (var4x, var5x) -> {
            o.push();
            o.peek().copy(var4x);
            this.a(var1, o, var5x, var4, var5);
            o.pop();
         });
      }
   }

   public void a(CosmeticModel var1, MatrixStack var2, VertexConsumerProvider var3, int var4, GeckolibCosmeticRenderer.AnimState var5) {
      if (var1 != null && var1.e() != null) {
         RenderLayer var6 = RenderLayers.entityCutoutNoCull(var1.e());
         this.a(var1, var2, var3.getBuffer(var6), var4, var5);
      }
   }

   private void a(CosmeticModel var1, MatrixStack var2, VertexConsumer var3, int var4, GeckolibCosmeticRenderer.AnimState var5) {
      if (var1 != null && var1.e() != null) {
         GeoModel var6 = this.a(var1);
         if (var6 != null) {
            GeckolibCosmeticRenderer.AllAnimationsData var7 = this.b(var1);
            if (var7 != null) {
               this.a(var6, var7, var1.b(), var5);
            }

            float var8 = 0.0F;
            if (var1.v()) {
               long var9 = System.currentTimeMillis() / 50L;
               int var11 = (int)(var9 / var1.u()) % var1.r();
               var8 = (float)var1.s() / var1.t() * var11;
            }

            for (GeoBone var10 : var6.a) {
               this.a(var10, var2, var3, var4, OverlayTexture.DEFAULT_UV, 1.0F, 1.0F, 1.0F, 1.0F, var8);
            }
         }
      }
   }

   public void a(CosmeticModel var1, MatrixStack var2, VertexConsumerProvider var3, int var4) {
      this.a(var1, var2, var3, var4, GeckolibCosmeticRenderer.AnimState.a);
   }

   private GeoModel a(CosmeticModel var1) {
      int var2 = var1.b();
      if (this.b.containsKey(var2)) {
         return this.b.get(var2);
      } else {
         GeoModel var3 = this.m.a(var1);
         if (var3 != null) {
            this.b.put(var2, var3);
            this.a(var2, var3);
            Pulse.m().info("Cached model for cosmetic: " + var1.a());
         }

         return var3;
      }
   }

   private void a(int var1, GeoModel var2) {
      HashMap var3 = new HashMap<>();
      HashMap var4 = new HashMap<>();

      for (GeoBone var6 : var2.a) {
         this.a(var6, var3, var4);
      }

      this.g.put(var1, var3);
      this.h.put(var1, var4);
   }

   private void a(GeoBone var1, Map<String, float[]> var2, Map<String, GeoBone> var3) {
      var2.put(var1.d, new float[]{var1.a(), var1.b(), var1.c(), var1.d(), var1.e(), var1.f(), var1.g(), var1.h(), var1.i()});
      var3.putIfAbsent(var1.d, var1);

      for (GeoBone var5 : var1.b) {
         this.a(var5, var2, var3);
      }
   }

   private void a(GeoBone var1, MatrixStack var2, VertexConsumer var3, int var4, int var5, float var6, float var7, float var8, float var9, float var10) {
      if (!var1.e) {
         var2.push();
         GeckoRenderHelper.a(var1, var2);
         GeckoRenderHelper.b(var1, var2);
         GeckoRenderHelper.d(var1, var2);
         GeckoRenderHelper.e(var1, var2);
         GeckoRenderHelper.c(var1, var2);

         for (GeoCube var12 : var1.c) {
            this.a(var12, var2, var3, var4, var5, var6, var7, var8, var9, var10);
         }

         for (GeoBone var14 : var1.b) {
            this.a(var14, var2, var3, var4, var5, var6, var7, var8, var9, var10);
         }

         var2.pop();
      }
   }

   private void a(GeoCube var1, MatrixStack var2, VertexConsumer var3, int var4, int var5, float var6, float var7, float var8, float var9, float var10) {
      var2.push();
      GeckoRenderHelper.a(var1, var2);
      GeckoRenderHelper.c(var1, var2);
      GeckoRenderHelper.b(var1, var2);
      Entry var11 = var2.peek();
      Matrix4f var12 = var11.getPositionMatrix();

      for (GeoQuad var16 : var1.a) {
         if (var16 != null) {
            float var17 = var16.b.a();
            float var18 = var16.b.b();
            float var19 = var16.b.c();
            if ((var1.b.b() == 0.0F || var1.b.c() == 0.0F) && var17 < 0.0F) {
               var17 = -var17;
            }

            if ((var1.b.a() == 0.0F || var1.b.c() == 0.0F) && var18 < 0.0F) {
               var18 = -var18;
            }

            if ((var1.b.a() == 0.0F || var1.b.b() == 0.0F) && var19 < 0.0F) {
               var19 = -var19;
            }

            for (GeoVertex var23 : var16.a) {
               var3.vertex(var12, var23.a.a(), var23.a.b(), var23.a.c())
                  .color(var6, var7, var8, var9)
                  .texture(var23.b, var23.c + var10)
                  .overlay(var5)
                  .light(var4)
                  .normal(var11, var17, var18, var19);
            }
         }
      }

      var2.pop();
   }

   private GeckolibCosmeticRenderer.AllAnimationsData b(CosmeticModel var1) {
      int var2 = var1.b();
      if (this.c.containsKey(var2)) {
         return this.c.get(var2);
      } else if (this.d.contains(var2)) {
         return null;
      } else {
         JsonObject var3 = var1.q();
         if (var3 == null) {
            this.d.add(var2);
            return null;
         } else {
            try {
               GeckolibCosmeticRenderer.AllAnimationsData var4 = this.a(var3);
               if (var4 != null && !var4.a.isEmpty()) {
                  this.c.put(var2, var4);
                  Pulse.m().info("Cached {} animation(s) for cosmetic: {}", var4.a.size(), var1.a());
               } else {
                  this.d.add(var2);
               }

               return var4;
            } catch (Exception var5) {
               Pulse.m().error("Failed to parse animation for: " + var1.a(), (Throwable)var5);
               this.d.add(var2);
               return null;
            }
         }
      }
   }

   private GeckolibCosmeticRenderer.AllAnimationsData a(JsonObject var1) {
      if (!var1.has("animations")) {
         return null;
      } else {
         JsonObject var2 = var1.getAsJsonObject("animations");
         GeckolibCosmeticRenderer.AllAnimationsData var3 = new GeckolibCosmeticRenderer.AllAnimationsData();
         boolean var4 = true;

         for (java.util.Map.Entry var6 : var2.entrySet()) {
            String var7 = (String)var6.getKey();
            JsonObject var8 = ((JsonElement)var6.getValue()).getAsJsonObject();
            GeckolibCosmeticRenderer.SingleAnimData var9 = new GeckolibCosmeticRenderer.SingleAnimData();
            var9.a = var8.has("loop") && var8.get("loop").getAsBoolean();
            var9.b = var8.has("animation_length") ? var8.get("animation_length").getAsFloat() : 1.0F;
            if (var8.has("bones")) {
               JsonObject var10 = var8.getAsJsonObject("bones");

               for (java.util.Map.Entry var12 : var10.entrySet()) {
                  String var13 = (String)var12.getKey();
                  JsonObject var14 = ((JsonElement)var12.getValue()).getAsJsonObject();
                  GeckolibCosmeticRenderer.BoneAnimationData var15 = new GeckolibCosmeticRenderer.BoneAnimationData();
                  if (var14.has("rotation")) {
                     var15.a = this.a(var14.get("rotation"));
                  }

                  if (var14.has("position")) {
                     var15.b = this.a(var14.get("position"));
                  }

                  if (var14.has("scale")) {
                     var15.c = this.a(var14.get("scale"));
                  }

                  var9.c.put(var13, var15);
               }
            }

            String var16 = this.a(var7);
            var3.a.put(var16, var9);
            if (var4) {
               var3.b = var16;
               var4 = false;
            }

            Pulse.m().info("  Parsed animation '{}' -> state '{}' (length={}, loop={})", var7, var16, var9.b, var9.a);
         }

         return var3;
      }
   }

   private String a(String var1) {
      String var2 = var1.toLowerCase();
      if (var2.contains("in_water_deep") || var2.contains("water_deep")) {
         return "water_deep";
      } else if (var2.contains("in_water_surface") || var2.contains("water_surface")) {
         return "water_surface";
      } else if (var2.contains("is_swimming") || var2.contains("swimming")) {
         return "swimming";
      } else if (var2.contains("flying")) {
         return "flying";
      } else if (var2.endsWith(".fly") || var2.equals("fly") || var2.contains("elytra")) {
         return "elytra";
      } else if (var2.contains("sneak")) {
         return "sneak";
      } else if (var2.contains("water")) {
         return "water";
      } else if (var2.contains("afk")) {
         return "afk";
      } else if (var2.contains("walk") || var2.contains("moving") || var2.contains("run")) {
         return "moving";
      } else if (var2.contains("gui") || var2.contains("preview")) {
         return "gui";
      } else if (!var2.contains("idle") && !var2.contains("main")) {
         String var3 = var1.contains(".") ? var1.substring(var1.lastIndexOf(46) + 1) : var1;
         return var3.toLowerCase();
      } else {
         return "idle";
      }
   }

   private GeckolibCosmeticRenderer.SingleAnimData a(GeckolibCosmeticRenderer.AllAnimationsData var1, GeckolibCosmeticRenderer.AnimState var2) {
      GeckolibCosmeticRenderer.SingleAnimData var3 = var1.a.get(var2.k);
      if (var3 != null) {
         return var3;
      } else {
         if (var2.l != null) {
            var3 = var1.a.get(var2.l);
            if (var3 != null) {
               return var3;
            }
         }

         var3 = var1.a.get("idle");
         return var3 != null ? var3 : var1.a.get(var1.b);
      }
   }

   private TreeMap<Float, float[]> a(JsonElement var1) {
      TreeMap var2 = new TreeMap();
      if (var1.isJsonObject()) {
         JsonObject var3 = var1.getAsJsonObject();

         for (java.util.Map.Entry var5 : var3.entrySet()) {
            try {
               float var6 = Float.parseFloat((String)var5.getKey());
               JsonElement var7 = (JsonElement)var5.getValue();
               float[] var8 = new float[3];
               if (var7.isJsonObject()) {
                  JsonObject var9 = var7.getAsJsonObject();
                  JsonArray var10 = null;
                  if (var9.has("vector")) {
                     var10 = var9.getAsJsonArray("vector");
                  } else if (var9.has("post")) {
                     JsonElement var11 = var9.get("post");
                     var10 = var11.isJsonArray() ? var11.getAsJsonArray() : null;
                  } else if (var9.has("pre")) {
                     JsonElement var14 = var9.get("pre");
                     var10 = var14.isJsonArray() ? var14.getAsJsonArray() : null;
                  }

                  if (var10 != null && var10.size() >= 3) {
                     var8[0] = var10.get(0).getAsFloat();
                     var8[1] = var10.get(1).getAsFloat();
                     var8[2] = var10.get(2).getAsFloat();
                  }
               } else if (var7.isJsonArray()) {
                  JsonArray var13 = var7.getAsJsonArray();
                  var8[0] = var13.get(0).getAsFloat();
                  var8[1] = var13.get(1).getAsFloat();
                  var8[2] = var13.get(2).getAsFloat();
               }

               var2.put(var6, var8);
            } catch (NumberFormatException var12) {
            }
         }
      }

      return var2;
   }

   private void a(GeoModel var1, GeckolibCosmeticRenderer.AllAnimationsData var2, int var3, GeckolibCosmeticRenderer.AnimState var4) {
      var var5 = this.g.get(var3);
      if (var5 != null) {
         GeckolibCosmeticRenderer.SingleAnimData var6 = this.a(var2, var4);
         if (var6 != null) {
            long var7 = var3 * 100L + var4.ordinal();
            GeckolibCosmeticRenderer.AnimState var9 = this.f.get(var3);
            float var10 = 1.0F;
            if (var9 != null && var9 != var4) {
               HashMap var11 = new HashMap<>();

               for (GeoBone var13 : var1.a) {
                  this.a(var13, var11);
               }

               this.i.put(var3, var11);
               this.j.put(var3, System.currentTimeMillis());
               this.f.put(var3, var4);
               if (!var6.a) {
                  this.e.put(var7, System.currentTimeMillis());
               }
            } else if (var9 == null) {
               this.f.put(var3, var4);
            }

            Long var30 = this.j.get(var3);
            if (var30 != null) {
               float var31 = (float)(System.currentTimeMillis() - var30) / 1000.0F;
               if (var31 < 0.5F) {
                  var10 = var31 / 0.5F;
                  var10 = var10 * var10 * (3.0F - 2.0F * var10);
               } else {
                  this.i.remove(var3);
                  this.j.remove(var3);
               }
            }

            long var32 = this.e.computeIfAbsent(var7, var0 -> System.currentTimeMillis());
            float var14 = (float)(System.currentTimeMillis() - var32) / 1000.0F;
            float var15 = var6.a && var6.b > 0.0F ? var14 % var6.b : Math.min(var14, var6.b);

            for (GeoBone var17 : var1.a) {
               this.b(var17, var5);
            }

            var var33 = this.i.get(var3);
            var var34 = this.h.get(var3);

            for (java.util.Map.Entry var19 : var6.c.entrySet()) {
               String var20 = (String)var19.getKey();
               GeckolibCosmeticRenderer.BoneAnimationData var21 = (GeckolibCosmeticRenderer.BoneAnimationData)var19.getValue();
               GeoBone var22 = var34 != null ? (GeoBone)var34.get(var20) : this.a(var1, var20);
               if (var22 != null) {
                  float[] var23 = (float[])var5.get(var20);
                  if (var23 == null) {
                     var23 = l;
                  }

                  if (!var21.a.isEmpty()) {
                     float[] var24 = this.a(var21.a, var15);
                     float var25 = var23[0] + (float)Math.toRadians(-var24[0]);
                     float var26 = var23[1] + (float)Math.toRadians(-var24[1]);
                     float var27 = var23[2] + (float)Math.toRadians(var24[2]);
                     if (var10 < 1.0F && var33 != null) {
                        float[] var28 = var33.getOrDefault(var20, var23);
                        var22.a(a(var28[0], var25, var10));
                        var22.b(a(var28[1], var26, var10));
                        var22.c(a(var28[2], var27, var10));
                     } else {
                        var22.a(var25);
                        var22.b(var26);
                        var22.c(var27);
                     }
                  }

                  if (!var21.b.isEmpty()) {
                     float[] var40 = this.a(var21.b, var15);
                     float var42 = var23[3] + var40[0];
                     float var44 = var23[4] + var40[1];
                     float var46 = var23[5] + var40[2];
                     if (var10 < 1.0F && var33 != null) {
                        float[] var48 = var33.getOrDefault(var20, var23);
                        var22.d(a(var48[3], var42, var10));
                        var22.e(a(var48[4], var44, var10));
                        var22.f(a(var48[5], var46, var10));
                     } else {
                        var22.d(var42);
                        var22.e(var44);
                        var22.f(var46);
                     }
                  }

                  if (!var21.c.isEmpty()) {
                     float[] var41 = this.a(var21.c, var15);
                     float var43 = var23[6] * var41[0];
                     float var45 = var23[7] * var41[1];
                     float var47 = var23[8] * var41[2];
                     if (var10 < 1.0F && var33 != null) {
                        float[] var49 = var33.getOrDefault(var20, var23);
                        var22.g(a(var49[6], var43, var10));
                        var22.h(a(var49[7], var45, var10));
                        var22.i(a(var49[8], var47, var10));
                     } else {
                        var22.g(var43);
                        var22.h(var45);
                        var22.i(var47);
                     }
                  }
               }
            }

            if (var10 < 1.0F && var33 != null) {
               for (java.util.Map.Entry var36 : var33.entrySet()) {
                  if (!var6.c.containsKey(var36.getKey())) {
                     GeoBone var37 = var34 != null ? (GeoBone)var34.get(var36.getKey()) : this.a(var1, (String)var36.getKey());
                     if (var37 != null) {
                        float[] var38 = (float[])var5.get(var36.getKey());
                        if (var38 == null) {
                           var38 = l;
                        }

                        float[] var39 = (float[])var36.getValue();
                        var37.a(a(var39[0], var38[0], var10));
                        var37.b(a(var39[1], var38[1], var10));
                        var37.c(a(var39[2], var38[2], var10));
                        var37.d(a(var39[3], var38[3], var10));
                        var37.e(a(var39[4], var38[4], var10));
                        var37.f(a(var39[5], var38[5], var10));
                        var37.g(a(var39[6], var38[6], var10));
                        var37.h(a(var39[7], var38[7], var10));
                        var37.i(a(var39[8], var38[8], var10));
                     }
                  }
               }
            }
         }
      }
   }

   private void a(GeoBone var1, Map<String, float[]> var2) {
      var2.put(var1.d, new float[]{var1.a(), var1.b(), var1.c(), var1.d(), var1.e(), var1.f(), var1.g(), var1.h(), var1.i()});

      for (GeoBone var4 : var1.b) {
         this.a(var4, var2);
      }
   }

   private static float a(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   private void b(GeoBone var1, Map<String, float[]> var2) {
      float[] var3 = (float[])var2.get(var1.d);
      if (var3 != null) {
         var1.a(var3[0]);
         var1.b(var3[1]);
         var1.c(var3[2]);
         var1.d(var3[3]);
         var1.e(var3[4]);
         var1.f(var3[5]);
         var1.g(var3[6]);
         var1.h(var3[7]);
         var1.i(var3[8]);
      }

      for (GeoBone var5 : var1.b) {
         this.b(var5, var2);
      }
   }

   private GeoBone a(GeoModel var1, String var2) {
      for (GeoBone var4 : var1.a) {
         GeoBone var5 = this.a(var4, var2);
         if (var5 != null) {
            return var5;
         }
      }

      return null;
   }

   private GeoBone a(GeoBone var1, String var2) {
      if (var1.d.equals(var2)) {
         return var1;
      } else {
         for (GeoBone var4 : var1.b) {
            GeoBone var5 = this.a(var4, var2);
            if (var5 != null) {
               return var5;
            }
         }

         return null;
      }
   }

   private float[] a(TreeMap<Float, float[]> var1, float var2) {
      float[] var3 = this.n;
      if (var1.isEmpty()) {
         var3[0] = 0.0F;
         var3[1] = 0.0F;
         var3[2] = 0.0F;
         return var3;
      } else {
         java.util.Map.Entry var4 = var1.floorEntry(var2);
         java.util.Map.Entry var5 = var1.ceilingEntry(var2);
         if (var4 == null && var5 == null) {
            var3[0] = 0.0F;
            var3[1] = 0.0F;
            var3[2] = 0.0F;
            return var3;
         } else if (var4 == null) {
            System.arraycopy(var5.getValue(), 0, var3, 0, 3);
            return var3;
         } else if (var5 == null) {
            System.arraycopy(var4.getValue(), 0, var3, 0, 3);
            return var3;
         } else if (((Float)var4.getKey()).equals(var5.getKey())) {
            System.arraycopy(var4.getValue(), 0, var3, 0, 3);
            return var3;
         } else {
            float var6 = (Float)var4.getKey();
            float var7 = (Float)var5.getKey();
            float[] var8 = (float[])var4.getValue();
            float[] var9 = (float[])var5.getValue();
            java.util.Map.Entry var10 = var1.lowerEntry(var6);
            java.util.Map.Entry var11 = var1.higherEntry(var7);
            float[] var12 = var10 != null ? (float[])var10.getValue() : var8;
            float[] var13 = var11 != null ? (float[])var11.getValue() : var9;
            float var14 = (var2 - var6) / (var7 - var6);
            var3[0] = a(var12[0], var8[0], var9[0], var13[0], var14);
            var3[1] = a(var12[1], var8[1], var9[1], var13[1], var14);
            var3[2] = a(var12[2], var8[2], var9[2], var13[2], var14);
            return var3;
         }
      }
   }

   private static float a(float var0, float var1, float var2, float var3, float var4) {
      float var5 = var4 * var4;
      float var6 = var5 * var4;
      return 0.5F
         * (2.0F * var1 + (-var0 + var2) * var4 + (2.0F * var0 - 5.0F * var1 + 4.0F * var2 - var3) * var5 + (-var0 + 3.0F * var1 - 3.0F * var2 + var3) * var6);
   }

   @Environment(EnvType.CLIENT)
   private static class AllAnimationsData {
      Map<String, GeckolibCosmeticRenderer.SingleAnimData> a = new HashMap<>();
      String b;
   }

   @Environment(EnvType.CLIENT)
   public static enum AnimState {
      a("idle"),
      b("moving"),
      c("elytra"),
      d("afk"),
      e("sneak"),
      f("swimming", "water"),
      g("water"),
      h("flying"),
      i("water_deep", "water"),
      j("water_surface", "water");

      final String k;
      final String l;

      private AnimState(String var3) {
         this.k = var3;
         this.l = null;
      }

      private AnimState(String var3, String var4) {
         this.k = var3;
         this.l = var4;
      }

      private static GeckolibCosmeticRenderer.AnimState[] a() {
         return new GeckolibCosmeticRenderer.AnimState[]{a, b, c, d, e, f, g, h, i, j};
      }
   }

   @Environment(EnvType.CLIENT)
   private static class BoneAnimationData {
      TreeMap<Float, float[]> a = new TreeMap<>();
      TreeMap<Float, float[]> b = new TreeMap<>();
      TreeMap<Float, float[]> c = new TreeMap<>();
   }

   @Environment(EnvType.CLIENT)
   private static class SingleAnimData {
      boolean a;
      float b;
      Map<String, GeckolibCosmeticRenderer.BoneAnimationData> c = new HashMap<>();
   }
}
