package pulse.services.tracker.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.ui.clickgui.menu.friends.CloudFriendEntry;

@Environment(EnvType.CLIENT)
public class CloudFriendsCache {
   private static final CloudFriendsCache a = new CloudFriendsCache();
   private final Map<Integer, CloudFriendEntry> b = new ConcurrentHashMap<>();
   private final AtomicLong c = new AtomicLong(0L);

   public static CloudFriendsCache a() {
      return a;
   }

   public long b() {
      return this.c.get();
   }

   public List<CloudFriendEntry> c() {
      var var1 = new ArrayList<>(this.b.values());
      var1.sort((var1x, var2) -> {
         int var3 = this.a(var1x.m());
         int var4 = this.a(var2.m());
         if (var3 != var4) {
            return Integer.compare(var3, var4);
         } else {
            String var5 = var1x.k() != null ? var1x.k() : var1x.l();
            String var6 = var2.k() != null ? var2.k() : var2.l();
            if (var5 == null && var6 == null) {
               return 0;
            } else if (var5 == null) {
               return 1;
            } else {
               return var6 == null ? -1 : var5.compareToIgnoreCase(var6);
            }
         }
      });
      return var1;
   }

   public CloudFriendEntry a(int var1) {
      return this.b.get(var1);
   }

   public void a(List<CloudFriendDataDto> var1) {
      this.b.clear();

      for (CloudFriendDataDto var3 : var1) {
         this.b.put(var3.a(), this.a(var3));
      }

      this.c.incrementAndGet();
   }

   public void a(int var1, String var2, String var3) {
      this.a(var1, var2, var3, null);
   }

   public void a(int var1, String var2, String var3, String var4) {
      CloudFriendEntry var5 = this.b.get(var1);
      if (var5 != null) {
         var5.a(this.a(var2));
         var5.f(var3);
         if (var4 != null && !var4.isEmpty()) {
            var5.d(var4);
         } else if ("offline".equals(var2)) {
            var5.d(null);
         }

         this.c.incrementAndGet();
      }
   }

   public void a(int var1, String var2) {
      if (!this.b.containsKey(var1)) {
         this.b.put(var1, new CloudFriendEntry(var1, var2, var2, CloudFriendEntry.Status.b, null));
         this.c.incrementAndGet();
      }
   }

   public void b(int var1) {
      if (this.b.remove(var1) != null) {
         this.c.incrementAndGet();
      }
   }

   public void d() {
      this.b.clear();
      this.c.incrementAndGet();
   }

   public void b(int var1, String var2, String var3) {
      CloudFriendEntry var4 = this.b.get(var1);
      if (var4 != null) {
         var4.b(var2);
         var4.c(var3);
         this.c.incrementAndGet();
      }
   }

   public void a(int var1, String var2, String var3, String var4, String var5) {
      CloudFriendEntry var6 = this.b.get(var1);
      if (var6 != null) {
         var6.b(var2);
         var6.c(var3);
         if (var4 != null && !var4.isEmpty()) {
            var6.e(var4);
         }

         var6.a(var5);
         this.c.incrementAndGet();
      }
   }

   private CloudFriendEntry a(CloudFriendDataDto var1) {
      String var2 = var1.f();
      String var3 = var2 != null && !var2.isEmpty() ? var2 : null;
      CloudFriendEntry var4 = new CloudFriendEntry(var1.a(), var3, var1.b(), this.a(var1.d()), var1.e());
      var4.a(var1.c());
      var4.b(var1.g());
      var4.c(var1.h());
      return var4;
   }

   private CloudFriendEntry.Status a(String var1) {
      if (var1 == null) {
         return CloudFriendEntry.Status.b;
      } else {
         switch (var1) {
            case "online":
               return CloudFriendEntry.Status.a;
            case "dnd":
               return CloudFriendEntry.Status.c;
            default:
               return CloudFriendEntry.Status.b;
         }
      }
   }

   private int a(CloudFriendEntry.Status var1) {
      if (var1 == CloudFriendEntry.Status.a) {
         return 0;
      } else {
         return var1 == CloudFriendEntry.Status.c ? 1 : 2;
      }
   }
}
