package pulse.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gl.PostEffectProcessor.FramebufferSet;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.render.FramePass;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.gizmo.GizmoDrawerImpl;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.memory.ObjectAllocator;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.FrameEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.WorldOverlayEvent;
import pulse.mixin.accessor.WorldRendererEntityOutlineAccessor;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.RenderTweaksModule;
import pulse.utils.render.world.TargetRings;

@Environment(EnvType.CLIENT)
@Mixin({WorldRenderer.class})
public abstract class WorldRendererMixin {
   @Shadow
   @Final
   private MinecraftClient client;
   @Shadow
   @Final
   private DefaultFramebufferSet framebufferSet;
   @Unique
   private static final WorldOverlayEvent PULSE_WORLD_OVERLAY_EVENT = new WorldOverlayEvent();
   @Unique
   private SimpleFramebuffer pulse$depthBackup;
   @Unique
   private GizmoDrawerImpl pulse$alwaysOnTopGizmos;

   @Inject(
      method = {"collectGizmos"},
      at = {@At("TAIL")}
   )
   private void pulse$captureAlwaysOnTopGizmos(CallbackInfo var1, @Local(ordinal = 1) GizmoDrawerImpl var2) {
      this.pulse$alwaysOnTopGizmos = var2;
   }

   @Unique
   private boolean pulse$lateDebugWillClearDepth() {
      GizmoDrawerImpl var1 = this.pulse$alwaysOnTopGizmos;
      return var1 == null || !var1.isEmpty();
   }

   @Inject(
      method = {"renderWeather"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderWeather(FrameGraphBuilder var1, GpuBufferSlice var2, CallbackInfo var3) {
      RenderTweaksModule var4 = ModuleRegistry.h;
      if (var4 != null && var4.n()) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void preRender(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      TargetRings.a(var5, var6);
      EventHandler.a.post(new FrameEvent(var2.getDynamicDeltaTicks()));
   }

   @Inject(
      method = {"render"},
      at = {@At("RETURN")}
   )
   private void postRender(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      WorldRendererEntityOutlineAccessor var12 = (WorldRendererEntityOutlineAccessor)this;
      if (TargetRings.a() && var12.pulse$canDrawEntityOutlines()) {
         TargetRings.a(var12.pulse$entityOutlineFramebuffer());
      }

      MatrixStack var13 = new MatrixStack();
      var13.peek().getPositionMatrix().set(var5);
      EventHandler.a.post(new RenderEvent(var13, var2.getTickProgress(true), var4));
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;renderLateDebug(Lnet/minecraft/client/render/FrameGraphBuilder;Lnet/minecraft/client/render/state/CameraRenderState;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Matrix4f;)V"
      )}
   )
   private void pulse$backupDepthBeforeLateDebug(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11,
      @Local FrameGraphBuilder var12
   ) {
      FramePass var13 = var12.createPass("pulse:depth_backup");
      this.framebufferSet.mainFramebuffer = var13.transfer(this.framebufferSet.mainFramebuffer);
      var13.setRenderer(() -> {
         if (!this.pulse$isFabulous()) {
            if (this.pulse$lateDebugWillClearDepth()) {
               this.pulse$captureMainDepth();
            }
         }
      });
   }

   @Unique
   private boolean pulse$isFabulous() {
      return this.client.options.getPreset().getValue() == GraphicsMode.FABULOUS;
   }

   @Unique
   private void pulse$captureMainDepth() {
      Framebuffer var1 = this.client.getFramebuffer();
      SimpleFramebuffer var2 = this.pulse$depthBackup;
      if (var2 == null || var2.textureWidth != var1.textureWidth || var2.textureHeight != var1.textureHeight) {
         if (var2 != null) {
            var2.delete();
         }

         var2 = new SimpleFramebuffer("pulse:depth_backup", var1.textureWidth, var1.textureHeight, true);
         this.pulse$depthBackup = var2;
      }

      var2.copyDepthFrom(var1);
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         ordinal = 1,
         target = "Lnet/minecraft/client/gl/PostEffectProcessor;render(Lnet/minecraft/client/render/FrameGraphBuilder;IILnet/minecraft/client/gl/PostEffectProcessor$FramebufferSet;)V"
      )}
   )
   private void pulse$backupDepthBeforeTransparency(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11,
      @Local FrameGraphBuilder var12
   ) {
      FramePass var13 = var12.createPass("pulse:depth_backup_fabulous");
      this.framebufferSet.mainFramebuffer = var13.transfer(this.framebufferSet.mainFramebuffer);
      var13.setRenderer(this::pulse$captureMainDepth);
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;renderLateDebug(Lnet/minecraft/client/render/FrameGraphBuilder;Lnet/minecraft/client/render/state/CameraRenderState;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Matrix4f;)V",
         shift = Shift.AFTER
      )}
   )
   private void pulse$restoreDepthAfterLateDebug(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11,
      @Local FrameGraphBuilder var12
   ) {
      FramePass var13 = var12.createPass("pulse:depth_restore");
      this.framebufferSet.mainFramebuffer = var13.transfer(this.framebufferSet.mainFramebuffer);
      var13.setRenderer(() -> {
         if (this.pulse$isFabulous() || this.pulse$lateDebugWillClearDepth()) {
            if (this.pulse$depthBackup != null) {
               this.client.getFramebuffer().copyDepthFrom(this.pulse$depthBackup);
            }
         }
      });
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/FrameGraphBuilder;run(Lnet/minecraft/client/util/memory/ObjectAllocator;Lnet/minecraft/client/render/FrameGraphBuilder$Profiler;)V",
         shift = Shift.AFTER
      )}
   )
   private void onLateWorldOverlay(
      ObjectAllocator var1,
      RenderTickCounter var2,
      boolean var3,
      Camera var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      EventHandler.a.post(PULSE_WORLD_OVERLAY_EVENT);
   }

   @WrapOperation(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         ordinal = 0,
         target = "Lnet/minecraft/client/gl/PostEffectProcessor;render(Lnet/minecraft/client/render/FrameGraphBuilder;IILnet/minecraft/client/gl/PostEffectProcessor$FramebufferSet;)V"
      )}
   )
   private void pulse$skipVanillaOutlinePostEffect(
      PostEffectProcessor var1, FrameGraphBuilder var2, int var3, int var4, FramebufferSet var5, Operation<Void> var6
   ) {
      if (!TargetRings.a()) {
         var6.call(var1, var2, var3, var4, var5);
      }
   }

   @Inject(
      method = {"drawEntityOutlinesFramebuffer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$skipVanillaOutlineBlit(CallbackInfo var1) {
      if (TargetRings.b()) {
         var1.cancel();
      }
   }
}
