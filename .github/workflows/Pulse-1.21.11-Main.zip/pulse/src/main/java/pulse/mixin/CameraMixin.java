package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.FreeLookModule;
import pulse.features.modules.visuals.AnimationsModule;
import pulse.features.modules.visuals.animations.PerspectiveAnimator;

@Environment(EnvType.CLIENT)
@Mixin({Camera.class})
public abstract class CameraMixin {
   @Shadow
   protected abstract void setRotation(float var1, float var2);

   @Inject(
      method = {"update"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V",
         ordinal = 1,
         shift = Shift.AFTER
      )}
   )
   public void onUpdate(World var1, Entity var2, boolean var3, boolean var4, float var5, CallbackInfo var6) {
      if (FreeLookModule.c && var2 instanceof ClientPlayerEntity) {
         this.setRotation(FreeLookModule.f, FreeLookModule.g);
      }
   }

   @Unique
   private boolean isPerspectiveAnimationEnabled() {
      return ModuleRegistry.t != null && ModuleRegistry.t.k() && ModuleRegistry.t.i.a();
   }

   @Inject(
      method = {"update"},
      at = {@At("HEAD")}
   )
   private void onUpdateHead(World var1, Entity var2, boolean var3, boolean var4, float var5, CallbackInfo var6) {
      if (this.isPerspectiveAnimationEnabled()) {
         PerspectiveAnimator var7 = AnimationsModule.q();
         var7.a(var3, (long)(ModuleRegistry.t.j.q() * 1.5F));
         var7.a();
      }
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/Camera;clipToSpace(F)F"
      ),
      index = 0
   )
   private float modifyCameraDistance(float var1) {
      if (this.isPerspectiveAnimationEnabled()) {
         MinecraftClient var2 = MinecraftClient.getInstance();
         if (var2.options.getPerspective() != Perspective.FIRST_PERSON) {
            return AnimationsModule.q().b();
         }
      }

      return var1;
   }
}
