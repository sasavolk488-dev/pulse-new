package pulse.features.emote.render;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import org.joml.Matrix4f;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.bobj.BobjModel;
import pulse.features.emote.bobj.BobjProp;
import pulse.features.emote.bobj.BobjSkinning;

@Environment(EnvType.CLIENT)
public final class BobjEmoteFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
   private static final float a = 1.0F;
   private static final float b = 1.5F;

   public BobjEmoteFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> var1) {
      super(var1);
   }

   public void a(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, PlayerEntityRenderState var4, float var5, float var6) {
      if (!var4.invisible) {
         AbstractClientPlayerEntity var7 = a(var4.id);
         EmoteManager.ActiveRenderData var8 = EmoteManager.a().c(var7);
         if (var7 != null && var8 != null) {
            float[][] var9 = var8.model().a(var8.action(), var8.frame());
            var var10 = var8.model().a();
            RenderLayer var11 = RenderLayers.entityCutoutNoCull(var4.skinTextures.body().texturePath());
            var2.submitCustom(var1, var11, (var3x, var4x) -> {
               Matrix4f var5x = var3x.getPositionMatrix();
               float[] var6x = new float[3];

               for (byte var7x = 0; var7x + 2 < var10.size(); var7x += 3) {
                  a(var4x, var3x, var5x, (BobjModel.Vertex)var10.get(var7x), var9, var3, var6x);
                  a(var4x, var3x, var5x, (BobjModel.Vertex)var10.get(var7x + 1), var9, var3, var6x);
                  a(var4x, var3x, var5x, (BobjModel.Vertex)var10.get(var7x + 2), var9, var3, var6x);
                  a(var4x, var3x, var5x, (BobjModel.Vertex)var10.get(var7x + 2), var9, var3, var6x);
               }
            });

            for (BobjProp var13 : var8.props()) {
               if (var13.b() != null) {
                  var var14 = var13.a();
                  RenderLayer var15 = RenderLayers.entityCutoutNoCull(var13.b());
                  var2.submitCustom(var1, var15, (var3x, var4x) -> {
                     Matrix4f var5x = var3x.getPositionMatrix();
                     float[] var6x = new float[3];

                     for (byte var7x = 0; var7x + 2 < var14.size(); var7x += 3) {
                        a(var4x, var3x, var5x, (BobjModel.Vertex)var14.get(var7x), var9, var3, var6x);
                        a(var4x, var3x, var5x, (BobjModel.Vertex)var14.get(var7x + 1), var9, var3, var6x);
                        a(var4x, var3x, var5x, (BobjModel.Vertex)var14.get(var7x + 2), var9, var3, var6x);
                        a(var4x, var3x, var5x, (BobjModel.Vertex)var14.get(var7x + 2), var9, var3, var6x);
                     }
                  });
               }
            }
         }
      }
   }

   private static void a(VertexConsumer var0, Entry var1, Matrix4f var2, BobjModel.Vertex var3, float[][] var4, int var5, float[] var6) {
      float var7 = 0.0F;
      float var8 = 0.0F;
      float var9 = 0.0F;
      float var10 = 0.0F;
      float var11 = 0.0F;
      float var12 = 0.0F;
      float var13 = 0.0F;

      for (int var14 = 0; var14 < 4; var14++) {
         int var15 = var3.i[var14];
         float var16 = var3.j[var14];
         if (var15 >= 0 && !(var16 <= 0.0F)) {
            float[] var17 = var4[var15];
            BobjSkinning.a(var17, var3.a, var3.b, var3.c, var6);
            var7 += var6[0] * var16;
            var8 += var6[1] * var16;
            var9 += var6[2] * var16;
            BobjSkinning.b(var17, var3.f, var3.g, var3.h, var6);
            var10 += var6[0] * var16;
            var11 += var6[1] * var16;
            var12 += var6[2] * var16;
            var13 += var16;
         }
      }

      if (var13 == 0.0F) {
         var7 = var3.a;
         var8 = var3.b;
         var9 = var3.c;
         var10 = var3.f;
         var11 = var3.g;
         var12 = var3.h;
      }

      float var18 = (float)Math.sqrt(var10 * var10 + var11 * var11 + var12 * var12);
      if (var18 > 1.0E-6F) {
         var10 /= var18;
         var11 /= var18;
         var12 /= var18;
      }

      float var19 = var7 * 1.0F;
      float var20 = 1.5F - var8 * 1.0F;
      float var21 = -var9 * 1.0F;
      var0.vertex(var2, var19, var20, var21)
         .color(1.0F, 1.0F, 1.0F, 1.0F)
         .texture(var3.d, var3.e)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(var5)
         .normal(var1, var10, -var11, -var12);
   }

   private static AbstractClientPlayerEntity a(int var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.world == null) {
         return null;
      } else {
         return var1.world.getEntityById(var0) instanceof AbstractClientPlayerEntity var2 ? var2 : null;
      }
   }

   @Override
   public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state, float limbAngle, float limbDistance) {
      this.a(matrices, queue, light, (PlayerEntityRenderState)state, limbAngle, limbDistance);
   }
}
