package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Watermark",
   b = "Display client watermark",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class WatermarkModule extends Module {
   public WatermarkModule() {
      this.d();
   }
}
