package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pulse.core.event.impl.MouseEvent;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.InputSetting;
import pulse.utils.game.ChatUtils;
import pulse.utils.time.TimeUtils;

@ModuleInfo(
   a = "RW Joiner",
   b = "Автоматически подключается к выбранному грифу ReallyWorld",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class RWJoinerModule extends Module {
   private static final Logger a = LogManager.getLogger("RWJoiner");
   private final InputSetting b = new InputSetting("Номер грифа", InputSetting.InputType.d, "1", "Введите номер");
   private static final String c = "ГРИФЕРСКОЕ ВЫЖИВАНИЕ";
   private static final int f = 5000;
   private static final int g = 32;
   private final TimeUtils h = new TimeUtils();
   private int i = -1;
   private String j = "";
   private boolean k = false;
   private boolean l = false;
   private boolean m = false;
   private List<ItemStack> n;
   private int o = 0;
   private int p = 1;
   private long q = 0L;
   private static final long r = 100L;
   private static final long s = 1000L;
   private boolean t = false;
   private long u = 0L;
   private long v = 0L;
   private static final long w = 3000L;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      TimeUtils retry = this.h;
      if (d.player == null || d.world == null) {
         return;
      }
      boolean inLobby;
      try {
         inLobby = this.q();
      } catch (RuntimeException | Error failure) {
         if (a != null) {
            a.isDebugEnabled();
         }
         throw failure;
      }
      if (!inLobby) {
         if (a.isDebugEnabled()) {
            a.debug("[RWJoiner] isInLobby=false");
         }
         return;
      }
      boolean debug;
      try {
         debug = a.isDebugEnabled();
      } catch (RuntimeException | Error failure) {
         if (!this.l && !this.k) {
            this.n();
         }
         throw failure;
      }
      if (debug) {
         a.debug("[RWJoiner] isInLobby=true, failedConnection={}, containerOpened={}, containerItems={}, processingClick={}", this.l, this.k, this.n != null, this.t);
      }
      if (this.l) {
         if (retry.a() >= 5000L) {
            this.l = false;
            this.p();
            this.u = 0L;
            this.n();
         }
      } else if (this.k && this.n != null) {
         this.o();
      } else if (!this.k && !this.t) {
         if (this.u > 0L) {
            long now;
            try {
               now = System.currentTimeMillis();
            } catch (RuntimeException | Error failure) {
               this.n();
               throw failure;
            }
            if (now - this.u > 1000L) {
               this.u = 0L;
            }
         }
         this.n();
      }
   }

   private void n() {
      if (System.currentTimeMillis() - this.q >= 100L) {
         if (this.u <= 0L || System.currentTimeMillis() - this.u >= 1000L) {
            if (this.v <= 0L || System.currentTimeMillis() - this.v >= 3000L) {
               Optional var1 = this.a(Items.COMPASS);
               if (var1.isPresent()) {
                  int var2 = (Integer)var1.get();
                  if (d.player.getInventory().getSelectedSlot() != var2) {
                     d.player.getInventory().setSelectedSlot(var2);
                  } else {
                     d.interactionManager.interactItem(d.player, Hand.MAIN_HAND);
                     this.q = System.currentTimeMillis();
                     this.u = System.currentTimeMillis();
                     this.t = true;
                  }
               }
            }
         }
      }
   }

   private Optional<Integer> a(Item var1) {
      for (int var2 = 0; var2 < 9; var2++) {
         ItemStack var3 = d.player.getInventory().getStack(var2);
         if (!var3.isEmpty() && var3.getItem() == var1) {
            return Optional.of(var2);
         }
      }

      return Optional.empty();
   }

   private void o() {
      if (this.n != null && !this.n.isEmpty()) {
         if (System.currentTimeMillis() - this.q >= 100L) {
            if (this.j.contains("Выбор сервера") && !this.m) {
               int var5 = this.c("ГРИФЕРСКОЕ ВЫЖИВАНИЕ");
               if (var5 != -1) {
                  d.interactionManager.clickSlot(this.i, var5, 0, SlotActionType.PICKUP, d.player);
                  this.m = true;
                  this.q = System.currentTimeMillis();
               } else {
                  this.p();
                  this.d();
               }
            } else if (this.j.contains("Выбор мира грифа") && this.m) {
               int var1 = Integer.parseInt(this.b.q());
               int var2 = (var1 - 1) / 32 + 1;
               if (this.p < var2) {
                  int var3 = this.b("Следующая страница");
                  if (var3 != -1) {
                     d.interactionManager.clickSlot(this.i, var3, 0, SlotActionType.PICKUP, d.player);
                     this.p++;
                     this.q = System.currentTimeMillis();
                     this.n = null;
                  } else {
                     this.p();
                  }
               } else if (this.p > var2) {
                  int var6 = this.b("Предыдущая страница");
                  if (var6 != -1) {
                     d.interactionManager.clickSlot(this.i, var6, 0, SlotActionType.PICKUP, d.player);
                     this.p--;
                     this.q = System.currentTimeMillis();
                     this.n = null;
                  } else {
                     this.p();
                  }
               } else {
                  String var7 = "ГРИФ #" + var1;
                  int var4 = this.c(var7);
                  if (var4 != -1) {
                     d.interactionManager.clickSlot(this.i, var4, 0, SlotActionType.PICKUP, d.player);
                     this.o++;
                     this.q = System.currentTimeMillis();
                     this.v = System.currentTimeMillis();
                     this.p();
                  } else {
                     this.p();
                  }
               }
            }
         }
      }
   }

   private void a(String var1) {
      ChatUtils.a(this.g() + ": " + var1);
   }

   private void p() {
      this.i = -1;
      this.j = "";
      this.k = false;
      this.n = null;
      this.m = false;
      this.t = false;
      this.u = 0L;
      this.p = 1;
   }

   @EventHandler
   @Compile
   public void a(PacketEvent var1) {
      TimeUtils retry = this.h;
      Object first;
      try {
         first = var1.d();
      } catch (RuntimeException | Error failure) {
         if (var1 != null) {
            var1.d();
         }
         throw failure;
      }
      if (first instanceof net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket) {
         var packet = (net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket)var1.d();
         String title = Formatting.strip(packet.getName().getString());
         if (title.contains("Выбор сервера") || title.contains("Выбор мира грифа")) {
            try {
               this.i = packet.getSyncId();
            } catch (RuntimeException | Error failure) {
               this.i = 0;
               throw failure;
            }
            this.j = title;
            this.k = true;
            this.t = false;
            var1.b();
         }
         return;
      }
      if (var1.d() instanceof net.minecraft.network.packet.s2c.play.InventoryS2CPacket) {
         Object value = var1.d();
         net.minecraft.network.packet.s2c.play.InventoryS2CPacket packet;
         int syncId;
         try {
            packet = (net.minecraft.network.packet.s2c.play.InventoryS2CPacket)value;
            syncId = packet.syncId();
         } catch (RuntimeException | Error failure) {
            this.n = null;
            throw failure;
         }
         if (syncId == this.i || this.i != -1 && this.k) {
            try {
               this.n = packet.contents();
            } catch (RuntimeException | Error failure) {
               this.n = null;
               throw failure;
            }
            var1.b();
            return;
         }
      }
      if (var1.d() instanceof net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket) {
         var packet = (net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket)var1.d();
         if (((pulse.mixin.accessor.CloseScreenS2CPacketAccessor)packet).getSyncId() == this.i) {
            this.p();
            var1.b();
            return;
         }
      }
      if (var1.d() instanceof net.minecraft.network.packet.s2c.play.GameMessageS2CPacket) {
         var packet = (net.minecraft.network.packet.s2c.play.GameMessageS2CPacket)var1.d();
         String message = Formatting.strip(packet.content().getString());
         if (message != null && (message.contains("Не удалось подключиться к серверу")
               || message.contains("Подождите несколько секунд перед повторым подключением")
               || message.contains("сервер переполнен") || message.contains("Unable to connect"))) {
            if (!message.contains("Unable to connect")) {
               var1.b();
            }
            this.l = true;
            retry.b();
            this.p();
         }
      }
   }

   @EventHandler
   @Compile
   public void a(WorldChangeEvent var1) {
      if (!this.l) {
         this.a("Успешно подключено к Гриф #" + Integer.parseInt((String)this.b.q()));
         this.d();
      }
   }

   @EventHandler
   @Compile
   public void a(MouseEvent var1) {


   }

   private boolean q() {
      if (d.inGameHud != null && d.inGameHud.getPlayerListHud() != null) {
         try {
            PlayerListHudAccessor var1 = (PlayerListHudAccessor)d.inGameHud.getPlayerListHud();
            Text var2 = var1.getHeader();
            if (var2 == null) {
               if (a.isDebugEnabled()) {
                  a.debug("[RWJoiner] isInLobby: header is null");
               }

               return false;
            } else {
               String var3 = Formatting.strip(var2.getString());
               if (a.isDebugEnabled()) {
                  a.debug("[RWJoiner] isInLobby: header='{}', contains Lobby={}", var3, var3 != null && var3.contains("Вы находитесь в: Lobby"));
               }

               return var3 != null && var3.contains("Вы находитесь в: Lobby");
            }
         } catch (Exception var4) {
            a.error("[RWJoiner] isInLobby error", (Throwable)var4);
            return false;
         }
      } else {
         return false;
      }
   }

   private int b(String var1) {
      if (this.n == null) {
         return -1;
      } else {
         for (int var2 = 0; var2 < this.n.size(); var2++) {
            ItemStack var3 = this.n.get(var2);
            if (!var3.isEmpty() && var3.getItem() == Items.ARROW && var3.contains(DataComponentTypes.CUSTOM_NAME)) {
               String var4 = Formatting.strip(var3.getName().getString());
               if (var4 != null && var4.contains(var1)) {
                  return var2;
               }
            }
         }

         return -1;
      }
   }

   private int c(String var1) {
      if (this.n == null) {
         return -1;
      } else {
         for (int var2 = 0; var2 < this.n.size(); var2++) {
            ItemStack var3 = this.n.get(var2);
            if (!var3.isEmpty() && var3.contains(DataComponentTypes.CUSTOM_NAME)) {
               String var4 = Formatting.strip(var3.getName().getString());
               if (var4 != null && var4.contains(var1)) {
                  return var2;
               }
            }
         }

         return -1;
      }
   }

   @Compile
   @Override
   public void e() {
      TimeUtils timer = this.h;
      super.e();
      if (d.player == null || d.world == null || !this.q()) {
         this.d();
         return;
      }
      this.l = false;
      this.k = false;
      this.o = 0;
      this.t = false;
      this.q = 0L;
      this.u = 0L;
      this.v = 0L;
      timer.b();
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.p();
      this.l = false;
      this.o = 0;
      this.t = false;
      this.v = 0L;
   }

   static {
      NativeMethodLookup.lookup(RWJoinerModule.class, 72);
   }
}
