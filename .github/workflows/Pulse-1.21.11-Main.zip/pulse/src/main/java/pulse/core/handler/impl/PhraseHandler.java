package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.features.phrase.PhraseManager;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.shader.ShaderProgram;
import pulse.utils.render.shader.ShaderRegistry;
import pulse.utils.input.KeyBindings;
import pulse.utils.render.ScaleUtils;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class PhraseHandler extends Handler implements IMinecraft {
   private static final int f = 8;
   public static volatile boolean a = false;
   public static volatile double b = 0.0;
   public static volatile double c = 0.0;
   private final List<Integer> g = new ArrayList<>();
   private double h;
   private double i;
   private int j = -1;
   private final Animation k = new Animation();
   private boolean l;
   private boolean m;
   private static final float n = 48.0F;
   private static final float o = 100.0F;
   private static final float p = 0.05F;
   private static final float q = 5.0F;
   private static final float r = 44.0F;
   private static final Color s = new Color(13, 13, 17, 205);
   private static final Color t = new Color(115, 83, 255, 215);
   private static final Color u = new Color(10, 10, 14, 235);
   private static final Color v = new Color(115, 83, 255, 230);
   private static final Color w = new Color(223, 223, 243, 235);
   private static final int[] x = new int[]{15, 14, 13, 12, 11, 10, 9, 8};
   private static final float y = 1.25F;

   @Override
   public void a() {
      super.a();
      if (!this.m) {
         this.m = true;
         ClientTickEvents.END_CLIENT_TICK.register(var1 -> this.d());
         Pulse.m().info("[Phrase] PhraseHandler init — клавиша = {}", KeyBindings.d != null ? KeyBindings.d.getBoundKeyLocalizedText().getString() : "NULL");
      }
   }

   private void d() {
      if (d.player != null && d.world != null) {
         boolean var1 = KeyBindings.d != null && KeyBindings.d.isPressed();
         if (var1 && !this.l && d.currentScreen == null && !EmoteHandler.a && !GraffitiHandler.a) {
            this.e();
         } else if (!var1 && this.l) {
            this.f();
         }

         this.l = var1;
      } else {
         a = false;
         this.k.d(0.0);
         this.l = false;
      }
   }

   @EventHandler
   public void a(WorldChangeEvent var1) {
      a = false;
      this.k.d(0.0);
      PhraseManager.a().f();
   }

   private void e() {
      this.g.clear();

      for (Integer var2 : PhraseManager.a().d()) {
         if (this.g.size() >= 8) {
            break;
         }

         this.g.add(var2);
      }

      if (this.g.isEmpty()) {
         Pulse.m().info("[Phrase] колесо не открылось: надетых фраз нет");
         if (d.player != null) {
            MutableText var3 = Text.literal("§dPulse §7— §cнет надетых фраз, наденьте их на сайте");
            d.player.sendMessage(var3, true);
            d.player.sendMessage(var3, false);
         }
      } else {
         a = true;
         b = 0.0;
         c = 0.0;
         this.h = 0.0;
         this.i = 0.0;
         this.j = -1;
         this.k.d(0.0);
         this.k.a(1.0, 0.25, Easings.F);
      }
   }

   private void f() {
      if (a) {
         a = false;
         this.k.a(0.0, 0.15000003539778992, Easings.g);
         if (this.j >= 0 && this.j < this.g.size()) {
            String var1 = PhraseManager.a().e();
            if (var1 != null) {
               Pulse.m().info("[Phrase] фраза не ушла: {}", var1);
               if (d.player != null) {
                  MutableText var2 = Text.literal("§dPulse §7— §c" + var1);
                  d.player.sendMessage(var2, true);
                  d.player.sendMessage(var2, false);
               }
            } else {
               PhraseManager.a().b(this.g.get(this.j));
            }
         }
      }
   }

   @EventHandler
   @Compile
   public void a(RenderHudPostEvent var1) {
      this.k.a();
      float opacity = (float)this.k.j();
      if (opacity < 0.01F || this.g.isEmpty()) {
         return;
      }
      if (a) {
         this.h += b * 1.4;
         this.i += c * 1.4;
         b = 0.0;
         c = 0.0;
         double radius = Math.sqrt(this.h * this.h + this.i * this.i);
         boolean select;
         if (!(radius > 41.0)) {
            select = radius > 32.800000000000004;
         } else {
            double scale = 41.0 / radius;
            this.h *= scale;
            this.i *= scale;
            select = true;
         }
         if (select) {
            int size = this.g.size();
            double angle = ((Math.atan2(this.i, this.h) + 1.5707963267948966)
               % 6.283185307179586 + 6.283185307179586) % 6.283185307179586;
            this.j = (int)(angle / (6.283185307179586 / size));
            if (this.j >= size) {
               this.j = size - 1;
            }
         } else {
            this.j = -1;
         }
      }
      this.a(var1.a(), opacity);
   }

   private void a(MatrixStack var1, float var2) {
      int var3 = this.g.size();
      if (var3 != 0) {
         ScaleUtils.a(2.0);
         float var4 = (float)(d.getWindow().getFramebufferWidth() / 2.0 / 2.0);
         float var5 = (float)(d.getWindow().getFramebufferHeight() / 2.0 / 2.0);
         float var6 = Math.max(0.0F, Math.min(1.0F, var2));
         float var7 = 48.0F * var6;
         float var8 = 100.0F * var6;
         float var9 = (float)(6.283187811055335 / var3);
         float var10 = (float) (-Math.PI / 2);
         Optional var11 = ShaderRegistry.a().a("emote_wheel");
         if (var11.isPresent()) {
            ShaderProgram var12 = (ShaderProgram)var11.get();
            float var13 = 104.0F;
            float var14 = var13 * 2.0F;
            var12.d();
            Matrix4f var15 = new Matrix4f()
               .setOrtho(0.0F, d.getWindow().getFramebufferWidth() / 2.0F, d.getWindow().getFramebufferHeight() / 2.0F, 0.0F, -1.0F, 1.0F);
            float[] var16 = new float[16];
            var15.get(var16);
            var12.a("ProjMat", var16);
            var12.a("ModelViewMat", new float[]{1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F});
            var12.a("size", var14);
            var12.a("innerR", var7);
            var12.a("outerR", var8);
            var12.a("centerR", 0.0F);
            var12.a("accentR", 0.0F);
            var12.a("cursorR", a ? 5.0F * var6 : 0.0F);
            var12.b("count", var3);
            var12.b("selected", this.j);
            var12.a("gap", var3 <= 1 ? 0.0F : 0.05F);
            var12.a("opacity", var6);
            var12.a("cursor", (float)this.h * var6, (float)this.i * var6);
            var12.a("bgColor", s);
            var12.a("hoverColor", t);
            var12.a("centerColor", u);
            var12.a("accentColor", v);
            var12.a("cursorColor", w);
            float var17 = var4 - var13;
            float var18 = var5 - var13;
            boolean var19 = GL11.glIsEnabled(3042);
            GL11.glEnable(3042);
            GL14.glBlendFuncSeparate(770, 771, 1, 771);
            ShaderProgram.a(var17, var18, var14, var14);
            if (!var19) {
               GL11.glDisable(3042);
            }

            var12.e();
         }

         if (var6 > 0.5F) {
            Render var22 = Pulse.l().p();
            float var23 = 44.0F * var6;

            for (int var24 = 0; var24 < var3; var24++) {
               float var26 = var10 + (var24 + 0.5F) * var9;
               float var27 = (var7 + var8) / 2.0F;
               float var28 = var4 + (float)Math.cos(var26) * var27;
               float var29 = var5 + (float)Math.sin(var26) * var27;
               PhraseManager.Phrase var30 = PhraseManager.a().a(this.g.get(var24));
               if (var30 != null) {
                  Identifier var20 = var30.icon();
                  if (var20 != null) {
                     Color var21 = var24 == this.j ? Color.WHITE : new Color(255, 255, 255, 200);
                     var22.a(var20, var28 - var23 / 2.0F, var29 - var23 / 2.0F, var23, var23, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var21, var1);
                  } else {
                     Color var31 = var24 == this.j ? new Color(255, 255, 255) : new Color(223, 223, 243);
                     this.a(var30.text(), var28, var29, this.a(var27, var3), var8 - var7 - 10.0F, var31, var1);
                  }
               }
            }

            String var25 = this.j >= 0 && PhraseManager.a().a(this.g.get(this.j)) != null ? PhraseManager.a().a(this.g.get(this.j)).text() : "Выбери фразу";
            Fonts.b[18].b(var25, var4, var5 - var8 - 18.0F, new Color(255, 255, 255), var1);
         }

         ScaleUtils.a();
      }
   }

   private String a(String var1, int var2) {
      return var1.length() <= var2 ? var1 : var1.substring(0, var2 - 1) + "…";
   }

   private static float a(FontRenderer var0, String var1) {
      return var0.b(var1) / 2.0F;
   }

   private float a(float var1, int var2) {
      if (var2 <= 1) {
         return var1 * 1.7F;
      } else {
         float var3 = (float)(6.283187811055335 * var1 / var2);
         return Math.max(28.0F, var3 - 12.0F);
      }
   }

   private void a(String var1, float var2, float var3, float var4, float var5, Color var6, MatrixStack var7) {
      for (int var11 : x) {
         FontRenderer var12 = Fonts.b[var11];
         List var13 = this.a(var1, var12, var4);
         if (var13.isEmpty()) {
            return;
         }

         float var14 = a(var12, var1) * 1.25F;
         if (!(var13.size() * var14 > var5) && !(this.a(var12, var13) > var4)) {
            float var15 = var3 - var13.size() * var14 / 2.0F;

            for (int var16 = 0; var16 < var13.size(); var16++) {
               var12.b((String)var13.get(var16), var2, var15 + var16 * var14, var6, var7);
            }

            return;
         }
      }

      FontRenderer var17 = Fonts.b[x[x.length - 1]];
      String var18 = this.a(var1, 12);
      var17.b(var18, var2, var3 - a(var17, var18) / 2.0F, var6, var7);
   }

   private List<String> a(String var1, FontRenderer var2, float var3) {
      ArrayList var4 = new ArrayList();
      StringBuilder var5 = new StringBuilder();

      for (String var9 : var1.trim().split("\\s+")) {
         if (!var9.isEmpty()) {
            String var10 = var5.length() == 0 ? var9 : var5 + " " + var9;
            if (!(var2.a(var10) <= var3) && var5.length() != 0) {
               var4.add(var5.toString());
               var5.setLength(0);
               var5.append(var9);
            } else {
               var5.setLength(0);
               var5.append(var10);
            }
         }
      }

      if (var5.length() > 0) {
         var4.add(var5.toString());
      }

      return var4;
   }

   private float a(FontRenderer var1, List<String> var2) {
      float var3 = 0.0F;

      for (String var5 : var2) {
         var3 = Math.max(var3, var1.a(var5));
      }

      return var3;
   }

   static {
      NativeMethodLookup.lookup(PhraseHandler.class, 29);
   }
}
