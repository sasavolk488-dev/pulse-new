package pulse.services.tracker.v2;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GroupInviteInfo {
   private final String a;
   private final int b;
   private final String c;
   private final long d;

   public GroupInviteInfo(String var1, int var2, String var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = System.currentTimeMillis();
   }

   @Generated
   public String a() {
      return this.a;
   }

   @Generated
   public int b() {
      return this.b;
   }

   @Generated
   public String c() {
      return this.c;
   }

   @Generated
   public long d() {
      return this.d;
   }
}
