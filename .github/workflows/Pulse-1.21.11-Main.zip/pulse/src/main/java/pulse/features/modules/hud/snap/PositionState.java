package pulse.features.modules.hud.snap;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.hud.DraggableComponent;

@Environment(EnvType.CLIENT)
public class PositionState {
   private final DraggableComponent a;
   private final float b;
   private final float c;

   public PositionState(DraggableComponent var1) {
      this.a = var1;
      this.b = var1.m();
      this.c = var1.n();
   }

   public void a() {
      this.a.a(this.b);
      this.a.b(this.c);
   }

   public DraggableComponent b() {
      return this.a;
   }

   public float c() {
      return this.b;
   }

   public float d() {
      return this.c;
   }
}
