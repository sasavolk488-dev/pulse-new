package pulse.core.settings;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SeparatorSetting extends Setting<String> {
   public SeparatorSetting(String var1) {
      super(var1, "", var1);
   }

   public SeparatorSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
