package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;

@ModuleInfo(
   a = "Auto Potion",
   b = "Автоматически использует выбранные зелья",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoPotionModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Невидимость", true);
   private final BooleanSetting b = new BooleanSetting("Скорость", false);
   private boolean c;
   private int f = -1;
   private boolean g = false;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      BooleanSetting invisibility = this.a;
      BooleanSetting speed = this.b;
      if (d.world == null || d.player == null) {
         return;
      }
      if (!this.c) {
         try {
            this.g = d.options.useKey.isPressed();
         } catch (RuntimeException | Error failure) {
            this.g = false;
            throw failure;
         }
      }
      int invisibilitySlot = -1;
      int speedSlot = -1;
      if ((Boolean)invisibility.q() && (!d.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.INVISIBILITY)
         || d.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.INVISIBILITY) != null
         && d.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.INVISIBILITY).getDuration() <= 100)) {
         for (int index = 0; index < 9; index++) {
            ItemStack stack = d.player.getInventory().getStack(index);
            if (!stack.isEmpty() && stack.getItem() == net.minecraft.item.Items.POTION
               && this.a(stack, net.minecraft.entity.effect.StatusEffects.INVISIBILITY)) {
               invisibilitySlot = index;
               break;
            }
         }
      }
      boolean speedEnabled;
      try {
         speedEnabled = (Boolean)speed.q();
      } catch (RuntimeException | Error failure) {
         if (invisibilitySlot != -1 && !this.c) {
            this.f = 0;
         }
         throw failure;
      }
      boolean needSpeed = false;
      if (speedEnabled) {
         if (!d.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED)) {
            needSpeed = true;
         } else {
            boolean hasCurrent;
            try {
               hasCurrent = d.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED) != null;
            } catch (RuntimeException | Error failure) {
               if (invisibilitySlot != -1 && !this.c) {
                  this.f = 0;
               }
               throw failure;
            }
            needSpeed = hasCurrent && d.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED).getDuration() <= 100;
         }
      }
      if (needSpeed) {
         for (int index = 0; index < 9; index++) {
            ItemStack stack = d.player.getInventory().getStack(index);
            if (!stack.isEmpty() && stack.getItem() == net.minecraft.item.Items.POTION
               && this.a(stack, net.minecraft.entity.effect.StatusEffects.SPEED)) {
               speedSlot = index;
               break;
            }
         }
      }
      int slot = invisibilitySlot != -1 ? invisibilitySlot : speedSlot;
      if (slot != -1) {
         if (!this.c) {
            try {
               this.f = d.player.getInventory().getSelectedSlot();
            } catch (RuntimeException | Error failure) {
               this.f = 0;
               throw failure;
            }
         }
         d.player.getInventory().setSelectedSlot(slot);
         d.options.useKey.setPressed(true);
         this.c = true;
      } else if (this.c) {
         if (this.f != -1) {
            d.player.getInventory().setSelectedSlot(this.f);
            this.f = -1;
         }
         d.options.useKey.setPressed(this.g);
         this.c = false;
      }
   }

   private boolean a(ItemStack var1, RegistryEntry<StatusEffect> var2) {
      PotionContentsComponent var3 = var1.get(DataComponentTypes.POTION_CONTENTS);
      if (var3 == null) {
         return false;
      } else {
         for (StatusEffectInstance var5 : var3.customEffects()) {
            if (var5.getEffectType().equals(var2)) {
               return true;
            }
         }

         return var3.potion().map(var1x -> var1x.value().getEffects().stream().anyMatch(var1xx -> var1xx.getEffectType().equals(var2))).orElse(false);
      }
   }

   @Compile
   @Override
      public void f() {
      super.f();
      if (this.c) {
         d.options.useKey.setPressed(this.g);
      }
      if (this.f != -1) {
         d.player.getInventory().setSelectedSlot(this.f);
      }
      this.c = false;
      this.f = -1;
   }

   static {
      NativeMethodLookup.lookup(AutoPotionModule.class, 51);
   }
}
