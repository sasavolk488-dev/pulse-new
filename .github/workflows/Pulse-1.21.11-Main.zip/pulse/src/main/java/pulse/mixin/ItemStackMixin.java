package pulse.mixin;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.ItemUsedEvent;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.AucHelperModule;

@Environment(EnvType.CLIENT)
@Mixin({ItemStack.class})
public class ItemStackMixin {
   @Inject(
      method = {"finishUsing"},
      at = {@At("HEAD")}
   )
   private void onItemUseFinish(World var1, LivingEntity var2, CallbackInfoReturnable<ItemStack> var3) {
      ItemUsedEvent var4 = new ItemUsedEvent((ItemStack)(Object)this, var1, var2);
      EventHandler.a.post(var4);
      if (var4.c()) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"getTooltip"},
      at = {@At("RETURN")}
   )
   private void pulse$highlightKnockbackTooltip(TooltipContext var1, @Nullable PlayerEntity var2, TooltipType var3, CallbackInfoReturnable<List<Text>> var4) {
      AucHelperModule var5 = ModuleRegistry.V;
      if (var5 != null) {
         var5.a((ItemStack)(Object)this, (List<Text>)var4.getReturnValue());
      }
   }
}
