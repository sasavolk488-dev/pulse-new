package pulse.core.handler.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;

@HandlerInfo
@Environment(EnvType.CLIENT)
public class ClickGuiRenderHandler extends Handler {
}
