package pulse.features.resourcepack;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resource.AbstractFileResourcePack;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.ResourcePack.ResultConsumer;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class PulseInMemoryResourcePack extends AbstractFileResourcePack {
   private final PpackContainer a;

   public PulseInMemoryResourcePack(ResourcePackInfo var1, PpackContainer var2) {
      super(var1);
      this.a = var2;
   }

   private static InputSupplier<InputStream> a(byte[] var0) {
      return var0 == null ? null : () -> new ByteArrayInputStream(var0);
   }

   @Override
   public InputSupplier<InputStream> openRoot(String... segments) {
      String var2 = String.join("/", segments);
      return a(this.a.b(var2));
   }

   @Override
   public InputSupplier<InputStream> open(ResourceType type, Identifier id) {
      String var3 = type.getDirectory() + "/" + id.getNamespace() + "/" + id.getPath();
      return a(this.a.b(var3));
   }

   @Override
   public void findResources(ResourceType type, String namespace, String prefix, ResultConsumer consumer) {
      String var5 = type.getDirectory() + "/" + namespace + "/";
      String var6 = var5 + prefix;

      for (String var8 : this.a.b()) {
         if (var8.startsWith(var6)) {
            String var9 = var8.substring(var5.length());
            Identifier var10 = Identifier.tryParse(namespace + ":" + var9);
            if (var10 != null) {
               InputSupplier var11 = a(this.a.b(var8));
               if (var11 != null) {
                  consumer.accept(var10, var11);
               }
            }
         }
      }
   }

   @Override
   public Set<String> getNamespaces(ResourceType type) {
      String var2 = type.getDirectory() + "/";
      HashSet var3 = new HashSet();

      for (String var5 : this.a.b()) {
         if (var5.startsWith(var2)) {
            int var6 = var5.indexOf(47, var2.length());
            if (var6 > var2.length()) {
               var3.add(var5.substring(var2.length(), var6));
            }
         }
      }

      return var3;
   }

   @Override
   public void close() {
   }
}
