package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class ChatEvent extends CancellableEvent {
   private final String a;

   @Generated
   public String d() {
      return this.a;
   }

   @Generated
   public ChatEvent(String var1) {
      this.a = var1;
   }
}
