package pulse.features.modules.hud.island;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class NotificationIsland extends Island {
   private static final float k = 16.0F;
   private static final float l = 5.0F;
   private static final float m = -9.0F;
   private static final float n = 3.0F;
   private static final float o = 8.0F;
   private static final float p = 15.0F;
   private static final float q = 13.0F;
   private static final float r = 5.0F;
   private final NotificationIsland.NotificationType s;
   private final String t;
   private final String u;
   private final String v;
   private final Runnable w;
   private final String x;
   private final Runnable y;
   private final Color z;
   private final Color A;
   private final Color B;
   private final Supplier<Boolean> C;
   private final boolean D;
   private List<String> E;
   private boolean F = false;
   private boolean G = false;
   private float H;
   private float I;
   private float J;
   private float K;
   private float L;
   private float M;
   private float N;
   private float O;
   private float P;
   private float Q;
   private static final double[] R = new double[1];
   private static final double[] S = new double[1];

   private NotificationIsland(NotificationIsland.Builder var1) {
      this.s = var1.a;
      this.t = var1.b;
      this.u = var1.c;
      this.v = var1.d;
      this.w = var1.e;
      this.x = var1.f;
      this.y = var1.g;
      this.z = var1.h;
      this.A = var1.i != null ? var1.i : this.s.b();
      this.B = var1.j != null ? var1.j : this.s.c();
      this.C = var1.l;
      this.D = var1.m;
      this.e = 9.5F;
      this.f = 7.0F;
      this.h = var1.k;
      this.r();
   }

   @Override
   public void e() {
      this.b.a();
      this.c.a();
      this.d.a();
      if (!this.D && !this.j && System.currentTimeMillis() - this.i > this.h) {
         this.f();
      }

      if (this.C != null && !this.j) {
         if (!this.C.get()) {
            this.f();
         } else {
            this.i = System.currentTimeMillis();
         }
      }
   }

   public boolean m() {
      return this.C != null;
   }

   private void r() {
      this.E = new ArrayList<>();
      if (this.u != null && !this.u.isEmpty()) {
         FontRenderer var1 = Fonts.a[13];
         float var2 = this.a() - -9.0F - 16.0F - 5.0F;
         String[] var3 = this.u.split("\n");

         for (String var7 : var3) {
            if (var7.isEmpty()) {
               this.E.add("");
            } else {
               String[] var8 = var7.split(" ");
               StringBuilder var9 = new StringBuilder();

               for (String var13 : var8) {
                  String var14 = var9.length() == 0 ? var13 : var9 + " " + var13;
                  if (var1.a(var14) > var2 && var9.length() > 0) {
                     this.E.add(var9.toString());
                     var9 = new StringBuilder(var13);
                  } else {
                     if (var9.length() > 0) {
                        var9.append(" ");
                     }

                     var9.append(var13);
                  }
               }

               if (var9.length() > 0) {
                  this.E.add(var9.toString());
               }
            }
         }
      }
   }

   @Override
   public float a() {
      if ((this.u == null || this.u.isEmpty()) && this.v == null) {
         FontRenderer var1 = Fonts.b[15];
         return 13.0F + var1.a(this.t);
      } else {
         return 147.5F;
      }
   }

   @Override
   public float b() {
      float var1 = 9.0F;
      if (!this.E.isEmpty()) {
         var1 += 3.0F;
         var1 += this.E.size() * 8.0F;
      }

      if (this.v != null) {
         var1 += 20.0F;
      }

      return var1;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      this.P = var3 - this.e;
      this.Q = var4 - this.f;
      FontRenderer var8 = Fonts.b[15];
      FontRenderer var9 = Fonts.a[13];
      FontRenderer var10 = Fonts.b[12];
      int var11 = (int)(var7 * 255.0F);
      float var13 = var3 + -9.0F;
      float var14 = 9.0F;
      float var15 = var4 + var14 / 2.0F - 8.0F;
      Color var16 = new Color(this.A.getRed(), this.A.getGreen(), this.A.getBlue(), var11);
      FontRenderer var17 = Fonts.d[15];
      var17.a(this.s.a(), var13 + 8.0F, var15 + 4.0F, var16, var1);
      Color var18 = new Color(255, 255, 255, var11);
      float var19 = var13 + 16.0F + 5.0F;
      float var20 = var15 + 8.0F - var14 / 2.0F;
      var8.a(this.t, var19, var20, var18, var1);
      float var12 = var4 + var14;
      if (!this.E.isEmpty()) {
         var12 += 3.0F;
         Color var21 = new Color(223, 223, 243, var11);

         for (String var23 : this.E) {
            var9.a(var23, var19, var12, var21, var1);
            var12 += 8.0F;
         }
      }

      if (this.v != null) {
         var12 += 5.0F;
         float var34 = 4.0F;
         boolean var35 = this.x != null;
         float var36 = var35 ? (var5 - var34) / 2.0F : var5;
         this.H = var3;
         this.I = var12;
         this.J = var36;
         this.K = 15.0F;
         this.s();
         Color var24;
         if (this.F) {
            var24 = new Color(Math.min(255, this.B.getRed() + 30), Math.min(255, this.B.getGreen() + 30), Math.min(255, this.B.getBlue() + 30), var11);
         } else {
            var24 = new Color(this.B.getRed(), this.B.getGreen(), this.B.getBlue(), var11);
         }

         var2.a(this.H, this.I, this.J, this.K, 13.0F, var24, var1);
         Color var25 = new Color(255, 255, 255, var11);
         float var26 = var10.a(this.v);
         float var27 = this.H + (this.J - var26) / 2.0F;
         float var28 = this.I + this.K / 2.0F - 3.5F;
         var10.a(this.v, var27, var28, var25, var1);
         if (var35) {
            this.L = this.H + this.J + var34;
            this.M = this.I;
            this.N = var36;
            this.O = 15.0F;
            Color var29 = this.z != null ? this.z : new Color(80, 80, 112);
            Color var30;
            if (this.G) {
               var30 = new Color(Math.min(255, var29.getRed() + 30), Math.min(255, var29.getGreen() + 30), Math.min(255, var29.getBlue() + 30), var11);
            } else {
               var30 = new Color(var29.getRed(), var29.getGreen(), var29.getBlue(), var11);
            }

            var2.a(this.L, this.M, this.N, this.O, 13.0F, var30, var1);
            float var31 = var10.a(this.x);
            float var32 = this.L + (this.N - var31) / 2.0F;
            var10.a(this.x, var32, var28, var25, var1);
         }
      }
   }

   private void s() {
      if (this.v != null && a.currentScreen != null && a.currentScreen instanceof ChatScreen) {
         this.t();
         double var1 = R[0] / 2.0;
         double var3 = S[0] / 2.0;
         this.F = var1 >= this.H && var1 <= this.H + this.J && var3 >= this.I && var3 <= this.I + this.K;
         this.G = this.x != null && var1 >= this.L && var1 <= this.L + this.N && var3 >= this.M && var3 <= this.M + this.O;
      } else {
         this.F = false;
         this.G = false;
      }
   }

   public void n() {
      if (this.v != null && a.currentScreen != null && a.currentScreen instanceof ChatScreen) {
         this.t();
         double var1 = R[0] / 2.0;
         double var3 = S[0] / 2.0;
         boolean var5 = var1 >= this.H && var1 <= this.H + this.J && var3 >= this.I && var3 <= this.I + this.K;
         boolean var6 = this.x != null && var1 >= this.L && var1 <= this.L + this.N && var3 >= this.M && var3 <= this.M + this.O;
         if (var5 || var6) {
            MouseUtil.g();
         }
      }
   }

   private void t() {
      GLFW.glfwGetCursorPos(a.getWindow().getHandle(), R, S);
   }

   public boolean a(double var1, double var3, int var5) {
      if (var5 != 0) {
         return false;
      } else if (!(a.currentScreen instanceof ChatScreen)) {
         return false;
      } else if (this.v != null && this.w != null && var1 >= this.H && var1 <= this.H + this.J && var3 >= this.I && var3 <= this.I + this.K) {
         this.w.run();
         this.f();
         return true;
      } else if (this.x != null && this.y != null && var1 >= this.L && var1 <= this.L + this.N && var3 >= this.M && var3 <= this.M + this.O) {
         this.y.run();
         this.f();
         return true;
      } else {
         return false;
      }
   }

   public boolean o() {
      return this.v != null;
   }

   public static NotificationIsland.Builder a(String var0) {
      return new NotificationIsland.Builder(var0);
   }

   @Generated
   public String p() {
      return this.t;
   }

   @Generated
   public boolean q() {
      return this.D;
   }

   @Environment(EnvType.CLIENT)
   public static class Builder {
      private NotificationIsland.NotificationType a;
      private final String b;
      private String c;
      private String d;
      private Runnable e;
      private String f;
      private Runnable g;
      private Color h;
      private Color i;
      private Color j;
      private long k;
      private Supplier<Boolean> l;
      private boolean m;

      public Builder(String var1) {
         this.a = NotificationIsland.NotificationType.a;
         this.k = 5000L;
         this.m = false;
         this.b = var1;
      }

      public NotificationIsland.Builder a(NotificationIsland.NotificationType var1) {
         this.a = var1;
         return this;
      }

      public NotificationIsland.Builder a(String var1) {
         this.c = var1;
         return this;
      }

      public NotificationIsland.Builder a(String var1, Runnable var2) {
         this.d = var1;
         this.e = var2;
         return this;
      }

      public NotificationIsland.Builder a(String var1, Color var2, Runnable var3) {
         this.f = var1;
         this.h = var2;
         this.g = var3;
         return this;
      }

      public NotificationIsland.Builder a(Color var1) {
         this.i = var1;
         return this;
      }

      public NotificationIsland.Builder b(Color var1) {
         this.j = var1;
         return this;
      }

      public NotificationIsland.Builder a(long var1) {
         this.k = var1;
         return this;
      }

      public NotificationIsland.Builder a(Supplier<Boolean> var1) {
         this.l = var1;
         return this;
      }

      public NotificationIsland.Builder a() {
         this.m = true;
         return this;
      }

      public NotificationIsland b() {
         return new NotificationIsland(this);
      }
   }

   @Environment(EnvType.CLIENT)
   public static enum NotificationType {
      a("\ue903", new Color(49, 49, 69), new Color(87, 215, 106)),
      b("\ue925", new Color(243, 82, 66), new Color(243, 82, 66)),
      c("\ue90c", new Color(248, 135, 64), new Color(248, 135, 64)),
      d("\ue904", new Color(100, 72, 227), new Color(100, 72, 227));

      private final String e;
      private final Color f;
      private final Color g;

      private NotificationType(String var3, Color var4, Color var5) {
         this.e = var3;
         this.f = var4;
         this.g = var5;
      }

      @Generated
      public String a() {
         return this.e;
      }

      @Generated
      public Color b() {
         return this.f;
      }

      @Generated
      public Color c() {
         return this.g;
      }

      private static NotificationIsland.NotificationType[] d() {
         return new NotificationIsland.NotificationType[]{a, b, c, d};
      }
   }
}
