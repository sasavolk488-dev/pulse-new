package pulse.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.gui.screen.Overlay;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.render.fog.FogRenderer.FogType;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.Pulse;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiOverlay;
import pulse.ui.clickgui.invmanager.InventoryManagerScreen;
import pulse.ui.clickgui.keybind.KbGuiOverlay;
import pulse.ui.clickgui.keybind.KeybindManagerScreen;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.RenderWorldEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.features.modules.hud.HudRenderContext;
import pulse.features.modules.hud.PulseHudRenderer;
import pulse.core.api.ISplashOverlay;
import pulse.ui.menu.PulseConfirmExitScreen;
import pulse.ui.menu.PulseGameMenuScreen;
import pulse.ui.menu.PulseMainMenuScreen;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.ZoomModule;
import pulse.features.modules.visuals.AspectRatioModule;
import pulse.features.modules.visuals.MotionBlurModule;
import pulse.features.modules.visuals.RenderTweaksModule;
import pulse.features.modules.visuals.WorldCustomizerModule;
import pulse.utils.render.AlphaFramebuffer;
import pulse.utils.render.world.ColorGrading;
import pulse.utils.render.world.HandOutlineRenderer;
import pulse.utils.render.world.JumpShockwave;
import pulse.utils.render.world.MotionBlur;
import pulse.utils.render.ScreenUtils;

@Environment(EnvType.CLIENT)
@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
   @Shadow
   @Final
   private GuiRenderer guiRenderer;
   @Shadow
   @Final
   private FogRenderer fogRenderer;
   private static final MatrixStack SCRATCH_MATRICES = new MatrixStack();

   @Inject(
      method = {"renderWorld"},
      at = {@At("RETURN")}
   )
   private void onRenderWorldEnd(RenderTickCounter var1, CallbackInfo var2) {
      Camera var3 = ((GameRenderer)(Object)this).getCamera();
      EventHandler.a.post(new RenderWorldEvent(SCRATCH_MATRICES, var1.getDynamicDeltaTicks(), var3));
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;render(Lnet/minecraft/client/util/memory/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V"
      )}
   )
   private void captureWorldMatrices(RenderTickCounter var1, CallbackInfo var2, @Local(ordinal = 0) Matrix4f var3, @Local(ordinal = 1) Matrix4f var4) {
      ScreenUtils.a.set(var3);
      ScreenUtils.c.set(var4);
      ScreenUtils.b.identity();
   }

   @Inject(
      method = {"tiltViewWhenHurt"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onTiltViewWhenHurt(MatrixStack var1, float var2, CallbackInfo var3) {
      RenderTweaksModule var4 = ModuleRegistry.h;
      if (var4 != null && var4.o()) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"showFloatingItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onShowFloatingItem(ItemStack var1, CallbackInfo var2) {
      RenderTweaksModule var3 = ModuleRegistry.h;
      if (var3 != null && var3.q()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"getBasicProjectionMatrix"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetBasicProjectionMatrix(float var1, CallbackInfoReturnable<Matrix4f> var2) {
      AspectRatioModule var3 = ModuleRegistry.g;
      boolean var4 = var3 != null && var3.k();
      boolean var5 = ZoomModule.a;
      if (var4 || var5) {
         if (var5) {
            var1 = (float)ZoomModule.b;
         }

         GameRenderer var6 = (GameRenderer)(Object)this;
         MinecraftClient var7 = MinecraftClient.getInstance();
         float var8 = (float)var7.getWindow().getFramebufferWidth() / var7.getWindow().getFramebufferHeight();
         if (var4) {
            var8 = var3.n();
         }

         Matrix4f var9 = new Matrix4f();
         var9.perspective((float)(var1 * (Math.PI / 180.0)), var8, 0.05F, var6.getFarPlaneDistance());
         var2.setReturnValue(var9);
      }
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V",
         shift = Shift.AFTER
      )}
   )
   private void pulse$applyColorGrading(RenderTickCounter var1, boolean var2, CallbackInfo var3) {
      WorldCustomizerModule var4 = ModuleRegistry.k;
      if (var4 != null && var4.w()) {
         ColorGrading.a(var4.x());
         ColorGrading.a(var4.y());
         ColorGrading.b(var4.z());
         ColorGrading.b();
      } else {
         ColorGrading.a();
      }
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V",
         shift = Shift.AFTER
      )}
   )
   private void pulse$compositeHandOutline(RenderTickCounter var1, boolean var2, CallbackInfo var3) {
      HandOutlineRenderer.e();
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/GameRenderer;renderHand(FZLorg/joml/Matrix4f;)V"
      )}
   )
   private void pulse$applyJumpShockwave(RenderTickCounter var1, CallbackInfo var2) {
      JumpShockwave.c();
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/GameRenderer;renderHand(FZLorg/joml/Matrix4f;)V"
      )}
   )
   private void pulse$applyMotionBlur(RenderTickCounter var1, CallbackInfo var2) {
      MotionBlurModule var3 = ModuleRegistry.x;
      if (var3 != null && var3.k()) {
         MotionBlur.a(var3.n());
      }
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/hud/InGameHud;render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
         shift = Shift.AFTER
      )}
   )
   private void pulse$renderMainHud(RenderTickCounter var1, boolean var2, CallbackInfo var3, @Local DrawContext var4) {
      MinecraftClient var5 = MinecraftClient.getInstance();
      if (var5.world != null) {
         PulseHudRenderer.a(var4, var1.getTickProgress(true));
      }
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V",
         shift = Shift.AFTER
      )}
   )
   private void onAfterGuiRender(RenderTickCounter var1, boolean var2, CallbackInfo var3, @Local DrawContext var4) {
      MinecraftClient var5 = MinecraftClient.getInstance();
      int var6 = (int)(var5.mouse.getX() * var5.getWindow().getScaledWidth() / var5.getWindow().getWidth());
      int var7 = (int)(var5.mouse.getY() * var5.getWindow().getScaledHeight() / var5.getWindow().getHeight());
      float var8 = var1.getDynamicDeltaTicks();
      Runnable var9 = () -> this.guiRenderer.render(this.fogRenderer.getFogBuffer(FogType.NONE));
      Overlay var10 = var5.getOverlay();
      if (var10 == null) {
         Pulse.l().b();
      }
      if (var10 instanceof SplashOverlay) {
         Pulse.l().a();
         long var122 = var10 instanceof ISplashOverlay var132 ? var132.pulse$reloadStartTime() : -1L;
         long var133 = var10 instanceof ISplashOverlay var15 ? var15.pulse$reloadCompleteTime() : -1L;
         if (var5.currentScreen instanceof PulseMainMenuScreen var134) {
            HudRenderContext.a(var4);
            AlphaFramebuffer.b(var4);
            HudRenderContext.a(var9);

            try {
               var134.a(var6, var7, var8);
            } finally {
               HudRenderContext.b();
            }

            var9.run();
         }

         HandlerRegistry.m.a(var122, var133);
      } else if (var5.currentScreen instanceof ClickGuiScreen var121) {
         HudRenderContext.a(var4);
         AlphaFramebuffer.b(var4);
         HudRenderContext.a(var9);

         try {
            var121.a(var6, var7, var8);
         } finally {
            HudRenderContext.b();
         }

         var9.run();
      } else if (var5.currentScreen instanceof InventoryManagerScreen var120) {
         HudRenderContext.a(var4);
         AlphaFramebuffer.b(var4);
         HudRenderContext.a(var9);

         try {
            var120.a(var6, var7, var8);
         } finally {
            HudRenderContext.b();
         }

         var9.run();
      } else if (var5.currentScreen instanceof KeybindManagerScreen var119) {
         HudRenderContext.a(var4);
         AlphaFramebuffer.b(var4);
         HudRenderContext.a(var9);

         try {
            var119.a(var6, var7, var8);
         } finally {
            HudRenderContext.b();
         }

         var9.run();
      } else if (var5.currentScreen instanceof PulseMainMenuScreen var118) {
         HudRenderContext.a(var4);
         AlphaFramebuffer.b(var4);
         HudRenderContext.a(var9);

         try {
            var118.a(var6, var7, var8);
         } finally {
            HudRenderContext.b();
         }

         var9.run();
      } else if (var5.currentScreen instanceof PulseGameMenuScreen var117) {
         HudRenderContext.a(var4);
         AlphaFramebuffer.b(var4);
         HudRenderContext.a(var9);

         try {
            var117.a(var6, var7, var8);
         } finally {
            HudRenderContext.b();
         }

         var9.run();
      } else if (var5.currentScreen instanceof PulseConfirmExitScreen var116) {
         HudRenderContext.a(var4);
         AlphaFramebuffer.b(var4);
         HudRenderContext.a(var9);

         try {
            var116.a(var6, var7, var8);
         } finally {
            HudRenderContext.b();
         }

         var9.run();
      } else {
         GuiOverlay var11 = GuiOverlay.a();
         if (var11.g() && Pulse.l().j() instanceof ClickGuiScreen var128) {
            float var130 = var11.e();
            if (var130 > 0.001F) {
               HudRenderContext.a(var4);
               AlphaFramebuffer.a(var4);

               try {
                  var128.a(var6, var7, var8, var130);
               } finally {
                  HudRenderContext.b();
               }
            }
         }

         KbGuiOverlay var129 = KbGuiOverlay.a();
         if (var129.d() && var129.e() != null) {
            float var131 = var129.c();
            if (var131 > 0.001F) {
               HudRenderContext.a(var4);
               AlphaFramebuffer.a(var4);

               try {
                  var129.e().a(var6, var7, var8, var131);
               } finally {
                  HudRenderContext.b();
               }
            } else {
               var129.f();
            }
         }
      }
   }
}
