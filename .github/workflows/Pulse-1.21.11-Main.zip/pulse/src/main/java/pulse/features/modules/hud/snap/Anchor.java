package pulse.features.modules.hud.snap;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Anchor {
   private float a = 0.0F;
   private float b = 0.0F;

   public void a(float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = var1 + var3 / 2.0F;
      float var8 = var2 + var4 / 2.0F;
      this.a = var7 / var5;
      this.b = var8 / var6;
      this.a = Math.max(0.0F, Math.min(1.0F, this.a));
      this.b = Math.max(0.0F, Math.min(1.0F, this.b));
   }

   public float a(float var1, float var2) {
      float var3 = this.a * var2;
      return var3 - var1 / 2.0F;
   }

   public float b(float var1, float var2) {
      float var3 = this.b * var2;
      return var3 - var1 / 2.0F;
   }

   public float a() {
      return this.a;
   }

   public float b() {
      return this.b;
   }

   public void a(float var1) {
      this.a = var1;
   }

   public void b(float var1) {
      this.b = var1;
   }
}
