package pulse.features.modules.utilities;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ItemColorSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Item Highliter",
   b = "Подсвечивает указанные предметы в инвентаре",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ItemHighliterModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Пульсация", false);
   private final NumberSetting b = new NumberSetting("Альфа", 170.0F, 0.0F, 255.0F, 1.0F);
   private final ItemColorSetting c = new ItemColorSetting("Дезориентация", Items.ENDER_EYE, false, new Color(100, 255, 100));
   private final ItemColorSetting f = new ItemColorSetting("Огненный смерч", Items.FIRE_CHARGE, false, new Color(255, 100, 0));
   private final ItemColorSetting g = new ItemColorSetting("Явная пыль", Items.SUGAR, false, new Color(255, 255, 255));
   private final ItemColorSetting h = new ItemColorSetting("Тотем бессмертия", Items.TOTEM_OF_UNDYING, false, new Color(255, 215, 0));
   private final ItemColorSetting i = new ItemColorSetting("Бутылка опыта", Items.EXPERIENCE_BOTTLE, false, new Color(100, 255, 200));
   private final ItemColorSetting j = new ItemColorSetting("Трапка", Items.NETHERITE_SCRAP, false, new Color(150, 150, 255));
   private final ItemColorSetting k = new ItemColorSetting("Пласт", Items.DRIED_KELP, false, new Color(180, 180, 180));
   private final ItemColorSetting l = new ItemColorSetting("Золотое яблоко", Items.GOLDEN_APPLE, false, new Color(255, 215, 0));
   private final ItemColorSetting m = new ItemColorSetting("Чарка", Items.ENCHANTED_GOLDEN_APPLE, false, new Color(255, 100, 255));
   private final ItemColorSetting n = new ItemColorSetting("Хорус", Items.CHORUS_FRUIT, false, new Color(200, 100, 255));
   private final ItemColorSetting o = new ItemColorSetting("Эндер пёрл", Items.ENDER_PEARL, false, new Color(0, 255, 150));
   private final ItemColorSetting p = new ItemColorSetting("Снежок заморозка", Items.SNOWBALL, false, new Color(200, 230, 255));
   private final ItemColorSetting q = new ItemColorSetting("Трапка 2", Items.POPPED_CHORUS_FRUIT, false, new Color(200, 170, 140));
   private final ItemColorSetting r = new ItemColorSetting("Стан", Items.NETHER_STAR, false, new Color(180, 140, 100));
   private final ItemColorSetting s = new ItemColorSetting("Светильник джека", Items.JACK_O_LANTERN, false, new Color(255, 150, 0));
   private final ItemColorSetting t = new ItemColorSetting("Взрывная трапка", Items.PRISMARINE_SHARD, false, new Color(255, 50, 50));
   private final BooleanSetting u = new BooleanSetting("Положительные зелья", false);
   private final ColorSetting v = new ColorSetting("Цвет положительных", new Color(100, 255, 100)).a(this.u::q);
   private final BooleanSetting w = new BooleanSetting("Негативные зелья", false);
   private final ColorSetting x = new ColorSetting("Цвет негативных", new Color(255, 100, 100)).a(this.w::q);
   private final Map<Item, ItemColorSetting> y;

   public ItemHighliterModule() {
      HashMap var1 = new HashMap<>();
      var1.put(Items.ENDER_EYE, this.c);
      var1.put(Items.FIRE_CHARGE, this.f);
      var1.put(Items.SUGAR, this.g);
      var1.put(Items.TOTEM_OF_UNDYING, this.h);
      var1.put(Items.EXPERIENCE_BOTTLE, this.i);
      var1.put(Items.NETHERITE_SCRAP, this.j);
      var1.put(Items.DRIED_KELP, this.k);
      var1.put(Items.GOLDEN_APPLE, this.l);
      var1.put(Items.ENCHANTED_GOLDEN_APPLE, this.m);
      var1.put(Items.CHORUS_FRUIT, this.n);
      var1.put(Items.ENDER_PEARL, this.o);
      var1.put(Items.SNOWBALL, this.p);
      var1.put(Items.POPPED_CHORUS_FRUIT, this.q);
      var1.put(Items.NETHER_STAR, this.r);
      var1.put(Items.JACK_O_LANTERN, this.s);
      var1.put(Items.PRISMARINE_SHARD, this.t);
      this.y = Collections.unmodifiableMap(var1);
   }

   public boolean a(ItemStack var1) {
      if (this.k() && !var1.isEmpty()) {
         Item var2 = var1.getItem();
         ItemColorSetting var3 = this.y.get(var2);
         if (var3 != null && var3.q()) {
            return true;
         } else {
            if (this.b(var2)) {
               ItemHighliterModule.PotionType var4 = this.c(var1);
               if (var4 == ItemHighliterModule.PotionType.a && this.u.q()) {
                  return true;
               }

               if (var4 == ItemHighliterModule.PotionType.b && this.w.q()) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private boolean b(Item var1) {
      return var1 == Items.POTION || var1 == Items.SPLASH_POTION || var1 == Items.LINGERING_POTION;
   }

   private ItemHighliterModule.PotionType c(ItemStack var1) {
      PotionContentsComponent var2 = var1.get(DataComponentTypes.POTION_CONTENTS);
      if (var2 == null) {
         return ItemHighliterModule.PotionType.d;
      } else {
         Iterable<StatusEffectInstance> var3 = var2.getEffects();
         int var4 = 0;
         int var5 = 0;
         boolean var6 = false;

         for (StatusEffectInstance var8 : var3) {
            var6 = true;
            StatusEffectCategory var9 = var8.getEffectType().value().getCategory();
            if (var9 == StatusEffectCategory.BENEFICIAL) {
               var4++;
            } else if (var9 == StatusEffectCategory.HARMFUL) {
               var5++;
            }
         }

         if (!var6) {
            return ItemHighliterModule.PotionType.d;
         } else if (var4 > var5) {
            return ItemHighliterModule.PotionType.a;
         } else if (var5 > var4) {
            return ItemHighliterModule.PotionType.b;
         } else {
            return var4 > 0 ? ItemHighliterModule.PotionType.a : ItemHighliterModule.PotionType.d;
         }
      }
   }

   public Color a(Item var1) {
      ItemColorSetting var2 = this.y.get(var1);
      return var2 != null ? var2.e() : Color.WHITE;
   }

   public Color b(ItemStack var1) {
      Item var2 = var1.getItem();
      ItemColorSetting var3 = this.y.get(var2);
      if (var3 != null && var3.q()) {
         return var3.e();
      } else {
         if (this.b(var2)) {
            ItemHighliterModule.PotionType var4 = this.c(var1);
            if (var4 == ItemHighliterModule.PotionType.a && this.u.q()) {
               return this.v.a();
            }

            if (var4 == ItemHighliterModule.PotionType.b && this.w.q()) {
               return this.x.a();
            }
         }

         return Color.WHITE;
      }
   }

   public int n() {
      if (this.a.q()) {
         int var1 = this.b.c();
         double var2 = Math.sin(System.currentTimeMillis() / 100.0) * 0.5 + 0.5;
         int var4 = Math.max(0, var1 / 2);
         int var5 = Math.min(255, var1 + var1 / 2);
         return var4 + (int)((var5 - var4) * var2);
      } else {
         return this.b.c();
      }
   }

   public List<Item> o() {
      if (d.player == null) {
         return Collections.emptyList();
      } else {
         ArrayList<Item> var1 = new ArrayList<>();

         for (ItemStack var3 : d.player.getInventory().getMainStacks()) {
            if (this.a(var3)) {
               Item var4 = var3.getItem();
               if (!var1.contains(var4)) {
                  var1.add(var4);
               }
            }
         }

         return var1;
      }
   }

   @Generated
   public BooleanSetting p() {
      return this.a;
   }

   @Generated
   public ItemColorSetting q() {
      return this.c;
   }

   @Generated
   public ItemColorSetting r() {
      return this.f;
   }

   @Generated
   public ItemColorSetting s() {
      return this.g;
   }

   @Generated
   public ItemColorSetting t() {
      return this.h;
   }

   @Generated
   public ItemColorSetting v() {
      return this.i;
   }

   @Generated
   public ItemColorSetting w() {
      return this.j;
   }

   @Generated
   public ItemColorSetting x() {
      return this.k;
   }

   @Generated
   public ItemColorSetting y() {
      return this.l;
   }

   @Generated
   public ItemColorSetting z() {
      return this.m;
   }

   @Generated
   public ItemColorSetting A() {
      return this.n;
   }

   @Generated
   public ItemColorSetting B() {
      return this.o;
   }

   @Generated
   public ItemColorSetting C() {
      return this.p;
   }

   @Generated
   public ItemColorSetting D() {
      return this.q;
   }

   @Generated
   public ItemColorSetting E() {
      return this.r;
   }

   @Generated
   public ItemColorSetting F() {
      return this.s;
   }

   @Generated
   public ItemColorSetting G() {
      return this.t;
   }

   @Generated
   public BooleanSetting H() {
      return this.u;
   }

   @Generated
   public ColorSetting I() {
      return this.v;
   }

   @Generated
   public BooleanSetting J() {
      return this.w;
   }

   @Generated
   public ColorSetting K() {
      return this.x;
   }

   @Generated
   public Map<Item, ItemColorSetting> L() {
      return this.y;
   }

   @Environment(EnvType.CLIENT)
   private static enum PotionType {
      a,
      b,
      c,
      d;

      private static ItemHighliterModule.PotionType[] a() {
         return new ItemHighliterModule.PotionType[]{a, b, c, d};
      }
   }
}
