package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class ChatSendEvent extends Event {
   private String a;

   public ChatSendEvent(String var1) {
      this.a = var1;
   }

   @Generated
   public String a() {
      return this.a;
   }

   @Generated
   public void a(String var1) {
      this.a = var1;
   }
}
