package pulse.features.resourcepack;

import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.json.JSONArray;
import org.json.JSONObject;

@Environment(EnvType.CLIENT)
public final class PpackContainer {
   private static final byte[] a = "PULSEPK1".getBytes(StandardCharsets.US_ASCII);
   private static final int b = 128;
   private final Path c;
   private final byte[] d;
   private final long e;
   private final int f;
   private final Map<String, long[]> g;

   private PpackContainer(Path var1, byte[] var2, long var3, int var5, Map<String, long[]> var6) {
      this.c = var1;
      this.d = var2;
      this.e = var3;
      this.f = var5;
      this.g = var6;
   }

   public int a() {
      return this.f;
   }

   public boolean a(String var1) {
      return this.g.containsKey(var1);
   }

   public List<String> b() {
      return new ArrayList<>(this.g.keySet());
   }

   public byte[] b(String var1) {
      long[] var2 = this.g.get(var1);
      if (var2 == null) {
         return null;
      } else {
         try {
            byte[] var5;
            try (RandomAccessFile var3 = new RandomAccessFile(this.c.toFile(), "r")) {
               var3.seek(this.e + var2[0]);
               byte[] var4 = new byte[(int)var2[1]];
               var3.readFully(var4);
               var5 = this.a(var4, var1);
            }

            return var5;
         } catch (Exception var8) {
            return null;
         }
      }
   }

   private byte[] a(byte[] var1, String var2) throws Exception {
      byte[] var3 = new byte[12];
      System.arraycopy(var1, 0, var3, 0, 12);
      Cipher var4 = Cipher.getInstance("AES/GCM/NoPadding");
      var4.init(2, new SecretKeySpec(this.d, "AES"), new GCMParameterSpec(128, var3));
      var4.updateAAD(var2.getBytes(StandardCharsets.UTF_8));
      return var4.doFinal(var1, 12, var1.length - 12);
   }

   public static PpackContainer a(Path var0, byte[] var1) throws Exception {
      if (var1 != null && var1.length == 32) {
         PpackContainer var20;
         try (RandomAccessFile var2 = new RandomAccessFile(var0.toFile(), "r")) {
            byte[] var3 = new byte[8];
            var2.readFully(var3);

            for (int var4 = 0; var4 < 8; var4++) {
               if (var3[var4] != a[var4]) {
                  throw new IllegalStateException("bad ppack magic");
               }
            }

            int var19 = var2.readInt();
            byte[] var5 = new byte[12];
            var2.readFully(var5);
            byte[] var6 = new byte[var19];
            var2.readFully(var6);
            long var7 = 24L + var19;
            Cipher var9 = Cipher.getInstance("AES/GCM/NoPadding");
            var9.init(2, new SecretKeySpec(var1, "AES"), new GCMParameterSpec(128, var5));
            var9.updateAAD("index".getBytes(StandardCharsets.UTF_8));
            byte[] var10 = var9.doFinal(var6);
            JSONObject var11 = new JSONObject(new String(var10, StandardCharsets.UTF_8));
            int var12 = var11.optInt("packFormat", 0);
            JSONArray var13 = var11.getJSONArray("entries");
            LinkedHashMap var14 = new LinkedHashMap(var13.length() * 2);

            for (int var15 = 0; var15 < var13.length(); var15++) {
               JSONObject var16 = var13.getJSONObject(var15);
               var14.put(var16.getString("p"), new long[]{var16.getLong("o"), var16.getLong("l")});
            }

            var20 = new PpackContainer(var0, (byte[])var1.clone(), var7, var12, var14);
         }

         return var20;
      } else {
         throw new IllegalArgumentException("DEK must be 32 bytes");
      }
   }

   public static boolean a(Path var0) {
      try {
         byte[] var1 = new byte[8];

         try (RandomAccessFile var2 = new RandomAccessFile(var0.toFile(), "r")) {
            if (var2.length() < 8L) {
               return false;
            }

            var2.readFully(var1);
         }

         for (int var8 = 0; var8 < 8; var8++) {
            if (var1[var8] != a[var8]) {
               return false;
            }
         }

         return true;
      } catch (Exception var7) {
         return false;
      }
   }
}
