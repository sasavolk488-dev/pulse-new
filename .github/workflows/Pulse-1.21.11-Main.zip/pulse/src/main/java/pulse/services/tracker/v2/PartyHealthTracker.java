package pulse.services.tracker.v2;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

@Environment(EnvType.CLIENT)
public final class PartyHealthTracker {
   private static final PartyHealthTracker b = new PartyHealthTracker();
   public static final long a = 15000L;
   private final Map<Integer, PartyHealthTracker.Health> c = new ConcurrentHashMap<>();

   private PartyHealthTracker() {
   }

   public static PartyHealthTracker a() {
      return b;
   }

   public void a(int var1, float var2, float var3, float var4) {
      this.c.put(var1, new PartyHealthTracker.Health(var2, var3, var4, System.currentTimeMillis()));
   }

   public PartyHealthTracker.Health a(int var1, String var2) {
      MinecraftClient var3 = MinecraftClient.getInstance();
      if (var3.world != null && var2 != null && !var2.isEmpty()) {
         for (AbstractClientPlayerEntity var5 : var3.world.getPlayers()) {
            if (var2.equalsIgnoreCase(var5.getGameProfile().name())) {
               return new PartyHealthTracker.Health(var5.getHealth(), var5.getMaxHealth(), var5.getAbsorptionAmount(), System.currentTimeMillis());
            }
         }
      }

      return this.c.get(var1);
   }

   public void a(Set<Integer> var1) {
      this.c.keySet().retainAll(var1);
   }

   public void b() {
      this.c.clear();
   }

   @Environment(EnvType.CLIENT)
   public record Health(float hp, float maxHp, float absorption, long receivedAt) {
      public boolean a() {
         return System.currentTimeMillis() - this.receivedAt > 15000L;
      }
   }
}
