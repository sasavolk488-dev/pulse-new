package pulse.features.cosmetic.geckolib;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.Pulse;
import pulse.features.cosmetic.geo.GeoModel;
import pulse.features.cosmetic.geo.GeoModelParser;
import pulse.features.cosmetic.model.CosmeticModel;

@Environment(EnvType.CLIENT)
public class GeckolibModelParser {
   public GeoModel a(CosmeticModel var1) {
      try {
         String var2 = var1.d();
         if (var2 == null) {
            Pulse.m().error("No raw model JSON available for cosmetic: " + var1.a());
            return null;
         } else {
            GeoModel var3 = GeoModelParser.a(var2);
            if (var3 == null) {
               Pulse.m().error("Failed to parse GeoModel for: " + var1.a());
               return null;
            } else {
               Pulse.m().info("Successfully parsed model for: " + var1.a() + " (bones: " + var3.a.size() + ")");
               return var3;
            }
         }
      } catch (Exception var4) {
         Pulse.m().error("Error parsing model for: " + var1.a(), (Throwable)var4);
         return null;
      }
   }
}
