package pulse.services.accounts;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class AltAccount {
   private static final DateTimeFormatter a = DateTimeFormatter.ofPattern("dd/MM/yyyy");
   private final AltAccount.Type b;
   private String c;
   private String d;
   private final String e;
   private String f;
   private String g;
   private String h;
   private boolean i;

   public AltAccount(AltAccount.Type var1, String var2) {
      this(var1, var2, null, LocalDate.now().format(a));
   }

   public AltAccount(AltAccount.Type var1, String var2, String var3, String var4) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4 != null && !var4.isEmpty() ? var4 : LocalDate.now().format(a);
   }

   public AltAccount.Type a() {
      return this.b;
   }

   public String b() {
      return this.c;
   }

   public void a(String var1) {
      this.c = var1;
   }

   public String c() {
      return this.d;
   }

   public void b(String var1) {
      this.d = var1;
   }

   public String d() {
      return this.e;
   }

   boolean e() {
      return this.i;
   }

   void a(boolean var1) {
      this.i = var1;
   }

   public String f() {
      return this.f;
   }

   public void c(String var1) {
      this.f = var1;
   }

   String g() {
      return this.g;
   }

   void d(String var1) {
      this.g = var1;
   }

   public boolean h() {
      return this.g != null || this.h != null;
   }

   String i() {
      return this.h;
   }

   void e(String var1) {
      if (var1 != null) {
         this.h = var1;
      }
   }

   public String j() {
      if (this.h == null && this.g != null) {
         this.h = Dpapi.a(this.g) ? Dpapi.b(this.g) : this.g;
      }

      return this.h;
   }

   void a(String var1, String var2) {
      this.h = var1;
      this.g = var2;
   }

   public String k() {
      return this.b.name().toLowerCase(Locale.ROOT) + ":" + this.c.toLowerCase(Locale.ROOT);
   }

   @Environment(EnvType.CLIENT)
   public static enum Type {
      a("Оффлайн"),
      b("Microsoft");

      private final String c;

      private Type(String var3) {
         this.c = var3;
      }

      public String a() {
         return this.c;
      }

      private static AltAccount.Type[] b() {
         return new AltAccount.Type[]{a, b};
      }
   }
}
