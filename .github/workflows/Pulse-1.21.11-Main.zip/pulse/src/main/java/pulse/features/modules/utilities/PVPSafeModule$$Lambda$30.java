package pulse.features.modules.utilities;

import java.util.function.Predicate;
import pulse.utils.time.TimeUtils;

public final class PVPSafeModule$$Lambda$30 implements Predicate {
   @Override
   public boolean test(Object var1) {
      return PVPSafeModule.a((TimeUtils)var1);
   }
}
