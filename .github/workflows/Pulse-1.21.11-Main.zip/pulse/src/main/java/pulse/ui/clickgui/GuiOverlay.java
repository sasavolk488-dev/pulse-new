package pulse.ui.clickgui;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class GuiOverlay {
   private static final GuiOverlay a = new GuiOverlay();
   private static final double b = 0.2000000377418723;
   private final Animation c = new Animation();
   private boolean d = false;
   private boolean e = false;

   private GuiOverlay() {
      this.c.d(0.0);
   }

   public static GuiOverlay a() {
      return a;
   }

   public void b() {
      this.d = true;
      this.e = false;
      this.c.d(0.0);
      this.c.a(1.0, 0.2000000377418723, Easings.C);
   }

   public void c() {
      this.d = false;
      this.e = true;
      this.c.a(0.0, 0.2000000377418723, Easings.C);
   }

   public float d() {
      this.c.a();
      return Math.max(0.0F, Math.min(1.0F, (float)this.c.j()));
   }

   public float e() {
      if (!this.e) {
         return 0.0F;
      } else {
         this.c.a();
         float var1 = Math.max(0.0F, Math.min(1.0F, (float)this.c.j()));
         if (!this.c.d() && !(var1 <= 0.001F)) {
            return var1;
         } else {
            this.e = false;
            return 0.0F;
         }
      }
   }

   public void a(MatrixStack var1) {
      if (this.e) {
         this.c.a();
         float var2 = Math.max(0.0F, Math.min(1.0F, (float)this.c.j()));
         if (!this.c.d() && !(var2 <= 0.001F)) {
            if (Pulse.l().j() instanceof ClickGuiScreen var4) {
               Render var5 = Pulse.l().p();
               float var6 = IMinecraft.u().getWidth() / 4.0F - ClickGuiScreen.e() / 2.0F;
               float var7 = IMinecraft.u().getHeight() / 4.0F - ClickGuiScreen.f() / 2.0F;
               var4.a(var1, var5, var6, var7);
            }
         } else {
            this.e = false;
         }
      }
   }

   @Generated
   public boolean f() {
      return this.d;
   }

   @Generated
   public boolean g() {
      return this.e;
   }
}
