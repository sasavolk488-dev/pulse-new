package pulse.core.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;

@Environment(EnvType.CLIENT)
public interface ILivingStateEntity {
   LivingEntity pulse$getEntity();

   void pulse$setEntity(LivingEntity var1);
}
