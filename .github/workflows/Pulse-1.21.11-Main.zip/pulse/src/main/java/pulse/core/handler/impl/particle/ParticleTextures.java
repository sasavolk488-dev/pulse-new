package pulse.core.handler.impl.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public final class ParticleTextures {
   public static final Identifier a = b("star");
   public static final Identifier b = b("circle");
   public static final Identifier c = b("twirl");
   public static final Identifier d = b("flare");
   public static final Identifier[] e = new Identifier[]{a, b, c, d};
   public static final String[] f = new String[]{"Звезда", "Кольцо", "Спираль", "Лучи"};

   public static Identifier a(String var0) {
      for (int var1 = 0; var1 < f.length; var1++) {
         if (f[var1].equals(var0)) {
            return e[var1];
         }
      }

      return a;
   }

   private static Identifier b(String var0) {
      return Identifier.of("pulse", "textures/particle/" + var0 + ".png");
   }

   private ParticleTextures() {
   }
}
