package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.state.OutlineRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.BlockOutlineEvent;

@Environment(EnvType.CLIENT)
@Mixin({WorldRenderer.class})
public class BlockOutlineMixin {
   @Inject(
      method = {"drawBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onDrawBlockOutline(
      MatrixStack var1, VertexConsumer var2, double var3, double var5, double var7, OutlineRenderState var9, int var10, float var11, CallbackInfo var12
   ) {
      MinecraftClient var13 = MinecraftClient.getInstance();
      Entity var14 = var13.getCameraEntity();
      BlockPos var15 = var9.pos();
      BlockState var16 = var13.world != null ? var13.world.getBlockState(var15) : null;
      BlockOutlineEvent var17 = new BlockOutlineEvent(var1, var2, var14, var3, var5, var7, var15, var16);
      EventHandler.a.post(var17);
      if (var17.c()) {
         var12.cancel();
      }
   }
}
