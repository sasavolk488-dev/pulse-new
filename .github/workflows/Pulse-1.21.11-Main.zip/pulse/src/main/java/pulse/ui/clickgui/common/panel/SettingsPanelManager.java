package pulse.ui.clickgui.common.panel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.ui.clickgui.common.ModuleSettingsPanel;
import pulse.ui.clickgui.common.OverlayElement;
import pulse.ui.clickgui.common.provider.ToggleEntry;
import pulse.ui.clickgui.menu.modules.ModulesMenu;
import pulse.features.modules.Module;
import pulse.utils.render.Render;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class SettingsPanelManager {
   private final List<ModuleSettingsPanel> a = new ArrayList<>();
   private float b;
   private float c;

   public List<ModuleSettingsPanel> a() {
      return this.a;
   }

   public void a(float var1, float var2, float var3, int var4, float var5, float var6) {
      this.b = var1;
      this.c = var2;
      float var7 = var1 - var3;
      Iterator var8 = this.a.iterator();

      while (var8.hasNext()) {
         ModuleSettingsPanel var9 = (ModuleSettingsPanel)var8.next();
         if (var9.e()) {
            var8.remove();
         } else {
            int var10 = var9.m();
            if (var10 >= 0) {
               int var11 = var10 / var4;
               float var12 = var7 + var11 * (var5 + var6) + 1.0F;
               var9.a(var12);
               if (!var9.f() && var9.a(var1, var2)) {
                  var9.b();
               }
            }
         }
      }
   }

   public void b() {
      boolean var1 = false;
      boolean var2 = false;

      for (ModuleSettingsPanel var4 : this.a) {
         if (!var4.f() && var4.g()) {
            var1 = true;
            float var5 = var4.j();
            float var6 = var4.i();
            float var7 = 150.0F;
            float var8 = var4.k();
            MouseUtil.a(var5, var6, var7, var8);
            break;
         }
      }

      if (!var1) {
         for (ModuleSettingsPanel var10 : this.a) {
            if (!var10.f() && !var10.g() && var10.u()) {
               var2 = true;
               float[] var11 = var10.w();
               if (var11 != null) {
                  MouseUtil.a(var11[0], var11[1], var11[2], var11[3]);
               }
               break;
            }
         }
      }

      if (!var1 && !var2) {
         MouseUtil.a();
      }

      OverlayElement.a().a(var1);
      OverlayElement.a().c(var2);
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7, float var8) {
      ModuleSettingsPanel var9 = this.a(var5, var6);
      boolean var10 = var9 != null;

      for (ModuleSettingsPanel var12 : this.a) {
         if (!var12.g()) {
            boolean var13 = var10 && var9 != var12;
            var12.a(var1, var2, var3, var4, var5, var6, var7, var8, var13);
         }
      }

      for (ModuleSettingsPanel var15 : this.a) {
         if (!var15.g()) {
            var15.b(var1, var2, var5, var6);
         }
      }
   }

   public void b(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7, float var8) {
      for (ModuleSettingsPanel var10 : this.a) {
         if (var10.g()) {
            var10.a(var1, var2, var3, var4, var5, var6, var7, var8);
         }
      }
   }

   public boolean c() {
      for (ModuleSettingsPanel var2 : this.a) {
         if (!var2.f() && var2.g()) {
            return true;
         }
      }

      return false;
   }

   public boolean d() {
      for (ModuleSettingsPanel var2 : this.a) {
         if (!var2.f() && !var2.g() && var2.u()) {
            return true;
         }
      }

      return false;
   }

   public ToggleEntry e() {
      for (ModuleSettingsPanel var2 : this.a) {
         if (!var2.f() && var2.g()) {
            return var2.l();
         }
      }

      return null;
   }

   public void f() {
      for (ModuleSettingsPanel var2 : this.a) {
         if (!var2.f() && var2.g()) {
            var2.b();
         }
      }
   }

   public void g() {
      Iterator var1 = this.a.iterator();

      while (var1.hasNext()) {
         ModuleSettingsPanel var2 = (ModuleSettingsPanel)var1.next();
         if (var2.g()) {
            var2.c();
            var1.remove();
         }
      }
   }

   public void h() {
      for (ModuleSettingsPanel var2 : this.a) {
         if (!var2.f() && !var2.g()) {
            var2.v();
         }
      }
   }

   public void i() {
      for (ModuleSettingsPanel var2 : this.a) {
         var2.b();
      }
   }

   public void j() {
      for (ModuleSettingsPanel var2 : this.a) {
         var2.c();
      }

      this.a.clear();
   }

   public void k() {
      Iterator var1 = this.a.iterator();

      while (var1.hasNext()) {
         ModuleSettingsPanel var2 = (ModuleSettingsPanel)var1.next();
         if (var2.g()) {
            var2.c();
            var1.remove();
         } else {
            var2.d();
         }
      }
   }

   public ModuleSettingsPanel a(int var1, int var2) {
      for (ModuleSettingsPanel var4 : this.a) {
         if (!var4.f() && !var4.g() && var4.f(var1, var2)) {
            return var4;
         }
      }

      return null;
   }

   public boolean b(int var1, int var2) {
      return this.a(var1, var2) != null;
   }

   public boolean c(int var1, int var2) {
      ModuleSettingsPanel var3 = this.a(var1, var2);
      if (var3 != null) {
         var3.a(var1, var2);
         return true;
      } else {
         for (ModuleSettingsPanel var5 : this.a) {
            if (!var5.f() && var5.d(var1, var2)) {
               var5.a(var1, var2);
               return true;
            }
         }

         if (this.c()) {
            this.f();
            return true;
         } else if (this.d()) {
            this.h();
            return true;
         } else {
            return false;
         }
      }
   }

   public boolean d(int var1, int var2) {
      ModuleSettingsPanel var3 = this.a(var1, var2);
      if (var3 != null) {
         var3.b(var1, var2);
         return true;
      } else {
         for (ModuleSettingsPanel var5 : this.a) {
            if (!var5.f() && var5.d(var1, var2)) {
               if (var5.b(var1, var2)) {
                  return true;
               }

               var5.b();
               return true;
            }
         }

         if (this.c()) {
            this.f();
            return true;
         } else if (this.d()) {
            this.h();
            return true;
         } else {
            return false;
         }
      }
   }

   public void e(int var1, int var2) {
      for (ModuleSettingsPanel var4 : this.a) {
         var4.c(var1, var2);
      }
   }

   public void a(int var1, int var2, double var3, double var5) {
      for (ModuleSettingsPanel var8 : this.a) {
         if (!var8.f()) {
            var8.a(var1, var2, var3, var5);
         }
      }
   }

   public boolean a(float var1, int var2, int var3) {
      if (this.c()) {
         this.f();
         return true;
      } else if (this.d()) {
         this.h();
         return true;
      } else {
         for (ModuleSettingsPanel var5 : this.a) {
            if (!var5.f() && var5.e(var2, var3)) {
               var5.a(var1, var2, var3);
               return true;
            }
         }

         return false;
      }
   }

   public boolean a(int var1, int var2, int var3) {
      for (ModuleSettingsPanel var5 : this.a) {
         if (!var5.f() && var5.a(var1, var2, var3)) {
            return true;
         }
      }

      return false;
   }

   public boolean a(char var1, int var2) {
      for (ModuleSettingsPanel var4 : this.a) {
         if (!var4.f() && var4.a(var1, var2)) {
            return true;
         }
      }

      return false;
   }

   public boolean l() {
      for (ModuleSettingsPanel var2 : this.a) {
         if (!var2.f() && var2.h()) {
            return true;
         }
      }

      return false;
   }

   public void a(ToggleEntry var1, int var2, boolean var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      for (ModuleSettingsPanel var11 : this.a) {
         if (var11.l() == var1 && !var11.f() && var11.g()) {
            var11.b();
            return;
         }
      }

      for (ModuleSettingsPanel var19 : this.a) {
         if (!var19.f() && var19.g()) {
            var19.b();
         }
      }

      this.h();
      float var18 = 12.0F;
      float var20 = var8 + var18 / 2.0F;
      float var12 = 30.0F;
      float var13 = 150.0F;
      float var14 = var20 - var13 / 2.0F;
      float var15 = var9 - var12 - 4.0F;
      ModuleSettingsPanel var16 = ModuleSettingsPanel.a(var1, var1.e(), var2, var3, var5, var7);
      var16.a(var14, var15, true);
      this.a.add(var16);
   }

   public void a(ToggleEntry var1, int var2, boolean var3, float var4, float var5, float var6, float var7, int var8, int var9) {
      for (ModuleSettingsPanel var11 : this.a) {
         if (var11.l() == var1 && !var11.f() && var11.g()) {
            var11.b();
            return;
         }
      }

      for (ModuleSettingsPanel var17 : this.a) {
         if (!var17.f() && var17.g()) {
            var17.b();
         }
      }

      this.h();
      float var16 = 30.0F;
      float var18 = 150.0F;
      float var12 = var8 - var18 / 2.0F;
      float var13 = var9 - var16 - 8.0F;
      ModuleSettingsPanel var14 = ModuleSettingsPanel.a(var1, var1.e(), var2, var3, var5, var7);
      var14.a(var12, var13, true);
      this.a.add(var14);
   }

   public void a(ToggleEntry var1, int var2, boolean var3, float var4, float var5) {
      if (var1.e() != null && !var1.e().m().isEmpty()) {
         ModuleSettingsPanel var6 = null;

         for (ModuleSettingsPanel var8 : this.a) {
            if (var8.l() == var1 && !var8.f() && !var8.g()) {
               var6 = var8;
               break;
            }
         }

         if (var6 != null) {
            var6.b();
         } else {
            for (ModuleSettingsPanel var28 : this.a) {
               if (!var28.f() && var28.g()) {
                  var28.b();
               }
            }

            this.h();
            TextureRegistry.TextureEntry var27 = TextureRegistry.b("arrow_v");
            float var29 = var27 != null ? var27.c() / 2.0F : 0.0F;
            ArrayList<ModuleSettingsPanel> var9 = new ArrayList<>();

            for (ModuleSettingsPanel var11 : this.a) {
               if (!var11.f() && var11.n() == var3) {
                  var9.add(var11);
               }
            }

            ModuleSettingsPanel.ArrowPosition var30 = ModuleSettingsPanel.ArrowPosition.b;
            ModuleSettingsPanel var31 = new ModuleSettingsPanel(var1, var1.e(), var2, var3, var4, var5, var30);
            float var12 = var31.k();
            if (!var9.isEmpty()) {
               float var13 = ModuleSettingsPanel.a(var4, var5, ModuleSettingsPanel.ArrowPosition.b, var29, var12);
               ArrayList<ModuleSettingsPanel> var14 = new ArrayList<>();

               for (ModuleSettingsPanel var16 : var9) {
                  if (ModuleSettingsPanel.a(var13, var12, var16.i(), var16.k())) {
                     var14.add(var16);
                  }
               }

               if (!var14.isEmpty()) {
                  ModuleSettingsPanel var32 = (ModuleSettingsPanel)var14.get(0);
                  float var33 = var32.i() + var32.k() / 2.0F;
                  float var17 = var4 + var5 / 2.0F;
                  ModuleSettingsPanel.ArrowPosition var18;
                  if (var17 < var33) {
                     var18 = ModuleSettingsPanel.ArrowPosition.c;
                  } else {
                     var18 = ModuleSettingsPanel.ArrowPosition.a;
                  }

                  float var19 = ModuleSettingsPanel.a(var4, var5, var18, var29, var12);
                  ArrayList var20 = new ArrayList<>();

                  for (ModuleSettingsPanel var22 : var9) {
                     if (ModuleSettingsPanel.a(var19, var12, var22.i(), var22.k())) {
                        var20.add(var22);
                     }
                  }

                  if (var20.isEmpty()) {
                     var30 = var18;
                  } else {
                     ModuleSettingsPanel.ArrowPosition var34 = var18 == ModuleSettingsPanel.ArrowPosition.a
                        ? ModuleSettingsPanel.ArrowPosition.c
                        : ModuleSettingsPanel.ArrowPosition.a;
                     float var35 = ModuleSettingsPanel.a(var4, var5, var34, var29, var12);
                     ArrayList var23 = new ArrayList<>();

                     for (ModuleSettingsPanel var25 : var9) {
                        if (ModuleSettingsPanel.a(var35, var12, var25.i(), var25.k())) {
                           var23.add(var25);
                        }
                     }

                     if (var23.isEmpty()) {
                        var30 = var34;
                     } else {
                        var30 = ModuleSettingsPanel.ArrowPosition.b;

                        for (ModuleSettingsPanel var37 : var14) {
                           var37.b();
                        }
                     }
                  }
               }
            }

            var31.a(var30);
            this.a.add(var31);
         }
      }
   }

   public void a(Module var1) {
      if (var1 != null && !var1.m().isEmpty()) {
         for (ModuleSettingsPanel var3 : this.a) {
            if (var3.l().e() == var1 && !var3.f()) {
               var3.b();
               return;
            }
         }

         this.i();
         this.h();
         ModulesMenu.ModuleToggleEntry var6 = new ModulesMenu.ModuleToggleEntry(var1);
         float var7 = this.b - 32.0F;
         float var4 = 15.0F;
         ModuleSettingsPanel var5 = new ModuleSettingsPanel(var6, var1, -1, false, var7, var4, ModuleSettingsPanel.ArrowPosition.b);
         this.a.add(var5);
      }
   }
}
