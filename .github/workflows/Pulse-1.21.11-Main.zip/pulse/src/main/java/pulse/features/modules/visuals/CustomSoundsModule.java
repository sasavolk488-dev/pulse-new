package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.CriticalHitEvent;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.PlaySoundEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.utilities.ft.FunTimeItemType;
import pulse.features.modules.visuals.sounds.SoundDistance;
import pulse.features.modules.visuals.sounds.StructureSoundReplacer;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.FolderSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.audio.SoundsUtils;

@ModuleInfo(
   a = "Custom Sounds",
   b = "Заменяет игровые звуки своими: удар, тотем, дезориентация, явная пыль, трапки и пласты",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class CustomSoundsModule extends Module {
   private static final String a = "Свой";
   private static final String b = "Файл из папки; .wav и .mp3. Пустая папка — ванильный звук просто выключается";
   private static final String[] c = new String[]{"wav", "mp3", "aif", "aiff", "au"};
   private static final Identifier f = Identifier.of("minecraft:item.totem.use");
   private static final Identifier g = Identifier.of("minecraft:entity.illusioner.mirror_move");
   private static final Identifier h = Identifier.of("minecraft:entity.illusioner.prepare_blindness");
   private final SeparatorSetting i = new SeparatorSetting("Удар");
   private final BooleanSetting j = new BooleanSetting("Звук удара", true);
   private final ModeSetting k = new ModeSetting(
         "Звук удара", new String[]{"Bell", "UwU", "Bonk", "Bubble", "Pop", "Moan", "Hit1", "Hit2", "Hit3", "Свой"}, "Bell"
      )
      .a(this.j::a);
   private final FolderSetting l = new FolderSetting("Свой звук удара", "Выбор звука из папки; .wav и .mp3", "pulse_sounds/hitsounds", c)
      .a(() -> this.j.a() && this.k.b("Свой"));
   private final NumberSetting m = new NumberSetting("Громкость удара", 1.0F, 0.1F, 2.0F, 0.1F).a(this.j::a);
   private final BooleanSetting n = new BooleanSetting("Только при крите", false).a(this.j::a);
   private final SeparatorSetting o = new SeparatorSetting("Тотем");
   private final BooleanSetting p = new BooleanSetting("Звук тотема", false);
   private final FolderSetting q = new FolderSetting(
         "Свой звук тотема", "Файл из папки; .wav и .mp3. Пустая папка — ванильный звук просто выключается", "pulse_sounds/totem", c
      )
      .a(this.p::a);
   private final NumberSetting r = new NumberSetting("Громкость тотема", 1.0F, 0.1F, 2.0F, 0.1F).a(this.p::a);
   private final SeparatorSetting s = new SeparatorSetting("Дезориентация");
   private final BooleanSetting t = new BooleanSetting("Звук дезориентации", false);
   private final FolderSetting u = new FolderSetting(
         "Свой звук дезориентации", "Файл из папки; .wav и .mp3. Пустая папка — ванильный звук просто выключается", "pulse_sounds/disorient", c
      )
      .a(this.t::a);
   private final NumberSetting v = new NumberSetting("Громкость дезориентации", 1.0F, 0.1F, 2.0F, 0.1F).a(this.t::a);
   private final SeparatorSetting w = new SeparatorSetting("Явная пыль");
   private final BooleanSetting x = new BooleanSetting("Звук явной пыли", false);
   private final FolderSetting y = new FolderSetting(
         "Свой звук явной пыли", "Файл из папки; .wav и .mp3. Пустая папка — ванильный звук просто выключается", "pulse_sounds/dust", c
      )
      .a(this.x::a);
   private final NumberSetting z = new NumberSetting("Громкость явной пыли", 1.0F, 0.1F, 2.0F, 0.1F).a(this.x::a);
   private final SeparatorSetting A = new SeparatorSetting("Трапки и пласты");
   private final BooleanSetting B = new BooleanSetting("Звуки построек", false);
   private final FolderSetting C = new FolderSetting(
         "Свой звук трапки", "Файл из папки; .wav и .mp3. Пустая папка — ванильный звук просто выключается", "pulse_sounds/trap", c
      )
      .a(this.B::a);
   private final NumberSetting D = new NumberSetting("Громкость трапки", 1.0F, 0.1F, 2.0F, 0.1F).a(this.B::a);
   private final FolderSetting E = new FolderSetting(
         "Свой звук пласта", "Файл из папки; .wav и .mp3. Пустая папка — ванильный звук просто выключается", "pulse_sounds/plast", c
      )
      .a(this.B::a);
   private final NumberSetting F = new NumberSetting("Громкость пласта", 1.0F, 0.1F, 2.0F, 0.1F).a(this.B::a);
   private final SeparatorSetting G = new SeparatorSetting("Прочее");
   private final BooleanSetting H = new BooleanSetting("Тише на расстоянии", true);
   private final StructureSoundReplacer I = new StructureSoundReplacer();
   private LivingEntity J = null;

   @Override
   public void f() {
      super.f();
      this.I.a();
      this.J = null;
   }

   @EventHandler
   @Compile
   public void a(AttackEvent var1) {
      if (this.j.a() && var1.a() != d.player && var1.a() instanceof LivingEntity) {
         this.J = (LivingEntity)var1.a();
         if (!((Boolean)this.n.q()).booleanValue()) {
            this.n();
         }
      }
   }

   @EventHandler
   @Compile
   public void a(CriticalHitEvent var1) {
      if (this.j.a() && var1.a() != d.player && var1.a() instanceof LivingEntity
         && var1.a() == this.J && ((Boolean)this.n.q()).booleanValue()) {
         this.n();
      }
   }

   private void n() {
      String var1 = this.k.e();
      float var2 = this.m.q();
      if (var1.equals("Свой")) {
         SoundsUtils.a(this.l.f(), var2);
      } else if (var1.equals("Moan")) {
         SoundsUtils.a(var2);
      } else {
         SoundsUtils.a(var1.toLowerCase(), var2);
      }
   }

   @EventHandler
   @Compile
   public void a(PlaySoundEvent var1) {
      BooleanSetting totem = this.p;
      FolderSetting totemSound = this.q;
      NumberSetting totemVolume = this.r;
      BooleanSetting disorient = this.t;
      BooleanSetting dust = this.x;
      FolderSetting dustSound = this.y;
      NumberSetting dustVolume = this.z;
      FolderSetting disorientSound = this.u;
      NumberSetting disorientVolume = this.v;
      SoundInstance sound = var1.d();
      if (sound == null) {
         return;
      }
      Identifier id = sound.getId();
      if (id == null) {
         return;
      }
      if (totem.a() && f.equals(id)) {
         this.a(var1, totemSound, totemVolume);
      } else if (disorient.a() && g.equals(id)) {
         this.a(var1, disorientSound, disorientVolume);
      } else if (dust.a() && h.equals(id)) {
         this.a(var1, dustSound, dustVolume);
      }
   }

   private void a(PlaySoundEvent var1, FolderSetting var2, NumberSetting var3) {
      var1.b();
      float var4 = this.a(var1.d());
      if (!(var4 <= 0.0F)) {
         SoundsUtils.a(var2.f(), var3.q() * var4);
      }
   }

   private float a(SoundInstance var1) {
      return this.H.a() && !var1.isRelative() ? SoundDistance.a(new Vec3d(var1.getX(), var1.getY(), var1.getZ())) : 1.0F;
   }

   @EventHandler
   @Compile
   public void a(PacketEvent var1) {
      if (var1.e() == PacketEvent.EventType.b && this.B.a()) {
         Object packet = var1.d();
         if (packet instanceof net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket sound && this.I.a(sound)) {
            var1.b();
         }
      }
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      if (this.B.a()) {
         this.I.a(this::a);
      } else {
         this.I.a();
      }
   }

   @EventHandler
   @Compile
   public void a(WorldChangeEvent var1) {
      this.I.a();
      this.J = null;
   }

   public void a(FunTimeItemType var1, Float var2) {
      float var3 = this.H.a() ? var2 : 1.0F;
      if (var1 == FunTimeItemType.a) {
         SoundsUtils.a(this.C.f(), this.D.q() * var3);
      } else if (var1 == FunTimeItemType.b) {
         SoundsUtils.a(this.E.f(), this.F.q() * var3);
      }
   }

   static {
      NativeMethodLookup.lookup(CustomSoundsModule.class, 82);
   }
}
