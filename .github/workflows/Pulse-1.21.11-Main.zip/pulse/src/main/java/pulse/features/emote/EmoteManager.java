package pulse.features.emote;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.util.Identifier;
import pulse.Pulse;
import pulse.features.emote.bobj.BobjAction;
import pulse.features.emote.bobj.BobjModel;
import pulse.features.emote.bobj.BobjProp;
import pulse.features.modules.utilities.FreeLookModule;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@Environment(EnvType.CLIENT)
public final class EmoteManager {
   private static final EmoteManager a = new EmoteManager();
   private static final double b = 5.0E7;
   private final Map<String, EmoteManager.ServerEmote> c = new ConcurrentHashMap<>();
   private final List<String> d = new CopyOnWriteArrayList<>();
   private final Map<String, String> e = new ConcurrentHashMap<>();
   private final Map<String, Identifier> f = new ConcurrentHashMap<>();
   private final Set<String> g = ConcurrentHashMap.newKeySet();
   private final Map<Integer, EmoteManager.Playback> h = new ConcurrentHashMap<>();
   private volatile BobjModel i;
   private volatile BobjModel j;
   private Perspective k;

   private EmoteManager() {
   }

   public static EmoteManager a() {
      return a;
   }

   public static boolean a(LivingEntity var0) {
      if (var0 == null) {
         return false;
      } else {
         return !var0.isInvisible()
            ? true
            : !var0.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
               || !var0.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
               || !var0.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
               || !var0.getEquippedStack(EquipmentSlot.FEET).isEmpty();
      }
   }

   public boolean b() {
      return !this.h.isEmpty();
   }

   public void a(BobjModel var1, BobjModel var2) {
      this.i = var1;
      this.j = var2;
   }

   public void a(String var1, BobjAction var2, int var3, boolean var4) {
      this.a(var1, var2, var3, var4, List.of());
   }

   public void a(String var1, BobjAction var2, int var3, boolean var4, List<BobjProp> var5) {
      if (var1 != null && var2 != null && var3 > 0) {
         if (!this.c.containsKey(var1)) {
            this.d.add(var1);
         }

         this.c.put(var1, new EmoteManager.ServerEmote(var2, var3, var4, var5 != null ? var5 : List.of()));
      }
   }

   public void a(String var1, String var2) {
      if (var1 != null && var2 != null) {
         this.e.put(var1, var2);
      }
   }

   public String a(String var1) {
      return this.e.getOrDefault(var1, "Emote " + var1);
   }

   public void a(String var1, Identifier var2) {
      if (var1 != null && var2 != null) {
         this.f.put(var1, var2);
      }
   }

   public Identifier b(String var1) {
      return this.f.get(var1);
   }

   public void c() {
      this.c.clear();
      this.d.clear();
      this.e.clear();
      this.f.clear();
      EmoteAudio.b();
   }

   public void d() {
      this.k();
      this.h.clear();
      this.g.clear();
      this.c();
      this.i = null;
      this.j = null;
   }

   public boolean c(String var1) {
      return this.c.containsKey(var1);
   }

   public int e() {
      return this.c.size();
   }

   public String a(int var1) {
      return var1 >= 0 && var1 < this.d.size() ? this.d.get(var1) : null;
   }

   public void a(Collection<String> var1) {
      this.g.clear();
      if (var1 != null) {
         this.g.addAll(var1);
      }

      Pulse.m().info("[Emote] setOwned: надето {} -> {}; в каталоге {}", this.g.size(), this.g, this.c.size());
   }

   public boolean d(String var1) {
      return this.g.contains(var1);
   }

   public List<String> f() {
      ArrayList var1 = new ArrayList();

      for (String var3 : this.d) {
         if (this.g.contains(var3)) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public String g() {
      return this.d.toString();
   }

   public String h() {
      return this.g.toString();
   }

   public boolean i() {
      Integer var1 = this.o();
      return var1 != null && this.h.containsKey(var1);
   }

   public String j() {
      Integer var1 = this.o();
      EmoteManager.Playback var2 = var1 == null ? null : this.h.get(var1);
      return var2 == null ? null : var2.a;
   }

   public void e(String var1) {
      EmoteManager.ServerEmote var2 = this.c.get(var1);
      if (var2 == null) {
         Pulse.m().warn("[Emote] unknown emote id: {}", var1);
      } else {
         MinecraftClient var3 = MinecraftClient.getInstance();
         Integer var4 = this.o();
         if (var4 != null) {
            if (!FreeLookModule.c && !this.h.containsKey(var4) && var3.options.getPerspective() == Perspective.FIRST_PERSON) {
               this.k = Perspective.FIRST_PERSON;
               var3.options.setPerspective(Perspective.THIRD_PERSON_FRONT);
            }

            this.h.put(var4, new EmoteManager.Playback(var1, var2, System.nanoTime()));
            this.a(g(var1), false);
         }
      }
   }

   public void k() {
      Integer var1 = this.o();
      EmoteManager.Playback var2 = var1 == null ? null : this.h.remove(var1);
      if (var2 != null) {
         this.a(0, true);
      }

      if (var2 != null && this.k != null && !FreeLookModule.c) {
         MinecraftClient var3 = MinecraftClient.getInstance();
         if (var3.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
            var3.options.setPerspective(this.k);
         }
      }

      this.k = null;
   }

   public void f(String var1) {
      if (var1 != null && var1.equals(this.j())) {
         this.k();
      } else {
         this.e(var1);
      }
   }

   public boolean l() {
      Integer var1 = this.o();
      EmoteManager.Playback var2 = var1 == null ? null : this.h.get(var1);
      return var2 != null && !var2.b.looping && this.a(var2) >= var2.b.durationTicks;
   }

   private void a(int var1, boolean var2) {
      RealtimeSyncServiceV2.L().b(var1, var2);
   }

   private static int g(String var0) {
      try {
         return Integer.parseInt(var0);
      } catch (Exception var2) {
         return 0;
      }
   }

   public void a(AbstractClientPlayerEntity var1, String var2) {
      if (var1 != null) {
         EmoteManager.ServerEmote var3 = this.c.get(var2);
         if (var3 == null) {
            Pulse.m().warn("[Emote] remote emote id {} отсутствует в каталоге", var2);
         } else {
            this.h.put(var1.getId(), new EmoteManager.Playback(var2, var3, System.nanoTime()));
         }
      }
   }

   public void a(AbstractClientPlayerEntity var1) {
      if (var1 != null) {
         this.h.remove(var1.getId());
      }
   }

   public Map<Integer, EmoteManager.PlayingInfo> m() {
      if (this.h.isEmpty()) {
         return Map.of();
      } else {
         HashMap var1 = new HashMap(this.h.size());

         for (Entry var3 : this.h.entrySet()) {
            EmoteManager.Playback var4 = (EmoteManager.Playback)var3.getValue();
            var1.put((Integer)var3.getKey(), new EmoteManager.PlayingInfo(var4.a, var4.c));
         }

         return var1;
      }
   }

   public void n() {
      if (!this.h.isEmpty()) {
         Integer var1 = this.o();

         for (Entry var3 : this.h.entrySet()) {
            if (var1 == null || !var1.equals(var3.getKey())) {
               EmoteManager.Playback var4 = (EmoteManager.Playback)var3.getValue();
               if (!var4.b.looping && this.a(var4) >= var4.b.durationTicks) {
                  this.h.remove(var3.getKey(), var4);
               }
            }
         }
      }
   }

   public boolean b(AbstractClientPlayerEntity var1) {
      return var1 != null && !this.h.isEmpty() && this.h.containsKey(var1.getId());
   }

   public EmoteManager.ActiveRenderData c(AbstractClientPlayerEntity var1) {
      if (var1 == null) {
         return null;
      } else if (this.h.isEmpty()) {
         return null;
      } else {
         EmoteManager.Playback var2 = this.h.get(var1.getId());
         if (var2 == null) {
            return null;
         } else {
            EmoteManager.ServerEmote var3 = var2.b;
            BobjModel var4 = var1.getSkin().model() == PlayerSkinType.SLIM ? this.j : this.i;
            if (var4 == null) {
               return null;
            } else {
               float var5 = this.a(var2);
               if (var3.looping) {
                  var5 %= var3.durationTicks;
               } else if (var5 >= var3.durationTicks) {
                  Integer var6 = this.o();
                  if (var6 == null || var1.getId() != var6) {
                     this.h.remove(var1.getId());
                     return null;
                  }

                  var5 = var3.durationTicks;
               }

               return new EmoteManager.ActiveRenderData(var4, var3.action, var5, var3.props);
            }
         }
      }
   }

   private Integer o() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      return var1.player == null ? null : var1.player.getId();
   }

   private float a(EmoteManager.Playback var1) {
      return (float)((System.nanoTime() - var1.c) / 5.0E7);
   }

   @Environment(EnvType.CLIENT)
   public record ActiveRenderData(BobjModel model, BobjAction action, float frame, List<BobjProp> props) {
   }

   @Environment(EnvType.CLIENT)
   private static final class Playback {
      final String a;
      final EmoteManager.ServerEmote b;
      final long c;

      Playback(String var1, EmoteManager.ServerEmote var2, long var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   @Environment(EnvType.CLIENT)
   public record PlayingInfo(String emoteId, long startedAtNanos) {
   }

   @Environment(EnvType.CLIENT)
   private record ServerEmote(BobjAction action, int durationTicks, boolean looping, List<BobjProp> props) {
   }
}
