package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.input.MouseUtil;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class InventoryBuilderHandler extends Handler implements IMinecraft {
   private static InventoryBuilderHandler.AuctionReturn a = InventoryBuilderHandler.AuctionReturn.a;
   private static long b;
   private static WeakReference<Object> c;
   private final Map<Integer, ItemStack> f = new HashMap<>();
   private String g;
   private static final int h = 120;
   private boolean i;
   private int j;
   private int k;
   private final ArrayDeque<int[]> l = new ArrayDeque<>();

   public static void a(InventoryBuilderHandler.AuctionReturn var0) {
      a = var0;
      b = System.currentTimeMillis();
      c = null;
      MouseUtil.j();
   }

   private static boolean l() {
      if (a == InventoryBuilderHandler.AuctionReturn.a) {
         return false;
      } else if (System.currentTimeMillis() - b > 30000L) {
         a = InventoryBuilderHandler.AuctionReturn.a;
         c = null;
         return false;
      } else {
         return true;
      }
   }

   public static void a(Object var0) {
      if (l()) {
         c = new WeakReference<>(var0);
         MouseUtil.k();
      }
   }

   public static boolean b(Object var0) {
      return l() && c != null && c.get() == var0;
   }

   public static InventoryBuilderHandler.AuctionReturn d() {
      InventoryBuilderHandler.AuctionReturn var0 = l() ? a : InventoryBuilderHandler.AuctionReturn.a;
      a = InventoryBuilderHandler.AuctionReturn.a;
      c = null;
      return var0;
   }

   public void a(String var1, Map<Integer, ItemStack> var2) {
      this.f.clear();
      this.f.putAll(var2);
      this.g = var1;
   }

   public void e() {
      this.f.clear();
      this.g = null;
   }

   public boolean f() {
      return !this.f.isEmpty() && d.player != null;
   }

   public Map<Integer, ItemStack> g() {
      return Collections.unmodifiableMap(this.f);
   }

   public String h() {
      return this.g;
   }

   public boolean i() {
      return this.i;
   }

   public void j() {
      if (this.f()) {
         this.i = true;
         this.k = 0;
         this.j = 0;
         this.l.clear();
      }
   }

   public void k() {
      this.i = false;
      this.l.clear();
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      var queue = this.l;
      if (!this.i) {
         return;
      }
      if (d.player == null || d.interactionManager == null || !(d.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen) || !this.f()) {
         this.k();
         return;
      }
      if (this.j > 0) {
         this.j--;
         return;
      }
      if (queue.isEmpty() && !this.m()) {
         this.k();
         return;
      }
      while (!queue.isEmpty()) {
         Object operation = queue.poll();
         var client = d;
         var interaction = client.interactionManager;
         int syncId = client.player.playerScreenHandler.syncId;
         int[] swap = (int[])operation;
         interaction.clickSlot(syncId, swap[0], swap[1], net.minecraft.screen.slot.SlotActionType.SWAP, client.player);
      }
      double random;
      try {
         random = Math.random();
      } catch (RuntimeException | Error failure) {
         this.j = 1;
         throw failure;
      }
      this.j = random < 0.25 ? 1 : 0;
   }

   private boolean m() {
      if (++this.k > 120) {
         return false;
      } else {
         PlayerInventory var1 = d.player.getInventory();
         int var2 = -1;
         int var3 = -1;
         int var4 = -1;
         int var5 = -1;

         for (Entry var7 : this.f.entrySet()) {
            int var8 = (Integer)var7.getKey();
            ItemStack var9 = (ItemStack)var7.getValue();
            if (!var9.isEmpty() && !this.a(var8, var1)) {
               int var10 = this.a(var9, var1);
               if (var10 >= 0) {
                  if (var10 <= 8 || var10 == 40 || var8 <= 8 || var8 == 40) {
                     var2 = var10;
                     var3 = var8;
                     break;
                  }

                  if (var4 < 0) {
                     var4 = var10;
                     var5 = var8;
                  }
               }
            }
         }

         if (var2 >= 0) {
            this.a(var2, var3, var1);
         } else if (var4 >= 0) {
            this.a(var4, var5, var1);
         }

         return !this.l.isEmpty();
      }
   }

   private boolean a(int var1, PlayerInventory var2) {
      ItemStack var3 = this.f.get(var1);
      return var3 != null && !var3.isEmpty() && a(var2.getStack(var1), var3);
   }

   private int a(ItemStack var1, PlayerInventory var2) {
      for (int var3 = 0; var3 < var2.size(); var3++) {
         ItemStack var4 = var2.getStack(var3);
         if (!var4.isEmpty() && a(var4, var1) && !this.a(var3, var2)) {
            return var3;
         }
      }

      return -1;
   }

   private static boolean a(ItemStack var0, ItemStack var1) {
      return !var0.isEmpty() && !var1.isEmpty() ? ItemGroupKey.a(var0).equals(ItemGroupKey.a(var1)) : false;
   }

   private void a(int var1, int var2, PlayerInventory var3) {
      Integer var4 = this.a(var1);
      Integer var5 = this.a(var2);
      if (var4 != null && var5 != null) {
         if (var2 <= 8 || var2 == 40) {
            this.l.add(new int[]{var4, var2});
         } else if (var1 > 8 && var1 != 40) {
            int var6 = this.b(var1, var3);
            if (var6 < 0) {
               return;
            }

            this.l.add(new int[]{var4, var6});
            this.l.add(new int[]{var5, var6});
         } else {
            this.l.add(new int[]{var5, var1});
         }
      }
   }

   private int b(int var1, PlayerInventory var2) {
      boolean var3 = var1 >= 36 && var1 <= 39;
      int var4 = -1;
      int var5 = -1;
      int var6 = -1;

      for (int var7 = 0; var7 <= 8; var7++) {
         ItemStack var8 = var2.getStack(var7);
         if (!var3 || var8.isEmpty()) {
            if (var8.isEmpty()) {
               return var7;
            }

            if (this.a(var7, var2)) {
               if (var6 < 0) {
                  var6 = var7;
               }
            } else if (this.b(var8, var2)) {
               if (var5 < 0) {
                  var5 = var7;
               }
            } else if (var4 < 0) {
               var4 = var7;
            }
         }
      }

      if (var4 >= 0) {
         return var4;
      } else if (var5 >= 0) {
         return var5;
      } else {
         return var3 ? -1 : var6;
      }
   }

   private boolean b(ItemStack var1, PlayerInventory var2) {
      for (Entry var4 : this.f.entrySet()) {
         if (!((ItemStack)var4.getValue()).isEmpty() && !this.a((Integer)var4.getKey(), var2) && a(var1, (ItemStack)var4.getValue())) {
            return true;
         }
      }

      return false;
   }

   private Integer a(int var1) {
      for (Slot var3 : d.player.playerScreenHandler.slots) {
         if (var3.inventory == d.player.getInventory() && var3.getIndex() == var1) {
            return var3.id;
         }
      }

      return null;
   }

   static {
      NativeMethodLookup.lookup(InventoryBuilderHandler.class, 25);
   }

   @Environment(EnvType.CLIENT)
   public static enum AuctionReturn {
      a,
      b,
      c;

      private static InventoryBuilderHandler.AuctionReturn[] a() {
         return new InventoryBuilderHandler.AuctionReturn[]{a, b, c};
      }
   }
}
