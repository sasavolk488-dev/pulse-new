package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({RenderLayer.class})
public interface RenderLayerAccessor {
   @Invoker("of")
   static RenderLayer pulse$invokeOf(String var0, RenderSetup var1) {
      throw new AssertionError();
   }
}
