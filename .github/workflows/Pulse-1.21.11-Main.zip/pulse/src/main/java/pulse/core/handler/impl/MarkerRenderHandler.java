package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.menu.markers.MarkerEntry;
import pulse.core.event.impl.PlayerDeathEvent;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.TextureRegistry;

@HandlerInfo
@Environment(EnvType.CLIENT)
public class MarkerRenderHandler extends Handler implements IMinecraft {
   private static final float a = 22.0F;
   private static final float b = 6.0F;
   private static final float c = 3.0F;
   private static final float f = 16.0F;
   private static final float g = 5.0F;
   private static final float h = 10.0F;
   private static final float i = 2.5F;
   private static final float j = -7.0F;
   private static final float k = 8.0F;
   private static final float l = 0.0F;
   private static final float m = 64.0F;
   private static final float n = 5.0F;

   private static float a(float var0) {
      return Math.round(var0 * 2.0F) / 2.0F;
   }

   @EventHandler
   @Compile
   public void a(PlayerDeathEvent var1) {
      if (pulse.ui.clickgui.menu.markers.MarkerSettings.g() && d.player != null && var1.a() == d.player) {
         pulse.ui.clickgui.menu.markers.MarkerManager.a(new MarkerEntry("Место смерти", (int)Math.floor(var1.b()), (int)Math.floor(var1.c()), (int)Math.floor(var1.d()), ClickGuiColors.W, MarkerEntry.IconType.e));
      }
   }

   @EventHandler(
      priority = -100
   )
   @Compile
   public void a(RenderHudPostEvent var1) {
      if (d.player == null || d.world == null || pulse.ui.clickgui.menu.markers.MarkerManager.d()) {
         return;
      }
      Render render = pulse.Pulse.l().p();
      MatrixStack matrices = var1.a();
      var markers = pulse.ui.clickgui.menu.markers.MarkerManager.a();
      var events = pulse.core.handler.HandlerRegistry.c;
      var position = d.player.getLerpedPos(1.0F);
      boolean active = events.k();
      int anarchy = events.h();
      String mode = events.i();
      boolean hasServer;
      try {
         hasServer = d.getCurrentServerEntry() != null;
      } catch (RuntimeException | Error failure) {
         markers.size();
         throw failure;
      }
      String server = hasServer ? d.getCurrentServerEntry().address.toLowerCase() : "";
      java.util.List<MarkerRenderHandler.VisibleMarker> visible = new java.util.ArrayList<>(markers.size());
      for (MarkerEntry marker : markers) {
         if (marker.j() && (!active || !this.a(marker, anarchy, mode, server))) {
            continue;
         }
         var target = new net.minecraft.util.math.Vec3d(marker.b() + 0.5, marker.c() + 1.5, marker.d() + 0.5);
         var projected = pulse.utils.render.ScreenUtils.a(target);
         if (projected != null && pulse.utils.render.ScreenUtils.b(projected)) {
            visible.add(new MarkerRenderHandler.VisibleMarker(marker, a((float)projected.x), a((float)projected.y), position.distanceTo(target)));
         }
      }
      if (visible.isEmpty()) {
         return;
      }
      visible.sort(java.util.Comparator.<MarkerRenderHandler.VisibleMarker>comparingDouble(MarkerRenderHandler::a).reversed());
      for (MarkerRenderHandler.VisibleMarker marker : visible) {
         this.a(matrices, render, marker.a, marker.b, marker.c, marker.d);
      }
   }

   private boolean a(MarkerEntry var1, int var2, String var3, String var4) {
      if (var4.contains("holyworld")) {
         if (var1.l() != var2) {
            return false;
         }

         if (var1.m() != null && var3 != null && !var1.m().equals(var3)) {
            return false;
         }
      } else if (!var4.contains("fillcube") && var1.l() != var2) {
         return false;
      }

      return true;
   }

   private void a(MatrixStack var1, Render var2, MarkerEntry var3, float var4, float var5, double var6) {
      String var8 = this.a(var6);
      FontRenderer var9 = Fonts.b[12];
      FontRenderer var10 = Fonts.b[10];
      String var11 = var3.a();
      if (var3.j() && var3.r()) {
         long var12 = var3.p();
         if (var12 > 0L) {
            int var14 = (int)(var12 / 1000L);
            int var15 = var14 / 60;
            var14 %= 60;
            if (var15 > 0) {
               var11 = var11 + " (" + var15 + " мин " + var14 + " сек)";
            } else {
               var11 = var11 + " (" + var14 + " сек)";
            }
         }
      }

      float var27 = var9.a(var11);
      float var13 = var10.a(var8);
      float var29 = Math.max(var27, var13);
      float var30 = Math.max(64.0F, 21.5F + var29 + 5.0F);
      float var16 = a(var4 - var30 / 2.0F);
      float var17 = a(var5 - 11.0F);
      this.a(var1, var2, var16, var17, var30);
      float var18 = a(var16 + 3.0F);
      float var19 = a(var17 + 3.0F);
      this.a(var1, var2, var18, var19, var3);
      float var20 = a(var18 + 16.0F + 2.5F);
      float var21 = var9.b(var11);
      float var22 = var10.b(var8);
      float var23 = var21 + -7.0F + var22 - 4.0F;
      float var24 = var17 + (22.0F - var23) / 2.0F + 1.0F;
      float var25 = a(var24);
      float var26 = a(var25 + var21 + -7.0F);
      var9.a(var11, var20, var25, ClickGuiColors.a, var1);
      var10.a(var8, var20, var26, ClickGuiColors.a, var1);
      this.a(var1, var2, var4, var17 + 22.0F);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5) {
      Color var6 = ClickGuiColors.a(ClickGuiColors.m, 200);
      Color var7 = ClickGuiColors.a(ClickGuiColors.n, 200);
      var2.a(var3 - 0.5F, var4 - 0.5F, var5 + 1.0F, 23.0F, 6.0F, var6, var6, var7, var7, var1);
      Color var8 = ClickGuiColors.a(ClickGuiColors.e, 230);
      Color var9 = ClickGuiColors.a(ClickGuiColors.f, 230);
      var2.a(var3, var4, var5, 22.0F, 6.0F, var8, var8, var9, var9, var1);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, MarkerEntry var5) {
      Color var6 = var5.e();
      Color var8 = ClickGuiColors.c(var6, 150);
      Color var9 = ClickGuiColors.b(var6, 50);
      Color var10 = ClickGuiColors.a(var9, 50);
      Color var11 = ClickGuiColors.a(var9, 10);
      var2.a(var3 - 0.5F, var4 - 0.5F, 17.0F, 17.0F, 5.0F, var10, var10, var11, var11, var1);
      var2.a(var3, var4, 16.0F, 16.0F, 5.0F, var6, var6, var8, var8, var1);
      FontRenderer var12 = Fonts.d[18];
      String var13 = var5.f().b();
      float var14 = var3 + 3.0F;
      float var15 = var4 + 3.0F;
      var12.a(var13, var14 + 0.5F, var15 + 0.5F, ClickGuiColors.aa, var1);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4) {
      TextureRegistry.TextureEntry var5 = TextureRegistry.b("arrow_v");
      if (var5 != null) {
         Identifier var6 = var5.a();
         float var7 = var5.b() / 2.0F;
         float var8 = var5.c() / 2.0F;
         float var10 = var4 + var7 / 2.0F;
         var1.push();
         var1.translate(var3, var10, 0.0F);
         var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90.0F));
         var1.translate(-var3, -var10, 0.0F);
         float var11 = var3 - var7 / 2.0F - 0.5F;
         float var12 = var10 - var8 / 2.0F;
         var2.a(var6, var11, var12, var7, var8, ClickGuiColors.aa, var1);
         var1.pop();
      }
   }

   private String a(double var1) {
      if (var1 < 1.0) {
         return "< 1 метра";
      } else if (var1 < 2.0) {
         return "1 метр";
      } else {
         return var1 < 5.0 ? String.format("%.0f метра", var1) : String.format("%.0f метров", var1);
      }
   }

   public static double a(MarkerRenderHandler.VisibleMarker var0) {
      return var0.d;
   }

   static {
      NativeMethodLookup.lookup(MarkerRenderHandler.class, 27);
   }

   @Environment(EnvType.CLIENT)
   static final class VisibleMarker {
      final MarkerEntry a;
      final float b;
      final float c;
      final double d;

      VisibleMarker(MarkerEntry var1, float var2, float var3, double var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }
}
