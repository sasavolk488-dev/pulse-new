package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Sprint",
   b = "Автоматически включает режим бега",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class SprintModule extends Module {
   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      if (d.player != null) {
         d.options.sprintKey.setPressed(d.player.age > 5);
      }
   }

   static {
      NativeMethodLookup.lookup(SprintModule.class, 75);
   }
}
