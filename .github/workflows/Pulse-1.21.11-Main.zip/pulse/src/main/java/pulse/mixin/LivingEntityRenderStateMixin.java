package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import pulse.core.api.ILivingStateEntity;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntityRenderState.class})
public abstract class LivingEntityRenderStateMixin implements ILivingStateEntity {
   @Unique
   private LivingEntity pulse$entity;

   @Override
   public LivingEntity pulse$getEntity() {
      return this.pulse$entity;
   }

   @Override
   public void pulse$setEntity(LivingEntity var1) {
      this.pulse$entity = var1;
   }
}
