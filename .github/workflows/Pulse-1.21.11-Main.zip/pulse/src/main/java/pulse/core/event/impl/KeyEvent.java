package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class KeyEvent extends Event {
   private final int a;
   private final int b;
   private final int c;
   private final int d;

   @Generated
   public int a() {
      return this.a;
   }

   @Generated
   public int b() {
      return this.b;
   }

   @Generated
   public int c() {
      return this.c;
   }

   @Generated
   public int d() {
      return this.d;
   }

   @Generated
   public KeyEvent(int var1, int var2, int var3, int var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }
}
