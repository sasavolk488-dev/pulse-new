package pulse.features.modules.hud;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.config.cloud.CloudConfigManager;
import pulse.features.modules.hud.snap.Anchor;
import pulse.features.modules.hud.snap.SnapResult;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public abstract class DraggableComponent {
   protected final MinecraftClient a = MinecraftClient.getInstance();
   protected float b;
   protected float c;
   protected float d;
   protected float e;
   protected boolean f = false;
   protected float g;
   protected float h;
   protected boolean i = true;
   protected boolean j = false;
   protected boolean k = false;
   protected int l = 0;
   private final Animation m = new Animation();
   private final Anchor n = new Anchor();
   private float o = -1.0F;
   private float p = -1.0F;
   private SnapResult q = null;
   private final ComponentSettingsPanel r = new ComponentSettingsPanel();
   private static final float s = 5.0F;

   public DraggableComponent(float var1, float var2) {
      this.b = var1;
      this.c = var2;
      this.m.d(0.0);
   }

   public abstract void a(MatrixStack var1, Render var2, float var3, float var4);

   protected abstract void a();

   public void b_() {
      this.a();
   }

   public boolean c() {
      return true;
   }

   public boolean a(double var1, double var3, int var5) {
      if (this.f) {
         return true;
      } else {
         if (this.r.c()) {
            if (this.r.a((int)var1, (int)var3)) {
               return true;
            }

            if (!this.r.c((int)var1, (int)var3)) {
               this.r.a();
               return true;
            }
         }

         if (var5 == 1 && this.a(var1, var3)) {
            return true;
         } else if (var5 == 0 && this.a(var1, var3)) {
            if (this.r.c()) {
               this.r.a();
            }

            this.f = true;
            this.g = (float)var1 - this.b;
            this.h = (float)var3 - this.c;
            return true;
         } else {
            return false;
         }
      }
   }

   public void b(double var1, double var3, int var5) {
      if (var5 == 0) {
         if (this.f) {
            CloudConfigManager.a().h();
         }

         this.f = false;
         this.q = null;
      }

      this.r.b((int)var1, (int)var3);
   }

   public void a(SnapResult var1, float var2, float var3) {
      if (this.f) {
         this.b = var1.a();
         this.c = var1.b();
         this.q = var1;
         this.n.a(this.b, this.c, this.d, this.e, var2, var3);
         this.o = var2;
         this.p = var3;
      }
   }

   public void a(double var1, double var3, float var5, float var6) {
      if (this.f) {
         float var7 = (float)var1 - this.g;
         float var8 = (float)var3 - this.h;
         this.b = Math.max(5.0F, Math.min(var7, var5 - this.d - 5.0F));
         this.c = Math.max(5.0F, Math.min(var8, var6 - this.e - 5.0F));
         this.n.a(this.b, this.c, this.d, this.e, var5, var6);
         this.o = var5;
         this.p = var6;
      }
   }

   public void a(float var1, float var2) {
      if (this.o > 0.0F && this.p > 0.0F) {
         float var3 = this.n.a(this.d, var1);
         float var4 = this.n.b(this.e, var2);
         this.b = Math.max(5.0F, Math.min(var3, var1 - this.d - 5.0F));
         this.c = Math.max(5.0F, Math.min(var4, var2 - this.e - 5.0F));
      }

      this.o = var1;
      this.p = var2;
   }

   public void b(float var1, float var2) {
      this.n.a(this.b, this.c, this.d, this.e, var1, var2);
      this.o = var1;
      this.p = var2;
   }

   public void a(double var1, double var3, boolean var5) {
      this.j = this.a(var1, var3);
      this.k = var5;
      boolean var6 = this.j && var5 || this.f;
      if (var6 && this.m.i() < 1.0) {
         this.m.a(1.0, 0.15000000093150914, Easings.h);
      } else if (!var6 && this.m.i() > 0.0) {
         this.m.a(0.0, 0.20000004508551622, Easings.h);
      }
   }

   public void d() {
      this.j = false;
      this.k = false;
      this.f = false;
      this.r.b();
      if (this.m.j() > 0.0 || this.m.i() > 0.0) {
         this.m.a(0.0, 0.15000000093150914, Easings.h);
      }
   }

   public void e() {
      this.m.a();
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4) {
      this.r.b(this.b, this.c, this.d, this.e);
      this.r.a(var1, var2, var3, var4);
   }

   public void a(double var1, double var3, double var5, double var7) {
      this.r.a((int)var1, (int)var3, var5, var7);
   }

   public boolean a(double var1, double var3, double var5) {
      return this.r.a((float)var5, (int)var1, (int)var3);
   }

   public ComponentSettingsPanel f() {
      return this.r;
   }

   public float g() {
      return this.r.i();
   }

   public float h() {
      return (float)this.m.j();
   }

   protected float i() {
      return 8.0F;
   }

   public void a(Render var1, MatrixStack var2) {
      float var3 = this.h();
      if (!(var3 < 0.01F)) {
         int var4 = (int)(25.0F * var3);
         Color var5 = new Color(255, 255, 255, var4);
         float var6 = this.i() * this.g();
         var1.a(this.b, this.c, this.d, this.e, var6, var5, var2);
      }
   }

   public boolean a(double var1, double var3) {
      return var1 >= this.b && var1 <= this.b + this.d && var3 >= this.c && var3 <= this.c + this.e;
   }

   public boolean j() {
      return this.f;
   }

   public boolean k() {
      return this.i;
   }

   public void a_(boolean var1) {
      this.i = var1;
   }

   public boolean l() {
      return this.j;
   }

   public float m() {
      return this.b;
   }

   public void a(float var1) {
      this.b = var1;
   }

   public float n() {
      return this.c;
   }

   public void b(float var1) {
      this.c = var1;
   }

   public float o() {
      return this.d;
   }

   public float p() {
      return this.e;
   }

   public int q() {
      return this.l;
   }

   public void a(int var1) {
      this.l = var1;
   }

   public SnapResult r() {
      return this.q;
   }

   public float s() {
      return this.g;
   }

   public float t() {
      return this.h;
   }

   public Anchor u() {
      return this.n;
   }
}
