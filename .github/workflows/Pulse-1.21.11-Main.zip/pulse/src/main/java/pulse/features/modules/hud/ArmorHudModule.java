package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Armor HUD",
   b = "Отображает броню рядом с хотбаром",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class ArmorHudModule extends Module {
   public final ModeSetting a = new ModeSetting("Прочность", new String[]{"Полоска", "Проценты"}, "Полоска");
   public static boolean b = false;
}
