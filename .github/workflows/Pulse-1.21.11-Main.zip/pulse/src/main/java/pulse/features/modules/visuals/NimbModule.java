package pulse.features.modules.visuals;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.ModelWithHead;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import org.joml.Quaternionf;
import pulse.core.event.impl.RenderHeadLayerEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Nimb",
   b = "Отображает нимб над головой игрока",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class NimbModule extends Module {
   private final NumberSetting a = new NumberSetting("Толщина кольца", 0.05F, 0.01F, 0.2F, 0.01F);
   private final NumberSetting b = new NumberSetting("Внутренний радиус", 0.5F, 0.3F, 1.5F, 0.05F);
   private final NumberSetting c = new NumberSetting("Высота", -0.1F, -1.0F, 0.5F, 0.05F);
   private final SeparatorSetting f = new SeparatorSetting("Цвет");
   private final BooleanSetting g = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting h = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.g.a());
   private static final int i = 72;
   private static final float[] j = new float[73];
   private static final float[] k = new float[73];

   @EventHandler
   public void a(RenderHeadLayerEvent var1) {
      if (var1.d() instanceof ModelWithHead) {
         if (var1.a() instanceof PlayerEntity) {
            PlayerEntity var2 = (PlayerEntity)var1.a();
            if (var2 instanceof ClientPlayerEntity) {
               if (!var2.isBaby()) {
                  LivingEntity var3 = var1.a();
                  MatrixStack var4 = var1.c();
                  OrderedRenderCommandQueue var5 = var1.e();
                  if (var5 != null) {
                     float var6 = this.a(var3);
                     var4.push();
                     ((ModelWithHead)var1.d()).getHead().applyTransform(var4);
                     var4.translate(0.0F, var6, 0.0F);
                     var4.multiply(new Quaternionf().rotationZ((float)Math.toRadians(180.0)));
                     Color var7 = this.n();
                     float var8 = var7.getRed() / 255.0F;
                     float var9 = var7.getGreen() / 255.0F;
                     float var10 = var7.getBlue() / 255.0F;
                     float var11 = this.b.b();
                     float var12 = this.a.b();
                     float var13 = var11 + var12;
                     float var14 = 0.030000001F;
                     float var15 = 0.4F;
                     float var16 = 0.43F;
                     float var17 = 0.7058824F;
                     float var18 = 0.47058824F;
                     var5.submitCustom(
                        var4,
                        BlockOverlayLayers.f,
                        (var5x, var6x) -> {
                           for (int var7x = 0; var7x < 72; var7x++) {
                              int var8x = var7x + 1;
                              float var9x = j[var7x];
                              float var10x = k[var7x];
                              float var11x = j[var8x];
                              float var12x = k[var8x];
                              float var13x = var9x * var11;
                              float var14x = var10x * var11;
                              float var15x = var11x * var11;
                              float var16x = var12x * var11;
                              float var17x = var9x * var13;
                              float var18x = var10x * var13;
                              float var19 = var11x * var13;
                              float var20 = var12x * var13;
                              a(var6x, var5x, var13x, 0.4F, var14x, var17x, 0.4F, var18x, var19, 0.4F, var20, var8, var9, var10, 0.7058824F);
                              a(var6x, var5x, var13x, 0.4F, var14x, var19, 0.4F, var20, var15x, 0.4F, var16x, var8, var9, var10, 0.7058824F);
                              a(var6x, var5x, var13x, 0.43F, var14x, var15x, 0.43F, var16x, var19, 0.43F, var20, var8, var9, var10, 0.47058824F);
                              a(var6x, var5x, var13x, 0.43F, var14x, var19, 0.43F, var20, var17x, 0.43F, var18x, var8, var9, var10, 0.47058824F);
                              a(
                                 var6x,
                                 var5x,
                                 var13x,
                                 0.4F,
                                 var14x,
                                 var15x,
                                 0.4F,
                                 var16x,
                                 var15x,
                                 0.43F,
                                 var16x,
                                 var8,
                                 var9,
                                 var10,
                                 0.7058824F,
                                 0.7058824F,
                                 0.47058824F
                              );
                              a(
                                 var6x,
                                 var5x,
                                 var13x,
                                 0.4F,
                                 var14x,
                                 var15x,
                                 0.43F,
                                 var16x,
                                 var13x,
                                 0.43F,
                                 var14x,
                                 var8,
                                 var9,
                                 var10,
                                 0.7058824F,
                                 0.47058824F,
                                 0.47058824F
                              );
                              a(
                                 var6x,
                                 var5x,
                                 var19,
                                 0.4F,
                                 var20,
                                 var17x,
                                 0.4F,
                                 var18x,
                                 var17x,
                                 0.43F,
                                 var18x,
                                 var8,
                                 var9,
                                 var10,
                                 0.7058824F,
                                 0.7058824F,
                                 0.47058824F
                              );
                              a(
                                 var6x,
                                 var5x,
                                 var19,
                                 0.4F,
                                 var20,
                                 var17x,
                                 0.43F,
                                 var18x,
                                 var19,
                                 0.43F,
                                 var20,
                                 var8,
                                 var9,
                                 var10,
                                 0.7058824F,
                                 0.47058824F,
                                 0.47058824F
                              );
                           }
                        }
                     );
                     var5.submitCustom(var4, BlockOverlayLayers.h, (var5x, var6x) -> {
                        a(var6x, var5x, var11, 0.4F, var8, var9, var10, 1.0F);
                        a(var6x, var5x, var13, 0.4F, var8, var9, var10, 1.0F);
                        a(var6x, var5x, var11, 0.43F, var8, var9, var10, 0.47058824F);
                        a(var6x, var5x, var13, 0.43F, var8, var9, var10, 0.47058824F);
                     });
                     var4.pop();
                  }
               }
            }
         }
      }
   }

   private static void a(VertexConsumer var0, Entry var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      for (int var8 = 0; var8 < 72; var8++) {
         int var9 = var8 + 1;
         float var10 = j[var8] * var2;
         float var11 = k[var8] * var2;
         float var12 = j[var9] * var2;
         float var13 = k[var9] * var2;
         float var14 = var12 - var10;
         float var15 = var13 - var11;
         float var16 = (float)Math.sqrt(var14 * var14 + var15 * var15);
         if (var16 < 1.0E-6F) {
            var16 = 1.0F;
         }

         float var17 = var14 / var16;
         float var18 = var15 / var16;
         var0.vertex(var1, var10, var3, var11).color(var4, var5, var6, var7).normal(var1, var17, 0.0F, var18).lineWidth(2.0F);
         var0.vertex(var1, var12, var3, var13).color(var4, var5, var6, var7).normal(var1, var17, 0.0F, var18).lineWidth(2.0F);
      }
   }

   private static void a(
      VertexConsumer var0,
      Entry var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14
   ) {
      var0.vertex(var1, var2, var3, var4).color(var11, var12, var13, var14).normal(var1, 0.0F, 1.0F, 0.0F);
      var0.vertex(var1, var5, var6, var7).color(var11, var12, var13, var14).normal(var1, 0.0F, 1.0F, 0.0F);
      var0.vertex(var1, var8, var9, var10).color(var11, var12, var13, var14).normal(var1, 0.0F, 1.0F, 0.0F);
   }

   private static void a(
      VertexConsumer var0,
      Entry var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16
   ) {
      var0.vertex(var1, var2, var3, var4).color(var11, var12, var13, var14).normal(var1, 0.0F, 1.0F, 0.0F);
      var0.vertex(var1, var5, var6, var7).color(var11, var12, var13, var15).normal(var1, 0.0F, 1.0F, 0.0F);
      var0.vertex(var1, var8, var9, var10).color(var11, var12, var13, var16).normal(var1, 0.0F, 1.0F, 0.0F);
   }

   private float a(LivingEntity var1) {
      float var2 = this.c.b();
      if (var1.getEquippedStack(EquipmentSlot.HEAD).isIn(ItemTags.HEAD_ARMOR)) {
         var2 -= 0.08F;
      }

      return var2;
   }

   private Color n() {
      return this.g.a() ? ModuleRegistry.aw.n() : this.h.a();
   }

   static {
      for (int var0 = 0; var0 <= 72; var0++) {
         double var1 = Math.toRadians(var0 * 5.0);
         j[var0] = (float)Math.sin(var1);
         k[var0] = (float)Math.cos(var1);
      }
   }
}
