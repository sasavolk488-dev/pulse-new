package pulse.core.event.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.sound.SoundInstance;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class PlaySoundEvent extends CancellableEvent {
   private final SoundInstance a;
   private float b;
   private float c;
   private final float d;
   private final float e;

   public PlaySoundEvent(SoundInstance var1) {
      this.a = var1;
      float var2 = 1.0F;
      float var3 = 1.0F;
      if (var1 != null && var1.getSound() != null) {
         try {
            var2 = var1.getVolume();
            var3 = var1.getPitch();
         } catch (NullPointerException var5) {
            var2 = 1.0F;
            var3 = 1.0F;
         }
      }

      this.b = var2;
      this.c = var3;
      this.d = var2;
      this.e = var3;
   }

   public SoundInstance d() {
      return this.a;
   }

   public float e() {
      return this.d;
   }

   public float f() {
      return this.e;
   }

   public float g() {
      return this.b;
   }

   public void a(float var1) {
      this.b = var1;
   }

   public float h() {
      return this.c;
   }

   public void b(float var1) {
      this.c = var1;
   }
}
