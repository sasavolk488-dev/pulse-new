package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import pulse.Pulse;
import pulse.ui.menu.MenuState;
import pulse.ui.menu.PulseMainMenuScreen;

@Environment(EnvType.CLIENT)
@Mixin({MinecraftClient.class})
public class MainMenuReplaceMixin {
   @ModifyVariable(
      method = {"setScreen"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private Screen pulse$replaceTitleScreen(Screen var1) {
      return (Screen)(var1 instanceof TitleScreen && MenuState.d() && Pulse.l() != null && Pulse.l().p() != null ? new PulseMainMenuScreen() : var1);
   }
}
