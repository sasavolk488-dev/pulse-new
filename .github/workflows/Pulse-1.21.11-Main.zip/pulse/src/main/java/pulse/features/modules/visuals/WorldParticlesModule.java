package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;
import pulse.core.event.impl.FrameEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.particle.ParticleShape;
import pulse.core.handler.impl.particle.ParticleTextures;
import pulse.core.handler.impl.particle.PhysicsMode;
import pulse.mixin.accessor.PersistentProjectileEntityInvoker;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.particle.AeParticleSystem;
import pulse.utils.render.particle.AeStar;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;

@ModuleInfo(
   a = "World Particles",
   b = "Частицы вокруг игрока: классические и звёзды",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class WorldParticlesModule extends Module {
   private static final float a = 0.005F;
   private static final String b = "Классические";
   private static final String c = "Звёзды";
   private static final String f = "Мир";
   private static final String g = "Снаряды";
   private final ModeSetting h = new ModeSetting("Стиль", new String[]{"Классические", "Звёзды"}, new int[]{0, 1});
   private final SeparatorSetting i = new SeparatorSetting("Классические").a(() -> this.h.c("Классические"));
   private final ModeSetting j = new ModeSetting("Тип частиц", ParticleShape.d, "Кольцо").a(() -> this.h.c("Классические"));
   private final NumberSetting k = new NumberSetting("Скорость вращения", 1.0F, 0.0F, 3.0F, 0.1F).a(() -> this.h.c("Классические") && this.n().b());
   private final ModeSetting l = new ModeSetting("Режим физики", new String[]{"Реалистичная", "Без коллизий", "Без физики", "Турбулентность"}, "Без физики")
      .a(() -> this.h.c("Классические"));
   private final NumberSetting m = new NumberSetting("Частота спавна", 5.0F, 1.0F, 10.0F, 1.0F).a(() -> this.h.c("Классические"));
   private final NumberSetting n = new NumberSetting("Количество за спавн", 5.0F, 1.0F, 15.0F, 1.0F).a(() -> this.h.c("Классические"));
   private final NumberSetting o = new NumberSetting("Радиус спавна", 30.0F, 5.0F, 50.0F, 1.0F).a(() -> this.h.c("Классические"));
   private final NumberSetting p = new NumberSetting("Высота спавна", 10.0F, 5.0F, 30.0F, 1.0F).a(() -> this.h.c("Классические"));
   private final NumberSetting q = new NumberSetting("Размер", 0.25F, 0.1F, 1.0F, 0.05F).a(() -> this.h.c("Классические"));
   private final NumberSetting r = new NumberSetting("Время жизни", 100.0F, 30.0F, 300.0F, 10.0F).a(() -> this.h.c("Классические"));
   private final NumberSetting s = new NumberSetting("Сила притяжения", 0.02F, 0.0F, 0.1F, 0.01F).a(() -> this.h.c("Классические"));
   private final BooleanSetting t = new BooleanSetting("Горизонтальное движение", true).a(() -> this.h.c("Классические"));
   private final NumberSetting u = new NumberSetting("Скорость движения", 0.05F, 0.0F, 0.2F, 0.01F).a(() -> this.h.c("Классические") && this.t.a());
   private final SeparatorSetting v = new SeparatorSetting("Звёзды").a(() -> this.h.c("Звёзды"));
   private final ModeSetting w = new ModeSetting("Источники", new String[]{"Мир", "Снаряды"}, new int[]{0, 1}).a(() -> this.h.c("Звёзды"));
   private final NumberSetting x = new NumberSetting("Плотность", 1.0F, 0.3F, 3.0F, 0.1F).a(() -> this.h.c("Звёзды"));
   private final SeparatorSetting y = new SeparatorSetting("Цвет");
   private final BooleanSetting z = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting A = new ColorSetting("Кастомный цвет", new Color(-21812, true)).a(() -> !this.z.a());
   private long B = 0L;

   private ParticleShape n() {
      return ParticleShape.a(this.j.e());
   }

   private int o() {
      if (this.z.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         return ColorUtils.a(var1.n().getRGB());
      } else {
         return ColorUtils.a(this.A.a().getRGB());
      }
   }

   private int b(int var1) {
      return Math.max(0, (int)(var1 * this.x.b()));
   }

   private static float a(float var0, float var1) {
      return var0 + ThreadLocalRandom.current().nextFloat() * (var1 - var0);
   }

   private static int a(int var0, int var1) {
      return ThreadLocalRandom.current().nextInt(var0, var1 + 1);
   }

   @EventHandler
   public void a(FrameEvent var1) {
      if (this.h.c("Классические") && d.player != null && d.world != null) {
         long var2 = System.currentTimeMillis();
         double var4 = 1000.0 / this.m.b();
         if (var2 - this.B >= var4) {
            this.p();
            this.B = var2;
         }
      }
   }

   private void p() {
      Vec3d var1 = d.player.getLerpedPos(1.0F);
      int var2 = this.n.c();
      PhysicsMode var3 = PhysicsMode.a(this.l.e());
      ParticleShape var4 = this.n();
      float var5 = var4.b() ? 0.8F : 1.0F;
      Identifier var6 = ParticleTextures.a(this.j.e());
      int var7 = this.o();

      for (int var8 = 0; var8 < var2; var8++) {
         double var9 = ThreadLocalRandom.current().nextDouble(-this.o.b(), this.o.b());
         double var11 = ThreadLocalRandom.current().nextDouble(-this.o.b(), this.o.b());
         double var13 = var3 == PhysicsMode.c ? ThreadLocalRandom.current().nextDouble(0.0, this.p.b()) : this.p.b();
         Vec3d var15 = new Vec3d(var1.x + var9, var1.y + var13, var1.z + var11);
         Vec3d var16;
         if (this.t.a() && this.u.b() > 0.0F) {
            var16 = new Vec3d(
               ThreadLocalRandom.current().nextDouble(-this.u.b(), this.u.b()), 0.0, ThreadLocalRandom.current().nextDouble(-this.u.b(), this.u.b())
            );
         } else {
            var16 = Vec3d.ZERO;
         }

         float var17 = (this.q.b() + (ThreadLocalRandom.current().nextFloat() * 0.1F - 0.05F)) * var5;
         HandlerRegistry.g.d().a(var15).b(var16).a(this.r.c()).a(var17).a(var6).a(var4).b(this.k.b()).b(var7).a((double)this.s.b()).a(var3).a();
      }
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      ModeSetting style = this.h;
      if (d.player != null && d.world != null && style.c("Звёзды")) {
         this.q();
      }
   }

   private void q() {
      float var1 = (float)d.player.getX();
      float var2 = (float)d.player.getY();
      float var3 = (float)d.player.getZ();
      int var4 = this.o();
      int var5 = this.b(4);
      if (var5 > 0 && this.w.c("Снаряды") && !AeParticleSystem.c()) {
         for (Entity var7 : d.world.getEntities()) {
            if (var7 instanceof ProjectileEntity var8
               && !(var8.getVelocity().lengthSquared() < 9.99999531894794E-5)
               && (!(var8 instanceof PersistentProjectileEntity var9) || !((PersistentProjectileEntityInvoker)var9).pulse$isInGround())) {
               for (int var20 = 0; var20 < var5; var20++) {
                  Vec3d var10 = var8.getLerpedPos((float)var20 / var5);
                  AeParticleSystem.a(
                     new AeStar(
                        var10.toVector3f(), new Vector3f(a(-0.06F, 0.06F), a(-0.06F, 0.06F), a(-0.06F, 0.06F)), var4, a(0.24F, 0.4F), false, a(50, 70), 0, 20
                     )
                  );
               }
            }
         }
      }

      if (this.w.c("Мир")) {
         for (int var14 = 0; var14 < this.b(8); var14++) {
            float var16 = a(0.0F, 1.0F) * (float) Math.PI * 2.0F;
            float var18 = (float)Math.sqrt(a(0.0F, 1.0F)) * 25.0F;
            float var21 = (float)Math.cos(var16) * var18;
            float var23 = (float)Math.sin(var16) * var18;
            float var11 = 10.0F + (a(0.0F, 1.0F) - 0.5F) * 20.0F;
            float var12 = 0.005F * var18;
            Vector3f var13 = new Vector3f(-var23 / var18 * var12, -0.04F, var21 / var18 * var12);
            AeParticleSystem.a(new AeStar(new Vector3f(var1 + var21, var2 + var11, var3 + var23), var13, var4, 0.26F, false));
         }

         if (this.x.b() > 0.0F && a(0.0F, 1.0F) < this.x.b() / 7.0F) {
            float var15 = a(0.0F, 1.0F) * (float) Math.PI * 2.0F;
            float var17 = (float)Math.sqrt(a(0.0F, 1.0F)) * 20.0F;
            float var19 = (float)Math.cos(var15) * var17;
            float var22 = (float)Math.sin(var15) * var17;
            float var24 = 10.0F + (a(0.0F, 1.0F) - 0.5F) * 20.0F;
            float var25 = 0.005F * var17 * 4.0F;
            Vector3f var26 = new Vector3f(-var22 / var17 * var25, -0.24F, var19 / var17 * var25);
            AeParticleSystem.a(new AeStar(new Vector3f(var1 + var19, var2 + var24, var3 + var22), var26, var4, 0.36F, true));
         }
      }
   }

   @Compile
   @Override
   public void f() {
      super.f();
      HandlerRegistry.g.f();
   }

   static {
      NativeMethodLookup.lookup(WorldParticlesModule.class, 90);
   }
}
