package pulse.mixin.accessor;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({RenderPipelines.class})
public interface RenderPipelinesInvoker {
   @Invoker("register")
   static RenderPipeline pulse$register(RenderPipeline var0) {
      throw new AssertionError();
   }
}
