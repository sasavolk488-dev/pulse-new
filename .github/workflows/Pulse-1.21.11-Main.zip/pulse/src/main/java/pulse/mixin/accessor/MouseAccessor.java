package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({Mouse.class})
public interface MouseAccessor {
   @Accessor("x")
   void pulse$setX(double var1);

   @Accessor("y")
   void pulse$setY(double var1);
}
