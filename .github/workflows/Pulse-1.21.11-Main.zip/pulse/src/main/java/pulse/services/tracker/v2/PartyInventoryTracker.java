package pulse.services.tracker.v2;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.nbt.NbtString;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public final class PartyInventoryTracker {
   private static final PartyInventoryTracker b = new PartyInventoryTracker();
   public static final long a = 20000L;
   private static final long c = 3000L;
   private static final long d = 4194304L;
   private final Map<Integer, PartyInventoryTracker.Snapshot> e = new ConcurrentHashMap<>();
   private final Map<Integer, Long> f = new ConcurrentHashMap<>();

   private PartyInventoryTracker() {
   }

   public static PartyInventoryTracker a() {
      return b;
   }

   public PartyInventoryTracker.Snapshot a(int var1) {
      return this.e.get(var1);
   }

   public void b(int var1) {
      PartyInventoryTracker.Snapshot var2 = this.e.get(var1);
      if (var2 == null || !var2.a()) {
         this.c(var1);
      }
   }

   private void c(int var1) {
      long var2 = System.currentTimeMillis();
      Long var4 = this.f.get(var1);
      if (var4 == null || var2 - var4 >= 3000L) {
         this.f.put(var1, var2);

         try {
            RealtimeSyncServiceV2.L().c(var1, true);
         } catch (Exception var6) {
         }
      }
   }

   public void a(int var1, String var2, boolean var3, boolean var4, long var5) {
      if (!var4) {
         if (!var3 && var2 != null && !var2.isEmpty()) {
            MinecraftClient var8 = MinecraftClient.getInstance();
            var8.execute(() -> {
               try {
                  if (var8.player == null) {
                     return;
                  }

                  byte[] var6 = Base64.getDecoder().decode(var2);
                  DynamicRegistryManager var7x = var8.player.getRegistryManager();
                  var var8x = a(var7x);
                  NbtCompound var9 = NbtIo.readCompressed(new ByteArrayInputStream(var6), NbtSizeTracker.of(4194304L));
                  HashMap var10 = new HashMap<>();

                  for (String var12 : var9.getKeys()) {
                     if (var12.startsWith("slot_")) {
                        int var13;
                        try {
                           var13 = Integer.parseInt(var12.substring(5));
                        } catch (NumberFormatException var16) {
                           continue;
                        }

                        if (var13 >= 0 && var13 <= 40) {
                           NbtElement var14 = var9.get(var12);
                           if (var14 != null) {
                              ItemStack var15 = a(var8x, var14);
                              if (!var15.isEmpty()) {
                                 var10.put(var13, var15);
                              }
                           }
                        }
                     }
                  }

                  this.e.put(var1, new PartyInventoryTracker.Snapshot(var10, false, var5));
               } catch (Exception var17) {
                  Pulse.m().warn("[Party] снапшот инвентаря от {} не декодировался: {}", var1, var17.toString());
               }
            });
         } else {
            this.e.put(var1, new PartyInventoryTracker.Snapshot(Map.of(), true, var5));
         }
      } else {
         PartyInventoryTracker.Snapshot var7 = this.e.get(var1);
         if (var7 != null && !var7.b && var7.c == var5) {
            var7.b();
         } else {
            this.c(var1);
         }
      }
   }

   public void b() {
      PartyInventoryReporter.d();
   }

   private static ItemStack a(RegistryOps<NbtElement> var0, NbtElement var1) {
      if (var1 instanceof NbtCompound && (((NbtCompound)var1).contains("Count") || ((NbtCompound)var1).contains("tag"))) {
         var1 = b((NbtCompound)var1);
      }

      ItemStack var2 = ItemStack.CODEC.parse(var0, var1).result().orElse(null);
      if (var2 != null && !var2.isEmpty()) {
         return var2;
      } else if (!(var1 instanceof NbtCompound)) {
         return ItemStack.EMPTY;
      } else {
         NbtCompound var3 = ((NbtCompound)var1).copy();
         var3.remove("components");
         ItemStack var4 = ItemStack.CODEC.parse(var0, var3).result().orElse(null);
         if (var4 != null && !var4.isEmpty()) {
            if (((NbtCompound)var1).get("components") instanceof NbtCompound var6) {
               NbtCompound var7 = new NbtCompound();

               for (String var9 : var6.getKeys()) {
                  NbtCompound var10 = var3.copy();
                  NbtCompound var11 = new NbtCompound();
                  var11.put(var9, var6.get(var9));
                  var10.put("components", var11);
                  if (ItemStack.CODEC.parse(var0, var10).result().isPresent()) {
                     var7.put(var9, var6.get(var9));
                  }
               }

               if (!var7.isEmpty()) {
                  var3.put("components", var7);
                  ItemStack var12 = ItemStack.CODEC.parse(var0, var3).result().orElse(null);
                  if (var12 != null && !var12.isEmpty()) {
                     return var12;
                  }
               }
            }

            return var4;
         } else {
            return ItemStack.EMPTY;
         }
      }
   }

   private static NbtCompound b(NbtCompound var0) {
      NbtCompound var1 = new NbtCompound();
      var1.putString("id", var0.getString("id", ""));
      var1.putInt("count", Math.max(1, var0.getInt("Count", var0.getInt("count", 1))));
      NbtCompound var2 = new NbtCompound();
      NbtCompound var3 = var0.getCompoundOrEmpty("tag");
      if (!var3.isEmpty()) {
         NbtCompound var4 = var3.getCompoundOrEmpty("display");
         if (var4.contains("color")) {
            var2.putInt("minecraft:dyed_color", var4.getInt("color", 0));
         }

         if (var4.contains("Name")) {
            String var5 = a(var4.getString("Name", ""));
            if (!var5.isEmpty()) {
               var2.putString("minecraft:custom_name", var5);
            }
         }

         NbtList var13 = var4.getListOrEmpty("Lore");
         if (!var13.isEmpty()) {
            NbtList var6 = new NbtList();

            for (NbtElement var8 : var13) {
               String var9 = a(var8.asString().orElse(""));
               var6.add(NbtString.of(var9));
            }

            var2.put("minecraft:lore", var6);
         }

         if (var3.contains("Damage")) {
            var2.putInt("minecraft:damage", var3.getInt("Damage", 0));
         }

         if (var3.contains("Unbreakable")) {
            var2.put("minecraft:unbreakable", new NbtCompound());
         }

         if (var3.contains("RepairCost")) {
            var2.putInt("minecraft:repair_cost", var3.getInt("RepairCost", 0));
         }

         NbtList var14 = var3.getListOrEmpty("Enchantments");
         if (!var14.isEmpty()) {
            NbtCompound var15 = new NbtCompound();

            for (NbtElement var18 : var14) {
               if (var18 instanceof NbtCompound var10) {
                  String var11 = var10.getString("id", "");
                  int var12 = var10.getInt("lvl", 1);
                  if (!var11.isEmpty() && var12 > 0) {
                     var15.putInt(var11, var12);
                  }
               }
            }

            if (!var15.isEmpty()) {
               var2.put("minecraft:enchantments", var15);
            }
         }

         if (var3.contains("Potion")) {
            NbtCompound var16 = new NbtCompound();
            var16.putString("potion", var3.getString("Potion", ""));
            if (var3.contains("CustomPotionColor")) {
               var16.putInt("custom_color", var3.getInt("CustomPotionColor", 0));
            }

            var2.put("minecraft:potion_contents", var16);
         }
      }

      if (!var2.isEmpty()) {
         var1.put("components", var2);
      }

      return var1;
   }

   private static String a(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         try {
            return a(JsonParser.parseString(var0));
         } catch (Exception var2) {
            return var0;
         }
      } else {
         return "";
      }
   }

   private static String a(JsonElement var0) {
      if (var0.isJsonPrimitive()) {
         return var0.getAsString();
      } else if (var0.isJsonObject()) {
         JsonObject var5 = var0.getAsJsonObject();
         StringBuilder var6 = new StringBuilder();
         if (var5.has("text")) {
            var6.append(var5.get("text").getAsString());
         }

         if (var5.has("extra") && var5.get("extra").isJsonArray()) {
            for (JsonElement var4 : var5.getAsJsonArray("extra")) {
               var6.append(a(var4));
            }
         }

         return var6.toString();
      } else if (!var0.isJsonArray()) {
         return "";
      } else {
         StringBuilder var1 = new StringBuilder();

         for (JsonElement var3 : var0.getAsJsonArray()) {
            var1.append(a(var3));
         }

         return var1.toString();
      }
   }

   static NbtCompound c() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (var0.player == null) {
         return null;
      } else {
         PlayerInventory var1 = var0.player.getInventory();
         DynamicRegistryManager var2 = var0.player.getRegistryManager();
         var var3 = a(var2);
         NbtCompound var4 = new NbtCompound();

         for (int var5 = 0; var5 < var1.size(); var5++) {
            ItemStack var6 = var1.getStack(var5);
            if (!var6.isEmpty()) {
               try {
                  var4.put("slot_" + var5, ItemStack.CODEC.encodeStart(var3, var6).getOrThrow());
               } catch (Exception var8) {
               }
            }
         }

         return var4;
      }
   }

   static String a(NbtCompound var0) {
      try {
         ByteArrayOutputStream var1 = new ByteArrayOutputStream();
         NbtIo.writeCompressed(var0, var1);
         return Base64.getEncoder().encodeToString(var1.toByteArray());
      } catch (Exception var2) {
         Pulse.m().warn("[Party] не удалось упаковать снапшот инвентаря: {}", var2.toString());
         return null;
      }
   }

   private static RegistryOps<NbtElement> a(WrapperLookup var0) {
      return RegistryOps.of(NbtOps.INSTANCE, var0);
   }

   public void a(Set<Integer> var1) {
      this.e.keySet().retainAll(var1);
      this.f.keySet().retainAll(var1);
   }

   public void d() {
      this.e.clear();
      this.f.clear();
   }

   @Environment(EnvType.CLIENT)
   public static final class Snapshot {
      public final Map<Integer, ItemStack> a;
      public final boolean b;
      public final long c;
      public volatile long d;

      Snapshot(Map<Integer, ItemStack> var1, boolean var2, long var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = System.currentTimeMillis();
      }

      public boolean a() {
         return System.currentTimeMillis() - this.d < 20000L;
      }

      void b() {
         this.d = System.currentTimeMillis();
      }
   }
}
