package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.phrase.PhraseManager;
import pulse.utils.render.world.BillboardLayers;
import pulse.services.tracker.v2.ModUserTrackerV2;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderer.class})
public abstract class EntityRendererMixin {
   @Unique
   private static final int PULSE$ICON_SIZE = 8;
   @Unique
   private static final float PULSE$ICON_GAP = 0.5F;
   @Unique
   private static final String PULSE$LABEL_PADDING = "   ";
   @Unique
   private static final float PULSE$SECOND_LABEL_OFFSET = 0.25875F;
   @Unique
   private static final float PULSE$BUBBLE_GAP = 9.0F;
   @Unique
   private static final float PULSE$BUBBLE_SCALE = 0.72F;
   @Unique
   private static final float PULSE$MIN_VISIBLE_ALPHA = 0.06F;
   @Unique
   private static final float PULSE$BUBBLE_ICON_SIZE = 12.0F;
   @Unique
   private static final float PULSE$BUBBLE_ICON_GAP = 5.0F;

   @Inject(
      method = {"renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At("HEAD")}
   )
   private void pulse$renderModUserIcon(
      PlayerEntityRenderState var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5
   ) {
      if (ModUserTrackerV2.d().c()) {
         if (var1.displayName != null && var1.nameLabelPos != null) {
            String var6 = this.pulse$extractPlayerName(var1.displayName.getString());
            if (var6 != null) {
               if (ModUserTrackerV2.d().a(var6)) {
                  Text var7 = var1.displayName;
                  var1.displayName = Text.literal("   ").append(var7);
                  int var8 = MinecraftClient.getInstance().textRenderer.getWidth(var1.displayName);
                  float var9 = -var8 / 2.0F + 0.5F;
                  float var10 = (var1.extraEars ? -10.0F : 0.0F) + 0.5F;
                  var2.push();
                  if (var1.playerName != null) {
                     var2.translate(0.0F, 0.25875F, 0.0F);
                  }

                  var2.translate(var1.nameLabelPos.x, var1.nameLabelPos.y + 0.5, var1.nameLabelPos.z);
                  var2.multiply(var4.orientation);
                  var2.scale(0.025F, -0.025F, 0.025F);
                  Identifier var11 = TextureRegistry.a(ModUserTrackerV2.d().c(var6) == 1 ? "logo_free" : "logo");
                  var3.submitCustom(
                     var2,
                     BillboardLayers.a(var11, false, !var1.sneaking),
                     (var3x, var4x) -> this.pulse$emitIconQuad(var3x.getPositionMatrix(), var4x, var9, var10)
                  );
                  var2.pop();
               }
            }
         }
      }
   }

   @Inject(
      method = {"renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At("HEAD")}
   )
   private void pulse$renderPhraseBubble(
      PlayerEntityRenderState var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5
   ) {
      if (var1.displayName != null && var1.nameLabelPos != null) {
         String var6 = this.pulse$extractPlayerName(var1.displayName.getString());
         if (var6 != null) {
            PhraseManager.Bubble var7 = PhraseManager.a().a(var6);
            if (var7 != null) {
               float var8 = var7.c();
               if (!(var8 <= 0.06F)) {
                  TextRenderer var9 = MinecraftClient.getInstance().textRenderer;
                  MutableText var10 = Text.literal(var7.text());
                  float var11 = var9.getWidth(var10);
                  float var12 = 9.0F;
                  float var13 = Math.max(var12, 12.0F);
                  float var14 = 17.0F + var11;
                  var2.push();
                  var2.translate(var1.nameLabelPos.x, var1.nameLabelPos.y + 0.5, var1.nameLabelPos.z);
                  var2.multiply(var4.orientation);
                  var2.scale(0.025F, -0.025F, 0.025F);
                  var2.scale(0.72F, 0.72F, 1.0F);
                  float var15 = -12.499999F;
                  float var16 = var15 - var13;
                  float var17 = -var14 / 2.0F;
                  float var18 = var16 + (var13 - 12.0F) / 2.0F;
                  int var19 = (int)(255.0F * var8) << 24 | 16777215;
                  var3.submitText(
                     var2, var17 + 12.0F + 5.0F, var16 + (var13 - var12) / 2.0F, var10.asOrderedText(), true, TextLayerType.NORMAL, var1.light, var19, 0, 0
                  );
                  Identifier var20 = TextureRegistry.a("speaker");
                  var3.submitCustom(
                     var2,
                     BillboardLayers.a(var20, false, !var1.sneaking),
                     (var4x, var5x) -> this.pulse$emitBubbleIconQuad(var4x.getPositionMatrix(), var5x, var17, var18, var8)
                  );
                  var2.pop();
               }
            }
         }
      }
   }

   @Unique
   private void pulse$emitBubbleIconQuad(Matrix4f var1, VertexConsumer var2, float var3, float var4, float var5) {
      int var6 = (int)(255.0F * var5);
      float var7 = var3 + 12.0F;
      float var8 = var4 + 12.0F;
      var2.vertex(var1, var3, var4, 0.0F).texture(0.0F, 0.0F).color(255, 255, 255, var6);
      var2.vertex(var1, var3, var8, 0.0F).texture(0.0F, 1.0F).color(255, 255, 255, var6);
      var2.vertex(var1, var7, var8, 0.0F).texture(1.0F, 1.0F).color(255, 255, 255, var6);
      var2.vertex(var1, var7, var4, 0.0F).texture(1.0F, 0.0F).color(255, 255, 255, var6);
   }

   @Unique
   private String pulse$extractPlayerName(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         MinecraftClient var2 = MinecraftClient.getInstance();
         if (var2.player != null && var2.player.networkHandler != null) {
            for (PlayerListEntry var4 : var2.player.networkHandler.getListedPlayerListEntries()) {
               if (var4.getProfile() != null && var4.getProfile().name() != null) {
                  String var5 = var4.getProfile().name();
                  if (var1.contains(var5)) {
                     return var5;
                  }
               }
            }

            return null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   @Unique
   private void pulse$emitIconQuad(Matrix4f var1, VertexConsumer var2, float var3, float var4) {
      float var5 = var3 + 8.0F;
      float var6 = var4 + 8.0F;
      var2.vertex(var1, var3, var4, 0.0F).texture(0.0F, 0.0F).color(255, 255, 255, 255);
      var2.vertex(var1, var3, var6, 0.0F).texture(0.0F, 1.0F).color(255, 255, 255, 255);
      var2.vertex(var1, var5, var6, 0.0F).texture(1.0F, 1.0F).color(255, 255, 255, 255);
      var2.vertex(var1, var5, var4, 0.0F).texture(1.0F, 0.0F).color(255, 255, 255, 255);
   }
}
