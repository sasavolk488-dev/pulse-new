package pulse.core.handler.impl.music;

import java.util.Arrays;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class MusicState {
   private String a = "No media";
   private String b = "";
   private byte[] c = null;
   private boolean d = false;
   private boolean e = false;
   private float f = 0.0F;
   private float g = 0.0F;
   private long h = 0L;
   private float i = -1.0F;
   private boolean j = false;
   private boolean k = false;
   private boolean l = false;
   private float m = 0.0F;
   private boolean n = false;
   private float o = 0.0F;
   private boolean p = false;
   private boolean q = false;
   private boolean r = false;
   private boolean s = false;
   private String t = "";
   private final float[] u = new float[6];

   public float a() {
      if (this.l) {
         return this.m;
      } else if (this.n) {
         if (this.c() && this.h > 0L) {
            long var4 = System.currentTimeMillis() - this.h;
            float var5 = this.o + (float)var4;
            return this.f > 0.0F ? Math.min(var5, this.f) : var5;
         } else {
            return this.o;
         }
      } else if (this.c() && this.h > 0L) {
         long var1 = System.currentTimeMillis() - this.h;
         float var3 = this.g + (float)var1;
         return this.f > 0.0F ? Math.min(var3, this.f) : var3;
      } else {
         return this.g;
      }
   }

   public float b() {
      return this.f <= 0.0F ? 0.0F : Math.max(0.0F, Math.min(1.0F, this.a() / this.f));
   }

   public boolean c() {
      return this.k ? this.j : this.e;
   }

   public void a(boolean var1) {
      float var2 = this.a();
      this.j = var1;
      this.k = true;
      this.g = var2;
      this.h = System.currentTimeMillis();
   }

   public void d() {
      this.k = false;
   }

   public void a(float var1) {
      this.l = true;
      this.m = var1;
      this.n = false;
   }

   public void b(float var1) {
      this.m = var1;
   }

   public void e() {
      this.l = false;
      this.n = true;
      this.o = this.m;
      this.h = System.currentTimeMillis();
   }

   public void a(String var1, String var2, boolean var3, float var4, float var5, byte[] var6) {
      boolean var7 = !this.a.equals(var1);
      this.a = var1;
      this.b = var2;
      if (var6 != null && var6.length > 0 && !Arrays.equals(this.c, var6)) {
         this.c = var6;
         this.d = true;
      }

      this.e = var3;
      this.f = var5;
      if (var7) {
         this.g = var4;
         this.h = System.currentTimeMillis();
         this.i = var4;
         this.d();
         this.l = false;
         this.n = false;
      } else {
         if (this.k && this.j == var3) {
            this.d();
         }

         if (this.n) {
            float var10 = Math.abs(var4 - this.o);
            if (var10 < 2000.0F) {
               this.n = false;
               this.g = var4;
               this.h = System.currentTimeMillis();
               this.i = var4;
            }
         } else {
            if (!this.l) {
               if (Math.abs(var4 - this.i) < 100.0F) {
                  return;
               }

               this.i = var4;
               float var8 = this.a();
               float var9 = Math.abs(var8 - var4);
               if (var9 > 1000.0F) {
                  this.g = var4;
                  this.h = System.currentTimeMillis();
               }
            }
         }
      }
   }

   public void f() {
      this.d = false;
   }

   public float g() {
      return this.a() / 1000.0F;
   }

   public float h() {
      return this.f / 1000.0F;
   }

   public void i() {
      this.p = true;
   }

   public void j() {
      this.p = false;
   }

   public boolean k() {
      if (this.q) {
         this.q = false;
         return true;
      } else {
         return false;
      }
   }

   public boolean l() {
      if (this.r) {
         this.r = false;
         return true;
      } else {
         return false;
      }
   }

   public void m() {
      boolean var1 = this.c();
      String var2 = this.a;
      if (!var2.equals(this.t) && !var2.equals("No media")) {
         this.q = true;
         this.p = false;
      }

      if (var1 && !this.s) {
         this.q = true;
         this.p = false;
      }

      if (!var1 && this.s && !this.p) {
         this.r = true;
      }

      this.s = var1;
      this.t = var2;
   }

   @Generated
   public String n() {
      return this.a;
   }

   @Generated
   public String o() {
      return this.b;
   }

   @Generated
   public byte[] p() {
      return this.c;
   }

   @Generated
   public boolean q() {
      return this.d;
   }

   @Generated
   public boolean r() {
      return this.e;
   }

   @Generated
   public float s() {
      return this.f;
   }

   @Generated
   public float t() {
      return this.g;
   }

   @Generated
   public long u() {
      return this.h;
   }

   @Generated
   public float v() {
      return this.i;
   }

   @Generated
   public boolean w() {
      return this.j;
   }

   @Generated
   public boolean x() {
      return this.k;
   }

   @Generated
   public boolean y() {
      return this.l;
   }

   @Generated
   public float z() {
      return this.m;
   }

   @Generated
   public boolean A() {
      return this.n;
   }

   @Generated
   public float B() {
      return this.o;
   }

   @Generated
   public boolean C() {
      return this.p;
   }

   @Generated
   public boolean D() {
      return this.q;
   }

   @Generated
   public boolean E() {
      return this.r;
   }

   @Generated
   public boolean F() {
      return this.s;
   }

   @Generated
   public String G() {
      return this.t;
   }

   @Generated
   public float[] H() {
      return this.u;
   }

   @Generated
   public void a(String var1) {
      this.a = var1;
   }

   @Generated
   public void b(String var1) {
      this.b = var1;
   }

   @Generated
   public void a(byte[] var1) {
      this.c = var1;
   }

   @Generated
   public void b(boolean var1) {
      this.d = var1;
   }

   @Generated
   public void c(boolean var1) {
      this.e = var1;
   }

   @Generated
   public void c(float var1) {
      this.f = var1;
   }

   @Generated
   public void d(float var1) {
      this.g = var1;
   }

   @Generated
   public void a(long var1) {
      this.h = var1;
   }

   @Generated
   public void e(float var1) {
      this.i = var1;
   }

   @Generated
   public void d(boolean var1) {
      this.k = var1;
   }

   @Generated
   public void e(boolean var1) {
      this.l = var1;
   }

   @Generated
   public void f(float var1) {
      this.m = var1;
   }

   @Generated
   public void f(boolean var1) {
      this.n = var1;
   }

   @Generated
   public void g(float var1) {
      this.o = var1;
   }

   @Generated
   public void g(boolean var1) {
      this.p = var1;
   }

   @Generated
   public void h(boolean var1) {
      this.q = var1;
   }

   @Generated
   public void i(boolean var1) {
      this.r = var1;
   }

   @Generated
   public void j(boolean var1) {
      this.s = var1;
   }

   @Generated
   public void c(String var1) {
      this.t = var1;
   }
}
