package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import pulse.core.event.impl.BlockOutlineEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Block Overlay",
   b = "Красиво выделяет блок на который наведен игрок",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class BlockOverlayModule extends Module {
   private final SeparatorSetting a = new SeparatorSetting("Обводка");
   private final BooleanSetting b = new BooleanSetting("Обводка", true);
   private final NumberSetting c = new NumberSetting("Толщина линий", 2.0F, 1.0F, 5.0F, 0.5F).a(() -> this.b.a());
   private final SeparatorSetting f = new SeparatorSetting("Заливка");
   private final BooleanSetting g = new BooleanSetting("Заливка", true);
   private final ModeSetting h = new ModeSetting("Тип заливки", new String[]{"Обычная", "Шейдер"}, "Обычная").a(() -> this.g.a());
   private final NumberSetting i = new NumberSetting("Прозрачность заливки", 0.3F, 0.1F, 1.0F, 0.05F).a(() -> this.g.a() && this.h.b("Обычная"));
   private final ModeSetting j = new ModeSetting("Шейдер", new String[]{"Небула", "Звёзды", "Паутина", "Плазма"}, "Небула")
      .a(() -> this.g.a() && this.h.b("Шейдер"));
   private final NumberSetting k = new NumberSetting("Скорость анимации", 1.0F, 0.1F, 3.0F, 0.1F).a(() -> this.g.a() && this.h.b("Шейдер"));
   private final NumberSetting l = new NumberSetting("Прозрачность", 1.0F, 0.1F, 1.0F, 0.05F).a(() -> this.g.a() && this.h.b("Шейдер"));
   private final SeparatorSetting m = new SeparatorSetting("Анимация");
   private final ModeSetting n = new ModeSetting("Режим анимации", new String[]{"Нет", "Пульсация", "Волна"}, "Нет");
   private final SeparatorSetting o = new SeparatorSetting("Цвет");
   private final BooleanSetting p = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting q = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.p.a());
   private static final double r = 0.0020000000165076876;
   private RenderLayer s;
   private boolean t;
   private boolean u;

   @EventHandler
   @Compile
   public void a(BlockOutlineEvent var1) {
      var1.b();
      BlockPos var2 = var1.j();
      BlockState var3 = var1.k();
      if (var3 != null && !var3.isAir()) {
         this.a(var1.d(), var2, var3, var1.g(), var1.h(), var1.i());
      }
   }

   private void a(MatrixStack var1, BlockPos var2, BlockState var3, double var4, double var6, double var8) {
      if (d.world != null) {
         Box var10 = var3.getOutlineShape(d.world, var2).getBoundingBox().offset(var2.getX() - var4, var2.getY() - var6, var2.getZ() - var8);
         var1.push();
         this.s = null;
         this.t = false;
         this.u = false;
         Color var11 = this.n();
         String var12 = this.n.e();
         switch (var12) {
            case "Пульсация":
               this.a(var1, var10, var11);
               break;
            case "Волна":
               this.b(var1, var10, var11);
               break;
            default:
               if (this.g.a()) {
                  this.b(var1, var10, var11, this.i.b());
               }

               if (this.b.a()) {
                  this.a(var1, var10, var11, 1.0F);
               }
         }

         Immediate var14 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         if (this.t) {
            var14.draw(BlockOverlayLayers.d);
         }

         if (this.u) {
            var14.draw(BlockOverlayLayers.b);
         }

         if (this.s != null) {
            var14.draw(this.s);
         }

         var1.pop();
      }
   }

   private void a(MatrixStack var1, Box var2, Color var3) {
      double var4 = System.currentTimeMillis() / 1000.0;
      float var6 = (float)(Math.sin(var4 * 3.1415928922493954 * 2.0) * 0.5 + 0.5);
      Box var7 = this.a(var2, var2.getCenter(), 1.0F + var6 * 0.1F);
      if (this.g.a()) {
         float var8 = this.i.b() * (0.5F + var6 * 0.5F);
         this.b(var1, var7, var3, var8);
      }

      if (this.b.a()) {
         this.a(var1, var7, var3, 1.0F);
      }
   }

   private void b(MatrixStack var1, Box var2, Color var3) {
      double var4 = System.currentTimeMillis() / 500.0;
      float var6 = (float)(var4 % 2.0);
      if (var6 < 1.0F && this.b.a()) {
         Box var7 = this.a(var2, var2.getCenter(), 1.0F + var6 * 0.15F);
         float var8 = 1.0F - var6;
         this.a(var1, var7, var3, var8);
      }

      if (this.g.a()) {
         this.b(var1, var2, var3, this.i.b());
      }

      if (this.b.a()) {
         this.a(var1, var2, var3, 1.0F);
      }
   }

   private void a(MatrixStack var1, Box var2, Color var3, float var4) {
      this.t = true;
      Immediate var5 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
      VertexConsumer var6 = var5.getBuffer(BlockOverlayLayers.d);
      float var7 = var3.getRed() / 255.0F;
      float var8 = var3.getGreen() / 255.0F;
      float var9 = var3.getBlue() / 255.0F;
      float var10 = (float)var2.minX;
      float var11 = (float)var2.minY;
      float var12 = (float)var2.minZ;
      float var13 = (float)var2.maxX;
      float var14 = (float)var2.maxY;
      float var15 = (float)var2.maxZ;
      a(var1, var6, var10, var11, var12, var13, var11, var12, var7, var8, var9, var4);
      a(var1, var6, var13, var11, var12, var13, var11, var15, var7, var8, var9, var4);
      a(var1, var6, var13, var11, var15, var10, var11, var15, var7, var8, var9, var4);
      a(var1, var6, var10, var11, var15, var10, var11, var12, var7, var8, var9, var4);
      a(var1, var6, var10, var14, var12, var13, var14, var12, var7, var8, var9, var4);
      a(var1, var6, var13, var14, var12, var13, var14, var15, var7, var8, var9, var4);
      a(var1, var6, var13, var14, var15, var10, var14, var15, var7, var8, var9, var4);
      a(var1, var6, var10, var14, var15, var10, var14, var12, var7, var8, var9, var4);
      a(var1, var6, var10, var11, var12, var10, var14, var12, var7, var8, var9, var4);
      a(var1, var6, var13, var11, var12, var13, var14, var12, var7, var8, var9, var4);
      a(var1, var6, var13, var11, var15, var13, var14, var15, var7, var8, var9, var4);
      a(var1, var6, var10, var11, var15, var10, var14, var15, var7, var8, var9, var4);
   }

   private static void a(
      MatrixStack var0,
      VertexConsumer var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11
   ) {
      float var12 = var5 - var2;
      float var13 = var6 - var3;
      float var14 = var7 - var4;
      float var15 = (float)Math.sqrt(var12 * var12 + var13 * var13 + var14 * var14);
      if (!(var15 < 1.0E-6F)) {
         var12 /= var15;
         var13 /= var15;
         var14 /= var15;
         Entry var16 = var0.peek();
         var1.vertex(var16, var2, var3, var4).color(var8, var9, var10, var11).normal(var16, var12, var13, var14).lineWidth(1.0F);
         var1.vertex(var16, var5, var6, var7).color(var8, var9, var10, var11).normal(var16, var12, var13, var14).lineWidth(1.0F);
      }
   }

   private void b(MatrixStack var1, Box var2, Color var3, float var4) {
      if (this.h.b("Шейдер")) {
         RenderLayer var5 = this.a(this.j.e());
         if (var5 != null) {
            this.a(var5, var1, var2, var3);
            return;
         }
      }

      Box var18 = this.a(var2, 0.0020000000165076876);
      this.u = true;
      Immediate var6 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
      VertexConsumer var7 = var6.getBuffer(BlockOverlayLayers.b);
      Matrix4f var8 = var1.peek().getPositionMatrix();
      float var9 = var3.getRed() / 255.0F;
      float var10 = var3.getGreen() / 255.0F;
      float var11 = var3.getBlue() / 255.0F;
      float var12 = (float)var18.minX;
      float var13 = (float)var18.minY;
      float var14 = (float)var18.minZ;
      float var15 = (float)var18.maxX;
      float var16 = (float)var18.maxY;
      float var17 = (float)var18.maxZ;
      a(var7, var8, var12, var13, var14, var15, var13, var14, var15, var13, var17, var12, var13, var17, var9, var10, var11, var4);
      a(var7, var8, var12, var16, var14, var12, var16, var17, var15, var16, var17, var15, var16, var14, var9, var10, var11, var4);
      a(var7, var8, var12, var13, var14, var12, var16, var14, var15, var16, var14, var15, var13, var14, var9, var10, var11, var4);
      a(var7, var8, var12, var13, var17, var15, var13, var17, var15, var16, var17, var12, var16, var17, var9, var10, var11, var4);
      a(var7, var8, var12, var13, var14, var12, var13, var17, var12, var16, var17, var12, var16, var14, var9, var10, var11, var4);
      a(var7, var8, var15, var13, var14, var15, var16, var14, var15, var16, var17, var15, var13, var17, var9, var10, var11, var4);
   }

   private RenderLayer a(String var1) {
      switch (var1) {
         case "Небула":
            return BlockOverlayLayers.n;
         case "Звёзды":
            return BlockOverlayLayers.p;
         case "Паутина":
            return BlockOverlayLayers.r;
         case "Плазма":
            return BlockOverlayLayers.t;
         default:
            return null;
      }
   }

   private void a(RenderLayer var1, MatrixStack var2, Box var3, Color var4) {
      Box var5 = this.a(var3, 0.0020000000165076876);
      Immediate var6 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
      VertexConsumer var7 = var6.getBuffer(var1);
      Matrix4f var8 = var2.peek().getPositionMatrix();
      float var9 = (float)var5.minX;
      float var10 = (float)var5.minY;
      float var11 = (float)var5.minZ;
      float var12 = (float)var5.maxX;
      float var13 = (float)var5.maxY;
      float var14 = (float)var5.maxZ;
      long var15 = System.currentTimeMillis();
      float var17 = (float)(var15 % 100000L) / 1000.0F * this.k.b();
      float var18 = var4.getRed() / 255.0F;
      float var19 = var4.getGreen() / 255.0F;
      float var20 = var4.getBlue() / 255.0F;
      float var21 = this.l.b();
      double var22 = (var5.minX + var5.maxX) * 0.5;
      double var24 = (var5.minY + var5.maxY) * 0.5;
      double var26 = (var5.minZ + var5.maxZ) * 0.5;
      if (var24 > 0.0) {
         b(var7, var8, var9, var10, var11, var12, var10, var11, var12, var10, var14, var9, var10, var14, var17, var18, var19, var20, var21);
      } else {
         b(var7, var8, var9, var13, var11, var9, var13, var14, var12, var13, var14, var12, var13, var11, var17, var18, var19, var20, var21);
      }

      if (var26 > 0.0) {
         b(var7, var8, var9, var10, var11, var9, var13, var11, var12, var13, var11, var12, var10, var11, var17, var18, var19, var20, var21);
      } else {
         b(var7, var8, var9, var10, var14, var12, var10, var14, var12, var13, var14, var9, var13, var14, var17, var18, var19, var20, var21);
      }

      if (var22 > 0.0) {
         b(var7, var8, var9, var10, var11, var9, var10, var14, var9, var13, var14, var9, var13, var11, var17, var18, var19, var20, var21);
      } else {
         b(var7, var8, var12, var10, var11, var12, var13, var11, var12, var13, var14, var12, var10, var14, var17, var18, var19, var20, var21);
      }

      this.s = var1;
   }

   private static void a(
      VertexConsumer var0,
      Matrix4f var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17,
      float var18
   ) {
      var0.vertex(var1, var2, var3, var4).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var5, var6, var7).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var8, var9, var10).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var2, var3, var4).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var8, var9, var10).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var11, var12, var13).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var2, var3, var4).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var8, var9, var10).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var5, var6, var7).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var2, var3, var4).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var11, var12, var13).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var8, var9, var10).texture(var14, 0.0F).color(var15, var16, var17, var18);
   }

   private static void b(
      VertexConsumer var0,
      Matrix4f var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17,
      float var18
   ) {
      var0.vertex(var1, var2, var3, var4).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var8, var9, var10).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var5, var6, var7).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var2, var3, var4).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var11, var12, var13).texture(var14, 0.0F).color(var15, var16, var17, var18);
      var0.vertex(var1, var8, var9, var10).texture(var14, 0.0F).color(var15, var16, var17, var18);
   }

   private static void a(
      VertexConsumer var0,
      Matrix4f var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17
   ) {
      var0.vertex(var1, var2, var3, var4).color(var14, var15, var16, var17);
      var0.vertex(var1, var5, var6, var7).color(var14, var15, var16, var17);
      var0.vertex(var1, var8, var9, var10).color(var14, var15, var16, var17);
      var0.vertex(var1, var2, var3, var4).color(var14, var15, var16, var17);
      var0.vertex(var1, var8, var9, var10).color(var14, var15, var16, var17);
      var0.vertex(var1, var11, var12, var13).color(var14, var15, var16, var17);
      var0.vertex(var1, var2, var3, var4).color(var14, var15, var16, var17);
      var0.vertex(var1, var8, var9, var10).color(var14, var15, var16, var17);
      var0.vertex(var1, var5, var6, var7).color(var14, var15, var16, var17);
      var0.vertex(var1, var2, var3, var4).color(var14, var15, var16, var17);
      var0.vertex(var1, var11, var12, var13).color(var14, var15, var16, var17);
      var0.vertex(var1, var8, var9, var10).color(var14, var15, var16, var17);
   }

   private Box a(Box var1, Vec3d var2, float var3) {
      double var4 = (var1.maxX - var1.minX) / 2.0 * var3;
      double var6 = (var1.maxY - var1.minY) / 2.0 * var3;
      double var8 = (var1.maxZ - var1.minZ) / 2.0 * var3;
      return new Box(var2.x - var4, var2.y - var6, var2.z - var8, var2.x + var4, var2.y + var6, var2.z + var8);
   }

   private Box a(Box var1, double var2) {
      return new Box(var1.minX - var2, var1.minY - var2, var1.minZ - var2, var1.maxX + var2, var1.maxY + var2, var1.maxZ + var2);
   }

   private Color n() {
      if (this.p.a()) {
         ClientColorModule var1 = ModuleRegistry.aw;
         if (var1 != null) {
            return var1.n();
         }
      }

      return this.q.a();
   }

   static {
      NativeMethodLookup.lookup(BlockOverlayModule.class, 81);
   }
}
