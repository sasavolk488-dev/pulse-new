package pulse.features.cosmetic.geo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GeoModel {
   public List<GeoBone> a = new ArrayList<>();
   public int b = 64;
   public int c = 64;

   public Optional<GeoBone> a(String var1) {
      for (GeoBone var3 : this.a) {
         GeoBone var4 = this.a(var1, var3);
         if (var4 != null) {
            return Optional.of(var4);
         }
      }

      return Optional.empty();
   }

   private GeoBone a(String var1, GeoBone var2) {
      if (var2.d.equals(var1)) {
         return var2;
      } else {
         for (GeoBone var4 : var2.b) {
            GeoBone var5 = this.a(var1, var4);
            if (var5 != null) {
               return var5;
            }
         }

         return null;
      }
   }
}
