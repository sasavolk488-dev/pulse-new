package pulse.core.event.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class CriticalHitEvent extends Event {
   private final Entity a;

   public CriticalHitEvent(Entity var1) {
      this.a = var1;
   }

   public Entity a() {
      return this.a;
   }
}
