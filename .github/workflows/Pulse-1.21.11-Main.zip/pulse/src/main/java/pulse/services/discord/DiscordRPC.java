package pulse.services.discord;

import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import org.json.JSONArray;
import org.json.JSONObject;

@Environment(EnvType.CLIENT)
public final class DiscordRPC {
   private static final String a = "1384570279199768750";
   private static final int b = 0;
   private static final int c = 1;
   private static final long d = 4000L;
   private static final long e = 15000L;
   private static final DiscordRPC f = new DiscordRPC();
   private final long g = System.currentTimeMillis() / 1000L;
   private volatile boolean h;
   private Thread i;
   private DiscordIpcChannel j;
   private String k = "";

   public static DiscordRPC a() {
      return f;
   }

   public void b() {
      if (!this.h) {
         this.h = true;
         this.i = new Thread(this::d, "Pulse-DiscordRPC");
         this.i.setDaemon(true);
         this.i.start();
      }
   }

   public void c() {
      this.h = false;
      this.l();
      if (this.i != null) {
         this.i.interrupt();
      }
   }

   private void d() {
      while (this.h) {
         try {
            if (this.j == null && !this.e()) {
               this.a(15000L);
            } else {
               String var1 = this.f();
               if (!var1.equals(this.k)) {
                  String var2 = new JSONObject(var1).put("nonce", UUID.randomUUID().toString()).toString();
                  this.j.a(1, var2);
                  this.j.b();
                  this.k = var1;
               }

               this.a(4000L);
            }
         } catch (InterruptedException var4) {
            break;
         } catch (Exception var5) {
            this.l();
            this.k = "";

            try {
               this.a(15000L);
            } catch (InterruptedException var3) {
               break;
            }
         }
      }

      this.l();
   }

   private boolean e() {
      try {
         DiscordIpcChannel var1 = DiscordIpcChannel.a();
         if (var1 == null) {
            return false;
         } else {
            JSONObject var2 = new JSONObject().put("v", 1).put("client_id", "1384570279199768750");
            var1.a(0, var2.toString());
            var1.b();
            this.j = var1;
            this.k = "";
            return true;
         }
      } catch (Exception var3) {
         this.l();
         return false;
      }
   }

   private String f() {
      JSONObject var1 = new JSONObject();
      String var2 = this.i();
      String var3 = this.g();
      var1.put("details", var2);
      var1.put("state", var3);
      var1.put("timestamps", new JSONObject().put("start", this.g));
      JSONObject var4 = new JSONObject().put("large_image", "pulse_logo").put("large_text", "Pulse Visuals • " + this.j());
      var1.put("assets", var4);
      int var5 = this.h();
      if (var5 > 0) {
         var1.put("party", new JSONObject().put("id", "pulse-party").put("size", new JSONArray().put(var5).put(var5)));
      }

      var1.put(
         "buttons",
         new JSONArray()
            .put(new JSONObject().put("label", "Купить").put("url", "https://pulsevisuals.pro/dashboard/store"))
            .put(new JSONObject().put("label", "Telegram").put("url", "https://t.me/pulsevisuals"))
      );
      JSONObject var6 = new JSONObject().put("pid", this.k()).put("activity", var1);
      return new JSONObject().put("cmd", "SET_ACTIVITY").put("args", var6).toString();
   }

   private String g() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.player == null || var1.world == null) {
         return "В главном меню";
      } else if (var1.isInSingleplayer()) {
         return "Одиночная игра";
      } else {
         ServerInfo var2 = var1.getCurrentServerEntry();
         return var2 != null && var2.address != null && !var2.address.isEmpty() ? "Сервер: " + var2.address : "В игре";
      }
   }

   private int h() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.player != null && var1.getNetworkHandler() != null) {
         try {
            return var1.getNetworkHandler().getPlayerList().size();
         } catch (Exception var3) {
            return 0;
         }
      } else {
         return 0;
      }
   }

   private String i() {
      try {
         return FabricLoader.getInstance().getModContainer("minecraft").map(var0 -> var0.getMetadata().getVersion().getFriendlyString()).orElse("1.21.11");
      } catch (Exception var2) {
         return "1.21.11";
      }
   }

   private String j() {
      try {
         String var1 = MinecraftClient.getInstance().getSession().getUsername();
         return var1 != null && !var1.isEmpty() ? var1 : "Pulse";
      } catch (Exception var2) {
         return "Pulse";
      }
   }

   private long k() {
      try {
         return ProcessHandle.current().pid();
      } catch (Exception var2) {
         return 0L;
      }
   }

   private void l() {
      if (this.j != null) {
         try {
            this.j.close();
         } catch (Exception var2) {
         }

         this.j = null;
      }
   }

   private void a(long var1) throws InterruptedException {
      Thread.sleep(var1);
   }
}
