package pulse.core.settings;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class NumberSetting extends Setting<Float> {
   private final float a;
   private final float b;
   private final float c;

   public NumberSetting(String var1, String var2, float var3, float var4, float var5, float var6) {
      super(var1, var2, var3);
      this.a = var4;
      this.b = var5;
      this.c = var6;
   }

   public NumberSetting(String var1, float var2, float var3, float var4, float var5) {
      this(var1, "", var2, var3, var4, var5);
   }

   public NumberSetting(String var1, float var2, float var3, float var4) {
      this(var1, "", var2, var3, var4, 0.1F);
   }

   public float b() {
      return this.q();
   }

   public void a(float var1) {
      float var2 = Math.round(var1 / this.c) * this.c;
      int var3 = this.b(this.c);
      float var4 = (float)Math.pow(10.0, var3);
      var2 = Math.round(var2 * var4) / var4;
      this.a(Float.valueOf(Math.max(this.a, Math.min(this.b, var2))));
   }

   private int b(float var1) {
      String var2 = Float.toString(var1);
      int var3 = var2.indexOf(46);
      return var3 < 0 ? 0 : var2.length() - var3 - 1;
   }

   public int c() {
      return Math.round(this.q());
   }

   public float d() {
      return this.a;
   }

   public float e() {
      return this.b;
   }

   public float f() {
      return this.c;
   }

   public NumberSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
