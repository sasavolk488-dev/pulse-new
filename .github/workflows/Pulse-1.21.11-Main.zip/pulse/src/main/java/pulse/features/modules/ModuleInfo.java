package pulse.features.modules;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Retention(RetentionPolicy.RUNTIME)
@Environment(EnvType.CLIENT)
public @interface ModuleInfo {
   String a();

   String b();

   Category c();
}
