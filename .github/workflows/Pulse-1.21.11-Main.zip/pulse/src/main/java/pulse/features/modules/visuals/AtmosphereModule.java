package pulse.features.modules.visuals;

import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.PacketEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "Atmosphere",
   b = "Своё время суток и погода в мире",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class AtmosphereModule extends Module {
   private static final String a = "Как на сервере";
   private final ModeSetting b = new ModeSetting("Время суток", new String[]{"Как на сервере", "День", "Закат", "Ночь", "Полночь", "Рассвет"}, "День");
   private final ModeSetting c = new ModeSetting("Погода", new String[]{"Как на сервере", "Ясно", "Дождь", "Снег", "Гроза"}, "Как на сервере");
   private final Animation f = new Animation();
   private final Animation g = new Animation();
   private final Animation h = new Animation();

   @EventHandler
   public void a(UpdateEvent var1) {
      if (d.world != null) {
         a(this.f, this.v(), 1.0);
         a(this.g, this.w(), 0.0039999985229912695);
         a(this.h, this.x(), 0.0039999985229912695);
      }
   }

   private static void a(Animation var0, double var1, double var3) {
      var0.a();
      if (Math.abs(var0.j() - var1) <= var3) {
         var0.d(var1);
      } else {
         var0.a(var1, 2.0, Easings.C, false);
      }
   }

   @EventHandler
   public void a(PacketEvent var1) {
      if (this.n() && var1.e() == PacketEvent.EventType.b && var1.d() instanceof WorldTimeUpdateS2CPacket) {
         var1.b();
      }
   }

   public boolean n() {
      return this.k() && !this.b.b("Как на сервере");
   }

   public boolean o() {
      return this.k() && !this.c.b("Как на сервере");
   }

   public boolean p() {
      return this.k() && this.c.b("Снег");
   }

   public long q() {
      return (long)this.f.j();
   }

   public float r() {
      return this.p() ? 0.0F : (float)this.g.j();
   }

   public float s() {
      return (float)this.g.j();
   }

   public float t() {
      return (float)this.h.j();
   }

   private long v() {
      String var1 = this.b.e();
      switch (var1) {
         case "День":
            return 1000L;
         case "Закат":
            return 12500L;
         case "Ночь":
            return 18000L;
         case "Полночь":
            return 22000L;
         case "Рассвет":
            return 23000L;
         default:
            return 1000L;
      }
   }

   private float w() {
      String var1 = this.c.e();
      switch (var1) {
         case "Дождь":
         case "Снег":
         case "Гроза":
            return 1.0F;
         default:
            return 0.0F;
      }
   }

   private float x() {
      return this.c.b("Гроза") ? 1.0F : 0.0F;
   }
}
