package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Totem Bar",
   b = "Показывает количество тотемов над хотбаром",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class TotemBarModule extends Module {
}
