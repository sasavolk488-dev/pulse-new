package pulse.features.graffiti;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class WebpAnimInfo {
   final int a;
   final int b;
   final List<WebpAnimInfo.Frame> c;

   boolean a() {
      return !this.c.isEmpty();
   }

   private WebpAnimInfo(int var1, int var2, List<WebpAnimInfo.Frame> var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   static WebpAnimInfo a(Path var0) throws IOException {
      return a(Files.readAllBytes(var0));
   }

   static WebpAnimInfo a(byte[] var0) throws IOException {
      if (var0.length >= 12 && a(var0, 0, "RIFF") && a(var0, 8, "WEBP")) {
         int var1 = 0;
         int var2 = 0;
         ArrayList var3 = new ArrayList();
         int var4 = 12;

         while (var4 + 8 <= var0.length) {
            String var5 = new String(var0, var4, 4, StandardCharsets.US_ASCII);
            int var6 = b(var0, var4 + 4);
            int var7 = var4 + 8;
            if (var7 + var6 > var0.length) {
               break;
            }

            switch (var5) {
               case "VP8X":
                  var1 = a(var0, var7 + 4) + 1;
                  var2 = a(var0, var7 + 7) + 1;
                  break;
               case "ANMF":
                  int var10 = a(var0, var7) * 2;
                  int var11 = a(var0, var7 + 3) * 2;
                  int var12 = a(var0, var7 + 6) + 1;
                  int var13 = a(var0, var7 + 9) + 1;
                  int var14 = a(var0, var7 + 12);
                  int var15 = var0[var7 + 15] & 255;
                  boolean var16 = (var15 & 2) == 0;
                  boolean var17 = (var15 & 1) != 0;
                  var3.add(new WebpAnimInfo.Frame(var10, var11, var12, var13, var14, var16, var17));
            }

            var4 = var7 + var6 + (var6 & 1);
         }

         return new WebpAnimInfo(var1, var2, var3);
      } else {
         throw new IOException("не webp");
      }
   }

   private static boolean a(byte[] var0, int var1, String var2) {
      for (int var3 = 0; var3 < 4; var3++) {
         if (var0[var1 + var3] != var2.charAt(var3)) {
            return false;
         }
      }

      return true;
   }

   private static int a(byte[] var0, int var1) {
      return var0[var1] & 0xFF | (var0[var1 + 1] & 0xFF) << 8 | (var0[var1 + 2] & 0xFF) << 16;
   }

   private static int b(byte[] var0, int var1) {
      return a(var0, var1) | (var0[var1 + 3] & 0xFF) << 24;
   }

   @Environment(EnvType.CLIENT)
   record Frame(int x, int y, int width, int height, int durationMs, boolean blendAlpha, boolean disposeToBackground) {
   }
}
