package pulse.mixin;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.BufferBuilderStorage;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.BufferAllocator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.utils.render.world.BubbleLayers;
import pulse.utils.render.world.JumpLayers;
import pulse.utils.render.world.KillEffectLayers;
import pulse.utils.render.world.ParticleLayers;
import pulse.utils.render.world.TrailLayers;

@Environment(EnvType.CLIENT)
@Mixin({BufferBuilderStorage.class})
public abstract class BufferBuilderStorageMixin {
   @Inject(
      method = {"method_54639"},
      at = {@At("RETURN")}
   )
   private void appendPulseLayers(Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator> var1, CallbackInfo var2) {
      register(var1, BlockOverlayLayers.j);
      register(var1, BlockOverlayLayers.l);
      register(var1, BlockOverlayLayers.f);
      register(var1, BlockOverlayLayers.h);
      register(var1, BlockOverlayLayers.n);
      register(var1, BlockOverlayLayers.p);
      register(var1, BlockOverlayLayers.r);
      register(var1, BlockOverlayLayers.t);
      register(var1, BlockOverlayLayers.v);
      register(var1, BlockOverlayLayers.w);
      register(var1, BlockOverlayLayers.y);
      register(var1, BlockOverlayLayers.z);
      register(var1, BlockOverlayLayers.B);
      register(var1, BlockOverlayLayers.C);
      register(var1, BlockOverlayLayers.E);
      register(var1, BlockOverlayLayers.F);
      register(var1, BubbleLayers.d);
      register(var1, BubbleLayers.e);
      register(var1, JumpLayers.c);

      for (RenderLayer var6 : JumpLayers.l) {
         register(var1, var6);
      }

      for (RenderLayer var13 : ParticleLayers.J) {
         register(var1, var13);
      }

      register(var1, ParticleLayers.G);
      register(var1, ParticleLayers.I);

      for (RenderLayer var14 : KillEffectLayers.g) {
         register(var1, var14);
      }

      register(var1, TrailLayers.b);
      register(var1, TrailLayers.d);
   }

   private static void register(Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator> var0, RenderLayer var1) {
      var0.put(var1, new BufferAllocator(var1.getExpectedBufferSize()));
   }
}
