package pulse.features.modules;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum Category {
   VISUALS("Visuals"),
   HUD("HUD"),
   UTILITIES("Utilities");

   private final String d;

   private Category(String var3) {
      this.d = var3;
   }

   public String a() {
      return this.d;
   }

   private static Category[] b() {
      return new Category[]{VISUALS, HUD, UTILITIES};
   }
}
