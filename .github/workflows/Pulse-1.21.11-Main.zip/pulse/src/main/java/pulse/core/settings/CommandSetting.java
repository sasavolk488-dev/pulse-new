package pulse.core.settings;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CommandSetting extends Setting<String> {
   public CommandSetting(String var1, String var2, String var3) {
      super(var1, var2, var3);
   }

   public CommandSetting(String var1, String var2) {
      this(var1, "", var2);
   }

   public String b() {
      return this.q();
   }

   public void a(String var1) {
      this.a((String)var1);
   }

   public CommandSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
