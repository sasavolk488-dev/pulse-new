package pulse.features.modules.hud;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Potions",
   b = "Show active potions",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class PotionsModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Показывать донат зелья", true);
   private final NumberSetting b = new NumberSetting("Масштаб", 1.0F, 0.8F, 2.0F, 0.1F);

   public PotionsModule() {
      this.d();
   }

   @Generated
   public BooleanSetting n() {
      return this.a;
   }

   @Generated
   public NumberSetting o() {
      return this.b;
   }
}
