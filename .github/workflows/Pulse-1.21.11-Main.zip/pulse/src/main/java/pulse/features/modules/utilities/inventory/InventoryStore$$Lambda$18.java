package pulse.features.modules.utilities.inventory;

import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.item.ItemStack;

public final class InventoryStore$$Lambda$18 implements Consumer {
   private final Map c0;
   private final int c1;

   public InventoryStore$$Lambda$18(Map var1, int var2) {
      this.c0 = var1;
      this.c1 = var2;
   }

   @Override
   public void accept(Object var1) {
      InventoryStore.a(this.c0, this.c1, (ItemStack)var1);
   }
}
