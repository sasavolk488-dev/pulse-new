package pulse.features.graffiti;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPInputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.utils.net.ApiRouter;

@Environment(EnvType.CLIENT)
public final class GraffitiBundleManager {
   private static final int a = 6;
   private static final int b = 5000;
   private static final Map<Integer, GraffitiEntry> c = new ConcurrentHashMap<>();
   private static volatile List<GraffitiEntry> d = List.of();

   private GraffitiBundleManager() {
   }

   public static GraffitiEntry a(int var0) {
      return c.get(var0);
   }

   public static List<GraffitiEntry> a() {
      return d;
   }

   public static void b() {
      new Thread(GraffitiBundleManager::c, "Graffiti-Bundle-Loader").start();
   }

   private static void c() {
      Pulse.m().info("[Graffiti] загрузка graffiti-bundle, хосты: {}", ApiRouter.a());
      int var0 = 0;

      for (int var1 = 0; var1 < 6; var1++) {
         String var2 = ApiRouter.a().get(var0) + "/cosmetics/graffiti-bundle";

         try {
            URL var3 = new URL(var2);
            HttpURLConnection var4 = (HttpURLConnection)var3.openConnection();
            var4.setRequestMethod("GET");
            var4.setConnectTimeout(15000);
            var4.setReadTimeout(60000);
            var4.setRequestProperty("Accept-Encoding", "gzip");
            String var5 = g();
            if (var5 != null && !var5.isEmpty()) {
               var4.setRequestProperty("If-None-Match", var5);
            }

            int var6 = var4.getResponseCode();
            String var7 = var4.getHeaderField("ETag");
            String var8;
            if (var6 == 304) {
               var8 = h();
               if (var8 == null) {
                  Pulse.m().warn("[Graffiti] 304, но локальный кэш отсутствует — перезапрос без ETag");
                  var4.disconnect();

                  try {
                     Files.deleteIfExists(f());
                  } catch (Exception var11) {
                  }
                  continue;
               }

               Pulse.m().info("[Graffiti] bundle: кэш актуален (304), читаю с диска");
            } else if (var6 == 200) {
               var8 = a(var4);
               a(var8, var7);
               Pulse.m().info("[Graffiti] bundle: свежий ответ ({} KB), кэш обновлён{}", var8.length() / 1024, var7 != null ? " (etag=" + var7 + ")" : "");
            } else {
               Pulse.m().warn("[Graffiti] bundle: HTTP {}", var6);
               var8 = h();
               if (var8 == null) {
                  return;
               }

               Pulse.m().info("[Graffiti] bundle: использую stale-кэш");
            }

            a(var8);
            return;
         } catch (SocketTimeoutException var12) {
            Pulse.m().warn("[Graffiti] таймаут bundle (попытка {}/{}, {})", var1 + 1, 6, var2);
            var0 = (var0 + 1) % ApiRouter.a().size();
            if (!b(var1)) {
               return;
            }
         } catch (Exception var13) {
            Pulse.m().error("[Graffiti] ошибка загрузки graffiti-bundle (попытка {}/{}, {}): {}", var1 + 1, 6, var2, var13.toString());
            var0 = (var0 + 1) % ApiRouter.a().size();
            if (!b(var1)) {
               return;
            }
         }
      }

      String var14 = h();
      if (var14 != null) {
         Pulse.m().info("[Graffiti] bundle: попытки исчерпаны, использую кэш");

         try {
            a(var14);
         } catch (Exception var10) {
         }
      } else {
         Pulse.m().error("[Graffiti] не удалось загрузить graffiti-bundle после {} попыток", 6);
      }
   }

   private static boolean b(int var0) {
      if (var0 >= 5) {
         return true;
      } else {
         try {
            Thread.sleep(5000L);
            return true;
         } catch (InterruptedException var2) {
            Thread.currentThread().interrupt();
            return false;
         }
      }
   }

   private static void a(String var0) {
      JSONObject var1 = new JSONObject(var0);
      if (!var1.optBoolean("success", false)) {
         Pulse.m().warn("[Graffiti] bundle: сервер вернул ошибку");
      } else {
         JSONArray var2 = var1.optJSONArray("data");
         if (var2 != null) {
            ArrayList var3 = new ArrayList<>();
            int var4 = 0;

            for (int var5 = 0; var5 < var2.length(); var5++) {
               JSONObject var6 = var2.getJSONObject(var5);
               int var7 = var6.optInt("id", -1);
               if (var7 >= 0) {
                  var3.add(var7);
                  if (c.containsKey(var7)) {
                     var4++;
                  } else {
                     try {
                        byte[] var8 = Base64.getDecoder().decode(var6.getString("image_base64"));
                        String var9 = var6.optString("ext", "png");
                        String var10 = var6.optString("name", "Graffiti " + var7);
                        GraffitiDecoder.Frames var11 = GraffitiDecoder.a(var8, var9);
                        GraffitiLibrary.a("bundle-" + var7, var10, var7, var11, var2x -> {
                           c.put(var7, var2x);
                           a(var3);
                        });
                        var4++;
                     } catch (Throwable var12) {
                        Pulse.m().warn("[Graffiti] bundle: skip id={}: {}", var7, var12.toString());
                     }
                  }
               }
            }

            a(var3);
            Pulse.m().info("[Graffiti] bundle: загружено {} граффити (из {})", var4, var2.length());
         }
      }
   }

   private static void a(List<Integer> var0) {
      ArrayList var1 = new ArrayList<>();

      for (int var3 : var0) {
         GraffitiEntry var4 = c.get(var3);
         if (var4 != null) {
            var1.add(var4);
         }
      }

      d = List.copyOf(var1);
   }

   private static String a(HttpURLConnection var0) throws Exception {
      InputStream var1 = var0.getInputStream();
      if ("gzip".equalsIgnoreCase(var0.getContentEncoding())) {
         var1 = new GZIPInputStream((InputStream)var1);
      }

      String var6;
      try (InputStream var2 = var1) {
         ByteArrayOutputStream var3 = new ByteArrayOutputStream();
         byte[] var4 = new byte[8192];

         int var5;
         while ((var5 = var2.read(var4)) != -1) {
            var3.write(var4, 0, var5);
         }

         var6 = var3.toString(StandardCharsets.UTF_8);
      }

      return var6;
   }

   private static Path d() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cache");
   }

   private static Path e() {
      return d().resolve("graffiti_bundle.json");
   }

   private static Path f() {
      return d().resolve("graffiti_bundle.etag");
   }

   private static String g() {
      try {
         Path var0 = f();
         if (Files.exists(var0)) {
            return new String(Files.readAllBytes(var0), StandardCharsets.UTF_8).trim();
         }
      } catch (Exception var1) {
      }

      return null;
   }

   private static String h() {
      try {
         Path var0 = e();
         if (Files.exists(var0)) {
            return new String(Files.readAllBytes(var0), StandardCharsets.UTF_8);
         }
      } catch (Exception var1) {
      }

      return null;
   }

   private static void a(String var0, String var1) {
      try {
         Files.createDirectories(d());
         Files.write(e(), var0.getBytes(StandardCharsets.UTF_8));
         if (var1 != null) {
            Files.write(f(), var1.getBytes(StandardCharsets.UTF_8));
         }
      } catch (Exception var3) {
         Pulse.m().warn("[Graffiti] не удалось сохранить кэш bundle: {}", var3.getMessage());
      }
   }
}
