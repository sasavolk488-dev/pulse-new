package pulse.features.modules.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Effect Notify",
   b = "Notify on effect changes",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class EffectNotifyModule extends Module {
}
