package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Keyboard;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.KeyEvent;
import pulse.core.input.KeybindManager;

@Environment(EnvType.CLIENT)
@Mixin({Keyboard.class})
public class KeyboardMixin {
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onKey(long var1, int var3, KeyInput var4, CallbackInfo var5) {
      net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
      if (client.getWindow() == null || var1 != client.getWindow().getHandle()) {
         return;
      }
      boolean guiKey = var3 == 1
         && pulse.utils.input.KeyBindings.a(var4.key(), var4.scancode(), var4.modifiers())
         && (client.currentScreen == null || client.currentScreen instanceof pulse.ui.clickgui.ClickGuiScreen);
      if (guiKey) {
         pulse.Pulse.l().b();
      }
      EventHandler.a.post(new KeyEvent(var4.key(), var4.scancode(), var3, var4.modifiers()));
      if (guiKey) {
         var5.cancel();
         return;
      }
      if (var3 == 1) {
         KeybindManager.a().d(var4.key());
      }
   }
}
