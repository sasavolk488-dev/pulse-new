package pulse.ui.clickgui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public interface Menu {
   void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6);

   void a(float var1, float var2, int var3, int var4);

   void b(float var1, float var2, int var3, int var4);

   void c(float var1, float var2, int var3, int var4);

   void a(float var1, float var2, int var3, int var4, double var5, double var7);

   void a(float var1);

   MenuType a();

   default boolean a(int var1, int var2, int var3) {
      return false;
   }

   default boolean b() {
      return false;
   }
}
