package pulse.ui.clickgui.common;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.ui.clickgui.Menu;
import pulse.ui.clickgui.MenuType;
import pulse.ui.clickgui.menu.modules.ModulesMenu;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class SettingsPanelElement implements GuiElement {
   private static final float a = 48.0F;
   private final ClickGuiScreen b;
   private int c;
   private int d;

   public SettingsPanelElement(ClickGuiScreen var1) {
      this.b = var1;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      Menu var7 = this.b.b();
      if (var7 != null && var7.a() == MenuType.a) {
         if (var7 instanceof ModulesMenu var8) {
            List<ModuleSettingsPanel> var9 = var8.h();
            if (!var9.isEmpty()) {
               this.c = var5;
               this.d = var6;
               float var10 = ClickGuiScreen.f();
               float var11 = var4 + 48.0F;
               float var12 = var10 - 48.0F - 5.0F;
               ModuleSettingsPanel var13 = this.a(var9, var5, var6);
               boolean var14 = var13 != null;

               for (ModuleSettingsPanel var16 : var9) {
                  boolean var17 = var14 && var13 != var16;
                  var16.a(var1, var2, var3, var4, var5, var6, var11, var12, var17);
               }
            }
         }
      }
   }

   private ModuleSettingsPanel a(List<ModuleSettingsPanel> var1, int var2, int var3) {
      for (ModuleSettingsPanel var5 : var1) {
         if (!var5.f() && !var5.g() && var5.f(var2, var3)) {
            return var5;
         }
      }

      return null;
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4) {
      Menu var5 = this.b.b();
      if (var5 != null && var5.a() == MenuType.a) {
         if (var5 instanceof ModulesMenu var6) {
            List<ModuleSettingsPanel> var7 = var6.h();
            if (!var7.isEmpty()) {
               for (ModuleSettingsPanel var9 : var7) {
                  var9.a(var1, var2, var3, var4);
               }
            }
         }
      }
   }

   @Override
   public void a(float var1, float var2, int var3, int var4) {
   }
}
