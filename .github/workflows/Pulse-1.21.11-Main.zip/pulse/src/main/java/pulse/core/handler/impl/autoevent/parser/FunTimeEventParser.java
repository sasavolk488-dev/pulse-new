package pulse.core.handler.impl.autoevent.parser;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.ui.clickgui.menu.markers.MarkerSettings;
import pulse.core.handler.impl.autoevent.AutoEventHandler;
import pulse.core.handler.impl.autoevent.EventConfig;
import pulse.core.handler.impl.autoevent.ServerEventParser;

@Environment(EnvType.CLIENT)
public class FunTimeEventParser implements ServerEventParser {
   private static final Set<String> a = Collections.unmodifiableSet(new HashSet<>(Arrays.asList("сундук смерти", "адская резня")));
   private static final Pattern b = Pattern.compile("\\[\\d+].+");
   private static final Pattern c = Pattern.compile("\\[(\\d+)]\\s*(.+?):");
   private static final Pattern d = Pattern.compile("до следующего ивента:\\s*(?:(\\d+)\\s*мин)?\\s*(?:(\\d+)\\s*сек)?");
   private static final Pattern e = Pattern.compile("\\|{3}\\s*\\[(.+?)]\\s*\\|{3}");
   private static final Pattern f = Pattern.compile("появился на координатах\\s*(?:\\[)?(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)(?:\\])?");
   private static final Pattern g = Pattern.compile("«\\s*(.+?)\\s*»");
   private static final Pattern h = Pattern.compile("на координатах\\s*\\[(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)]");
   private static final Pattern i = Pattern.compile("\\[(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)]");
   private static final Pattern j = Pattern.compile(
      "(до активации|до открытия|до закрытия|до извержения|до аварии|на подходе|до конца|открытие через|закрытие через|начнётся через|начнется через|осталось):?\\s*(?:(\\d+)\\s*ч\\s*)?(?:(\\d+)\\s*мин\\s*)?(?:(\\d+)\\s*сек)?"
   );
   private static final Pattern k = Pattern.compile(
      "(до активации|до открытия|до закрытия|до извержения|до аварии|на подходе|до конца|открытие через|закрытие через|начнётся через|начнется через|осталось):?\\s*(\\d+)\\s*сек"
   );
   private static final Map<String, EventConfig> l;
   private static final long m = 1000L;
   private String n = null;
   private int o = 0;
   private String p = null;
   private String q = null;
   private long r = 0L;
   private boolean s = false;
   private boolean t = false;
   private String u = null;
   private int v = 0;
   private int w = 0;
   private boolean x = false;

   @Override
   public boolean a(String var1) {
      return var1 == null ? false : var1.toLowerCase().contains("funtime");
   }

   @Override
   public boolean a(String var1, String var2, AutoEventHandler var3) {
      boolean var4 = false;
      long var5 = System.currentTimeMillis();
      boolean var7 = this.r > 0L && var5 - this.r < 1000L;
      if (var1.contains("[ивенты]")) {
         var3.d();
         this.n = null;
         this.o = 0;
         this.p = null;
         this.q = null;
         this.s = false;
         this.t = false;
         this.u = null;
         this.v = 0;
         this.w = 0;
         this.x = false;
         this.r = var5;
         var4 = true;
      } else if (var7 && b.matcher(var1).matches()) {
         this.a(var1, var3);
         var4 = true;
      } else if (var7
         && (
            var1.contains("статус:")
               || var1.contains("координаты:")
               || var1.contains("уровень лута:")
               || var1.contains("редкость:")
               || var1.contains("/event vote")
         )) {
         this.b(var1, var3);
         var4 = true;
         if (this.s && !this.x) {
            this.x = true;
            this.r = 0L;
         }
      }

      if (var1.contains("появился на координатах")) {
         this.c(var1, var3);
         var4 = true;
      }

      if (var1.contains("на координатах") && var1.contains("«") && var1.contains("»")) {
         this.d(var1, var3);
         var4 = true;
      }

      return var4;
   }

   private void a(String var1, AutoEventHandler var2) {
      if (var1.contains("до следующего ивента:")) {
         int var6 = this.b(var1);
         if (var6 > 0) {
            this.w = var6;
         }
      } else {
         Matcher var3 = c.matcher(var1);
         if (var3.find()) {
            String var4 = var3.group(2).trim();
            if (this.e(var4)) {
               this.n = null;
               return;
            }

            this.n = var4;
            this.o = 0;
            int var5 = var2.h();
            var2.b(var4, var5);
         }
      }
   }

   private int b(String var1) {
      Matcher var2 = d.matcher(var1);
      if (var2.find()) {
         int var3 = 0;
         String var4 = var2.group(1);
         String var5 = var2.group(2);
         if (var4 != null) {
            var3 += Integer.parseInt(var4) * 60;
         }

         if (var5 != null) {
            var3 += Integer.parseInt(var5);
         }

         return var3;
      } else {
         return 0;
      }
   }

   private void b(String var1, AutoEventHandler var2) {
      if (var1.contains("статус:")) {
         int var3 = var1.indexOf("статус:");
         String var4 = var1.substring(var3 + "статус:".length()).trim().replace("»", "").trim();
         if (this.n != null) {
            this.q = this.c(var4);
            int var5 = this.g(var4);
            if (var5 > 0) {
               this.o = var5;
               var2.c(var5);
               if (!this.t) {
                  this.t = true;
                  this.u = this.n;
                  this.v = var5;
               }
            }
         }
      } else if (!var1.contains("уровень лута:") && !var1.contains("редкость:")) {
         if (var1.contains("координаты:")) {
            int var9 = var1.indexOf("координаты:");
            String var12 = var1.substring(var9 + "координаты:".length()).trim();
            int[] var13 = this.f(var12);
            if (var13 != null && this.n != null) {
               var2.a(this.n, var13, this.o);
               String var6 = this.p != null ? this.p : this.q;
               var2.a(this.d(this.n), var6);
               this.s = true;
            }
         } else if (var1.contains("/event vote")) {
            var2.e();
            this.x = true;
         }
      } else {
         String var7;
         if (var1.contains("уровень лута:")) {
            int var10 = var1.indexOf("уровень лута:");
            var7 = var1.substring(var10 + "уровень лута:".length()).trim();
         } else {
            int var11 = var1.indexOf("редкость:");
            var7 = var1.substring(var11 + "редкость:".length()).trim();
         }

         var7 = var7.replace("»", "").trim();
         this.p = this.d(var7);
      }
   }

   private String c(String var1) {
      String var2 = var1.replaceAll("\\d+\\s*ч", "")
         .replaceAll("\\d+\\s*мин", "")
         .replaceAll("\\d+\\s*сек", "")
         .replaceAll(",?\\s*до извержения:?", "")
         .replaceAll(",?\\s*до открытия:?", "")
         .replaceAll(",?\\s*до закрытия:?", "")
         .replaceAll(",?\\s*до активации:?", "")
         .replaceAll(",?\\s*до аварии:?", "")
         .replaceAll(",?\\s*до конца:?", "")
         .replaceAll(",?\\s*до подарков:?", "")
         .replaceAll(",?\\s*на подходе:?", "")
         .replaceAll(",?\\s*начнётся через:?", "")
         .replaceAll(",?\\s*начнется через:?", "")
         .replaceAll(",?\\s*осталось:?", "")
         .replaceAll(",\\s*$", "")
         .replaceAll(":$", "")
         .trim();
      return var2.isEmpty() ? null : this.d(var2);
   }

   private String d(String var1) {
      return var1 != null && !var1.isEmpty() ? var1.substring(0, 1).toUpperCase() + var1.substring(1) : var1;
   }

   private void c(String var1, AutoEventHandler var2) {
      String[] var3 = var1.split("\\n");
      String var4 = null;
      int[] var5 = null;

      for (String var9 : var3) {
         var9 = var9.trim();
         Matcher var10 = e.matcher(var9);
         if (var10.find()) {
            var4 = var10.group(1).trim();
         } else {
            Matcher var11 = f.matcher(var9);
            if (var11.find()) {
               int var12 = Integer.parseInt(var11.group(1));
               int var13 = Integer.parseInt(var11.group(2));
               int var14 = Integer.parseInt(var11.group(3));
               var5 = new int[]{var12, var13, var14};
            }
         }
      }

      if (var4 != null && var5 != null && !this.e(var4)) {
         var2.a(var4, var5, 0);
         var2.a(this.d(var4), null);
      }
   }

   private void d(String var1, AutoEventHandler var2) {
      String var3 = null;
      int[] var4 = null;
      Matcher var5 = g.matcher(var1);
      if (var5.find()) {
         var3 = var5.group(1).trim();
      }

      Matcher var6 = h.matcher(var1);
      if (var6.find()) {
         int var7 = Integer.parseInt(var6.group(1));
         int var8 = Integer.parseInt(var6.group(2));
         int var9 = Integer.parseInt(var6.group(3));
         var4 = new int[]{var7, var8, var9};
      }

      if (var3 != null && var4 != null && !this.e(var3)) {
         var2.a(var3, var4, 0);
         var2.a(this.d(var3), null);
      }
   }

   private boolean e(String var1) {
      String var2 = var1.toLowerCase(Locale.ROOT);
      return a.contains(var2) ? true : var2.equals("загадочный маяк") && !MarkerSettings.i();
   }

   private int[] f(String var1) {
      Matcher var2 = i.matcher(var1);
      if (var2.find()) {
         int var3 = Integer.parseInt(var2.group(1));
         int var4 = Integer.parseInt(var2.group(2));
         int var5 = Integer.parseInt(var2.group(3));
         return new int[]{var3, var4, var5};
      } else {
         return null;
      }
   }

   private int g(String var1) {
      Matcher var2 = j.matcher(var1);
      if (var2.find()) {
         int var3 = 0;
         String var4 = var2.group(2);
         String var5 = var2.group(3);
         String var6 = var2.group(4);
         if (var4 != null) {
            var3 += Integer.parseInt(var4) * 3600;
         }

         if (var5 != null) {
            var3 += Integer.parseInt(var5) * 60;
         }

         if (var6 != null) {
            var3 += Integer.parseInt(var6);
         }

         if (var3 > 0) {
            return var3;
         }
      }

      Matcher var7 = k.matcher(var1);
      return var7.find() ? Integer.parseInt(var7.group(2)) : 0;
   }

   @Override
   public Set<String> a() {
      return l.keySet();
   }

   @Override
   public Map<String, EventConfig> b() {
      return l;
   }

   @Override
   public String c() {
      return "/event delay";
   }

   @Override
   public void a(AutoEventHandler var1) {
      if (this.r > 0L && !this.x) {
         long var2 = System.currentTimeMillis();
         if (var2 - this.r >= 1000L) {
            if (!this.s) {
               if (this.t && this.u != null) {
                  var1.a(this.u, this.v);
               } else if (this.w > 0) {
                  var1.b(this.w);
               } else {
                  var1.g();
               }
            }

            this.x = true;
            this.r = 0L;
         }
      }
   }

   static {
      HashMap var0 = new HashMap();
      var0.put("мистический сундук", new EventConfig(new Color(138, 43, 226)));
      var0.put("метеоритный дождь", new EventConfig(new Color(255, 69, 0)));
      var0.put("маяк убийца", new EventConfig(new Color(220, 20, 60)));
      var0.put("алтарь", new EventConfig(new Color(75, 0, 130)));
      var0.put("вулкан", new EventConfig(new Color(178, 34, 34)));
      var0.put("загадочный маяк", new EventConfig(new Color(0, 191, 255)));
      l = Collections.unmodifiableMap(var0);
   }
}
