package pulse.features.cosmetic;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.features.cosmetic.loader.CosmeticLoader;
import pulse.features.cosmetic.model.CosmeticModel;
import pulse.utils.net.ApiRouter;

@Environment(EnvType.CLIENT)
public class CosmeticTextureManager {
   private static final int a = 6;
   private static final int b = 5000;
   private final Map<Integer, Identifier> c = new ConcurrentHashMap<>();
   private final Map<Integer, CosmeticTextureManager.CosmeticInfo> d = new ConcurrentHashMap<>();
   private final Map<String, Integer> e = new ConcurrentHashMap<>();
   private final Map<String, List<Integer>> f = new ConcurrentHashMap<>();
   private volatile boolean g = false;
   private final Map<Integer, CosmeticTextureManager.CapeAnim> h = new ConcurrentHashMap<>();

   private static List<String> c() {
      return ApiRouter.a();
   }

   public static CosmeticTextureManager a() {
      return CosmeticTextureManager.InstanceHolder.a;
   }

   private CosmeticTextureManager() {
   }

   private Path d() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cache");
   }

   private Path e() {
      return this.d().resolve("bundle.json");
   }

   private Path f() {
      return this.d().resolve("bundle.etag");
   }

   private String g() {
      try {
         Path var1 = this.f();
         if (Files.exists(var1)) {
            return new String(Files.readAllBytes(var1), StandardCharsets.UTF_8).trim();
         }
      } catch (Exception var2) {
      }

      return null;
   }

   private String h() {
      try {
         Path var1 = this.e();
         if (Files.exists(var1)) {
            return new String(Files.readAllBytes(var1), StandardCharsets.UTF_8);
         }
      } catch (Exception var2) {
      }

      return null;
   }

   private void a(String var1, String var2) {
      try {
         Files.createDirectories(this.d());
         Files.write(this.e(), var1.getBytes(StandardCharsets.UTF_8));
         if (var2 != null) {
            Files.write(this.f(), var2.getBytes(StandardCharsets.UTF_8));
         }
      } catch (Exception var4) {
         Pulse.m().warn("Не удалось сохранить cache bundle: {}", var4.getMessage());
      }
   }

   public void b() {
      new Thread(
            () -> {
               Pulse.m().info("Начало загрузки косметики (bundle)...");
               List var1 = c();
               int var2 = var1.size();

               for (int var3 = 0; var3 < var2; var3++) {
                  String var4 = (String)var1.get(var3);
                  String var5 = var4 + "/cosmetics/bundle";

                  String var6;
                  try {
                     var6 = new URL(var5).getHost();
                  } catch (Exception var24) {
                     var6 = var5;
                  }

                  try {
                     URL var7 = new URL(var5);
                     HttpURLConnection var8 = (HttpURLConnection)var7.openConnection();
                     var8.setRequestMethod("GET");
                     var8.setConnectTimeout(15000);
                     var8.setReadTimeout(30000);
                     String var9 = this.g();
                     if (var9 != null && !var9.isEmpty()) {
                        var8.setRequestProperty("If-None-Match", var9);
                     }

                     int var10 = var8.getResponseCode();
                     String var12 = var8.getHeaderField("ETag");
                     if (var10 == 304) {
                        String var13 = this.h();
                        if (var13 == null) {
                           Pulse.m().warn("Bundle: {} вернул 304, но cache отсутствует — пропускаю", var6);

                           try {
                              Files.deleteIfExists(this.f());
                           } catch (Exception var23) {
                           }

                           var8.disconnect();
                        } else {
                           Pulse.m().info("Bundle: cache актуален (304 от {}), загрузка с диска", var6);
                           String var11 = var13;

                           try {
                              this.b(var11);
                              this.g = true;
                              return;
                           } catch (Exception var25) {
                              Pulse.m().warn("Bundle: cache битый ({}) — удаляю и пробую следующий хост", var25.getMessage());

                              try {
                                 Files.deleteIfExists(this.e());
                              } catch (Exception var22) {
                              }

                              try {
                                 Files.deleteIfExists(this.f());
                              } catch (Exception var21) {
                              }
                           }
                        }
                     } else if (var10 == 200) {
                        InputStream var31 = var8.getInputStream();
                        ByteArrayOutputStream var14 = new ByteArrayOutputStream();
                        byte[] var15 = new byte[8192];

                        int var16;
                        while ((var16 = var31.read(var15)) != -1) {
                           var14.write(var15, 0, var16);
                        }

                        var31.close();
                        String var30 = var14.toString("UTF-8");

                        try {
                           this.b(var30);
                        } catch (Exception var26) {
                           Pulse.m().warn("Bundle: {} вернул 200, но это не JSON ({}) — пробую следующий хост", var6, var26.getMessage());
                           continue;
                        }

                        this.a(var30, var12);
                        Pulse.m()
                           .info(
                              "Bundle: получен свежий ответ от {} ({} KB), cache обновлён{}",
                              var6,
                              var30.length() / 1024,
                              var12 != null ? " (etag=" + var12 + ")" : ""
                           );
                        this.g = true;
                        return;
                     } else {
                        Pulse.m().warn("Bundle: {} вернул HTTP {} — пробую следующий хост", var6, var10);
                     }
                  } catch (SocketTimeoutException var27) {
                     Pulse.m().warn("Bundle: таймаут от {} — пробую следующий хост", var6);
                  } catch (Exception var28) {
                     Pulse.m().warn("Bundle: ошибка от {} ({}) — пробую следующий хост", var6, var28.getMessage());
                  }
               }

               String var29 = this.h();
               if (var29 != null) {
                  try {
                     this.b(var29);
                     this.g = true;
                     Pulse.m().info("Bundle: все API недоступны, загружено из локального cache");
                  } catch (Exception var20) {
                     Pulse.m().error("Bundle: все API недоступны, а локальный cache битый — косметика не загружена", (Throwable)var20);

                     try {
                        Files.deleteIfExists(this.e());
                     } catch (Exception var19) {
                     }

                     try {
                        Files.deleteIfExists(this.f());
                     } catch (Exception var18) {
                     }
                  }
               } else {
                  Pulse.m().error("Bundle: все API недоступны и локального cache нет — косметика не загружена");
               }
            },
            "Cosmetic-Bundle-Loader"
         )
         .start();
   }

   private void b(String var1) {
      JSONObject var2 = new JSONObject(var1);
      if (!var2.optBoolean("success", false)) {
         Pulse.m().warn("Сервер вернул ошибку при загрузке bundle косметики");
      } else {
         JSONArray var3 = var2.optJSONArray("data");
         if (var3 != null && var3.length() != 0) {
            Pulse.m().info("Bundle: получено {} косметических элементов", var3.length());

            for (int var4 = 0; var4 < var3.length(); var4++) {
               JSONObject var5 = var3.getJSONObject(var4);
               int var6 = var5.getInt("id");
               String var7 = var5.optString("type", "unknown");
               String var8 = var5.optString("name", "Unnamed");
               boolean var9 = var5.optBoolean("has_model", false);
               CosmeticTextureManager.CosmeticInfo var10 = new CosmeticTextureManager.CosmeticInfo(var6, var7, var8, var9 ? "inline" : null);
               this.d.put(var6, var10);
               if ("cape".equals(var7) && !var5.isNull("image_base64")) {
                  try {
                     String var21 = var5.getString("image_base64");
                     byte[] var23 = Base64.getDecoder().decode(var21);
                     if (!var5.isNull("cape_animation")) {
                        JSONObject var24 = var5.getJSONObject("cape_animation");
                        int var26 = var24.getInt("frameWidth");
                        int var15 = var24.getInt("frameHeight");
                        int var16 = var24.optInt("frameTime", 4);
                        this.a(var6, var23, var26, var15, var16);
                        Pulse.m().info("Bundle: загружен анимированный плащ {} (id={})", var8, var6);
                     } else {
                        NativeImage var25 = NativeImage.read(new ByteArrayInputStream(var23));
                        NativeImage var27 = this.a(var25);
                        if (var27 != var25) {
                           var25.close();
                        }

                        Identifier var28 = Identifier.of("pulse", "cape/" + var6);
                        this.c.put(var6, var28);
                        MinecraftClient.getInstance().execute(() -> {
                           NativeImageBackedTexture var3x = this.a(var28, var27);
                           MinecraftClient.getInstance().getTextureManager().registerTexture(var28, var3x);
                        });
                        Pulse.m().info("Bundle: загружен статичный плащ {} (id={}, {}x{})", var8, var6, var27.getWidth(), var27.getHeight());
                     }
                  } catch (Exception var19) {
                     Pulse.m().error("Bundle: ошибка загрузки плаща {} (id={})", var8, var6, var19);
                  }
               } else if (var9 && !var5.isNull("model_json")) {
                  try {
                     String var20 = var5.getJSONObject("model_json").toString();
                     CosmeticModel var22 = CosmeticLoader.a().a(var20, null, var6);
                     if (var22 != null) {
                        Pulse.m().info("Bundle: загружена 3D модель {} (id={})", var8, var6);
                     }
                  } catch (Exception var18) {
                     Pulse.m().error("Bundle: ошибка загрузки модели {} (id={})", var8, var6, var18);
                  }
               } else if (!var5.isNull("image_base64")) {
                  try {
                     String var11 = var5.getString("image_base64");
                     byte[] var12 = Base64.getDecoder().decode(var11);
                     NativeImage var13 = NativeImage.read(new ByteArrayInputStream(var12));
                     Identifier var14 = Identifier.of("pulse", "cosmetic/" + var6);
                     this.c.put(var6, var14);
                     MinecraftClient.getInstance().execute(() -> {
                        NativeImageBackedTexture var3x = this.a(var14, var13);
                        MinecraftClient.getInstance().getTextureManager().registerTexture(var14, var3x);
                     });
                     Pulse.m().info("Bundle: загружена текстура {} (id={})", var8, var6);
                  } catch (Exception var17) {
                     Pulse.m().error("Bundle: ошибка загрузки текстуры {} (id={})", var8, var6, var17);
                  }
               }
            }

            Pulse.m().info("Bundle: загрузка косметики завершена ({} элементов)", this.d.size());
         } else {
            Pulse.m().info("Нет доступной косметики");
         }
      }
   }

   private void c(int var1) {
      new Thread(() -> {
         int var2 = 0;
         int var3 = 0;

         while (var3 < 6) {
            String var4 = c().get(var2) + "/cosmetics/" + var1 + "/image";

            try {
               URL var5 = new URL(var4);
               HttpURLConnection var6 = (HttpURLConnection)var5.openConnection();
               var6.setRequestMethod("GET");
               var6.setConnectTimeout(10000);
               var6.setReadTimeout(10000);
               int var7 = var6.getResponseCode();
               if (var7 != 200) {
                  Pulse.m().warn("Не удалось загрузить текстуру косметики {}: HTTP {}", var1, var7);
                  return;
               }

               InputStream var8 = var6.getInputStream();
               ByteArrayOutputStream var9 = new ByteArrayOutputStream();
               byte[] var10 = new byte[4096];

               int var11;
               while ((var11 = var8.read(var10)) != -1) {
                  var9.write(var10, 0, var11);
               }

               var8.close();
               byte[] var12 = var9.toByteArray();
               Pulse.m().info("Загружено изображение косметики {}, размер {} байт", var1, var12.length);
               NativeImage var13 = NativeImage.read(new ByteArrayInputStream(var12));
               Identifier var14 = Identifier.of("pulse", "cosmetic/" + var1);
               MinecraftClient.getInstance().execute(() -> {
                  NativeImageBackedTexture var4x = this.a(var14, var13);
                  MinecraftClient.getInstance().getTextureManager().registerTexture(var14, var4x);
                  this.c.put(var1, var14);
                  Pulse.m().info("Текстура косметики {} зарегистрирована", var1);
               });
               return;
            } catch (SocketTimeoutException var16) {
               Pulse.m().warn("Таймаут загрузки текстуры косметики {} (попытка {}/{}, URL: {})", var1, var3 + 1, 6, var4);
               var2 = (var2 + 1) % c().size();
               if (var3 < 5) {
                  try {
                     Thread.sleep(5000L);
                  } catch (InterruptedException var15) {
                     Thread.currentThread().interrupt();
                     return;
                  }
               }

               var3++;
            } catch (Exception var17) {
               Pulse.m().error("Ошибка загрузки текстуры косметики {}", var1, var17);
               return;
            }
         }

         Pulse.m().error("Не удалось загрузить текстуру косметики {} после {} попыток", var1, 6);
      }, "Cosmetic-Texture-Loader-" + var1).start();
   }

   public Identifier a(int var1) {
      return this.c.get(var1);
   }

   private NativeImageBackedTexture a(Identifier var1, NativeImage var2) {
      return new NativeImageBackedTexture(var1::toString, var2);
   }

   public Identifier b(int var1) {
      CosmeticTextureManager.CapeAnim var2 = this.h.get(var1);
      if (var2 != null && var2.frames.length != 0) {
         long var3 = System.currentTimeMillis() / 50L;
         int var5 = (int)(var3 / var2.frameTime % var2.frames.length);
         return var2.frames[var5];
      } else {
         return null;
      }
   }

   public void a(int cosmeticId, byte[] imageData, int frameWidth, int frameHeight, int frameDurationTicks) {
      try {
         NativeImage spriteSheet = NativeImage.read(new ByteArrayInputStream(imageData));
         int sheetHeight = spriteSheet.getHeight();
         int frameCount = sheetHeight / frameHeight;
         if (frameCount <= 0) {
            Pulse.m().warn("Animated cape {}: invalid frame count ({}x{} / {})", cosmeticId, spriteSheet.getWidth(), sheetHeight, frameHeight);
            return;
         }

         int scale = Math.max(1, frameWidth / 22);
         int canvasWidth = 64 * scale;
         int canvasHeight = 32 * scale;
         Pulse.m().info("Animated cape {}: frame={}x{}, scale={}, canvas={}x{}", cosmeticId, frameWidth, frameHeight, scale, canvasWidth, canvasHeight);
         Identifier[] frames = new Identifier[frameCount];

         for (int frameIndex = 0; frameIndex < frameCount; frameIndex++) {
            NativeImage frameImage = new NativeImage(canvasWidth, canvasHeight, true);
            int sourceY = frameIndex * frameHeight;
            for (int y = 0; y < frameHeight && y < canvasHeight; y++) {
               for (int x = 0; x < frameWidth && x < canvasWidth; x++) {
                  frameImage.setColorArgb(x, y, spriteSheet.getColorArgb(x, sourceY + y));
               }
            }

            Identifier frameId = Identifier.of("pulse", "cape/" + cosmeticId + "_f" + frameIndex);
            frames[frameIndex] = frameId;
            Runnable registerFrame = () -> {
               NativeImageBackedTexture frameTexture = this.a(frameId, frameImage);
               MinecraftClient.getInstance().getTextureManager().registerTexture(frameId, frameTexture);
            };
            if (MinecraftClient.getInstance().isOnThread()) {
               registerFrame.run();
            } else {
               MinecraftClient.getInstance().execute(registerFrame);
            }
         }

         this.h.put(cosmeticId, new CosmeticTextureManager.CapeAnim(frames, frameDurationTicks));
         this.c.put(cosmeticId, frames[0]);
         Pulse.m().info("Loaded animated cape {} ({} frames, {}t/frame)", cosmeticId, frameCount, frameDurationTicks);
      } catch (Exception exception) {
         Pulse.m().error("Failed to load animated cape {}", cosmeticId, exception);
      }
   }

   private NativeImage a(NativeImage var1) {
      int var2 = var1.getWidth();
      int var3 = var1.getHeight();
      if (var2 > 0 && var3 > 0 && var2 * 32 == var3 * 64) {
         return var1;
      } else {
         int var4 = Math.max(1, var2 / 22);
         int var5 = 64 * var4;
         int var6 = 32 * var4;
         NativeImage var7 = new NativeImage(var5, var6, true);

         for (int var8 = 0; var8 < var3 && var8 < var6; var8++) {
            for (int var9 = 0; var9 < var2 && var9 < var5; var9++) {
               var7.setColorArgb(var9, var8, var1.getColorArgb(var9, var8));
            }
         }

         return var7;
      }
   }

   public Integer a(String var1) {
      return this.e.get(var1);
   }

   private void i() {
      try {
         Path var1 = MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cosmetics");
         if (!Files.isDirectory(var1)) {
            return;
         }

         File[] var2 = var1.toFile().listFiles((var0, var1x) -> var1x.endsWith(".json"));
         if (var2 == null || var2.length == 0) {
            return;
         }

         for (File var6 : var2) {
            try {
               String var7 = new String(Files.readAllBytes(var6.toPath()), StandardCharsets.UTF_8);
               JsonObject var8 = new JsonParser().parse(var7).getAsJsonObject();
               if (var8.has("type") && "cape".equals(var8.get("type").getAsString())) {
                  this.a(var8);
               } else {
                  CosmeticModel var9 = CosmeticLoader.a().a(var7);
                  if (var9 != null) {
                     String var10 = switch (var9.f().a()) {
                        case 1 -> var9.c() == 2 ? "pet" : "wings";
                        case 2 -> "hat";
                        default -> "wings";
                     };
                     this.f.computeIfAbsent(var10, var0 -> Collections.synchronizedList(new ArrayList<>())).add(var9.b());
                     Pulse.m().info("Loaded local cosmetic: {} (id={}, type={})", var9.a(), var9.b(), var10);
                  }
               }
            } catch (Exception var11) {
               Pulse.m().error("Failed to load local cosmetic: {}", var6.getName(), var11);
            }
         }

         for (Entry var14 : this.f.entrySet()) {
            if (!((List)var14.getValue()).isEmpty()) {
               this.e.put((String)var14.getKey(), (Integer)((List)var14.getValue()).get(0));
               Pulse.m().info("Auto-equipped local {}: id={} (total: {})", var14.getKey(), ((List)var14.getValue()).get(0), ((List)var14.getValue()).size());
            }
         }
      } catch (Exception var12) {
         Pulse.m().error("Error scanning local cosmetics", (Throwable)var12);
      }
   }

   private void a(JsonObject var1) {
      try {
         String var2 = var1.has("name") ? var1.get("name").getAsString() : "Cape";
         int var3 = var1.has("id") ? var1.get("id").getAsInt() : var2.hashCode();
         String var4 = var1.has("texture") ? var1.get("texture").getAsString() : null;
         if (var4 == null) {
            return;
         }

         byte[] var5 = Base64.getDecoder().decode(var4);
         if (var1.has("capeAnimation")) {
            JsonObject var6 = var1.getAsJsonObject("capeAnimation");
            int var7 = var6.get("frameWidth").getAsInt();
            int var8 = var6.get("frameHeight").getAsInt();
            int var9 = var6.has("frameTime") ? var6.get("frameTime").getAsInt() : 4;
            this.a(var3, var5, var7, var8, var9);
         } else {
            NativeImage var12 = NativeImage.read(new ByteArrayInputStream(var5));
            NativeImage var13 = this.a(var12);
            if (var13 != var12) {
               var12.close();
            }

            Identifier var14 = Identifier.of("pulse", "cape/" + var3);
            Runnable var10 = () -> {
               NativeImageBackedTexture var4x = this.a(var14, var13);
               MinecraftClient.getInstance().getTextureManager().registerTexture(var14, var4x);
               this.c.put(var3, var14);
            };
            if (MinecraftClient.getInstance().isOnThread()) {
               var10.run();
            } else {
               MinecraftClient.getInstance().execute(var10);
            }

            this.c.put(var3, var14);
            Pulse.m().info("Loaded static cape: {} (id={}, {}x{})", var2, var3, var13.getWidth(), var13.getHeight());
         }

         this.f.computeIfAbsent("cape", var0 -> Collections.synchronizedList(new ArrayList<>())).add(var3);
         Pulse.m().info("Loaded local cape: {} (id={})", var2, var3);
      } catch (Exception var11) {
         Pulse.m().error("Failed to load local cape", (Throwable)var11);
      }
   }

   private void d(int var1) {
      new Thread(() -> {
         int var1x = 0;
         int var2 = 0;

         while (var2 < 6) {
            String var3 = c().get(var1x) + "/cosmetics/" + var1 + "/model";

            try {
               URL var4 = new URL(var3);
               HttpURLConnection var5 = (HttpURLConnection)var4.openConnection();
               var5.setRequestMethod("GET");
               var5.setConnectTimeout(10000);
               var5.setReadTimeout(10000);
               int var6 = var5.getResponseCode();
               if (var6 != 200) {
                  Pulse.m().warn("Failed to load cosmetic model {}: HTTP {}", var1, var6);
                  return;
               }

               InputStream var7 = var5.getInputStream();
               ByteArrayOutputStream var8 = new ByteArrayOutputStream();
               byte[] var9 = new byte[4096];

               int var10;
               while ((var10 = var7.read(var9)) != -1) {
                  var8.write(var9, 0, var10);
               }

               var7.close();
               String var11 = var8.toString(StandardCharsets.UTF_8.name());
               CosmeticModel var12 = CosmeticLoader.a().a(var11, null, var1);
               if (var12 != null) {
                  Pulse.m().info("Loaded 3D cosmetic model: {} (id={})", var12.a(), var12.b());
               }

               return;
            } catch (SocketTimeoutException var14) {
               Pulse.m().warn("Таймаут загрузки модели косметики {} (попытка {}/{}, URL: {})", var1, var2 + 1, 6, var3);
               var1x = (var1x + 1) % c().size();
               if (var2 < 5) {
                  try {
                     Thread.sleep(5000L);
                  } catch (InterruptedException var13) {
                     Thread.currentThread().interrupt();
                     return;
                  }
               }

               var2++;
            } catch (Exception var15) {
               Pulse.m().error("Error loading cosmetic model {}", var1, var15);
               return;
            }
         }

         Pulse.m().error("Не удалось загрузить модель косметики {} после {} попыток", var1, 6);
      }, "Cosmetic-Model-Loader-" + var1).start();
   }

   @Environment(EnvType.CLIENT)
   private record CapeAnim(Identifier[] frames, int frameTime) {
   }

   @Environment(EnvType.CLIENT)
   public static class CosmeticInfo {
      private final int a;
      private final String b;
      private final String c;
      private final String d;

      public CosmeticInfo(int var1, String var2, String var3, String var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }

      public int a() {
         return this.a;
      }

      public String b() {
         return this.b;
      }

      public String c() {
         return this.c;
      }

      public String d() {
         return this.d;
      }

      public boolean e() {
         return this.d != null && !this.d.isEmpty();
      }
   }

   @Environment(EnvType.CLIENT)
   private static class InstanceHolder {
      private static final CosmeticTextureManager a = new CosmeticTextureManager();
   }
}
