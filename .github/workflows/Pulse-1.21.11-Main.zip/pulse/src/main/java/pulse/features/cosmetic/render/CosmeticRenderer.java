package pulse.features.cosmetic.render;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import pulse.features.cosmetic.geckolib.GeckolibCosmeticRenderer;
import pulse.features.cosmetic.model.CosmeticModel;
import pulse.features.cosmetic.model.ModelPosition;

@Environment(EnvType.CLIENT)
public class CosmeticRenderer {
   private static CosmeticRenderer a;
   private final GeckolibCosmeticRenderer b = GeckolibCosmeticRenderer.a();
   private final RenderStack c = new RenderStack();
   private static final long d = 10000L;
   private final Map<Integer, Vec3d> e = new ConcurrentHashMap<>();
   private final Map<Integer, Long> f = new ConcurrentHashMap<>();
   private static final float g = 180.0F / (float)Math.PI;

   public static CosmeticRenderer a() {
      if (a == null) {
         a = new CosmeticRenderer();
      }

      return a;
   }

   public void a(
      CosmeticModel var1, AbstractClientPlayerEntity var2, MatrixStack var3, OrderedRenderCommandQueue var4, int var5, PlayerEntityModel var6, float var7
   ) {
      if (var1 != null && var1.e() != null) {
         this.c.a(var3);
         this.c.a();
         float var8 = this.a(var1, var6);
         this.c.f(180.0F);
         this.c.a(var1.h(), var1.i() + var8, var1.j());
         this.c.e(var1.k());
         this.c.d(var1.l());
         this.c.f(var1.m());
         this.c.b(var1.g(), var1.g(), var1.g());
         GeckolibCosmeticRenderer.AnimState var9 = GeckolibCosmeticRenderer.AnimState.a;
         if (var2 != null) {
            if (var2.isGliding()) {
               var9 = GeckolibCosmeticRenderer.AnimState.c;
            } else if (var2.getAbilities().flying) {
               var9 = GeckolibCosmeticRenderer.AnimState.h;
            } else if (var2.isSwimming()) {
               var9 = GeckolibCosmeticRenderer.AnimState.f;
            } else if (var2.isSneaking()) {
               var9 = GeckolibCosmeticRenderer.AnimState.e;
            } else if (var2.getVelocity().x * var2.getVelocity().x + var2.getVelocity().z * var2.getVelocity().z > 0.0030000000109143875) {
               var9 = GeckolibCosmeticRenderer.AnimState.b;
            } else if (this.a(var2)) {
               var9 = GeckolibCosmeticRenderer.AnimState.d;
            }
         }

         this.b.a(var1, var3, var4, var5, var9);
         this.c.b();
      }
   }

   private float a(CosmeticModel var1, PlayerEntityModel var2) {
      float var3 = 0.0F;
      ModelPosition var4 = var1.f();
      if (var2 == null) {
         return var3;
      } else {
         switch (var4) {
            case c:
               this.a(var2.head);
               break;
            case d:
               var3 = 0.75F;
               break;
            case b:
               this.a(var2.body);
               var3 = -0.3F;
               break;
            case e:
               this.a(var2.rightArm);
               var3 = -0.25F;
               break;
            case f:
               this.a(var2.leftArm);
               var3 = -0.25F;
               break;
            case g:
               this.a(var2.rightLeg);
               var3 = -0.35F;
               break;
            case h:
               this.a(var2.leftLeg);
               var3 = -0.35F;
            case a:
         }

         return var3;
      }
   }

   private void a(ModelPart var1) {
      this.c.a(var1.originX * 0.0625F, var1.originY * 0.0625F, var1.originZ * 0.0625F);
      this.c.d(var1.pitch * (180.0F / (float)Math.PI), var1.yaw * (180.0F / (float)Math.PI), var1.roll * (180.0F / (float)Math.PI));
   }

   public void b() {
      this.e.clear();
      this.f.clear();
   }

   private boolean a(AbstractClientPlayerEntity var1) {
      int var2 = var1.getId();
      Vec3d var3 = var1.getEntityPos();
      Vec3d var4 = this.e.get(var2);
      long var5 = System.currentTimeMillis();
      if (var4 != null && !(var4.squaredDistanceTo(var3) > 0.0010000000369009285)) {
         Long var7 = this.f.get(var2);
         return var7 != null && var5 - var7 > 10000L;
      } else {
         this.e.put(var2, var3);
         this.f.put(var2, var5);
         return false;
      }
   }
}
