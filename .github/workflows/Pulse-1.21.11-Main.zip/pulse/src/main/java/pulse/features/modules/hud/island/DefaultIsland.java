package pulse.features.modules.hud.island;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.features.modules.hud.components.WatermarkComponent;
import pulse.features.modules.hud.components.WatermarkSettingsPanel;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@Environment(EnvType.CLIENT)
public class DefaultIsland extends Island {
   private static final Color k = new Color(255, 255, 255);
   private static final Color l = new Color(223, 223, 243);
   private static final Color m = new Color(255, 255, 255, 77);
   private static final Color n = new Color(76, 46, 212, 100);
   private static final Color o = new Color(115, 83, 255);
   private static final Color p = new Color(70, 46, 174);
   private static final float q = 30.0F;
   private static final float r = 5.0F;
   private static final float s = 5.0F;
   private final String t = "pulsevisuals.pro";
   private final Animation u = new Animation();
   private boolean v = true;
   private int w = -1;
   private int x = -1;
   private String y = "0 ms";
   private String z = "0 FPS";
   private float A;
   private float B;

   private void a(FontRenderer var1) {
      int var2 = this.o();
      int var3 = this.n();
      if (var2 != this.w) {
         this.w = var2;
         this.y = var2 + " ms";
         this.A = var1.a(this.y);
      }

      if (var3 != this.x) {
         this.x = var3;
         this.z = var3 + " FPS";
         this.B = var1.a(this.z);
      }
   }

   public DefaultIsland() {
      this.e = 7.0F;
      this.f = 3.0F;
      this.h = Long.MAX_VALUE;
      this.u.d(1.0);
   }

   private boolean m() {
      WatermarkComponent var1 = WatermarkComponent.a();
      if (var1 == null) {
         return true;
      } else {
         WatermarkSettingsPanel var2 = var1.i();
         return var2 == null ? true : var2.j();
      }
   }

   @Override
   public float a() {
      FontRenderer var1 = Fonts.b[15];
      FontRenderer var2 = Fonts.a[15];
      float var3 = var1.a("pulsevisuals.pro");
      float var4 = 15.0F;
      float var5 = var4 + 5.0F + var3 + 1.5F;
      boolean var6 = this.m();
      if (var6 != this.v) {
         this.v = var6;
         this.u.a(var6 ? 1.0 : 0.0, 0.15000007478549057, Easings.k);
      }

      this.u.a();
      float var7 = (float)this.u.j();
      if (var7 < 0.01F) {
         return var5;
      } else {
         float var8 = var2.a("/");
         this.a(var2);
         float var9 = 5.0F + var8 + 5.0F + this.A + 5.0F + var8 + 5.0F + this.B;
         return var5 + var9 * var7;
      }
   }

   @Override
   public float b() {
      return 16.0F;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      FontRenderer var8 = Fonts.b[15];
      FontRenderer var9 = Fonts.a[15];
      float var11 = var4 + var6 / 2.0F;
      int var12 = (int)(var7 * 255.0F);
      FontRenderer var13 = Fonts.d[30];
      float var14 = var13.a("\ue91e");
      float var15 = var13.b("\ue91e");
      float var16 = var11 - var15 / 4.0F;
      Color var17 = this.a(n, var7);
      var2.a(var3 + 1.0F, var16 + 2.0F, 6.5F, var17, var1);
      Color var18 = this.a(o, var7);
      Color var19 = this.a(p, var7);
      var13.a("\ue91e", var3 + 1.0F, var16, var18, var19, var1);
      float var10 = var3 + (var14 + 5.0F);
      Color var20 = new Color(k.getRed(), k.getGreen(), k.getBlue(), var12);
      new Color(l.getRed(), l.getGreen(), l.getBlue(), var12);
      new Color(m.getRed(), m.getGreen(), m.getBlue(), (int)(m.getAlpha() * var7));
      float var23 = var11 - var8.b("pulsevisuals.pro") / 4.0F - 0.5F;
      var8.a("pulsevisuals.pro", var10, var23, var20, var1);
      float var24 = (float)this.u.j();
      if (!(var24 < 0.01F)) {
         float var25 = var7 * var24;
         Color var26 = new Color(l.getRed(), l.getGreen(), l.getBlue(), (int)(var25 * 255.0F));
         Color var27 = new Color(m.getRed(), m.getGreen(), m.getBlue(), (int)(m.getAlpha() * var25));
         this.a(var9);
         var10 += var8.a("pulsevisuals.pro") + 5.0F;
         var9.a("/", var10, var23, var27, var1);
         var10 += var9.a("/") + 5.0F;
         var9.a(this.y, var10, var23, var26, var1);
         var10 += this.A + 5.0F;
         var9.a("/", var10, var23, var27, var1);
         var10 += var9.a("/") + 5.0F;
         var9.a(this.z, var10, var23, var26, var1);
      }
   }

   private int n() {
      return a.getCurrentFps();
   }

   private int o() {
      if (a.player == null) {
         return 0;
      } else {
         ClientPlayNetworkHandler var1 = a.getNetworkHandler();
         if (var1 == null) {
            return 0;
         } else {
            PlayerListEntry var2 = var1.getPlayerListEntry(a.player.getUuid());
            return var2 == null ? 0 : var2.getLatency();
         }
      }
   }
}
