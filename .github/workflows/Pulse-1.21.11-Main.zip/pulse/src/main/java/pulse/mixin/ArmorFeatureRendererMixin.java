package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.emote.render.BobjLegSegments;
import pulse.utils.render.ArmorRenderState;

@Environment(EnvType.CLIENT)
@Mixin({ArmorFeatureRenderer.class})
public class ArmorFeatureRendererMixin {
   @Inject(
      method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V"},
      at = {@At("HEAD")}
   )
   private void captureState(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, BipedEntityRenderState var4, float var5, float var6, CallbackInfo var7) {
      ArmorRenderState.a(var4.hurt);
   }

   @Inject(
      method = {"renderArmor"},
      at = {@At("HEAD")}
   )
   private void pulse$markArmorSlot(
      MatrixStack var1, OrderedRenderCommandQueue var2, ItemStack var3, EquipmentSlot var4, int var5, BipedEntityRenderState var6, CallbackInfo var7
   ) {
      BobjLegSegments.a(var4 == EquipmentSlot.LEGS, var4 == EquipmentSlot.LEGS || var4 == EquipmentSlot.FEET);
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V"},
      at = {@At("RETURN")}
   )
   private void clearState(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, BipedEntityRenderState var4, float var5, float var6, CallbackInfo var7) {
      ArmorRenderState.b();
   }
}
