package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class RenderHeadLayerEvent extends Event {
   private final LivingEntity a;
   private final LivingEntityRenderState b;
   private final MatrixStack c;
   private final EntityModel<?> d;
   private final OrderedRenderCommandQueue e;
   private final VertexConsumerProvider f;

   public RenderHeadLayerEvent(
      LivingEntity var1, LivingEntityRenderState var2, MatrixStack var3, EntityModel<?> var4, OrderedRenderCommandQueue var5, VertexConsumerProvider var6
   ) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
   }

   public RenderHeadLayerEvent(LivingEntity var1, LivingEntityRenderState var2, MatrixStack var3, EntityModel<?> var4, OrderedRenderCommandQueue var5) {
      this(var1, var2, var3, var4, var5, null);
   }

   @Generated
   public LivingEntity a() {
      return this.a;
   }

   @Generated
   public LivingEntityRenderState b() {
      return this.b;
   }

   @Generated
   public MatrixStack c() {
      return this.c;
   }

   @Generated
   public EntityModel<?> d() {
      return this.d;
   }

   @Generated
   public OrderedRenderCommandQueue e() {
      return this.e;
   }

   @Generated
   public VertexConsumerProvider f() {
      return this.f;
   }
}
