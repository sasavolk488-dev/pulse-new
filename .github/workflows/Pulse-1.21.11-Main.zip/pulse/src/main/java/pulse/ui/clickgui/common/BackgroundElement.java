package pulse.ui.clickgui.common;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class BackgroundElement implements GuiElement {
   private static final float a = 90.0F;
   private static final float b = 0.5F;

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      float var7 = ClickGuiScreen.e();
      float var8 = ClickGuiScreen.f();
      float var9 = ClickGuiScreen.g();
      var2.a(var3 - 0.5F, var4 - 0.5F, var7 + 1.0F, var8 + 1.0F, var9, ClickGuiColors.w, ClickGuiColors.w, ClickGuiColors.w, ClickGuiColors.w, var1);
      var2.a(var3, var4, var7, var8, var9, ClickGuiColors.e, ClickGuiColors.e, ClickGuiColors.f, ClickGuiColors.f, var1);
   }

   public void b(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      float var7 = ClickGuiScreen.e();
      float var8 = ClickGuiScreen.f();
      float var9 = ClickGuiScreen.g();
      var2.a().a(var3, var4, var7, var8, var9, var1);
      var2.a(var3 + var7 / 2.0F - 90.0F, var4 - var8 / 2.0F, 90.0F, ClickGuiColors.a(ClickGuiColors.y, 25), var1);
      var2.a().a(var1);
   }

   @Override
   public void a(float var1, float var2, int var3, int var4) {
   }
}
