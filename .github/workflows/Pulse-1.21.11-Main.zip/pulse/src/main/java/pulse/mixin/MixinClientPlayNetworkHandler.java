package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.GameJoinEvent;
import pulse.core.event.impl.GameLeaveEvent;
import pulse.core.event.impl.TotemPopEvent;
import pulse.services.tracker.v2.ModUserTrackerV2;
import pulse.utils.game.TotemCache;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayNetworkHandler.class})
public class MixinClientPlayNetworkHandler {
   @Inject(
      method = {"onEntityStatus"},
      at = {@At("HEAD")}
   )
   private void onEntityStatus(EntityStatusS2CPacket var1, CallbackInfo var2) {
      MinecraftClient var3 = MinecraftClient.getInstance();
      if (var3.isOnThread()) {
         if (var1.getStatus() == 35 && var1.getEntity(var3.world) instanceof LivingEntity var5) {
            EventHandler.a.post(new TotemPopEvent(var5, TotemCache.a(var5.getUuid())));
         }
      }
   }

   @Inject(
      method = {"onGameJoin"},
      at = {@At("TAIL")}
   )
   private void onGameJoin(GameJoinS2CPacket var1, CallbackInfo var2) {
      EventHandler.a.post(new GameJoinEvent());
      ModUserTrackerV2.d().a();
   }

   @Inject(
      method = {"onPlayerList"},
      at = {@At("RETURN")}
   )
   private void onPlayerList(PlayerListS2CPacket var1, CallbackInfo var2) {
      ModUserTrackerV2.d().a(var1);
   }

   @Inject(
      method = {"clearWorld"},
      at = {@At("HEAD")}
   )
   private void onClearWorld(CallbackInfo var1) {
      TotemCache.b();
      ModUserTrackerV2.d().b();
      EventHandler.a.post(new GameLeaveEvent());
   }
}
