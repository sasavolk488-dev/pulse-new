package pulse.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import it.unimi.dsi.fastutil.ints.IntList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;

@Environment(EnvType.CLIENT)
@Mixin(
   targets = {"net/minecraft/client/particle/FireworksSparkParticle$FireworkParticle"}
)
public class FireworksSparkParticleMixin {
   @WrapMethod(
      method = {"addExplosionParticle"}
   )
   private void pulse$guardNullSpark(
      double var1,
      double var3,
      double var5,
      double var7,
      double var9,
      double var11,
      IntList var13,
      IntList var14,
      boolean var15,
      boolean var16,
      Operation<Void> var17
   ) {
      try {
         var17.call(var1, var3, var5, var7, var9, var11, var13, var14, var15, var16);
      } catch (NullPointerException var19) {
      }
   }
}
