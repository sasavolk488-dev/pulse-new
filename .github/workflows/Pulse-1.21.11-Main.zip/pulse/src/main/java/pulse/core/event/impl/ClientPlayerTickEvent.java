package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class ClientPlayerTickEvent extends Event {
   private final ClientPlayerTickEvent.State a;

   public ClientPlayerTickEvent(ClientPlayerTickEvent.State var1) {
      this.a = var1;
   }

   @Generated
   public ClientPlayerTickEvent.State a() {
      return this.a;
   }

   @Environment(EnvType.CLIENT)
   public static enum State {
      a,
      b;

      private static ClientPlayerTickEvent.State[] a() {
         return new ClientPlayerTickEvent.State[]{a, b};
      }
   }
}
