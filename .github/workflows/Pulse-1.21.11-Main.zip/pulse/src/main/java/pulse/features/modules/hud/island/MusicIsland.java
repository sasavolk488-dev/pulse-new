package pulse.features.modules.hud.island;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import javax.imageio.ImageIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.music.MusicHandler;
import pulse.core.handler.impl.music.MusicState;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class MusicIsland extends Island {
   private static final Color k = new Color(255, 255, 255);
   private static final Color l = new Color(223, 223, 243);
   private static final Color m = new Color(49, 49, 69);
   private static final Color n = new Color(49, 49, 69);
   private static final Color o = new Color(255, 255, 255);
   private static final Color p = new Color(15, 15, 20);
   private static final float q = 12.0F;
   private static final float r = 8.0F;
   private static final float s = 24.0F;
   private static final float t = 6.0F;
   private static final float u = 8.0F;
   private static final float v = 5.0F;
   private static final float w = 25.0F;
   private static final float x = 103.0F;
   private static final float y = 147.5F;
   private static final float z = 65.0F;
   private static final float A = 9.5F;
   private static final float B = 7.0F;
   private static final float C = 31.0F;
   private static final float D = 10.0F;
   private static final float E = 7.5F;
   private static final float F = 70.0F;
   private static final float G = 12.0F;
   private static final float H = 20.0F;
   private static final long I = 2500L;
   private static final long J = 1500L;
   private static final long K = 8000L;
   private static final int L = 6;
   private static final float M = 2.0F;
   private static final float N = 0.5F;
   private static final float O = 12.0F;
   private static final float P = 16.0F;
   private static final float Q = 2.0F;
   private static final float R = 1.0F;
   private static final float S = 4.0F;
   private static final float T = 3.0F;
   private static final float U = 32.0F;
   private static final float V = 32.0F;
   private static final float W = 0.0F;
   private byte[] X = null;
   private Identifier Y = null;
   private NativeImageBackedTexture Z = null;
   private volatile int aa = 0;
   private boolean ab = false;
   private final Animation ac = new Animation();
   private float ad;
   private float ae;
   private float af;
   private float ag;
   private float ah;
   private float ai;
   private float aj;
   private float ak;
   private float al;
   private float am;
   private float an;
   private float ao;
   private float ap;
   private boolean aq = false;
   private float ar;
   private float as;
   private float at;
   private float au;
   private boolean av = false;
   private final Animation aw = new Animation();
   private final Animation ax = new Animation();
   private final Animation ay = new Animation();
   private boolean az;
   private boolean aA;
   private boolean aB;
   private final Animation aC = new Animation();
   private final Animation aD = new Animation();
   private final Animation aE = new Animation();
   private final Animation aF = new Animation();
   private boolean aG = false;
   private final Animation aH = new Animation();
   private final Animation aI = new Animation();
   private String aJ = "";
   private final Animation aK = new Animation();
   private boolean aL = false;
   private double aM = 0.0;
   private double aN = 0.0;
   private long aO = 0L;
   private long aP = 0L;
   private boolean aQ = false;
   private boolean aR = false;
   private static final double aS = 0.25;

   public MusicIsland() {
      this.e = 9.5F;
      this.f = 7.0F;
      this.h = Long.MAX_VALUE;
      this.ac.d(0.0);
      this.aw.d(0.0);
      this.ax.d(0.0);
      this.ay.d(0.0);
      this.aC.d(0.0);
      this.aD.d(0.0);
      this.aE.d(0.0);
      this.aF.d(0.0);
      this.aH.d(0.0);
      this.aI.d(1.0);
      this.aK.d(0.0);
   }

   private MusicHandler q() {
      return HandlerRegistry.j;
   }

   private MusicState r() {
      MusicHandler var1 = this.q();
      return var1 != null ? var1.i() : null;
   }

   @Override
   public void e() {
      super.e();
      this.ac.a();
      this.e = 9.5F;
      this.f = 7.0F;
      float var1 = (float)this.ac.j();
      MusicState var2 = this.r();
      if (var2 != null) {
         byte[] var3 = var2.p();
         if (var2.q()) {
            if (var3 != null && var3.length > 0) {
               this.a(var3);
            } else {
               this.Y = null;
               this.X = null;
            }

            var2.f();
         } else if (this.Y == null && this.X == null && var3 != null && var3.length > 0) {
            this.a(var3);
         }

         this.aw.a();
         this.ax.a();
         this.ay.a();
         this.aC.a();
         this.aD.a();
         this.aE.a();
         this.aF.a();
         this.aH.a();
         this.aI.a();
         this.aK.a();
         boolean var4 = var2.c();
         if (var4 != this.aG) {
            this.aG = var4;
            this.aF.a(var4 ? 1.0 : 0.0, 0.20000004519243691, Easings.k);
         }

         boolean var5 = !var4;
         if (var5 && this.aH.j() < 0.5) {
            this.aH.a(1.0, 0.20000004519243691, Easings.k);
         } else if (!var5 && this.aH.j() > 0.5) {
            this.aH.a(0.0, 0.20000004519243691, Easings.k);
         }

         String var6 = var2.n();
         if (!var6.equals(this.aJ)) {
            this.aJ = var6;
            this.aI.d(0.0);
            this.aI.a(1.0, 0.25, Easings.k);
            this.aQ = false;
            this.aR = false;
         }

         FontRenderer var7 = Fonts.b[14];
         FontRenderer var8 = Fonts.b[15];
         FontRenderer var9 = Fonts.a[13];
         float var10 = this.a(25.0F, 70.0F, var1);
         FontRenderer var11 = var1 < 0.2F ? var7 : var8;
         float var12 = var11.a(var6);
         boolean var13 = var12 > var10;
         if (var13 && !this.aQ) {
            this.aQ = true;
            this.aO = System.currentTimeMillis();
         } else if (!var13) {
            this.aQ = false;
         }

         String var14 = var2.o();
         float var15 = var9.a(var14);
         boolean var16 = var15 > 70.0F && var1 > 0.3F;
         if (var16 && !this.aR) {
            this.aR = true;
            this.aP = System.currentTimeMillis();
         } else if (!var16) {
            this.aR = false;
         }
      }
   }

   private void s() {
      MusicState var1 = this.r();
      if (this.aq && var1 != null) {
         double var2 = this.aM;
         double var4 = this.aN;
         boolean var6 = this.az;
         this.az = this.a(var2, var4, this.ah, this.ai, this.aj, this.aj);
         if (this.az != var6) {
            this.aw.a(this.az ? 1.0 : 0.0, 0.1500000000000755, Easings.k);
         }

         boolean var7 = this.aA;
         this.aA = this.a(var2, var4, this.ak, this.al, this.am, this.am);
         if (this.aA != var7) {
            this.ax.a(this.aA ? 1.0 : 0.0, 0.1500000000000755, Easings.k);
         }

         boolean var8 = this.aB;
         this.aB = this.a(var2, var4, this.an, this.ao, this.ap, this.ap);
         if (this.aB != var8) {
            this.ay.a(this.aB ? 1.0 : 0.0, 0.1500000000000755, Easings.k);
         }

         if (this.av) {
            boolean var9 = this.aL;
            float var10 = 4.0F;
            this.aL = var2 >= this.ar - var10 && var2 <= this.ar + this.at + var10 && var4 >= this.as - var10 && var4 <= this.as + this.au + var10;
            if (this.aL != var9 || var1.y()) {
               this.aK.a(!this.aL && !var1.y() ? 0.0 : 1.0, 0.1500000000000755, Easings.k);
            }
         }
      } else {
         this.az = false;
         this.aA = false;
         this.aB = false;
         this.aL = false;
      }
   }

   public void m() {
      if (this.aq || this.av) {
         double var1 = this.aM;
         double var3 = this.aN;
         boolean var5 = false;
         if (this.aq) {
            if (this.a(var1, var3, this.ah, this.ai, this.aj, this.aj)) {
               var5 = true;
            }

            if (this.a(var1, var3, this.ak, this.al, this.am, this.am)) {
               var5 = true;
            }

            if (this.a(var1, var3, this.an, this.ao, this.ap, this.ap)) {
               var5 = true;
            }
         }

         if (this.av) {
            float var6 = 4.0F;
            if (var1 >= this.ar - var6 && var1 <= this.ar + this.at + var6 && var3 >= this.as - var6 && var3 <= this.as + this.au + var6) {
               var5 = true;
            }
         }

         if (var5) {
            MouseUtil.g();
         }
      }
   }

   private void a(byte[] var1) {
      int var2 = ++this.aa;
      this.X = var1;
      Util.getIoWorkerExecutor().execute(() -> {
         try {
            BufferedImage var3 = ImageIO.read(new ByteArrayInputStream(var1));
            if (var3 == null) {
               return;
            }

            int var4 = var3.getWidth();
            int var5 = var3.getHeight();
            int[] var6 = var3.getRGB(0, 0, var4, var5, null, 0, var4);
            NativeImage var7 = new NativeImage(var4, var5, false);

            for (int var8 = 0; var8 < var6.length; var8++) {
               var7.setColorArgb(var8 % var4, var8 / var4, var6[var8]);
            }

            a.execute(() -> {
               if (var2 != this.aa) {
                  var7.close();
               } else {
                  if (this.Z != null) {
                     this.Z.close();
                  }

                  this.Z = new NativeImageBackedTexture(() -> "pulse-music-cover", var7);
                  this.Y = Identifier.of("pulse", "music_island_cover");
                  a.getTextureManager().registerTexture(this.Y, this.Z);
               }
            });
         } catch (Exception var9) {
         }
      });
   }

   public void a(double var1, double var3) {
      this.aM = var1;
      this.aN = var3;
      this.t();
      this.s();
   }

   public void n() {
      if (this.ab) {
         this.ab = false;
         this.ac.a(0.0, 0.25, Easings.k);
      }

      this.az = false;
      this.aA = false;
      this.aB = false;
      this.aL = false;
   }

   private void t() {
      boolean var1 = this.ab;
      this.ab = this.aM >= this.ad && this.aM <= this.ad + this.af && this.aN >= this.ae && this.aN <= this.ae + this.ag;
      if (this.ab != var1) {
         this.ac.a(this.ab ? 1.0 : 0.0, 0.25, Easings.k);
      }
   }

   @Override
   public float a() {
      float var1 = (float)this.ac.j();
      return this.a(103.0F, 147.5F, var1);
   }

   @Override
   public float b() {
      float var1 = (float)this.ac.j();
      return this.a(12.0F, 65.0F, var1);
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      this.ad = var3 - this.e;
      this.ae = var4 - this.f;
      this.af = var5 + this.e * 2.0F;
      this.ag = var6 + this.f * 2.0F;
      MusicState var8 = this.r();
      if (var8 != null) {
         float var9 = (float)this.ac.j();
         int var10 = (int)(var7 * 255.0F);
         FontRenderer var11 = Fonts.b[15];
         FontRenderer var12 = Fonts.b[14];
         FontRenderer var13 = Fonts.a[13];
         FontRenderer var14 = Fonts.a[11];
         String var15 = var8.n();
         String var16 = var8.o();
         boolean var17 = var8.c();
         float var18 = var8.h();
         float var19 = this.a(12.0F, 31.0F, var9);
         float var20 = this.a(8.0F, 10.0F, var9);
         float var21 = (float)this.aH.j();
         float var22 = Math.max(0.0F, (var9 - 0.3F) / 0.7F);
         float var23 = var21 * 0.08F * var22;
         float var24 = 1.0F - var21 * 0.3F;
         float var25 = var19 * (1.0F - var23);
         float var26 = (var19 - var25) / 2.0F;
         float var27 = var4 + var6 / 2.0F - 6.0F;
         float var29 = this.a(var27, var4, var9) + var26;
         float var30 = var3 + var26;
         int var31 = (int)(var10 * var24);
         Color var32 = new Color(255, 255, 255, var31);
         if (this.Y != null) {
            var2.a(this.Y, var30, var29, var25, var25, var20, var32, var1);
         } else {
            Identifier var33 = TextureRegistry.a("track_cover");
            var2.a(var33, var30, var29, var25, var25, var20, var32, var1);
         }

         float var118 = var3 + 12.0F + 6.0F;
         float var34 = var3 + 31.0F + 5.5F;
         float var35 = this.a(var118, var34, var9);
         float var36 = var4 + var6 / 2.0F - var12.b(var15) / 4.0F - 0.5F;
         float var37 = var4 + 15.5F - 9.0F;
         float var38 = this.a(var36, var37, var9);
         float var39 = (float)this.aI.j();
         int var40 = (int)(var10 * var39);
         Color var41 = new Color(k.getRed(), k.getGreen(), k.getBlue(), var40);
         float var42 = this.a(25.0F, 70.0F, var9);
         float var43 = this.a(20.0F, 0.0F, var9);
         FontRenderer var44 = var9 < 0.2F ? var12 : var11;
         float var45 = var44.a(var15);
         boolean var46 = var45 > var42;
         float var47 = this.a(var45, var42 + var43, this.aO, this.aQ);
         if (var46) {
            var2.a().a(var35, var38 - 3.0F, var42 + var43, 16.0F, var1);
         }

         var44.a(var15, var35 + var47, var38, var41, var1);
         if (var46) {
            var2.a().a(var1);
            Color var48 = new Color(p.getRed(), p.getGreen(), p.getBlue(), 0);
            Color var49 = new Color(p.getRed(), p.getGreen(), p.getBlue(), var10);
            var2.a(var35 + var42 + var43 - 12.0F + 1.0F, var38 - 3.0F, 12.0F, 16.0F, 0.0F, var48, var49, var48, var49, var1);
         }

         if (var9 > 0.01F) {
            float var119 = this.b(var9) * var39;
            int var121 = (int)(var7 * var119 * 255.0F);
            Color var50 = new Color(l.getRed(), l.getGreen(), l.getBlue(), var121);
            float var51 = var13.a(var16);
            boolean var52 = var51 > 70.0F;
            float var53 = this.a(var51, 70.0F, this.aP, this.aR);
            if (var52) {
               var2.a().a(var35, var38 + 7.0F, 70.0F, 16.0F, var1);
            }

            var13.a(var16, var35 + var53, var38 + 10.0F, var50, var1);
            if (var52) {
               var2.a().a(var1);
               Color var54 = new Color(p.getRed(), p.getGreen(), p.getBlue(), 0);
               Color var55 = new Color(p.getRed(), p.getGreen(), p.getBlue(), var121);
               var2.a(var35 + 70.0F - 12.0F, var38 + 7.0F, 12.0F, 16.0F, 0.0F, var54, var55, var54, var55, var1);
            }
         }

         float var120 = this.a(12.0F, 16.0F, var9);
         float var122 = 14.5F;
         float var123 = var3 + var5 - var122 - 4.0F;
         float var124 = var3 + var5 - var122 - 4.0F;
         float var125 = this.a(var123, var124, var9) + 4.0F;
         float var126 = var4 + var6 / 2.0F;
         float var127 = var4 + var120 / 2.0F;
         float var128 = this.a(var126, var127, var9);
         float[] var56 = var8.H();

         for (int var57 = 0; var57 < 6; var57++) {
            float var58 = var56[var57];
            float var59 = Math.max(2.0F, var58 * var120);
            float var60 = var125 + var57 * 2.5F;
            float var61 = var128 - var59 / 2.0F;
            int var62 = (int)this.a(180.0F, 255.0F, var58);
            Color var63 = this.a(
               new Color(var62, var62, var62, var10),
               new Color(
                  (int)this.a((float)m.getRed(), (float)var62, 0.5F),
                  (int)this.a((float)m.getGreen(), (float)var62, 0.5F),
                  (int)this.a((float)m.getBlue(), (float)var62, 0.5F),
                  var10
               ),
               var9
            );
            var2.a(var60, var61, 2.0F, var59, 1.0F, var63, var1);
         }

         if (var9 > 0.01F) {
            float var129 = this.b(var9);
            int var130 = (int)(var7 * var129 * 255.0F);
            float var131 = var4 + 31.0F + 7.5F;
            float var132 = var8.b();
            float var133 = var132 * var18;
            String var134 = this.a((int)var133);
            String var135 = "-" + this.a((int)(var18 - var133));
            float var64 = var14.a(var134);
            float var65 = var14.a(var135);
            Color var66 = new Color(l.getRed(), l.getGreen(), l.getBlue(), var130);
            float var67 = var131 + 2.0F - 4.0F;
            var14.a(var134, var3, var67, var66, var1);
            var14.a(var135, var3 + var5 - var65, var67, var66, var1);
            float var68 = var3 + var64 + 3.5F;
            float var69 = var5 - var64 - var65 - 7.0F;
            this.ar = var68;
            this.as = var131 - 0.5F;
            this.at = var69;
            this.au = 4.0F;
            this.av = true;
            float var70 = (float)this.aK.j();
            float var71 = 4.0F + var70 * 2.0F;
            float var72 = var131 - 0.5F - var70 * 1.0F;
            float var73 = 3.0F + var70 * 1.0F;
            Color var74 = new Color(n.getRed(), n.getGreen(), n.getBlue(), var130);
            var2.a(var68, var72, var69, var71, var73, var74, var1);
            float var75 = var8.b();
            float var76 = var69 * Math.max(0.04F, var75);
            Color var77 = new Color(o.getRed(), o.getGreen(), o.getBlue(), var130);
            if (var76 > 0.0F) {
               var2.a(var68, var72, var76, var71, var73, 0.0F, var73, 0.0F, var77, var77, var77, var77, var1);
            }

            float var78 = var131 + 4.0F + 7.5F - 10.0F;
            float var79 = var3 + var5 / 2.0F;
            float var80 = (float)this.aw.j();
            float var81 = (float)this.aC.j();
            float var82 = 0.9F + var80 * 0.1F - var81 * 0.2F;
            int var83 = (int)(255.0F * Math.min(1.0F, var82));
            int var84 = (int)(var130 * Math.min(1.0F, var82));
            float var85 = var79 - 16.0F - 0.0F - 32.0F;
            float var86 = var78 + 0.0F;
            Color var87 = new Color(var83, var83, var83, var84);
            FontRenderer var88 = Fonts.d[35];
            float var89 = var88.a("\ue901");
            float var90 = var88.b("\ue901");
            float var91 = var85 + (32.0F - var89) / 2.0F;
            float var92 = var86 + (32.0F - var90 / 2.0F) / 2.0F;
            var88.a("\ue901", var91, var92, var87, var1);
            float var93 = (float)this.ax.j();
            float var94 = (float)this.aD.j();
            float var95 = 0.9F + var93 * 0.1F - var94 * 0.2F;
            int var96 = (int)(255.0F * Math.min(1.0F, var95));
            int var97 = (int)(var130 * Math.min(1.0F, var95));
            float var98 = var79 - 16.0F;
            Color var99 = new Color(var96, var96, var96, var97);
            FontRenderer var100 = Fonts.d[35];
            String var101 = var17 ? "\ue919" : "\ue91b";
            float var102 = var100.a(var101);
            float var103 = var100.b(var101);
            float var104 = var98 + (32.0F - var102) / 2.0F;
            float var105 = var78 + (32.0F - var103 / 2.0F) / 2.0F;
            var100.a(var101, var104, var105, var99, var1);
            float var106 = (float)this.ay.j();
            float var107 = (float)this.aE.j();
            float var108 = 0.9F + var106 * 0.1F - var107 * 0.2F;
            int var109 = (int)(255.0F * Math.min(1.0F, var108));
            int var110 = (int)(var130 * Math.min(1.0F, var108));
            float var111 = var79 + 16.0F + 0.0F;
            Color var112 = new Color(var109, var109, var109, var110);
            FontRenderer var113 = Fonts.d[35];
            float var114 = var113.a("\ue902");
            float var115 = var113.b("\ue902");
            float var116 = var111 + (32.0F - var114) / 2.0F;
            float var117 = var86 + (32.0F - var115 / 2.0F) / 2.0F;
            var113.a("\ue902", var116, var117, var112, var1);
            this.ah = var85;
            this.ai = var86;
            this.aj = 32.0F;
            this.ak = var98;
            this.al = var78;
            this.am = 32.0F;
            this.an = var111;
            this.ao = var86;
            this.ap = 32.0F;
            this.aq = true;
         } else {
            this.aq = false;
            this.av = false;
         }
      }
   }

   private String a(int var1) {
      int var2 = var1 / 60;
      int var3 = var1 % 60;
      return var2 + ":" + String.format("%02d", var3);
   }

   private float a(float var1, float var2, float var3) {
      return var1 + (var2 - var1) * var3;
   }

   private float a(float var1, float var2, long var3, boolean var5) {
      if (var5 && !(var1 <= var2)) {
         float var6 = var1 - var2;
         long var7 = (System.currentTimeMillis() - var3) % 8000L;
         float var9;
         if (var7 < 1500L) {
            var9 = 0.0F;
         } else if (var7 < 4000L) {
            float var10 = (float)(var7 - 1500L) / 2500.0F;
            var9 = this.a(var10);
         } else if (var7 < 5500L) {
            var9 = 1.0F;
         } else {
            float var11 = (float)(var7 - 1500L - 2500L - 1500L) / 2500.0F;
            var9 = 1.0F - this.a(var11);
         }

         return -var6 * var9;
      } else {
         return 0.0F;
      }
   }

   private float a(float var1) {
      return var1 < 0.5F ? 4.0F * var1 * var1 * var1 : 1.0F - (float)Math.pow(-2.0F * var1 + 2.0F, 3.0) / 2.0F;
   }

   private float b(float var1) {
      var1 = Math.max(0.0F, Math.min(1.0F, var1));
      return var1 * var1 * (3.0F - 2.0F * var1);
   }

   private Color a(Color var1, Color var2, float var3) {
      int var4 = (int)this.a((float)var1.getRed(), (float)var2.getRed(), var3);
      int var5 = (int)this.a((float)var1.getGreen(), (float)var2.getGreen(), var3);
      int var6 = (int)this.a((float)var1.getBlue(), (float)var2.getBlue(), var3);
      int var7 = (int)this.a((float)var1.getAlpha(), (float)var2.getAlpha(), var3);
      return new Color(var4, var5, var6, var7);
   }

   public boolean a(double var1, double var3, int var5) {
      if (var5 != 0) {
         return false;
      } else {
         MusicHandler var6 = this.q();
         MusicState var7 = this.r();
         if (var6 != null && var7 != null) {
            if (this.av && var7.h() > 0.0F) {
               float var8 = 4.0F;
               if (var1 >= this.ar - var8 && var1 <= this.ar + this.at + var8 && var3 >= this.as - var8 && var3 <= this.as + this.au + var8) {
                  float var9 = Math.max(0.0F, Math.min(1.0F, (float)(var1 - this.ar) / this.at));
                  var6.a(var9);
                  return true;
               }
            }

            if (!this.aq) {
               return false;
            } else if (this.a(var1, var3, this.ah, this.ai, this.aj, this.aj)) {
               this.aC.d(1.0);
               this.aC.a(0.0, 0.20000004519243691, Easings.k);
               var6.f();
               return true;
            } else if (this.a(var1, var3, this.ak, this.al, this.am, this.am)) {
               this.aD.d(1.0);
               this.aD.a(0.0, 0.20000004519243691, Easings.k);
               var6.d();
               return true;
            } else if (this.a(var1, var3, this.an, this.ao, this.ap, this.ap)) {
               this.aE.d(1.0);
               this.aE.a(0.0, 0.20000004519243691, Easings.k);
               var6.e();
               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public void b(double var1, double var3) {
      MusicHandler var5 = this.q();
      MusicState var6 = this.r();
      if (var5 != null && var6 != null) {
         if (var6.y() && this.at > 0.0F) {
            float var7 = Math.max(0.0F, Math.min(1.0F, (float)(var1 - this.ar) / this.at));
            var5.b(var7);
         }
      }
   }

   public boolean b(double var1, double var3, int var5) {
      MusicHandler var6 = this.q();
      MusicState var7 = this.r();
      if (var6 == null || var7 == null) {
         return false;
      } else if (var5 == 0 && var7.y()) {
         float var8 = Math.max(0.0F, Math.min(1.0F, (float)(var1 - this.ar) / this.at));
         var6.c(var8);
         return true;
      } else {
         return false;
      }
   }

   private boolean a(double var1, double var3, float var5, float var6, float var7, float var8) {
      return var1 >= var5 && var1 <= var5 + var7 && var3 >= var6 && var3 <= var6 + var8;
   }

   public void o() {
      if (this.Z != null) {
         this.Z.close();
         this.Z = null;
      }

      this.Y = null;
      this.X = null;
   }

   public static boolean p() {
      return MusicHandler.g();
   }
}
