package pulse.features.cosmetic.geo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Vec3F {
   public static final Vec3F a = new Vec3F(0.0F, 0.0F, 0.0F);
   public float b;
   public float c;
   public float d;

   public Vec3F(float var1, float var2, float var3) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
   }

   public float a() {
      return this.b;
   }

   public float b() {
      return this.c;
   }

   public float c() {
      return this.d;
   }

   public void a(float var1) {
      this.b = var1;
   }

   public void b(float var1) {
      this.c = var1;
   }

   public void c(float var1) {
      this.d = var1;
   }

   public void a(float var1, float var2, float var3) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
   }

   public Vec3F a(Vec3F var1) {
      return new Vec3F(this.c * var1.d - this.d * var1.c, this.d * var1.b - this.b * var1.d, this.b * var1.c - this.c * var1.b);
   }

   @Override
   public String toString() {
      return this.b + "," + this.c + "," + this.d;
   }
}
