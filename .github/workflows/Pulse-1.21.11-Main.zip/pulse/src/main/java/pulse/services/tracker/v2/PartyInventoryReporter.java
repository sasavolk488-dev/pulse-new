package pulse.services.tracker.v2;

import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.nbt.NbtCompound;
import pulse.ui.clickgui.menu.markers.MarkerSettings;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public final class PartyInventoryReporter extends Handler {
   private static final long a = 1000L;
   private static final long b = 2000L;
   private static final long c = 15000L;
   private static long d;
   private static long e;
   private static long f;
   private static long g;
   private static boolean h;
   private static int i;
   private static boolean j;
   private static volatile boolean k;

   public static void d() {
      k = true;
   }

   public static void e() {
      k = true;
      h = false;
   }

   @EventHandler
   public void a(UpdateEvent var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.player != null && var2.world != null) {
         GroupManagerClient var3 = GroupManagerClient.a();
         if (var3.c() && var3.d().size() > 1) {
            long var4 = System.currentTimeMillis();
            if (k || var4 - d >= 1000L) {
               d = var4;
               if (!MarkerSettings.l()) {
                  if (!j) {
                     j = true;
                     h = false;
                     k = false;
                     a(null, true, 0L, false);
                  }
               } else {
                  j = false;
                  NbtCompound var6 = PartyInventoryTracker.c();
                  if (var6 != null) {
                     long var7 = var6.hashCode() & 4294967295L;
                     boolean var9 = !h || var7 != g || k;
                     if (var9 && (k || var4 - e >= 2000L)) {
                        String var10 = PartyInventoryTracker.a(var6);
                        if (var10 == null) {
                           return;
                        }

                        g = var7;
                        h = true;
                        e = var4;
                        f = var4;
                        k = false;
                        a(var10, false, var7, false);
                     } else if (h && var4 - f >= 15000L) {
                        f = var4;
                        a(null, false, g, true);
                     }
                  }
               }
            }
         }
      }
   }

   private static void a(String var0, boolean var1, long var2, boolean var4) {
      try {
         RealtimeSyncServiceV2.L().a(var0, var1, var2, ++i, var4);
      } catch (Exception var6) {
      }
   }
}
