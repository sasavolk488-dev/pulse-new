package pulse.mixin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.ui.clickgui.invmanager.InventoryManagerScreen;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.ChestSorterHandler;
import pulse.core.handler.impl.InventoryBuilderHandler;
import pulse.core.handler.impl.ItemGroupKey;
import pulse.core.api.IFocusedSlot;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.CooldownsModule;
import pulse.features.modules.utilities.ItemScrollerModule;
import pulse.features.modules.utilities.ShulkerPreviewModule;
import pulse.utils.game.CooldownUtil;
import pulse.utils.input.MouseUtil;
import pulse.utils.time.TimeUtils;

@Environment(EnvType.CLIENT)
@Mixin({HandledScreen.class})
public class HandledScreenMixin implements IFocusedSlot {
   @Shadow
   protected int x;
   @Shadow
   protected int y;
   @Shadow
   protected int backgroundWidth;
   @Shadow
   protected int backgroundHeight;
   @Shadow
   @Nullable
   protected Slot focusedSlot;
   @Unique
   private static final Identifier PULSE$ANARCHY_BTN = Identifier.of("pulse", "textures/ui/inv/clear_button.png");
   @Unique
   private static final Identifier PULSE$ANARCHY_BTN_HOVER = Identifier.of("pulse", "textures/ui/inv/h_clear_button.png");
   @Unique
   private static final Identifier PULSE$ANARCHY_BTN_LOCKED = Identifier.of("pulse", "textures/ui/inv/l_clear_button.png");
   @Unique
   private int pulse$anarchyBtnX;
   @Unique
   private int pulse$anarchyBtnY;
   @Unique
   private boolean pulse$showAnarchyButton;
   @Unique
   private TimeUtils pulse$scrollTime;
   @Unique
   private static final int INV_MISSING_RGB = 15946306;
   @Unique
   private static final int INV_MISPLACED_RGB = 16757051;
   @Unique
   private static final int INV_DONE_COLOR = -9709208;
   @Unique
   private static final int INV_PANEL_BG = -804253672;
   @Unique
   private static final ItemStack PULSE$MANAGER_ICON = new ItemStack(Items.CHEST);
   @Unique
   private boolean pulse$managerBtnVisible;
   @Unique
   private int pulse$managerBtnX;
   @Unique
   private int pulse$managerBtnY;
   @Unique
   private int pulse$managerBtnW;
   @Unique
   private int pulse$managerBtnH;
   @Unique
   private List<ItemStack> pulse$panelRowsList;
   @Unique
   private int pulse$panelRowsX;
   @Unique
   private int pulse$panelRowsY;
   @Unique
   private int pulse$panelRowsW;
   @Unique
   private static final int PULSE$PANEL_VISIBLE_ROWS = 8;
   @Unique
   private int pulse$panelScroll;
   @Unique
   private int pulse$panelVisibleRows;
   @Unique
   private boolean pulse$sortBtnVisible;
   @Unique
   private int pulse$sortBtnX;
   @Unique
   private int pulse$sortBtnY;
   @Unique
   private int pulse$sortBtnW;
   @Unique
   private int pulse$sortBtnH;
   @Unique
   private static final ItemStack PULSE$CHEST_SORT_ICON = new ItemStack(Items.HOPPER);
   @Unique
   private boolean pulse$chestSortVisible;
   @Unique
   private int pulse$chestSortX;
   @Unique
   private int pulse$chestSortY;
   @Unique
   private int pulse$chestSortW;
   @Unique
   private int pulse$chestSortH;

   @Override
   public Slot pulse$getFocusedSlot() {
      return this.focusedSlot;
   }

   @Unique
   private TimeUtils pulse$getScrollTime() {
      if (this.pulse$scrollTime == null) {
         this.pulse$scrollTime = new TimeUtils();
      }

      return this.pulse$scrollTime;
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void pulse$initAnarchyFinderButton(CallbackInfo var1) {
      InventoryBuilderHandler.a(this);
      HandledScreen var2 = (HandledScreen)(Object)this;
      String var3 = var2.getTitle().getString();
      this.pulse$showAnarchyButton = var3.startsWith("☬ Выберите");
      if (this.pulse$showAnarchyButton) {
         this.pulse$anarchyBtnX = this.x + this.backgroundWidth - 17;
         this.pulse$anarchyBtnY = this.y + 5;
      }
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$clickInventoryBuilder(Click var1, boolean var2, CallbackInfoReturnable<Boolean> var3) {
      int var4 = var1.button();
      double var5 = var1.x();
      double var7 = var1.y();
      if (var4 == 0
         && this.pulse$managerBtnVisible
         && var5 >= this.pulse$managerBtnX
         && var5 < this.pulse$managerBtnX + this.pulse$managerBtnW
         && var7 >= this.pulse$managerBtnY
         && var7 < this.pulse$managerBtnY + this.pulse$managerBtnH) {
         MinecraftClient var12 = MinecraftClient.getInstance();
         var12.setScreen(new InventoryManagerScreen(new InventoryScreen(var12.player)));
         var3.setReturnValue(true);
      } else if (var4 == 0
         && this.pulse$sortBtnVisible
         && var5 >= this.pulse$sortBtnX
         && var5 < this.pulse$sortBtnX + this.pulse$sortBtnW
         && var7 >= this.pulse$sortBtnY
         && var7 < this.pulse$sortBtnY + this.pulse$sortBtnH) {
         InventoryBuilderHandler var11 = HandlerRegistry.l;
         if (var11.i()) {
            var11.k();
         } else {
            var11.j();
         }

         var3.setReturnValue(true);
      } else if (var4 == 0
         && this.pulse$chestSortVisible
         && var5 >= this.pulse$chestSortX
         && var5 < this.pulse$chestSortX + this.pulse$chestSortW
         && var7 >= this.pulse$chestSortY
         && var7 < this.pulse$chestSortY + this.pulse$chestSortH) {
         ChestSorterHandler var10 = HandlerRegistry.q;
         if (var10.d()) {
            var10.f();
         } else {
            var10.e();
         }

         var3.setReturnValue(true);
      } else {
         if (var4 == 0) {
            int var9 = this.pulse$panelRowIndexAt(var5, var7);
            if (var9 >= 0) {
               InventoryBuilderHandler.a(InventoryBuilderHandler.AuctionReturn.b);
               ModuleRegistry.V.a(this.pulse$panelRows().get(var9));
               var3.setReturnValue(true);
            }
         }
      }
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$clickAnarchyFinderButton(Click var1, boolean var2, CallbackInfoReturnable<Boolean> var3) {
      if (var1.button() == 0 && this.pulse$showAnarchyButton && this.pulse$hasAnarchyModeSelected()) {
         double var4 = var1.x();
         double var6 = var1.y();
         if (var4 >= this.pulse$anarchyBtnX && var4 < this.pulse$anarchyBtnX + 10 && var6 >= this.pulse$anarchyBtnY && var6 < this.pulse$anarchyBtnY + 10) {
            HandlerRegistry.i.e();
            var3.setReturnValue(true);
         }
      }
   }

   @Inject(
      method = {"renderMain"},
      at = {@At("TAIL")}
   )
   private void pulse$renderCooldownTimers(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      if (this.pulse$showAnarchyButton) {
         this.pulse$renderAnarchyFinderButton(var1, var2, var3);
      }

      CooldownsModule var6 = ModuleRegistry.K;
      if (var6 != null && var6.k() && var6.n()) {
         MinecraftClient var7 = MinecraftClient.getInstance();
         if (var7.player != null) {
            HandledScreen var8 = (HandledScreen)(Object)this;
            TextRenderer var9 = var7.textRenderer;
            float var10 = var6.q().q();

            for (Slot var12 : var8.getScreenHandler().slots) {
               ItemStack var13 = var12.getStack();
               if (!var13.isEmpty()) {
                  CooldownUtil.CooldownInfo var14 = CooldownUtil.a(var7.player.getItemCooldownManager(), var13);
                  boolean var15 = CooldownsModule.a(var13) && var6.b(var13.getItem());
                  if (var14.a() || var15) {
                     int var16 = var12.x + this.x;
                     int var17 = var12.y + this.y;
                     int var18;
                     int var19;
                     if (var15) {
                        float var20 = var6.a(var13.getItem());
                        var18 = (int)Math.ceil(var20 * 18.5);
                        var19 = var20 <= 0.33F ? '\uff00' : (var20 <= 0.66F ? 16776960 : 16711680);
                     } else {
                        var18 = (int)Math.ceil(var14.b());
                        float var26 = var14.c();
                        var19 = var26 <= 0.33F ? '\uff00' : (var26 <= 0.66F ? 16776960 : 16711680);
                     }

                     String var27 = String.valueOf(var18);
                     float var21 = var9.getWidth(var27);
                     float var22 = 14.0F;
                     float var23 = Math.min(1.0F, var22 / var21);
                     float var24 = var23 * var10;
                     Matrix3x2fStack var25 = var1.getMatrices();
                     var25.pushMatrix();
                     var25.scale(var24, var24);
                     var1.drawText(var9, var27, (int)((var16 + 0.5F) / var24), (int)((var17 + 0.5F) / var24), var19 | 0xFF000000, true);
                     var25.popMatrix();
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"renderMain"},
      at = {@At("TAIL")}
   )
   private void pulse$itemScrollerTick(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      this.pulse$handleItemScroller();
   }

   @Unique
   private List<ItemStack> pulse$panelRows() {
      if (this.pulse$panelRowsList == null) {
         this.pulse$panelRowsList = new ArrayList<>();
      }

      return this.pulse$panelRowsList;
   }

   @Inject(
      method = {"renderMain"},
      at = {@At("TAIL")}
   )
   private void pulse$renderInventoryBuilderOverlay(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      this.pulse$panelRows().clear();
      this.pulse$managerBtnVisible = false;
      this.pulse$sortBtnVisible = false;
      if ((Object)this instanceof InventoryScreen) {
         MinecraftClient var6 = MinecraftClient.getInstance();
         if (var6.player != null) {
            TextRenderer var7 = var6.textRenderer;
            MouseUtil.h();
            this.pulse$renderManagerButton(var1, var7, var2, var3);
            InventoryBuilderHandler var8 = HandlerRegistry.l;
            if (!var8.f()) {
               MouseUtil.i();
            } else {
               HandledScreen var9 = (HandledScreen)(Object)this;
               HashMap<ItemGroupKey, Integer> var10 = new HashMap<>();
               PlayerInventory var11 = var6.player.getInventory();

               for (int var12 = 0; var12 < var11.size(); var12++) {
                  ItemStack var13 = var11.getStack(var12);
                  if (!var13.isEmpty()) {
                     var10.merge(ItemGroupKey.a(var13), var13.getCount(), Integer::sum);
                  }
               }

               LinkedHashMap<ItemGroupKey, Integer> var29 = new LinkedHashMap<>();
               HashMap<ItemGroupKey, ItemStack> var30 = new HashMap<>();

               for (ItemStack var15 : var8.g().values()) {
                  if (!var15.isEmpty()) {
                     var29.merge(ItemGroupKey.a(var15), var15.getCount(), Integer::sum);
                     var30.putIfAbsent(ItemGroupKey.a(var15), var15);
                  }
               }

               int var31 = 25 + (int)((Math.sin(System.currentTimeMillis() / 250.0) * 0.5 + 0.5) * 35.0);
               Matrix3x2fStack var32 = var1.getMatrices();
               boolean var16 = false;
               boolean var17 = false;

               for (Entry var19 : var8.g().entrySet()) {
                  int var20 = (Integer)var19.getKey();
                  ItemStack var21 = (ItemStack)var19.getValue();
                  if (!var21.isEmpty()) {
                     ItemStack var22 = var6.player.getInventory().getStack(var20);
                     if (var22.isEmpty() || !ItemGroupKey.a(var22).equals(ItemGroupKey.a(var21))) {
                        Slot var23 = null;

                        for (Slot var25 : var9.getScreenHandler().slots) {
                           if (var25.inventory == var6.player.getInventory() && var25.getIndex() == var20) {
                              var23 = var25;
                              break;
                           }
                        }

                        if (var23 != null) {
                           var16 = true;
                           boolean var34 = var10.getOrDefault(ItemGroupKey.a(var21), 0) > 0;
                           if (var34) {
                              var17 = true;
                           }

                           int var35 = var34 ? 16757051 : 15946306;
                           int var26 = -536870912 | var35;
                           int var27 = var23.x + this.x;
                           int var28 = var23.y + this.y;
                           if (var22.isEmpty()) {
                              var1.fill(var27, var28, var27 + 16, var28 + 16, var31 << 24 | var35);
                              var1.fill(var27, var28, var27 + 16, var28 + 1, var26);
                              var1.fill(var27, var28 + 15, var27 + 16, var28 + 16, var26);
                              var1.fill(var27, var28 + 1, var27 + 1, var28 + 15, var26);
                              var1.fill(var27 + 15, var28 + 1, var27 + 16, var28 + 15, var26);
                              var1.drawItem(var21, var27, var28);
                              var1.drawStackOverlay(var7, var21, var27, var28);
                              var1.fill(var27, var28, var27 + 16, var28 + 16, 1938525067);
                           } else {
                              var1.fill(var27, var28, var27 + 16, var28 + 1, var26);
                              var1.fill(var27, var28 + 15, var27 + 16, var28 + 16, var26);
                              var1.fill(var27, var28 + 1, var27 + 1, var28 + 15, var26);
                              var1.fill(var27 + 15, var28 + 1, var27 + 16, var28 + 15, var26);
                              var1.fill(var27 + 8, var28 - 1, var27 + 17, var28 + 8, -435154920);
                              var1.fill(var27 + 8, var28 - 1, var27 + 17, var28, var26);
                              var32.pushMatrix();
                              var32.translate(var27 + 8.5F, var28 - 0.5F);
                              var32.scale(0.5F, 0.5F);
                              var1.drawItem(var21, 0, 0);
                              var32.popMatrix();
                           }
                        }
                     }
                  }
               }

               int var33 = this.pulse$renderAssemblyPanel(var1, var7, var29, var30, var10, var16, var2, var3);
               this.pulse$renderSortButton(var1, var7, var33, var17, var2, var3);
               MouseUtil.i();
            }
         }
      }
   }

   @Unique
   private void pulse$renderSortButton(DrawContext var1, TextRenderer var2, int var3, boolean var4, int var5, int var6) {
      InventoryBuilderHandler var7 = HandlerRegistry.l;
      boolean var8 = var7.i();
      if (var4 || var8) {
         String var9 = var8 ? "Раскладываю... (стоп)" : "Разложить всё";
         int var10 = var2.getWidth(var9) + 10;
         int var11 = this.x + this.backgroundWidth + 4;
         int var12 = var3 + 2;
         this.pulse$sortBtnVisible = true;
         this.pulse$sortBtnX = var11;
         this.pulse$sortBtnY = var12;
         this.pulse$sortBtnW = var10;
         this.pulse$sortBtnH = 14;
         boolean var13 = var5 >= var11 && var5 < var11 + var10 && var6 >= var12 && var6 < var12 + 14;
         var1.fill(var11, var12, var11 + var10, var12 + 14, -804253672);
         if (var13) {
            var1.fill(var11, var12, var11 + var10, var12 + 14, 687865855);
         }

         int var14 = var8 ? -20165 : (var13 ? -4815105 : -1);
         var1.drawText(var2, var9, var11 + 5, var12 + 3, var14, true);
         if (var13) {
            MouseUtil.g();
         }
      }
   }

   @Unique
   private void pulse$renderManagerButton(DrawContext var1, TextRenderer var2, int var3, int var4) {
      this.pulse$managerBtnVisible = true;
      this.pulse$managerBtnX = this.x + this.backgroundWidth - 30;
      this.pulse$managerBtnY = this.y - 11;
      this.pulse$managerBtnW = 24;
      this.pulse$managerBtnH = 14;
      int var5 = this.pulse$managerBtnX;
      int var6 = this.pulse$managerBtnY;
      int var7 = this.pulse$managerBtnW;
      int var8 = this.pulse$managerBtnH;
      boolean var9 = var3 >= var5 && var3 < var5 + var7 && var4 >= var6 && var4 < var6 + var8;
      var1.fill(var5 + 1, var6, var5 + var7 - 1, var6 + 1, -16777216);
      var1.fill(var5, var6 + 1, var5 + 1, var6 + var8 - 2, -16777216);
      var1.fill(var5 + var7 - 1, var6 + 1, var5 + var7, var6 + var8 - 2, -16777216);
      var1.fill(var5 + 1, var6 + 1, var5 + var7 - 1, var6 + var8, -3750202);
      var1.fill(var5 + 1, var6 + 1, var5 + var7 - 2, var6 + 2, -1);
      var1.fill(var5 + 1, var6 + 2, var5 + 2, var6 + var8, -1);
      var1.fill(var5 + var7 - 2, var6 + 1, var5 + var7 - 1, var6 + var8 - 2, -11184811);
      if (var9) {
         var1.fill(var5 + 1, var6 + 1, var5 + var7 - 1, var6 + var8, -1);
      }

      Matrix3x2fStack var10 = var1.getMatrices();
      var10.pushMatrix();
      var10.translate(var5 + var7 / 2.0F - 6.0F, var6 + 1.0F);
      var10.scale(0.75F, 0.75F);
      var1.drawItem(PULSE$MANAGER_ICON, 0, 0);
      var10.popMatrix();
      if (var9) {
         MouseUtil.g();
         var1.drawTooltip(var2, Text.literal("Менеджер инвентарей"), var3, var4);
      }
   }

   @Inject(
      method = {"renderMain"},
      at = {@At("TAIL")}
   )
   private void pulse$renderChestSortButton(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      this.pulse$chestSortVisible = false;
      boolean var6 = (Object)this instanceof ShulkerBoxScreen;
      if (var6 || (Object)this instanceof GenericContainerScreen) {
         if (var6 || this.pulse$isRealChestTitle()) {
            MouseUtil.h();
            boolean var7 = HandlerRegistry.q.d();
            this.pulse$chestSortVisible = true;
            this.pulse$chestSortX = this.x + this.backgroundWidth - 30;
            this.pulse$chestSortY = this.y - 11;
            this.pulse$chestSortW = 24;
            this.pulse$chestSortH = 14;
            int var8 = this.pulse$chestSortX;
            int var9 = this.pulse$chestSortY;
            int var10 = this.pulse$chestSortW;
            int var11 = this.pulse$chestSortH;
            boolean var12 = var2 >= var8 && var2 < var8 + var10 && var3 >= var9 && var3 < var9 + var11;
            var1.fill(var8 + 1, var9, var8 + var10 - 1, var9 + 1, -16777216);
            var1.fill(var8, var9 + 1, var8 + 1, var9 + var11 - 2, -16777216);
            var1.fill(var8 + var10 - 1, var9 + 1, var8 + var10, var9 + var11 - 2, -16777216);
            var1.fill(var8 + 1, var9 + 1, var8 + var10 - 1, var9 + var11, -3750202);
            var1.fill(var8 + 1, var9 + 1, var8 + var10 - 2, var9 + 2, -1);
            var1.fill(var8 + 1, var9 + 2, var8 + 2, var9 + var11, -1);
            var1.fill(var8 + var10 - 2, var9 + 1, var8 + var10 - 1, var9 + var11 - 2, -11184811);
            if (var7) {
               var1.fill(var8 + 1, var9 + 1, var8 + var10 - 1, var9 + var11, -7542);
            } else if (var12) {
               var1.fill(var8 + 1, var9 + 1, var8 + var10 - 1, var9 + var11, -1);
            }

            Matrix3x2fStack var13 = var1.getMatrices();
            var13.pushMatrix();
            var13.translate(var8 + var10 / 2.0F - 6.0F, var9 + 1.0F);
            var13.scale(0.75F, 0.75F);
            var1.drawItem(PULSE$CHEST_SORT_ICON, 0, 0);
            var13.popMatrix();
            if (var12) {
               MouseUtil.g();
               TextRenderer var14 = MinecraftClient.getInstance().textRenderer;
               var1.drawTooltip(var14, Text.literal(var7 ? "Сортировка... (клик — стоп)" : "Отсортировать сундук"), var2, var3);
            }

            MouseUtil.i();
         }
      }
   }

   @Unique
   private boolean pulse$isRealChestTitle() {
      HandledScreen var1 = (HandledScreen)(Object)this;
      Text var2 = var1.getTitle();
      return var2 != null && var2.getContent() instanceof TranslatableTextContent var3 && var3.getKey().startsWith("container.");
   }

   @Unique
   private int pulse$renderAssemblyPanel(
      DrawContext var1,
      TextRenderer var2,
      Map<ItemGroupKey, Integer> var3,
      Map<ItemGroupKey, ItemStack> var4,
      Map<ItemGroupKey, Integer> var5,
      boolean var6,
      int var7,
      int var8
   ) {
      ArrayList<ItemGroupKey> var9 = new ArrayList<>();
      HashMap var10 = new HashMap<>();

      for (Entry var12 : var3.entrySet()) {
         int var13 = (Integer)var12.getValue() - var5.getOrDefault(var12.getKey(), 0);
         if (var13 > 0) {
            var9.add((ItemGroupKey)var12.getKey());
            var10.put((ItemGroupKey)var12.getKey(), var13);
         }
      }

      HashMap var26 = new HashMap<>();

      for (ItemGroupKey var29 : var9) {
         var26.put(var29, ((ItemStack)var4.get(var29)).getName().getString());
      }

      var9.sort(
         Comparator.<ItemGroupKey, String>comparing(var1x -> (String)var26.get(var1x), String.CASE_INSENSITIVE_ORDER)
            .thenComparing(var1x -> -(Integer)var10.get(var1x))
      );
      int var28 = this.x + this.backgroundWidth + 4;
      int var30 = this.y;
      int var14;
      if (var9.isEmpty()) {
         this.pulse$panelScroll = 0;
         String var15 = var6 ? "Разложите по местам" : "Инвентарь собран ✔";
         int var16 = var6 ? -20165 : -9709208;
         int var17 = var2.getWidth(var15) + 10;
         var1.fill(var28, var30, var28 + var17, var30 + 16, -804253672);
         var1.drawText(var2, var15, var28 + 5, var30 + 4, var16, true);
         var14 = var30 + 16;
      } else {
         String var31 = "Не хватает:";

         for (ItemGroupKey var34 : var9) {
            this.pulse$panelRows().add((ItemStack)var4.get(var34));
         }

         int var33 = var9.size();
         int var35 = Math.min(var33, 8);
         this.pulse$panelVisibleRows = var35;
         int var18 = var33 - var35;
         this.pulse$panelScroll = Math.max(0, Math.min(this.pulse$panelScroll, var18));
         int var19 = var2.getWidth(var31) + 10;

         for (ItemGroupKey var21 : var9) {
            var19 = Math.max(var19, 20 + var2.getWidth("×" + var10.get(var21)) + 10);
         }

         int var36 = 14 + var35 * 18 + 4;
         var14 = var30 + var36;
         var1.fill(var28, var30, var28 + var19, var30 + var36, -804253672);
         var1.drawText(var2, var31, var28 + 5, var30 + 4, -830910, true);
         this.pulse$panelRowsX = var28;
         this.pulse$panelRowsY = var30 + 14;
         this.pulse$panelRowsW = var19;
         int var37 = var30 + 14;

         for (int var22 = 0; var22 < var35; var22++) {
            ItemGroupKey var23 = (ItemGroupKey)var9.get(this.pulse$panelScroll + var22);
            ItemStack var24 = (ItemStack)var4.get(var23);
            boolean var25 = var7 >= var28 && var7 < var28 + var19 && var8 >= var37 - 1 && var8 < var37 + 17;
            if (var25) {
               var1.fill(var28, var37 - 1, var28 + var19, var37 + 17, 687865855);
               MouseUtil.g();
            }

            var1.drawItem(var24, var28 + 5, var37);
            var1.drawText(var2, "×" + var10.get(var23), var28 + 5 + 16 + 4, var37 + 4, var25 ? -4815105 : -1, true);
            var37 += 18;
         }

         if (var18 > 0) {
            int var38 = var30 + 14;
            int var39 = var35 * 18 - 2;
            int var40 = Math.max(8, var39 * var35 / var33);
            int var41 = var38 + (var39 - var40) * this.pulse$panelScroll / var18;
            var1.fill(var28 + var19 - 2, var38, var28 + var19 - 1, var38 + var39, 1090519039);
            var1.fill(var28 + var19 - 2, var41, var28 + var19 - 1, var41 + var40, -7631973);
         }
      }

      return var14;
   }

   @Unique
   private int pulse$panelRowIndexAt(double var1, double var3) {
      if (this.pulse$panelRows().isEmpty()) {
         return -1;
      } else if (var1 < this.pulse$panelRowsX || var1 >= this.pulse$panelRowsX + this.pulse$panelRowsW) {
         return -1;
      } else if (var3 < this.pulse$panelRowsY - 1) {
         return -1;
      } else {
         int var5 = (int)((var3 - (this.pulse$panelRowsY - 1)) / 18.0);
         if (var5 >= 0 && var5 < this.pulse$panelVisibleRows) {
            int var6 = this.pulse$panelScroll + var5;
            return var6 < this.pulse$panelRows().size() ? var6 : -1;
         } else {
            return -1;
         }
      }
   }

   @Inject(
      method = {"mouseScrolled"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$scrollAssemblyPanel(double var1, double var3, double var5, double var7, CallbackInfoReturnable<Boolean> var9) {
      if (this.pulse$panelRows().size() > this.pulse$panelVisibleRows) {
         if (!(var1 < this.pulse$panelRowsX) && !(var1 >= this.pulse$panelRowsX + this.pulse$panelRowsW)) {
            int var10 = this.pulse$panelRowsY - 14;
            int var11 = this.pulse$panelRowsY + this.pulse$panelVisibleRows * 18 + 4;
            if (!(var3 < var10) && !(var3 >= var11)) {
               int var12 = this.pulse$panelRows().size() - this.pulse$panelVisibleRows;
               this.pulse$panelScroll = Math.max(0, Math.min(this.pulse$panelScroll - (int)Math.signum(var7), var12));
               var9.setReturnValue(true);
            }
         }
      }
   }

   @Inject(
      method = {"removed"},
      at = {@At("TAIL")}
   )
   private void pulse$resetCursorOnRemoved(CallbackInfo var1) {
      MouseUtil.h();
      MouseUtil.l();
   }

   @Inject(
      method = {"close"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$blockCloseWhileSorting(CallbackInfo var1) {
      if (HandlerRegistry.l.i()) {
         var1.cancel();
      }
   }

   @Inject(
      method = {"close"},
      at = {@At("HEAD")}
   )
   private void pulse$saveCursorBeforeAuctionClose(CallbackInfo var1) {
      if (InventoryBuilderHandler.b(this)) {
         MouseUtil.j();
      }
   }

   @Inject(
      method = {"close"},
      at = {@At("TAIL")}
   )
   private void pulse$returnAfterAuction(CallbackInfo var1) {
      if (InventoryBuilderHandler.b(this)) {
         InventoryBuilderHandler.AuctionReturn var2 = InventoryBuilderHandler.d();
         if (var2 != InventoryBuilderHandler.AuctionReturn.a) {
            MinecraftClient var3 = MinecraftClient.getInstance();
            if (var3.player != null) {
               if (var2 == InventoryBuilderHandler.AuctionReturn.b) {
                  var3.setScreen(new InventoryScreen(var3.player));
               } else {
                  var3.setScreen(new InventoryManagerScreen(new InventoryScreen(var3.player)));
               }

               MouseUtil.k();
            }
         }
      }
   }

   @Inject(
      method = {"drawMouseoverTooltip"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$shulkerPreviewTooltip(DrawContext var1, int var2, int var3, CallbackInfo var4) {
      ShulkerPreviewModule var5 = ModuleRegistry.ar;
      if (var5 != null && this.focusedSlot != null && this.focusedSlot.hasStack()) {
         if (var5.d(this.focusedSlot.getStack())) {
            var5.a(var1, this.focusedSlot.getStack(), var2, var3);
            var4.cancel();
         }
      }
   }

   @Unique
   private void pulse$handleItemScroller() {
      ItemScrollerModule var1 = ModuleRegistry.ac;
      if (var1 != null && var1.k()) {
         MinecraftClient var2 = MinecraftClient.getInstance();
         if (var2.player != null && var2.currentScreen != null) {
            if (this.focusedSlot != null && this.focusedSlot.hasStack() && this.focusedSlot.getStack().getItem() != Items.AIR) {
               long var3 = var2.getWindow().getHandle();
               boolean var5 = GLFW.glfwGetMouseButton(var3, 0) == 1;
               boolean var6 = GLFW.glfwGetKey(var3, 340) == 1;
               if (var5 && var6) {
                  long var7 = var1.a.q().longValue();
                  if (this.pulse$getScrollTime().a(var7)) {
                     HandledScreen var9 = (HandledScreen)(Object)this;
                     var2.interactionManager.clickSlot(var9.getScreenHandler().syncId, this.focusedSlot.id, 0, SlotActionType.QUICK_MOVE, var2.player);
                     this.pulse$getScrollTime().b();
                  }
               }
            }
         }
      }
   }

   @Unique
   private boolean pulse$hasAnarchyModeSelected() {
      HandledScreen var1 = (HandledScreen)(Object)this;

      for (Slot var3 : var1.getScreenHandler().slots) {
         if (var3 != null && var3.hasStack()) {
            ItemStack var4 = var3.getStack();
            if ((var4.getItem() == Items.TNT || var4.getItem() == Items.RESPAWN_ANCHOR) && var4.hasGlint()) {
               return true;
            }
         }
      }

      return false;
   }

   @Unique
   private void pulse$renderAnarchyFinderButton(DrawContext var1, int var2, int var3) {
      MinecraftClient var4 = MinecraftClient.getInstance();
      boolean var5 = !this.pulse$hasAnarchyModeSelected();
      boolean var6 = var2 >= this.pulse$anarchyBtnX
         && var2 < this.pulse$anarchyBtnX + 10
         && var3 >= this.pulse$anarchyBtnY
         && var3 < this.pulse$anarchyBtnY + 10;
      Identifier var7;
      if (var5) {
         var7 = PULSE$ANARCHY_BTN_LOCKED;
      } else {
         var7 = var6 ? PULSE$ANARCHY_BTN_HOVER : PULSE$ANARCHY_BTN;
      }

      var1.drawTexture(RenderPipelines.GUI_TEXTURED, var7, this.pulse$anarchyBtnX, this.pulse$anarchyBtnY, 0.0F, 0.0F, 10, 10, 10, 10);
      if (var6 && var4.currentScreen != null) {
         if (var5) {
            var1.drawTooltip(var4.textRenderer, Text.literal("Сначала выберите режим (1.16.5 или 1.21.8)"), var2, var3);
         } else {
            var1.drawTooltip(var4.textRenderer, Text.literal("Зайти на анархию с самым маленьким онлайном"), var2, var3);
         }
      }
   }
}
