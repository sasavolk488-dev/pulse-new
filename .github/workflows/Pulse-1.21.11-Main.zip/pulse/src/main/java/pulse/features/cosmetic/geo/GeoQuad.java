package pulse.features.cosmetic.geo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GeoQuad {
   public GeoVertex[] a;
   public Vec3F b;

   public GeoQuad(GeoVertex[] var1, Vec3F var2) {
      this.a = var1;
      this.b = var2;
   }

   public GeoQuad(GeoVertex[] var1, float var2, float var3, float var4) {
      this.a = var1;
      this.b = new Vec3F(var2, var3, var4);
   }
}
