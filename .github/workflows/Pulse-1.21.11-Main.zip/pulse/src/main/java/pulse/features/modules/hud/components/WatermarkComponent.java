package pulse.features.modules.hud.components;

import java.awt.Color;
import java.util.LinkedList;
import java.util.Queue;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.music.MusicHandler;
import pulse.core.handler.impl.music.MusicState;
import pulse.features.modules.hud.DraggableManager;
import pulse.features.modules.hud.island.DefaultIsland;
import pulse.features.modules.hud.island.EventStatusIsland;
import pulse.features.modules.hud.island.Island;
import pulse.features.modules.hud.island.ModuleToggleIsland;
import pulse.features.modules.hud.island.MusicIsland;
import pulse.features.modules.hud.island.NotificationIsland;
import pulse.mixin.accessor.BossBarHudAccessor;
import pulse.mixin.accessor.PlayerListHudAccessor;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public class WatermarkComponent {
   private static WatermarkComponent a;
   private static final MinecraftClient b = MinecraftClient.getInstance();
   private static final Color c = new Color(19, 19, 25);
   private static final Color d = new Color(19, 19, 26);
   private static final Color e = new Color(13, 13, 17);
   private static final Color f = new Color(17, 17, 23);
   private static final float g = 12.0F;
   private static final float h = 7.0F;
   private static final float i = 19.0F;
   private final DefaultIsland j = new DefaultIsland();
   private final Queue<Island> k = new LinkedList<>();
   private Island l = null;
   private NotificationIsland m = null;
   private final Animation n = new Animation();
   private final Animation o = new Animation();
   private final Animation p = new Animation();
   private final Animation q = new Animation();
   private final Animation r = new Animation();
   private float s;
   private float t;
   private float u;
   private float v;
   private final WatermarkSettingsPanel w = new WatermarkSettingsPanel();
   private long x = 0L;
   private boolean y = false;
   private static final long z = 3000L;
   private int A = 0;
   private int B = 0;
   private long C = 0L;
   private static final long D = 300L;
   private final Animation E = new Animation();
   private boolean F = false;

   public WatermarkComponent() {
      a = this;
      float var1 = this.j.c();
      float var2 = this.j.d();
      this.n.d(var1);
      this.o.d(var2);
      this.p.d(7.0);
      this.q.d(1.0);
      this.r.d(0.0);
      this.E.d(1.0);
      this.s = var1;
      this.t = var2;
      this.u = 7.0F;
   }

   public static WatermarkComponent a() {
      return a;
   }

   public static void a(String var0, boolean var1) {
      if (a != null && a.w.l()) {
         a.b(var0, var1);
      }
   }

   public static void a(String var0, String var1, String var2) {
      if (a != null && a.w.k()) {
         a.b(new EventStatusIsland(var0, var1, var2));
      }
   }

   public static void a(String var0, String var1) {
      if (a != null) {
         a.b(NotificationIsland.a(var0).a(NotificationIsland.NotificationType.b).a(var1).b());
      }
   }

   public static void a(NotificationIsland var0) {
      if (a != null && a.w.h()) {
         a.b(var0);
      }
   }

   public static void a(String var0) {
      if (a != null && a.w.h()) {
         a.b(NotificationIsland.a(var0).b());
      }
   }

   public static void b(String var0, String var1) {
      if (a != null && a.w.h()) {
         a.b(NotificationIsland.a(var0).a(var1).b());
      }
   }

   public static void b() {
      if (a != null && a.w.i()) {
         if (a.l instanceof MusicIsland) {
            return;
         }

         a.b(new MusicIsland());
      }
   }

   public static void c() {
      if (a != null && a.l instanceof MusicIsland) {
         a.d();
      }
   }

   @Deprecated
   public static void c(String var0, String var1) {
      b();
   }

   private void b(Island var1) {
      this.k.clear();
      if (this.w.d()) {
         this.w.b();
      }

      if (this.l instanceof NotificationIsland var2 && var2.m() && !var2.h()) {
         this.m = var2;
      }

      if (var1 instanceof NotificationIsland && ((NotificationIsland)var1).m()) {
         this.m = null;
      }

      boolean var6 = false;
      if (this.l != null && this.l.getClass() == var1.getClass()) {
         if (this.l instanceof NotificationIsland && var1 instanceof NotificationIsland) {
            var6 = ((NotificationIsland)this.l).p().equals(((NotificationIsland)var1).p());
         } else {
            var6 = true;
         }
      }

      boolean var3 = this.r.j() >= 0.9900000190925857;
      this.l = var1;
      float var4 = var1.c();
      float var5 = var1.d();
      this.n.a(var4, 0.30000018814265855, Easings.k);
      this.o.a(var5, 0.30000018814265855, Easings.k);
      if (!var6 || !var3) {
         this.r.d(0.0);
      }

      this.r.a(1.0, 0.1999999781541723, Easings.k);
      this.q.a(0.0, 0.1500000196196393, Easings.k);
   }

   public boolean a(double var1, double var3, int var5) {
      if (this.E.j() < 0.5) {
         return false;
      } else {
         int var6 = (int)var1;
         int var7 = (int)var3;
         if (this.w.d()) {
            if (var5 == 0) {
               if (this.w.a(var6, var7)) {
                  return true;
               }

               if (!this.w.d(var6, var7)) {
                  this.w.b();
                  return true;
               }
            } else if (var5 == 1) {
               if (this.w.b(var6, var7)) {
                  return true;
               }

               if (!this.w.d(var6, var7)) {
                  this.w.b();
                  return true;
               }
            }
         }

         if (var5 == 1 && this.l != null && this.b(var1, var3)) {
            if (this.l instanceof NotificationIsland && ((NotificationIsland)this.l).m()) {
               return false;
            } else {
               if (this.l instanceof MusicIsland) {
                  this.y = true;
                  this.x = System.currentTimeMillis();
               }

               this.d();
               return true;
            }
         } else if (var5 == 1 && this.l == null && this.b(var1, var3)) {
            this.w.a(this.v, this.u, this.s, this.t, 120.0F);
            return true;
         } else {
            return this.l instanceof NotificationIsland var8 && var8.o()
               ? var8.a(var1, var3, var5)
               : this.l instanceof MusicIsland var9 && var9.a(var1, var3, var5);
         }
      }
   }

   private boolean b(double var1, double var3) {
      return var1 >= this.v && var1 <= this.v + this.s && var3 >= this.u && var3 <= this.u + this.t;
   }

   public void b(double var1, double var3, int var5) {
      if (this.w.d()) {
         this.w.c((int)var1, (int)var3);
      }

      if (this.l instanceof MusicIsland) {
         ((MusicIsland)this.l).b(var1, var3, var5);
      }
   }

   public boolean a(double var1, double var3, double var5) {
      return this.w.d() ? this.w.a((float)var5, (int)var1, (int)var3) : false;
   }

   public void a(double var1, double var3, double var5, double var7) {
      if (this.w.d()) {
         this.w.a((int)var1, (int)var3, var5, var7);
      }

      if (this.l instanceof MusicIsland) {
         ((MusicIsland)this.l).b(var1, var3);
      }
   }

   public void d() {
      if (this.l != null || this.m != null) {
         this.l = null;
         this.m = null;
         this.k.clear();
         this.r.a(0.0, 0.1999999781541723, Easings.k);
         this.q.a(1.0, 0.1999999781541723, Easings.k);
         float var1 = this.j.c();
         float var2 = this.j.d();
         this.n.a(var1, 0.30000018814265855, Easings.k);
         this.o.a(var2, 0.30000018814265855, Easings.k);
      }
   }

   private void b(String var1, boolean var2) {
      if (this.l instanceof ModuleToggleIsland var3 && var3.m().equals(var1)) {
         var3.a(var2);
      } else {
         this.b(new ModuleToggleIsland(var1, var2));
      }
   }

   public void a(Island var1) {
      this.b(var1);
   }

   private boolean j() {
      if (!this.w.i()) {
         return false;
      } else if (this.y) {
         return false;
      } else {
         MusicHandler var1 = HandlerRegistry.j;
         if (var1 == null) {
            return false;
         } else {
            MusicState var2 = var1.i();
            return var2 == null ? false : var2.c();
         }
      }
   }

   private void k() {
      if (this.w.i()) {
         MusicHandler var1 = HandlerRegistry.j;
         if (var1 != null) {
            MusicState var2 = var1.i();
            if (var2 != null) {
               if (var2.k()) {
                  this.y = false;
                  b();
               }

               if (var2.l()) {
                  this.y = false;
                  c();
               }

               if (this.y && var2.c() && !this.w.d()) {
                  long var3 = System.currentTimeMillis() - this.x;
                  if (var3 >= 3000L) {
                     this.y = false;
                     b();
                  }
               }
            }
         }
      }
   }

   private void l() {
      this.k();
      if (this.m != null) {
         this.m.e();
         if (this.m.g() || this.m.h()) {
            this.m = null;
         }
      }

      if (this.l != null) {
         this.l.e();
         if (this.l instanceof MusicIsland) {
            float var1 = this.l.c();
            float var2 = this.l.d();
            if (this.r.j() >= 0.9900000190925857) {
               this.n.d(var1);
               this.o.d(var2);
            }
         } else {
            float var3 = this.l.c();
            float var9 = this.l.d();
            if (Math.abs(this.n.i() - var3) > 0.1F) {
               this.n.a(var3, 0.25, Easings.k);
            }

            if (Math.abs(this.o.i() - var9) > 0.1F) {
               this.o.a(var9, 0.25, Easings.k);
            }
         }

         if (this.l.g()) {
            this.l = null;
            if (this.m != null && !this.m.h()) {
               this.l = this.m;
               this.m = null;
               float var6 = this.l.c();
               float var12 = this.l.d();
               this.n.a(var6, 0.30000018814265855, Easings.k);
               this.o.a(var12, 0.30000018814265855, Easings.k);
               this.r.a(1.0, 0.1999999781541723, Easings.k);
               this.q.a(0.0, 0.1500000196196393, Easings.k);
            } else if (this.j()) {
               this.l = new MusicIsland();
               float var4 = this.l.c();
               float var10 = this.l.d();
               this.n.a(var4, 0.30000018814265855, Easings.k);
               this.o.a(var10, 0.30000018814265855, Easings.k);
               this.r.d(0.0);
               this.r.a(1.0, 0.1999999781541723, Easings.k);
               this.q.a(0.0, 0.1500000196196393, Easings.k);
            } else {
               this.r.a(0.0, 0.1999999781541723, Easings.k);
               this.q.a(1.0, 0.1999999781541723, Easings.k);
               float var5 = this.j.c();
               float var11 = this.j.d();
               this.n.a(var5, 0.30000018814265855, Easings.k);
               this.o.a(var11, 0.30000018814265855, Easings.k);
            }
         }
      }

      if (this.l == null && !this.k.isEmpty()) {
         this.l = this.k.poll();
         float var7 = this.l.c();
         float var13 = this.l.d();
         this.n.a(var7, 0.30000018814265855, Easings.k);
         this.o.a(var13, 0.30000018814265855, Easings.k);
         this.r.a(1.0, 0.1999999781541723, Easings.k);
         this.q.a(0.0, 0.1500000196196393, Easings.k);
      }

      this.n.a();
      this.o.a();
      this.q.a();
      this.r.a();
      float var8 = this.n();
      if (Math.abs(this.u - var8) > 0.5F) {
         this.p.a(var8, 0.30000018814265855, Easings.k, true);
      }

      this.p.a();
      this.s = (float)this.n.j();
      this.t = (float)this.o.j();
      this.u = (float)this.p.j();
      if (this.l == null) {
         float var14 = this.j.c();
         if (Math.abs(this.s - var14) > 0.5F) {
            this.n.a(var14, 0.30000018814265855, Easings.k, true);
         }
      }
   }

   public void a(MatrixStack var1, Render var2) {
      if (b.world != null && b.player != null) {
         this.l();
         boolean var3 = this.o();
         if (var3 != this.F) {
            if (var3) {
               this.E.a(0.0, 0.1500000196196393, Easings.k);
               if (this.w.d()) {
                  this.w.b();
               }
            } else {
               this.E.a(1.0, 0.1999999781541723, Easings.k);
            }

            this.F = var3;
         }

         this.E.a();
         float var4 = (float)this.E.j();
         if (!(var4 < 0.01F)) {
            float var5 = b.getWindow().getFramebufferWidth() / 2.0F;
            float var6 = var5 / 2.0F;
            float var7 = (float)(Math.round((var6 - this.s / 2.0F) * 2.0) / 2.0);
            float var8 = this.u;
            this.v = var7;
            Color var9 = this.a(c, var4);
            Color var10 = this.a(d, var4);
            Color var11 = this.a(e, var4);
            Color var12 = this.a(f, var4);
            byte var13 = 2;
            var2.a(var7 - var13 / 2.0F, var8 - var13 / 2.0F, this.s + var13, this.t + var13, 12.0F, var9, var9, var10, var10, var1);
            var2.a(var7, var8, this.s, this.t, 12.0F, var11, var11, var12, var12, var1);
            float var14 = (float)this.q.j() * var4;
            float var15 = (float)this.r.j() * var4;
            var2.a().a(var7, var8, this.s, this.t, 12.0F, var1);
            if (var14 > 0.01F) {
               float var16 = var7 + this.j.j();
               float var17 = var8 + this.j.k();
               float var18 = this.s - this.j.j() * 2.0F;
               float var19 = this.t - this.j.k() * 2.0F;
               this.j.a(var1, var2, var16, var17, var18, var19, var14);
            }

            if (this.l != null && var15 > 0.01F) {
               float var20 = var7 + this.l.j();
               float var22 = var8 + this.l.k();
               float var23 = this.s - this.l.j() * 2.0F;
               float var25 = this.t - this.l.k() * 2.0F;
               this.l.a(var1, var2, var20, var22, var23, var25, var15);
            }

            var2.a().a(var1);
            if (this.w.d()) {
               this.w.b(var7, var8, this.s, this.t);
               double var21 = b.getWindow().getScaleFactor();
               int var24 = (int)(b.mouse.getX() * var21 / 2.0);
               int var26 = (int)(b.mouse.getY() * var21 / 2.0);
               this.w.a(var1, var2, var24, var26);
            }
         }
      }
   }

   public float e() {
      return this.s;
   }

   public float f() {
      return this.t;
   }

   private int m() {
      if (b.inGameHud == null) {
         return 0;
      } else if (ModuleRegistry.h != null && ModuleRegistry.h.s()) {
         return 0;
      } else {
         BossBarHud var1 = b.inGameHud.getBossBarHud();
         return var1 == null ? 0 : ((BossBarHudAccessor)var1).getBossBars().size();
      }
   }

   private float n() {
      int var1 = this.m();
      long var2 = System.currentTimeMillis();
      if (var1 > this.B) {
         this.B = var1;
         this.C = 0L;
      } else if (var1 < this.B) {
         if (this.C == 0L) {
            this.C = var2;
         } else if (var2 - this.C >= 300L) {
            this.B = var1;
            this.C = 0L;
         }
      } else {
         this.C = 0L;
      }

      this.A = var1;
      if (this.B == 0) {
         return 7.0F;
      } else {
         double var4 = b.getWindow().getScaleFactor();
         float var6 = this.B * 19.0F;
         float var7 = (float)(var6 * var4 / 2.0);
         return 7.0F + var7;
      }
   }

   public void a(double var1, double var3) {
      if (this.l instanceof MusicIsland var5) {
         if (DraggableManager.a().s()) {
            var5.n();
         } else {
            var5.a(var1, var3);
            var5.m();
         }
      }

      if (this.l instanceof NotificationIsland var6) {
         var6.n();
      }
   }

   public void g() {
      if (this.l instanceof MusicIsland) {
         ((MusicIsland)this.l).n();
      }
   }

   private Color a(Color var1, float var2) {
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), (int)(var1.getAlpha() * var2));
   }

   private boolean o() {
      if (b.inGameHud == null) {
         return false;
      } else {
         PlayerListHud var1 = b.inGameHud.getPlayerListHud();
         return var1 == null ? false : ((PlayerListHudAccessor)var1).isVisible();
      }
   }

   @Generated
   public Island h() {
      return this.l;
   }

   @Generated
   public WatermarkSettingsPanel i() {
      return this.w;
   }
}
