package pulse.features.modules.visuals;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.render.particle.AeParticleSystem;
import pulse.utils.render.particle.AeStar;
import pulse.utils.render.world.KillEffectLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.utils.render.ColorUtils;

@ModuleInfo(
   a = "Kill Effect",
   b = "Шейдерный 3D-эффект при убийстве",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class KillEffectModule extends Module {
   private static final String a = "Игроки";
   private static final String b = "Животные";
   private static final String c = "Мобы";
   private final SeparatorSetting f = new SeparatorSetting("Эффект");
   private final ModeSetting g = new ModeSetting("Эффект", new String[]{"Молния", "Ударная волна", "Дух"}, "Молния");
   private final ColorSetting h = new ColorSetting("Цвет", new Color(80, 160, 255)).a(() -> !this.g.b("Дух"));
   private final SeparatorSetting i = new SeparatorSetting("Цели");
   private final ModeSetting j = new ModeSetting("Срабатывать на", new String[]{"Игроки", "Животные", "Мобы"}, new int[]{0});
   private final SeparatorSetting k = new SeparatorSetting("Звёздный залп");
   private final BooleanSetting l = new BooleanSetting("Включить", false);
   private final ColorSetting m = new ColorSetting("Цвет залпа", new Color(255, 170, 204)).a(this.l::a);
   private final List<KillEffectModule.KillFx> n = new ArrayList<>();
   private Entity o;

   @EventHandler
   @Compile
   private void a(AttackEvent var1) {
      Entity var2 = var1.a();
      if (var2 != d.player && var2 instanceof LivingEntity && this.a(var2)) {
         this.o = var2;
      }
   }

   private boolean a(Entity var1) {
      if (var1 instanceof PlayerEntity) {
         return this.j.c("Игроки");
      } else if (var1 instanceof PassiveEntity) {
         return this.j.c("Животные");
      } else {
         return var1 instanceof MobEntity ? this.j.c("Мобы") : false;
      }
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      List<KillEffectModule.KillFx> effects = this.n;
      if (d.player == null || d.world == null) {
         return;
      }
      if (this.o != null && (this.o.isRemoved() || this.o instanceof LivingEntity && ((LivingEntity)this.o).getHealth() <= 0.0F)) {
         this.b(this.o);
         this.o = null;
      }
      var iterator = effects.iterator();
      while (iterator.hasNext()) {
         if (iterator.next().b()) {
            iterator.remove();
         }
      }
      while (effects.size() > 5) {
         effects.remove(0);
      }
   }

   @EventHandler
   public void a(RenderEvent var1) {
      if (d.world != null && !this.n.isEmpty()) {
         MatrixStack var2 = var1.a();
         Vec3d var3 = d.gameRenderer.getCamera().getCameraPos();
         Color var4 = this.h.a();

         for (KillEffectModule.KillFx var6 : this.n) {
            float var7 = var6.a();
            if (!(var7 >= 1.0F)) {
               if (var6.g.equals("Дух")) {
                  this.a(var2, var3, var6, var7);
               } else {
                  this.a(var2, var3, var6, var7, var4);
               }
            }
         }
      }
   }

   private void a(MatrixStack var1, Vec3d var2, KillEffectModule.KillFx var3, float var4, Color var5) {
      float var6 = var5.getRed() / 255.0F;
      float var7 = var5.getGreen() / 255.0F;
      float var8 = var5.getBlue() / 255.0F;
      Immediate var9 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
      if (var3.g.equals("Молния")) {
         VertexConsumer var10 = var9.getBuffer(KillEffectLayers.b);
         this.a(var1, var2, var10, var3.a, var3.b, var3.c, 2.0F, (float)var3.d + 28.0F, false, var4, var6, var7, var8);
         var9.draw(KillEffectLayers.b);
         VertexConsumer var11 = var9.getBuffer(KillEffectLayers.d);
         this.a(var1, var2, var11, var3.a, var3.b + 0.05000000213049992, var3.c, 4.0F, var4, var6, var7, var8);
         var9.draw(KillEffectLayers.d);
      } else if (var3.g.equals("Ударная волна")) {
         VertexConsumer var12 = var9.getBuffer(KillEffectLayers.f);
         this.a(var1, var2, var12, var3.a, var3.b + 0.05000000213049992, var3.c, 10.0F, var4, var6, var7, var8);
         var9.draw(KillEffectLayers.f);
      }
   }

   private void a(
      MatrixStack var1,
      Vec3d var2,
      VertexConsumer var3,
      double var4,
      double var6,
      double var8,
      float var10,
      float var11,
      boolean var12,
      float var13,
      float var14,
      float var15,
      float var16
   ) {
      var1.push();
      var1.translate(var4 - var2.x, var6 - var2.y, var8 - var2.z);
      float var17 = d.gameRenderer.getCamera().getYaw();
      var1.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-var17 + 180.0F));
      Matrix4f var18 = var1.peek().getPositionMatrix();
      float var19 = var10 / 2.0F;
      float var20 = var12 ? -var11 / 2.0F : 0.0F;
      float var21 = var12 ? var11 / 2.0F : var11;
      var3.vertex(var18, -var19, var20, 0.0F).texture(0.0F, 1.0F).color(var14, var15, var16, var13);
      var3.vertex(var18, var19, var20, 0.0F).texture(1.0F, 1.0F).color(var14, var15, var16, var13);
      var3.vertex(var18, var19, var21, 0.0F).texture(1.0F, 0.0F).color(var14, var15, var16, var13);
      var3.vertex(var18, -var19, var21, 0.0F).texture(0.0F, 0.0F).color(var14, var15, var16, var13);
      var1.pop();
   }

   private void a(
      MatrixStack var1, Vec3d var2, VertexConsumer var3, double var4, double var6, double var8, float var10, float var11, float var12, float var13, float var14
   ) {
      var1.push();
      var1.translate(var4 - var2.x, var6 - var2.y, var8 - var2.z);
      Matrix4f var15 = var1.peek().getPositionMatrix();
      float var16 = var10 / 2.0F;
      var3.vertex(var15, -var16, 0.0F, -var16).texture(0.0F, 0.0F).color(var12, var13, var14, var11);
      var3.vertex(var15, -var16, 0.0F, var16).texture(0.0F, 1.0F).color(var12, var13, var14, var11);
      var3.vertex(var15, var16, 0.0F, var16).texture(1.0F, 1.0F).color(var12, var13, var14, var11);
      var3.vertex(var15, var16, 0.0F, -var16).texture(1.0F, 0.0F).color(var12, var13, var14, var11);
      var1.pop();
   }

   private void b(Entity var1) {
      if (var1 != null && d.world != null) {
         double var2 = var1.getX();
         double var4 = var1.getY();
         double var6 = var1.getZ();
         double var8 = var1.getHeight();
         String var10 = this.g.e();
         if (this.l.a()) {
            this.a(var2, var4 + var8 / 2.0, var6);
         }

         double var11 = var4;
         if (var10.equals("Молния") || var10.equals("Ударная волна")) {
            var11 = this.b(var2, var4, var6);
         }

         short var13;
         if (var10.equals("Молния")) {
            var13 = 1500;
            d.world.playSound(d.player, var2, var11, var6, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.WEATHER, 3.0F, 1.2F);
         } else if (var10.equals("Ударная волна")) {
            var13 = 1500;
            d.world.playSound(d.player, var2, var11, var6, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.MASTER, 3.0F, 1.5F);
         } else {
            var13 = 3000;
            d.world.playSound(d.player, var2, var4, var6, SoundEvents.PARTICLE_SOUL_ESCAPE.value(), SoundCategory.PLAYERS, 2.0F, 0.7F);
         }

         LivingEntity var14 = null;
         float var15 = 0.0F;
         float var16 = 0.0F;
         float var17 = 0.0F;
         float var18 = 0.0F;
         float var19 = 0.0F;
         if (var10.equals("Дух") && var1 instanceof LivingEntity) {
            var14 = (LivingEntity)var1;
            var15 = var14.bodyYaw;
            var16 = var14.headYaw;
            var17 = var14.getPitch();
            var18 = var14.limbAnimator.getAnimationProgress();
            var19 = var14.limbAnimator.getSpeed();
         }

         this.n.add(new KillEffectModule.KillFx(var2, var11, var6, var8, var13, var10, var14, var15, var16, var17, var18, var19));
      }
   }

   private void a(double var1, double var3, double var5) {
      int var7 = ColorUtils.a(this.m.a().getRGB());
      Vector3f var8 = new Vector3f((float)var1, (float)var3, (float)var5);

      for (int var9 = 0; var9 < 24; var9++) {
         Vector3f var10 = new Vector3f(a(-0.18F, 0.18F), a(0.0F, 0.22F), a(-0.18F, 0.18F));
         AeParticleSystem.a(new AeStar(new Vector3f(var8), var10, var7, a(0.24F, 0.4F), false));
      }
   }

   private static float a(float var0, float var1) {
      return var0 + ThreadLocalRandom.current().nextFloat() * (var1 - var0);
   }

   private double b(double var1, double var3, double var5) {
      Mutable var7 = new Mutable((int)var1, (int)var3, (int)var5);

      for (int var8 = 0; var8 < 5; var8++) {
         var7.set((int)var1, (int)(var3 - var8), (int)var5);
         if (!d.world.getBlockState(var7).isAir()) {
            return var7.getY() + 1.0;
         }
      }

      return var3;
   }

   private void a(MatrixStack var1, Vec3d var2, KillEffectModule.KillFx var3, float var4) {
      LivingEntity var5 = var3.h;
      if (var5 != null) {
         if (d.getEntityRenderDispatcher().getRenderer(var5) instanceof LivingEntityRenderer var7) {
            LivingEntityRenderState var8 = (LivingEntityRenderState)var7.createRenderState();
            var8.baby = var5.isBaby();
            Identifier var9 = var7.getTexture(var8);
            float var10 = 1.0F - (1.0F - var4) * (1.0F - var4);
            float var11 = var10 * 4.0F;
            float var12 = var4 < 0.1F ? var4 / 0.1F : 1.0F;
            float var13 = (1.0F - var4) * 0.4F * var12;
            float var14 = 1.0F + var4 * 0.04F;
            float var15 = 0.85F;
            float var16 = 0.9F;
            float var17 = 1.0F;
            GL11.glDepthMask(false);
            Immediate var18 = d.getBufferBuilders().getEntityVertexConsumers();
            RenderLayer var19 = RenderLayers.entityTranslucent(var9);
            this.a(var1, var2, var3, var18, var19, var3.a, var3.b + var11, var3.c, var3.i, var14, var13, var15, var16, var17);
            if (var13 * 0.25F > 0.01F) {
               this.a(var1, var2, var3, var18, var19, var3.a, var3.b + var11, var3.c, var3.i, var14 * 1.06F, var13 * 0.25F, var15, var16, var17);
            }

            float var20 = var13 * 0.18F;
            float var21 = var11 - 0.4F;
            if (var20 > 0.01F && var21 > 0.0F) {
               this.a(var1, var2, var3, var18, var19, var3.a, var3.b + var21, var3.c, var3.i, var14 * 0.98F, var20, var15, var16, var17);
            }

            float var22 = var13 * 0.08F;
            float var23 = var11 - 0.9F;
            if (var22 > 0.01F && var23 > 0.0F) {
               this.a(var1, var2, var3, var18, var19, var3.a, var3.b + var23, var3.c, var3.i, var14 * 0.95F, var22, var15, var16, var17);
            }

            GL11.glDepthMask(true);
         }
      }
   }

   private void a(
      MatrixStack var1,
      Vec3d var2,
      KillEffectModule.KillFx var3,
      Immediate var4,
      RenderLayer var5,
      double var6,
      double var8,
      double var10,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17
   ) {
      if (!(var14 < 0.01F)) {
         LivingEntity var18 = var3.h;
         if (d.getEntityRenderDispatcher().getRenderer(var18) instanceof LivingEntityRenderer var20) {
            EntityModel var21 = var20.getModel();
            LivingEntityRenderState var22 = (LivingEntityRenderState)var20.createRenderState();
            var22.baby = var18.isBaby();
            var21.setAngles(var22);
            int var23 = ColorHelper.getArgb((int)(var14 * 255.0F), (int)(var15 * 255.0F), (int)(var16 * 255.0F), (int)(var17 * 255.0F));
            this.a(var1, var2, var6, var8, var10, var12, var18, var13);
            var21.render(var1, var4.getBuffer(var5), 15728880, OverlayTexture.DEFAULT_UV, var23);
            var4.draw();
            var1.pop();
         }
      }
   }

   private void a(MatrixStack var1, Vec3d var2, double var3, double var5, double var7, float var9, LivingEntity var10, float var11) {
      var1.push();
      var1.translate(var3 - var2.x, var5 - var2.y, var7 - var2.z);
      var1.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(var9 + 180.0F));
      var1.scale(-var11, -var11, var11);
      if (var10 instanceof AbstractClientPlayerEntity) {
         var1.scale(0.9375F, 0.9375F, 0.9375F);
      }

      if (var10.isBaby()) {
         var1.scale(0.5F, 0.5F, 0.5F);
      }

      var1.translate(0.0, -1.5009998593782101, 0.0);
   }

   @Compile
   @Override
   public void f() {
      this.n.clear();
      this.o = null;
      super.f();
   }

   static {
      NativeMethodLookup.lookup(KillEffectModule.class, 85);
   }

   @Environment(EnvType.CLIENT)
   private static class KillFx {
      final double a;
      final double b;
      final double c;
      final double d;
      final long e;
      final int f;
      final String g;
      final LivingEntity h;
      final float i;
      final float j;
      final float k;
      final float l;
      final float m;

      KillFx(
         double var1,
         double var3,
         double var5,
         double var7,
         int var9,
         String var10,
         LivingEntity var11,
         float var12,
         float var13,
         float var14,
         float var15,
         float var16
      ) {
         this.a = var1;
         this.b = var3;
         this.c = var5;
         this.d = var7;
         this.e = System.currentTimeMillis();
         this.f = var9;
         this.g = var10;
         this.h = var11;
         this.i = var12;
         this.j = var13;
         this.k = var14;
         this.l = var15;
         this.m = var16;
      }

      float a() {
         return Math.min(1.0F, (float)(System.currentTimeMillis() - this.e) / this.f);
      }

      boolean b() {
         return this.a() >= 1.0F;
      }
   }
}
