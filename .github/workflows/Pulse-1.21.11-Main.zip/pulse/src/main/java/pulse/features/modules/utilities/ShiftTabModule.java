package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.hit.HitResult.Type;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Shift Tab",
   b = "Приседает на 1 удар в воздухе для гарантированного крита",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ShiftTabModule extends Module {
   private static final Random a = new Random();
   private boolean b = false;
   private int c = 0;
   private int f = 0;
   private boolean g = false;
   private boolean h = false;
   private boolean i = true;
   private int j = 0;
   private boolean k = false;

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      if (d.player == null || d.world == null) {
         return;
      }
      ClientPlayerEntity player = d.player;
      this.a(d.player);
      if (!this.b && this.b(player)) {
         this.n();
      }
      if (this.b) {
         this.c++;
         if (this.c >= this.f) {
            d.options.sneakKey.setPressed(this.k);
            this.b = false;
            this.c = 0;
         }
      }
   }

   private void a(ClientPlayerEntity var1) {
      boolean var2 = d.options.attackKey.isPressed();
      boolean var3 = !var1.isOnGround();
      if (var2 && !this.g) {
         this.j++;
      }

      if (!var3 && this.h) {
         this.j = 0;
         this.i = true;
      }

      if (!var2 && this.g) {
         this.i = true;
      }

      this.g = var2;
      this.h = var3;
   }

   private boolean b(ClientPlayerEntity var1) {
      boolean var2 = !var1.isOnGround();
      if (!var2) {
         return false;
      } else {
         boolean var3 = d.crosshairTarget != null && d.crosshairTarget.getType() == Type.ENTITY;
         boolean var4 = d.options.attackKey.isPressed();
         boolean var5 = var1.getVelocity().y < -0.20000000657758504;
         boolean var6 = this.j == 1;
         boolean var7 = !var1.isTouchingWater() && !var1.isClimbing() && !var1.hasVehicle();
         return var3 && var4 && var5 && var6 && this.i && var7;
      }
   }

   private void n() {
      this.k = this.o();
      this.b = true;
      this.c = 0;
      this.f = a.nextBoolean() ? 2 : 3;
      d.options.sneakKey.setPressed(true);
      this.i = false;
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.b = false;
      this.c = 0;
      this.j = 0;
      this.i = true;
      this.g = false;
      this.h = false;
      if (d != null && d.options != null) {
         d.options.sneakKey.setPressed(this.o());
      }
   }

   private boolean o() {
      return d != null && d.getWindow() != null ? InputUtil.isKeyPressed(d.getWindow(), d.options.sneakKey.getDefaultKey().getCode()) : false;
   }

   static {
      NativeMethodLookup.lookup(ShiftTabModule.class, 73);
   }
}
