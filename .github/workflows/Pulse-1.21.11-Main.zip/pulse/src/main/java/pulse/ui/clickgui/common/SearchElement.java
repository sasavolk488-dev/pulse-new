package pulse.ui.clickgui.common;

import java.awt.Color;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.ColorUtils;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class SearchElement {
   private static final Color a = ClickGuiColors.d;
   private static final float b = 8.5F;
   private static final float c = 12.0F;
   private static final float d = 4.0F;
   private static final float e = 4.0F;
   private static final int f = 16;
   private float g;
   private float h;
   private float i;
   private float j;
   private String k = "";
   private int l = 0;
   private int m = -1;
   private int n = -1;
   private boolean o = false;
   private final Animation p = new Animation();
   private final Animation q = new Animation();
   private final Animation r = new Animation();
   private boolean s = false;
   private boolean t = true;
   private boolean u = false;
   private Consumer<String> v;

   public SearchElement() {
      this.r.d(1.0);
   }

   public SearchElement(float var1, float var2) {
      this();
      this.i = var1;
      this.j = var2;
   }

   public void a(float var1, float var2) {
      this.g = var1;
      this.h = var2;
   }

   public void b(float var1, float var2) {
      this.i = var1;
      this.j = var2;
   }

   public void a(Consumer<String> var1) {
      this.v = var1;
   }

   public void a(boolean var1) {
      this.u = var1;
   }

   public String a() {
      return this.k;
   }

   public void a(String var1) {
      this.k = var1;
      this.l = var1.length();
      this.r();
      this.u();
   }

   public void b() {
      this.k = "";
      this.l = 0;
      this.r();
      this.u();
   }

   public boolean c() {
      return this.o;
   }

   public void b(boolean var1) {
      if (this.o != var1) {
         this.o = var1;
         this.p.a(var1 ? 1.0 : 0.0, 0.20000000608279528, Easings.h);
         if (var1) {
            this.r.d(1.0);
            this.t = false;
            this.r.a(0.3000000000350245, 0.5, Easings.i);
         }
      }
   }

   public boolean d() {
      return this.k.isEmpty();
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, int var7, int var8) {
      this.g = var3;
      this.h = var4;
      this.i = var5;
      this.j = var6;
      this.p.a();
      this.q.a();
      if (this.o) {
         this.r.a();
         if (this.r.d()) {
            this.t = !this.t;
            this.r.a(this.t ? 1.0 : 0.3000000000350245, 0.5, Easings.i);
         }
      } else {
         this.r.d(1.0);
         this.t = true;
      }

      boolean var9 = !this.u && OverlayElement.a().b();
      boolean var10 = !var9 && MouseUtil.a(var3, var4, var5, var6, (double)var7, (double)var8);
      if (var9 && this.s) {
         this.q.a(0.0, 0.15000007922092254, Easings.h);
         this.s = false;
      } else if (!var9 && var10 != this.s) {
         this.q.a(var10 ? 1.0 : 0.0, 0.15000007922092254, Easings.h);
         this.s = var10;
      }

      float var11 = (float)this.p.j();
      float var12 = (float)this.q.j();
      this.a(var1, var2, var3, var4, var5, var6, var11, var12);
      this.a(var1, var2, var3, var4, var6, var11, var12);
      this.b(var1, var2, var3, var4, var5, var6, var11);
      if ((var10 || this.o) && !var9) {
         MouseUtil.g();
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      int var9 = (int)(var8 * 3.0F);
      Color var10 = ClickGuiColors.b(ClickGuiColors.S, var9);
      Color var11 = ClickGuiColors.b(ClickGuiColors.T, var9);
      var2.a(var3, var4, var5, var6, 8.5F, var10, var10, var11, var11, var1);
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      FontRenderer var8 = Fonts.d[12];
      FontRenderer var9 = Fonts.b[14];
      String var10 = "\ue921";
      float var11 = var8.a(var10);
      float var12 = var3 + 4.0F + 6.0F;
      float var13 = var12 - var11 / 2.0F + 2.0F;
      float var14 = var4 + var5 / 2.0F - var9.b("A") / 4.0F + 0.5F;
      Color var15 = ColorUtils.a(ColorUtils.a(ClickGuiColors.b, a, var7), a, var6);
      var8.a(var10, var13, var14, var15, var1);
   }

   private void b(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      FontRenderer var8 = Fonts.b[14];
      float var9 = var3 + 4.0F + 12.0F + 4.0F;
      float var10 = var4 + var6 / 2.0F - var8.b("A") / 4.0F - 0.5F;
      float var11 = var5 - 4.0F - 12.0F - 4.0F - 10.0F;
      var2.a().a(var9 - 2.0F, var4, var11 + 4.0F, var6, var1);
      if (this.k.isEmpty() && !this.o) {
         var8.a("Поиск", var9, var10, ClickGuiColors.b, var1);
      } else if (this.k.isEmpty() && this.o) {
         float var18 = (float)this.r.j();
         Color var20 = ClickGuiColors.a(ClickGuiColors.a, (int)(255.0F * var18));
         var8.a("|", var9, var10 - 0.5F, var20, var1);
      } else {
         if (this.q()) {
            int var12 = Math.min(this.m, this.n);
            int var13 = Math.max(this.m, this.n);
            float var14 = var9 + var8.a(this.k, var12);
            float var15 = var9 + var8.a(this.k, var13);
            float var16 = var15 - var14;
            var2.a(var14, var4 + 4.0F, var16, var6 - 8.0F, 2.0F, ClickGuiColors.A, var1);
         }

         var8.a(this.k, var9, var10, ClickGuiColors.a, var1);
         if (this.o && !this.q()) {
            float var17 = (float)this.r.j();
            if (var17 > 0.3F) {
               float var19 = var9 + var8.a(this.k, this.l);
               Color var21 = ClickGuiColors.a(ClickGuiColors.a, (int)(255.0F * var17));
               var2.a(var19, var4 + 5.0F, 1.0F, var6 - 10.0F, var21, var1);
            }
         }
      }

      var2.a().a(var1);
   }

   public boolean a(int var1, int var2) {
      boolean var3 = OverlayElement.a().b();
      boolean var4 = MouseUtil.a(this.g, this.h, this.i, this.j, (double)var1, (double)var2);
      if (var4 && !var3) {
         this.b(true);
         FontRenderer var5 = Fonts.b[14];
         float var6 = this.g + 4.0F + 12.0F + 4.0F;
         float var7 = var1 - var6;
         this.l = var5.a(this.k, var7);
         this.r();
         return true;
      } else {
         if (this.o) {
            this.b(false);
         }

         return false;
      }
   }

   public boolean a(int var1, int var2, int var3) {
      if (!this.o) {
         return false;
      } else {
         boolean var4 = (var3 & 2) != 0;
         boolean var5 = (var3 & 1) != 0;
         if (var4) {
            switch (var1) {
               case 65:
                  this.m();
                  return true;
               case 67:
                  this.n();
                  return true;
               case 86:
                  this.o();
                  return true;
               case 88:
                  this.p();
                  return true;
            }
         }

         switch (var1) {
            case 256:
               this.b(false);
               this.r();
               return true;
            case 257:
               this.b(false);
               this.r();
               return true;
            case 258:
            case 260:
            case 264:
            case 265:
            case 266:
            case 267:
            default:
               return false;
            case 259:
               this.i();
               return true;
            case 261:
               this.j();
               return true;
            case 262:
               this.b(var5, var4);
               return true;
            case 263:
               this.a(var5, var4);
               return true;
            case 268:
               this.c(var5);
               return true;
            case 269:
               this.d(var5);
               return true;
         }
      }
   }

   public boolean a(char var1, int var2) {
      if (!this.o) {
         return false;
      } else if (Character.isISOControl(var1)) {
         return false;
      } else if (this.k.length() >= 16 && !this.q()) {
         return true;
      } else {
         if (this.q()) {
            this.s();
         }

         if (this.k.length() < 16) {
            this.k = this.k.substring(0, this.l) + var1 + this.k.substring(this.l);
            this.l++;
            this.t();
            this.u();
         }

         return true;
      }
   }

   private void i() {
      if (this.q()) {
         this.s();
      } else if (this.l > 0) {
         this.k = this.k.substring(0, this.l - 1) + this.k.substring(this.l);
         this.l--;
         this.u();
      }

      this.t();
   }

   private void j() {
      if (this.q()) {
         this.s();
      } else if (this.l < this.k.length()) {
         this.k = this.k.substring(0, this.l) + this.k.substring(this.l + 1);
         this.u();
      }

      this.t();
   }

   private void a(boolean var1, boolean var2) {
      int var3 = this.l;
      if (var2) {
         var3 = this.k();
      } else {
         var3 = Math.max(0, this.l - 1);
      }

      if (var1) {
         if (!this.q()) {
            this.m = this.l;
         }

         this.n = var3;
      } else {
         if (this.q()) {
            var3 = Math.min(this.m, this.n);
         }

         this.r();
      }

      this.l = var3;
      this.t();
   }

   private void b(boolean var1, boolean var2) {
      int var3 = this.l;
      if (var2) {
         var3 = this.l();
      } else {
         var3 = Math.min(this.k.length(), this.l + 1);
      }

      if (var1) {
         if (!this.q()) {
            this.m = this.l;
         }

         this.n = var3;
      } else {
         if (this.q()) {
            var3 = Math.max(this.m, this.n);
         }

         this.r();
      }

      this.l = var3;
      this.t();
   }

   private void c(boolean var1) {
      if (var1) {
         if (!this.q()) {
            this.m = this.l;
         }

         this.n = 0;
      } else {
         this.r();
      }

      this.l = 0;
      this.t();
   }

   private void d(boolean var1) {
      if (var1) {
         if (!this.q()) {
            this.m = this.l;
         }

         this.n = this.k.length();
      } else {
         this.r();
      }

      this.l = this.k.length();
      this.t();
   }

   private int k() {
      if (this.l == 0) {
         return 0;
      } else {
         int var1 = this.l - 1;

         while (var1 > 0 && Character.isWhitespace(this.k.charAt(var1))) {
            var1--;
         }

         while (var1 > 0 && !Character.isWhitespace(this.k.charAt(var1 - 1))) {
            var1--;
         }

         return var1;
      }
   }

   private int l() {
      if (this.l >= this.k.length()) {
         return this.k.length();
      } else {
         int var1 = this.l;

         while (var1 < this.k.length() && !Character.isWhitespace(this.k.charAt(var1))) {
            var1++;
         }

         while (var1 < this.k.length() && Character.isWhitespace(this.k.charAt(var1))) {
            var1++;
         }

         return var1;
      }
   }

   private void m() {
      this.m = 0;
      this.n = this.k.length();
      this.l = this.k.length();
   }

   private void n() {
      if (this.q()) {
         int var1 = Math.min(this.m, this.n);
         int var2 = Math.max(this.m, this.n);
         String var3 = this.k.substring(var1, var2);
         MinecraftClient.getInstance().keyboard.setClipboard(var3);
      }
   }

   private void o() {
      String var1 = MinecraftClient.getInstance().keyboard.getClipboard();
      if (var1 != null && !var1.isEmpty()) {
         var1 = var1.replaceAll("[\\r\\n\\t]", "");
         if (this.q()) {
            this.s();
         }

         int var2 = 16 - this.k.length();
         if (var1.length() > var2) {
            var1 = var1.substring(0, var2);
         }

         if (!var1.isEmpty()) {
            this.k = this.k.substring(0, this.l) + var1 + this.k.substring(this.l);
            this.l = this.l + var1.length();
            this.u();
         }

         this.t();
      }
   }

   private void p() {
      if (this.q()) {
         this.n();
         this.s();
      }
   }

   private boolean q() {
      return this.m != -1 && this.n != -1 && this.m != this.n;
   }

   private void r() {
      this.m = -1;
      this.n = -1;
   }

   private void s() {
      if (this.q()) {
         int var1 = Math.min(this.m, this.n);
         int var2 = Math.max(this.m, this.n);
         this.k = this.k.substring(0, var1) + this.k.substring(var2);
         this.l = var1;
         this.r();
         this.u();
      }
   }

   private void t() {
      this.r.d(1.0);
      this.t = false;
      this.r.a(0.3000000000350245, 0.5, Easings.i);
   }

   private void u() {
      if (this.v != null) {
         this.v.accept(this.k);
      }
   }

   public float e() {
      return this.g;
   }

   public float f() {
      return this.h;
   }

   public float g() {
      return this.i;
   }

   public float h() {
      return this.j;
   }
}
