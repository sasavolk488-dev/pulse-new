package pulse.config.cloud;

import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import pulse.Pulse;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.common.CategoriesElement;
import pulse.ui.clickgui.menu.friends.FriendEntry;
import pulse.ui.clickgui.menu.friends.FriendsListPanel;
import pulse.ui.clickgui.menu.friends.FriendsMenu;
import pulse.ui.clickgui.menu.markers.MarkerEntry;
import pulse.ui.clickgui.menu.markers.MarkerManager;
import pulse.ui.clickgui.menu.markers.MarkerSettings;
import pulse.config.ConfigData;
import pulse.config.ConfigMetadata;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.hud.DraggableManager;
import pulse.features.modules.hud.VanillaPositioned;
import pulse.features.modules.hud.components.WatermarkComponent;
import pulse.features.modules.hud.components.WatermarkSettingsPanel;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.hud.ClientColorModule;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.FolderSetting;
import pulse.core.settings.InputSetting;
import pulse.core.settings.ItemColorSetting;
import pulse.core.settings.KeySetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;
import pulse.core.settings.Setting;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;

@Environment(EnvType.CLIENT)
public class CloudConfigManager {
   private static final CloudConfigManager a = new CloudConfigManager();
   private static final int b = 30;
   private static final DateTimeFormatter c = DateTimeFormatter.ISO_LOCAL_DATE;
   private CloudConfigService d;
   private ScheduledExecutorService e;
   private volatile boolean f = false;

   private CloudConfigManager() {
   }

   public static CloudConfigManager a() {
      return a;
   }

   public void b() {
      if (!this.f) {
         RealtimeSyncServiceV2 var1 = RealtimeSyncServiceV2.L();
         if (var1 != null && var1.d != null) {
            this.d = var1.d;
            if (this.d.g()) {
               ConfigData var2 = this.d.b();
               if (var2 != null) {
                  this.a(var2);
               }

               this.f = true;
               this.m();
            }
         }
      }
   }

   public void c() {
      if (this.e != null) {
         this.e.shutdown();

         try {
            this.e.awaitTermination(5L, TimeUnit.SECONDS);
         } catch (InterruptedException var2) {
            Thread.currentThread().interrupt();
         }
      }

      this.d();
   }

   public void d() {
      if (this.d != null && this.d.g()) {
         ConfigData var1 = this.l();
         this.d.b(var1);
      }
   }

   private void m() {
      if (this.e != null) {
         this.e.shutdown();
      }

      this.e = Executors.newSingleThreadScheduledExecutor(var0 -> {
         Thread var1 = new Thread(var0, "CloudConfigAutoSave");
         var1.setDaemon(true);
         return var1;
      });
      this.e.scheduleAtFixedRate(() -> {
         if (this.d != null && this.d.i()) {
            try {
               ConfigData var1 = this.l();
               this.d.a(var1, null, null);
            } catch (Exception var2) {
            }
         }
      }, 30L, 30L, TimeUnit.SECONDS);
   }

   public void e() {
      if (this.d != null && this.d.g()) {
         ConfigData var1 = this.l();
         this.d.a(var1, null, null);
      }
   }

   public void f() {
      if (this.d != null && this.d.g()) {
         ConfigData var1 = this.d.b();
         if (var1 != null) {
            this.a(var1);
         }
      }
   }

   public void a(String var1, Runnable var2, Consumer<String> var3) {
      if (this.d != null && this.d.g()) {
         ConfigData var4 = this.l();
         this.d.a(var4, var1, () -> {
            ConfigData var2x = this.d.b();
            if (var2x != null) {
               MinecraftClient.getInstance().execute(() -> this.a(var2x));
            }

            if (var2 != null) {
               var2.run();
            }
         }, var3);
      } else {
         if (var3 != null) {
            var3.accept("Not initialized");
         }
      }
   }

   public void b(String var1, Runnable var2, Consumer<String> var3) {
      if (this.d != null && this.d.g()) {
         this.d.b(var1, var2, var3);
      } else {
         if (var3 != null) {
            var3.accept("Not initialized");
         }
      }
   }

   public void a(String var1, String var2, Runnable var3, Consumer<String> var4) {
      if (this.d != null && this.d.g()) {
         this.d.a(var1, var2, var3, var4);
      } else {
         if (var4 != null) {
            var4.accept("Not initialized");
         }
      }
   }

   public boolean a(String var1) {
      return this.d != null && this.d.g() ? this.d.a(var1) != null : false;
   }

   public String g() {
      if (this.d == null) {
         return "Default";
      } else {
         String var1 = this.d.c();
         return var1 != null ? var1 : "Default";
      }
   }

   public void h() {
      if (this.d != null) {
         this.d.h();
      }
   }

   public boolean i() {
      return this.f && this.d != null && this.d.g();
   }

   public CloudConfigService j() {
      return this.d;
   }

   public void a(String var1, int var2, Integer var3, Integer var4, Consumer<String> var5, Consumer<String> var6) {
      if (this.d != null && this.d.g()) {
         this.d.a(var1, var2, var3, var4, var5, var6);
      } else {
         if (var6 != null) {
            var6.accept("Not initialized");
         }
      }
   }

   public void c(String var1, Runnable var2, Consumer<String> var3) {
      if (this.d != null && this.d.g()) {
         this.d.d(var1, var2, var3);
      } else {
         if (var3 != null) {
            var3.accept("Not initialized");
         }
      }
   }

   public List<CloudConfigService.PremiumConfigMeta> k() {
      return this.d != null && this.d.g() ? this.d.a() : Collections.emptyList();
   }

   public void a(int var1, Consumer<ConfigData> var2, Consumer<String> var3) {
      if (this.d != null && this.d.g()) {
         this.d.a(var1, var2, var3);
      } else {
         if (var3 != null) {
            var3.accept("Not initialized");
         }
      }
   }

   public ConfigData l() {
      ConfigData var1 = new ConfigData();
      String var2 = this.g();
      ConfigData var3 = this.d != null ? this.d.b() : null;
      if (var3 != null && var3.b() != null) {
         ConfigMetadata var4 = var3.b();
         ConfigMetadata var5 = ConfigMetadata.a(var2, var4.c(), var4.d(), var4.e(), var4.f(), var4.j(), System.currentTimeMillis());
         var1.a(var5);
      } else {
         var1.a(ConfigMetadata.a(var2));
      }

      var1.a(this.n());
      var1.a(this.o());
      var1.b(this.p());
      var1.a(this.q());
      var1.b(this.r());
      var1.a(this.s());
      var1.a(this.t());
      var1.a(this.u());
      return var1;
   }

   public void a(ConfigData var1) {
      if (var1 != null) {
         this.a(var1.c());
         this.b(var1.d());
         this.c(var1.e());
         this.a(var1.f());
         this.b(var1.g());
         this.b(var1.h());
         this.a(var1.i());
         this.a(var1.j());
      }
   }

   private Map<String, ConfigData.ModuleData> n() {
      HashMap var1 = new HashMap<>();

      for (Module var3 : ModuleRegistry.b()) {
         ConfigData.ModuleData var4 = new ConfigData.ModuleData();
         var4.a(var3.k());
         var4.a(var3.j());
         var4.a(this.a(var3.m()));
         var1.put(var3.g(), var4);
      }

      return var1;
   }

   private Map<String, ConfigData.SettingData> a(List<Setting<?>> var1) {
      HashMap var2 = new HashMap<>();

      for (Setting var4 : var1) {
         if (!(var4 instanceof SeparatorSetting)) {
            ConfigData.SettingData var5 = new ConfigData.SettingData();
            if (var4 instanceof BooleanSetting) {
               var5.a("boolean");
               var5.a(((BooleanSetting)var4).a());
            } else if (var4 instanceof NumberSetting) {
               var5.a("number");
               var5.a(((NumberSetting)var4).b());
            } else if (var4 instanceof ColorSetting var6) {
               var5.a("color");
               var5.a(var6.c());
               var5.b(var6.d());
               var5.c(var6.e());
            } else if (var4 instanceof KeySetting) {
               var5.a("key");
               var5.a(((KeySetting)var4).b());
            } else if (var4 instanceof ModeSetting var8) {
               var5.a("mode");
               var5.a(var8.q());
               if (var8.d()) {
                  var var7 = var8.f();
                  var5.a(var7.stream().mapToInt(Integer::intValue).toArray());
               }
            } else if (var4 instanceof InputSetting) {
               var5.a("input");
               var5.a(((InputSetting)var4).i());
            } else if (var4 instanceof ItemColorSetting var9) {
               var5.a("itemColor");
               var5.a(var9.b());
               var5.a(var9.f());
            } else {
               if (!(var4 instanceof FolderSetting)) {
                  Pulse.m().warn("[CloudConfigManager] Unknown setting type: {} for setting: {}", var4.getClass().getSimpleName(), var4.l());
                  continue;
               }

               var5.a("folder");
               var5.a(var4.q());
            }

            var2.put(var4.l(), var5);
         }
      }

      return var2;
   }

   private List<ConfigData.FriendData> o() {
      ArrayList<ConfigData.FriendData> var1 = new ArrayList<>();
      FriendsListPanel var2 = this.v();
      if (var2 != null) {
         for (FriendEntry var4 : var2.a()) {
            ConfigData.FriendData var5 = new ConfigData.FriendData();
            var5.a(var4.a());
            var5.b(var4.b().format(c));
            var1.add(var5);
         }
      }

      return var1;
   }

   private List<ConfigData.MarkerData> p() {
      ArrayList<ConfigData.MarkerData> var1 = new ArrayList<>();

      for (MarkerEntry var3 : MarkerManager.a()) {
         if (!var3.j()) {
            ConfigData.MarkerData var4 = new ConfigData.MarkerData();
            var4.a(var3.a());
            var4.a(var3.b());
            var4.b(var3.c());
            var4.c(var3.d());
            var4.d(var3.e().getRGB());
            var4.b(var3.f().name());
            var4.a(var3.j());
            var4.a(var3.k());
            var4.e(var3.l());
            var4.b(var3.n());
            var1.add(var4);
         }
      }

      return var1;
   }

   private ConfigData.MarkerSettingsData q() {
      ConfigData.MarkerSettingsData var1 = new ConfigData.MarkerSettingsData();
      var1.a(MarkerSettings.e());
      var1.a(MarkerSettings.f());
      var1.b(MarkerSettings.g());
      var1.c(MarkerSettings.h());
      var1.d(MarkerSettings.i());
      var1.e(MarkerSettings.a());
      var1.b(MarkerSettings.b());
      var1.f(MarkerSettings.c());
      var1.g(MarkerSettings.d());
      var1.h(MarkerSettings.j());
      var1.i(MarkerSettings.k());
      var1.j(MarkerSettings.l());
      return var1;
   }

   private Map<String, ConfigData.HudPositionData> r() {
      HashMap var1 = new HashMap<>();
      DraggableManager var2 = DraggableManager.a();
      if (var2.i() != null) {
         var1.put("potions", this.a(var2.i()));
      }

      if (var2.j() != null) {
         var1.put("hotkeys", this.a(var2.j()));
      }

      if (var2.k() != null) {
         var1.put("cooldowns", this.a(var2.k()));
      }

      if (var2.l() != null) {
         var1.put("targetHud", this.a(var2.l()));
      }

      if (var2.m() != null) {
         var1.put("inventory", this.a(var2.m()));
      }

      if (var2.n() != null) {
         ConfigData.HudPositionData var3 = this.a(var2.n());
         var3.a(var2.n().b());
         var1.put("scoreboard", var3);
      }

      if (var2.o() != null) {
         ConfigData.HudPositionData var4 = this.a(var2.o());
         var4.a(var2.o().b());
         var1.put("bossbar", var4);
      }

      return var1;
   }

   private ConfigData.HudPositionData a(DraggableComponent var1) {
      return new ConfigData.HudPositionData(var1.u().a(), var1.u().b(), var1.g());
   }

   private String s() {
      try {
         if (Pulse.l().j() instanceof ClickGuiScreen) {
            ClickGuiScreen var1 = (ClickGuiScreen)Pulse.l().j();
            CategoriesElement var2 = var1.k();
            if (var2 != null) {
               return var2.a().name();
            }
         }
      } catch (Exception var3) {
         Pulse.m().error("Failed to capture categories position", (Throwable)var3);
      }

      return "BOTTOM";
   }

   private ConfigData.WatermarkSettingsData t() {
      ConfigData.WatermarkSettingsData var1 = new ConfigData.WatermarkSettingsData();
      WatermarkComponent var2 = WatermarkComponent.a();
      if (var2 != null) {
         WatermarkSettingsPanel var3 = var2.i();
         var1.a(var3.h());
         var1.b(var3.i());
         var1.c(var3.j());
         var1.d(var3.k());
         var1.e(var3.l());
      }

      return var1;
   }

   private void a(Map<String, ConfigData.ModuleData> var1) {
      if (var1 != null) {
         for (Module var3 : ModuleRegistry.b()) {
            ConfigData.ModuleData var4 = (ConfigData.ModuleData)var1.get(var3.g());
            if (var4 != null) {
               var3.a(var4.b());
               var3.b(var4.a());
               this.a(var3.m(), var4.c());
            }
         }
      }
   }

   private void a(List<Setting<?>> var1, Map<String, ConfigData.SettingData> var2) {
      if (var2 != null) {
         for (Setting var4 : var1) {
            ConfigData.SettingData var5 = (ConfigData.SettingData)var2.get(var4.l());
            if (var5 != null) {
               try {
                  if (var4 instanceof BooleanSetting && "boolean".equals(var5.a())) {
                     ((BooleanSetting)var4).a((Boolean)var5.b());
                  } else if (var4 instanceof NumberSetting && "number".equals(var5.a())) {
                     Object var17 = var5.b();
                     if (var17 instanceof Number) {
                        ((NumberSetting)var4).a(((Number)var17).floatValue());
                     }
                  } else if (var4 instanceof ColorSetting && "color".equals(var5.a())) {
                     ((ColorSetting)var4).a(var5.c(), var5.d(), var5.e());
                  } else if (var4 instanceof KeySetting && "key".equals(var5.a())) {
                     Object var16 = var5.b();
                     if (var16 instanceof Number) {
                        ((KeySetting)var4).a(((Number)var16).intValue());
                     }
                  } else if (var4 instanceof ModeSetting && "mode".equals(var5.a())) {
                     ModeSetting var15 = (ModeSetting)var4;
                     Object var7 = var5.b();
                     if (var7 instanceof Number) {
                        var15.a(Integer.valueOf(((Number)var7).intValue()));
                     }

                     if (var15.d() && var5.f() != null) {
                        HashSet var8 = new HashSet<>();

                        for (int var12 : var5.f()) {
                           var8.add(var12);
                        }

                        var15.a(var8);
                     }
                  } else if (var4 instanceof InputSetting && "input".equals(var5.a())) {
                     ((InputSetting)var4).b((String)var5.b());
                  } else if (var4 instanceof ItemColorSetting && "itemColor".equals(var5.a())) {
                     ItemColorSetting var14 = (ItemColorSetting)var4;
                     if (var5.g() != null) {
                        var14.a(var5.g());
                     }

                     if (var5.h() != null) {
                        var14.a(new Color(var5.h()));
                     }
                  } else if (var4 instanceof FolderSetting && "folder".equals(var5.a())) {
                     Object var6 = var5.b();
                     if (var6 instanceof String) {
                        ((FolderSetting)var4).a((String)((String)var6));
                     }
                  }
               } catch (Exception var13) {
                  Pulse.m().error("Failed to apply setting: " + var4.l(), (Throwable)var13);
               }
            }
         }
      }
   }

   private void b(List<ConfigData.FriendData> var1) {
      if (var1 != null) {
         FriendsListPanel var2 = this.v();
         if (var2 != null) {
            var2.b();

            for (ConfigData.FriendData var4 : var1) {
               try {
                  LocalDate var5 = LocalDate.parse(var4.b(), c);
                  var2.a(new FriendEntry(var4.a(), var5));
               } catch (Exception var6) {
                  var2.a(new FriendEntry(var4.a()));
               }
            }
         }
      }
   }

   private void c(List<ConfigData.MarkerData> var1) {
      if (var1 != null) {
         MarkerManager.g().forEach(MarkerManager::b);

         for (ConfigData.MarkerData var3 : var1) {
            try {
               MarkerEntry.IconType var4 = MarkerEntry.IconType.valueOf(var3.f());
               MarkerEntry var5 = new MarkerEntry(var3.a(), var3.b(), var3.c(), var3.d(), new Color(var3.e()), var4);
               MarkerManager.a(var5);
            } catch (Exception var6) {
               Pulse.m().error("Failed to apply marker: " + var3.a(), (Throwable)var6);
            }
         }
      }
   }

   private void a(ConfigData.MarkerSettingsData var1) {
      if (var1 != null) {
         MarkerSettings.d(var1.a());
         MarkerSettings.b(var1.b());
         MarkerSettings.e(var1.c());
         MarkerSettings.f(var1.d());
         MarkerSettings.g(var1.e());
         MarkerSettings.a(var1.f());
         MarkerSettings.a(var1.g());
         MarkerSettings.b(var1.h());
         MarkerSettings.c(var1.i());
         MarkerSettings.h(var1.j());
         MarkerSettings.i(var1.k());
         MarkerSettings.j(var1.l());
      }
   }

   private void b(Map<String, ConfigData.HudPositionData> var1) {
      if (var1 != null) {
         DraggableManager var2 = DraggableManager.a();
         MinecraftClient var3 = MinecraftClient.getInstance();
         float var4 = (float)(var3.getWindow().getFramebufferWidth() / 2.0);
         float var5 = (float)(var3.getWindow().getFramebufferHeight() / 2.0);
         this.b(var2.i(), (ConfigData.HudPositionData)var1.get("potions"), var4, var5);
         this.b(var2.j(), (ConfigData.HudPositionData)var1.get("hotkeys"), var4, var5);
         this.b(var2.k(), (ConfigData.HudPositionData)var1.get("cooldowns"), var4, var5);
         this.b(var2.l(), (ConfigData.HudPositionData)var1.get("targetHud"), var4, var5);
         this.b(var2.m(), (ConfigData.HudPositionData)var1.get("inventory"), var4, var5);
         this.a(var2.n(), (ConfigData.HudPositionData)var1.get("scoreboard"), var4, var5);
         this.a(var2.o(), (ConfigData.HudPositionData)var1.get("bossbar"), var4, var5);
         var2.d();
      }
   }

   private void a(DraggableComponent var1, ConfigData.HudPositionData var2, float var3, float var4) {
      if (var1 != null && var2 != null) {
         var1.f().a(var2.c());
         ((VanillaPositioned)var1).a(var2.d());
         if (var2.d()) {
            var1.b_();
         } else {
            this.b(var1, var2, var3, var4);
         }
      }
   }

   private void b(DraggableComponent var1, ConfigData.HudPositionData var2, float var3, float var4) {
      if (var1 != null && var2 != null) {
         var1.u().a(var2.a());
         var1.u().b(var2.b());
         var1.b_();
         float var5 = var1.u().a(var1.o(), var3);
         float var6 = var1.u().b(var1.p(), var4);
         var1.a(var5);
         var1.b(var6);
      }
   }

   private void b(String var1) {
      if (var1 != null) {
         try {
            CategoriesElement.Position var2 = CategoriesElement.Position.valueOf(var1);
            if (Pulse.l().j() instanceof ClickGuiScreen) {
               ClickGuiScreen var3 = (ClickGuiScreen)Pulse.l().j();
               CategoriesElement var4 = var3.k();
               if (var4 != null) {
                  var4.a(var2);
               }
            }
         } catch (IllegalArgumentException var5) {
            Pulse.m().warn("Unknown categories position: " + var1);
         } catch (Exception var6) {
            Pulse.m().error("Failed to apply categories position", (Throwable)var6);
         }
      }
   }

   private void a(ConfigData.WatermarkSettingsData var1) {
      if (var1 != null) {
         WatermarkComponent var2 = WatermarkComponent.a();
         if (var2 != null) {
            WatermarkSettingsPanel var3 = var2.i();
            var3.a(var1.a());
            var3.b(var1.b());
            var3.c(var1.c());
            var3.d(var1.d());
            var3.e(var1.e());
         }
      }
   }

   private ConfigData.ClientColorData u() {
      ConfigData.ClientColorData var1 = new ConfigData.ClientColorData();
      ClientColorModule var2 = ModuleRegistry.aw;
      var1.a(var2.a.e());
      var1.a(var2.b.c());
      var1.b(var2.b.d());
      var1.c(var2.b.e());
      var1.d(var2.c.c());
      var1.e(var2.c.d());
      var1.f(var2.c.e());
      var1.g(var2.f.c());
      var1.h(var2.f.d());
      var1.i(var2.f.e());
      return var1;
   }

   private void a(ConfigData.ClientColorData var1) {
      if (var1 != null) {
         ClientColorModule var2 = ModuleRegistry.aw;
         String[] var3 = var2.a.b();

         for (int var4 = 0; var4 < var3.length; var4++) {
            if (var3[var4].equals(var1.a())) {
               var2.a.a(Integer.valueOf(var4));
               break;
            }
         }

         var2.b.a(var1.b(), var1.c(), var1.d());
         var2.c.a(var1.e(), var1.f(), var1.g());
         var2.f.a(var1.h(), var1.i(), var1.j());
      }
   }

   private FriendsListPanel v() {
      try {
         if (Pulse.l().j() instanceof ClickGuiScreen) {
            ClickGuiScreen var1 = (ClickGuiScreen)Pulse.l().j();
            FriendsMenu var2 = var1.i();
            if (var2 != null) {
               return var2.f();
            }
         }
      } catch (Exception var3) {
         Pulse.m().error("Failed to get FriendsListPanel", (Throwable)var3);
      }

      return null;
   }
}
