package pulse.features.graffiti;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import javax.imageio.ImageIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public final class GraffitiLibrary {
   private static final GraffitiLibrary b = new GraffitiLibrary();
   public static final boolean a = false;
   private static final int c = 100;
   private static final long d = 4194304L;
   private static final int e = 256;
   private static final int f = 8;
   private final Map<String, GraffitiEntry> g = new ConcurrentHashMap<>();
   private volatile List<GraffitiEntry> h = List.of();
   private volatile long i = -1L;
   private volatile boolean j;

   private GraffitiLibrary() {
   }

   public static GraffitiLibrary a() {
      return b;
   }

   public Path b() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cache").resolve("graffiti");
   }

   public List<GraffitiEntry> c() {
      return this.h;
   }

   public boolean d() {
      return this.h.isEmpty();
   }

   public void e() {
      if (!this.j) {
         Thread var1 = new Thread(this::f, "pulse-graffiti-scan");
         var1.setDaemon(true);
         var1.start();
      }
   }

   private static boolean a(String var0) {
      String var1 = var0.toLowerCase();
      return var1.endsWith(".png") || var1.endsWith(".gif") || var1.endsWith(".webp");
   }

   private void f() {
      this.j = true;

      try {
         Path var1 = this.b();
         Files.createDirectories(var1);
         ArrayList<Path> var2 = new ArrayList<>();

         try (var var3 = Files.list(var1)) {
            Iterator var4 = var3.sorted(Comparator.comparing(var0 -> var0.getFileName().toString().toLowerCase())).iterator();

            while (var4.hasNext() && var2.size() < 100) {
               Path var5 = (Path)var4.next();
               if (Files.isRegularFile(var5) && a(var5.getFileName().toString())) {
                  var2.add(var5);
               }
            }
         }

         long var21 = 1L;

         for (Path var6 : var2) {
            var21 = var21 * 31L + var6.getFileName().toString().hashCode();
            var21 = var21 * 31L + Files.getLastModifiedTime(var6).toMillis();
            var21 = var21 * 31L + Files.size(var6);
         }

         if (var21 != this.i) {
            this.i = var21;
            var var25 = var2.stream().map(var0 -> var0.getFileName().toString()).toList();

            for (String var7 : new ArrayList<>(this.g.keySet())) {
               if (!var25.contains(var7)) {
                  GraffitiEntry var8 = this.g.remove(var7);
                  if (var8 != null) {
                     MinecraftClient.getInstance().execute(() -> {
                        for (Identifier var4x : var8.e()) {
                           MinecraftClient.getInstance().getTextureManager().destroyTexture(var4x);
                        }
                     });
                  }
               }
            }

            for (Path var28 : var2) {
               String var29 = var28.getFileName().toString();
               if (!this.g.containsKey(var29)) {
                  try {
                     this.a(var28, var29);
                  } catch (Exception var17) {
                     Pulse.m().warn("[Graffiti] пропускаю {}: {}", var29, var17.getMessage());
                  }
               }
            }

            this.g();
            return;
         }
      } catch (Exception var19) {
         Pulse.m().error("[Graffiti] скан папки не удался", (Throwable)var19);
         return;
      } finally {
         this.j = false;
      }
   }

   private void a(Path var1, String var2) throws Exception {
      long var3 = Files.size(var1);
      if (var3 > 4194304L) {
         throw new IllegalStateException("слишком жирный (" + var3 / 1024L / 1024L + " МБ, лимит 4)");
      } else {
         GraffitiDecoder.Frames var5 = GraffitiDecoder.a(var1);
         a(var2, null, -1, var5, var2x -> {
            this.g.put(var2, var2x);
            this.g();
         });
      }
   }

   public static void a(String var0, String var1, int var2, GraffitiDecoder.Frames var3, Consumer<GraffitiEntry> var4) {
      int[] var5 = a(var3.images());
      if (var5 == null) {
         throw new IllegalStateException("полностью прозрачный");
      } else {
         int var6 = var3.images().length;
         NativeImage[] var7 = new NativeImage[var6];

         for (int var8 = 0; var8 < var6; var8++) {
            BufferedImage var9 = var3.images()[var8].getSubimage(var5[0], var5[1], var5[2] - var5[0] + 1, var5[3] - var5[1] + 1);
            var7[var8] = b(a(var9));
         }

         Identifier[] var12 = new Identifier[var6];
         String var13 = "graffiti_" + b(var0);

         for (int var10 = 0; var10 < var6; var10++) {
            var12[var10] = Identifier.of("pulse", var13 + "_" + var10);
         }

         int[] var14 = var3.delaysMs();
         String var11 = var1 != null ? var1 : (var0.lastIndexOf(46) > 0 ? var0.substring(0, var0.lastIndexOf(46)) : var0);
         MinecraftClient.getInstance()
            .execute(
               () -> {
                  for (int var8x = 0; var8x < var6; var8x++) {
                     MinecraftClient.getInstance()
                        .getTextureManager()
                        .registerTexture(var12[var8x], new NativeImageBackedTexture(var12[var8x]::toString, var7[var8x]));
                  }

                  var4.accept(new GraffitiEntry(var0, var11, var12, var14, (float)var7[0].getWidth() / var7[0].getHeight(), var2));
               }
            );
         if (var6 > 1) {
            Pulse.m().info("[Graffiti] {} — анимированное, {} кадров", var0, var6);
         }
      }
   }

   private static int[] a(BufferedImage[] var0) {
      int var1 = var0[0].getWidth();
      int var2 = var0[0].getHeight();
      int var3 = var1;
      int var4 = var2;
      int var5 = -1;
      int var6 = -1;
      int[] var7 = new int[var1];

      for (BufferedImage var11 : var0) {
         for (int var12 = 0; var12 < var2; var12++) {
            var11.getRGB(0, var12, var1, 1, var7, 0, var1);

            for (int var13 = 0; var13 < var1; var13++) {
               if ((var7[var13] >>> 24 & 0xFF) > 8) {
                  if (var13 < var3) {
                     var3 = var13;
                  }

                  if (var13 > var5) {
                     var5 = var13;
                  }

                  if (var12 < var4) {
                     var4 = var12;
                  }

                  if (var12 > var6) {
                     var6 = var12;
                  }
               }
            }
         }
      }

      return var5 < 0 ? null : new int[]{var3, var4, var5, var6};
   }

   private static BufferedImage a(BufferedImage var0) {
      int var1 = var0.getWidth();
      int var2 = var0.getHeight();
      int var3 = Math.max(var1, var2);
      if (var3 <= 256 && var0.getType() == 2) {
         return var0;
      } else {
         float var4 = Math.min(1.0F, 256.0F / var3);
         int var5 = Math.max(1, Math.round(var1 * var4));
         int var6 = Math.max(1, Math.round(var2 * var4));
         BufferedImage var7 = new BufferedImage(var5, var6, 2);
         Graphics2D var8 = var7.createGraphics();
         var8.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
         var8.drawImage(var0, 0, 0, var5, var6, null);
         var8.dispose();
         return var7;
      }
   }

   private static NativeImage b(BufferedImage var0) {
      int var1 = var0.getWidth();
      int var2 = var0.getHeight();
      int[] var3 = var0.getRGB(0, 0, var1, var2, null, 0, var1);
      NativeImage var4 = new NativeImage(var1, var2, false);

      for (int var5 = 0; var5 < var2; var5++) {
         for (int var6 = 0; var6 < var1; var6++) {
            var4.setColorArgb(var6, var5, var3[var5 * var1 + var6]);
         }
      }

      return var4;
   }

   private void g() {
      var var1 = new ArrayList<>(this.g.values());
      var1.sort(Comparator.comparing(var0 -> var0.b().toLowerCase()));
      this.h = List.copyOf(var1);
   }

   private static String b(String var0) {
      StringBuilder var1 = new StringBuilder();

      for (char var5 : var0.toCharArray()) {
         var1.append(Character.isLetterOrDigit(var5) ? Character.toLowerCase(var5) : '_');
      }

      return var1.toString();
   }

   static {
      ImageIO.scanForPlugins();
   }
}
