package pulse.features.modules.visuals.animations;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.utils.animation.util.Easing;
import pulse.utils.animation.util.Easings;

@Environment(EnvType.CLIENT)
public class ChatAnimator {
   private float a = Float.NaN;
   private float b;
   private float c;
   private long d = 0L;
   private long e = 160L;
   private final Easing f = Easings.h;

   public void a() {
      if (!Float.isNaN(this.a) && this.d != 0L) {
         long var1 = System.currentTimeMillis();
         double var3 = var1 - this.d;
         double var5 = this.e;
         if (var3 >= var5) {
            this.a = this.c;
            this.d = 0L;
         } else {
            double var7 = var3 / var5;
            double var9 = this.f.ease(var7);
            this.a = (float)(this.b + (this.c - this.b) * var9);
         }
      }
   }

   public void a(long var1) {
      this.e = Math.max(1L, var1);
      if (Float.isNaN(this.a)) {
         this.a = 14.0F;
         this.b = 14.0F;
         this.c = 0.0F;
         this.d = System.currentTimeMillis();
      } else if (this.a != this.c) {
         this.b = this.a;
         this.c = 0.0F;
         this.d = System.currentTimeMillis();
      }
   }

   public float b() {
      return Float.isNaN(this.a) ? 0.0F : this.a;
   }

   public boolean c() {
      return this.b() > 0.0F;
   }

   public void d() {
      this.a = Float.NaN;
      this.d = 0L;
   }
}
