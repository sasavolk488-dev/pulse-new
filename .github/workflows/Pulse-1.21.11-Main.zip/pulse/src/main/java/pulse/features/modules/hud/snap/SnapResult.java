package pulse.features.modules.hud.snap;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class SnapResult {
   private final float a;
   private final float b;
   private final List<SnapLine> c;
   private final boolean d;
   private final boolean e;

   public SnapResult(float var1, float var2, List<SnapLine> var3, boolean var4, boolean var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public static SnapResult a(float var0, float var1) {
      return new SnapResult(var0, var1, new ArrayList<>(), false, false);
   }

   public float a() {
      return this.a;
   }

   public float b() {
      return this.b;
   }

   public List<SnapLine> c() {
      return this.c;
   }

   public boolean d() {
      return this.d;
   }

   public boolean e() {
      return this.e;
   }

   public boolean f() {
      return this.d || this.e;
   }
}
