package pulse.core.handler.impl;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import pulse.Pulse;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Fonts;
import pulse.utils.render.LoadingSpinner;
import pulse.utils.render.Render;
import pulse.utils.render.core.Renderer2D;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.ScaleUtils;

@HandlerInfo(
   a = true
)
@Environment(EnvType.CLIENT)
public class SplashRenderHandler extends Handler implements IMinecraft {
   private static final Color b = new Color(100, 72, 227);
   private static final int c = 16;
   private static final float f = 8.0F;
   private static final float g = 0.22F;
   private static final float h = 500.0F;
   private static final float i = 1000.0F;
   public static volatile boolean a = false;

   public void a(long var1, long var3) {
      float var5 = this.b(var1, var3);
      if (!(var5 <= 0.0F)) {
         int var6 = (int)(MathHelper.clamp(var5, 0.0F, 1.0F) * 255.0F);
         if (var6 > 0) {
            Renderer2D var7 = Pulse.l().o();
            Render var8 = Pulse.l().p();
            if (var7 != null && var8 != null) {
               a = true;
               MinecraftClient var9 = MinecraftClient.getInstance();
               int var10 = var9.getWindow().getFramebufferWidth();
               int var11 = var9.getWindow().getFramebufferHeight();
               if (var10 > 0 && var11 > 0) {
                  int var12 = var10 / 2;
                  int var13 = var11 / 2;
                  MatrixStack var14 = new MatrixStack();
                  Framebuffer var15 = var9.getFramebuffer();
                  int var16 = 0;
                  int var17 = GL11.glGetInteger(36006);
                  int var18 = GL11.glGetInteger(36010);
                  if (var15 != null && var15.getColorAttachment() instanceof GlTexture var20) {
                     int var42 = var20.getGlId();
                     var16 = GL30.glGenFramebuffers();
                     GL30.glBindFramebuffer(36160, var16);
                     GL30.glFramebufferTexture2D(36160, 36064, 3553, var42, 0);
                     GL11.glDrawBuffer(36064);
                     int var22 = GL30.glCheckFramebufferStatus(36160);
                     if (var22 != 36053) {
                        GL30.glDeleteFramebuffers(var16);
                        var16 = 0;
                        GL30.glBindFramebuffer(36160, var17);
                     }
                  }

                  GL11.glColorMask(true, true, true, true);
                  GL11.glDisable(2929);
                  GL11.glEnable(3042);
                  ScaleUtils.a(2.0);

                  try {
                     var7.a(var10, var11);

                     try {
                        var7.b(2.0F, 2.0F);

                        try {
                           this.a(var8, var14, var12, var13, var6);
                           var7.a();
                        } finally {
                           var7.h();
                        }
                     } finally {
                        var7.c();
                     }
                  } catch (Throwable var40) {
                     Pulse.m().error("Ошибка рендера сплеша", var40);
                  } finally {
                     ScaleUtils.a();
                     if (var16 != 0) {
                        GL30.glBindFramebuffer(36160, var16);
                        GL30.glFramebufferTexture2D(36160, 36064, 3553, 0, 0);
                     }

                     GL30.glBindFramebuffer(36009, var17);
                     GL30.glBindFramebuffer(36008, var18);
                     GL30.glBindFramebuffer(36160, var17);
                     if (var16 != 0) {
                        GL30.glDeleteFramebuffers(var16);
                     }
                  }
               }
            }
         }
      }
   }

   private void a(Render var1, MatrixStack var2, int var3, int var4, int var5) {
      float var6 = var3 / 2.0F;
      float var7 = var4 / 2.0F;
      Color var8 = new Color(b.getRed(), b.getGreen(), b.getBlue(), var5);
      var1.a(0.0F, 0.0F, var3, var4, var8, var2);
      FontRenderer var9 = Fonts.d[40];
      FontRenderer var10 = Fonts.b[32];
      String var11 = "\ue91e";
      String var12 = "PulseVisuals";
      float var13 = var9.a(var11);
      float var14 = var9.b(var11);
      float var15 = var10.a(var12);
      float var16 = var10.b(var12);
      float var17 = var13 + 8.0F + var15;
      float var18 = var6 - var17 / 2.0F;
      float var19 = var7 - var14 / 2.0F;
      float var20 = var7 - var16 / 2.0F;
      float var22 = var18 + var13 + 8.0F;
      float var23 = var20 + var16;
      float var24 = var23 + var4 * 0.22F + 8.0F;
      var24 = Math.min(var24, (float)(var4 - 16));
      LoadingSpinner.a(var6, var24, 16.0F, var5, var2);
      Color var25 = new Color(255, 255, 255, var5);
      var9.a(var11, var18, var19, var25, var2);
      var10.a(var12, var22, var20, var25, var2);
   }

   private float b(long var1, long var3) {
      long var5 = Util.getMeasuringTimeMs();
      if (var3 > -1L) {
         float var8 = (float)(var5 - var3) / 1000.0F;
         return 1.0F - MathHelper.clamp(var8 - 1.0F, 0.0F, 1.0F);
      } else if (var1 > -1L) {
         float var7 = (float)(var5 - var1) / 500.0F;
         return MathHelper.clamp(var7, 0.0F, 1.0F);
      } else {
         return 1.0F;
      }
   }
}
