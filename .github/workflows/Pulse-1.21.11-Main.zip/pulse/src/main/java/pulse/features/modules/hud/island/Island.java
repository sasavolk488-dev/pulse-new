package pulse.features.modules.hud.island;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.utils.render.Render;

@Environment(EnvType.CLIENT)
public abstract class Island {
   protected static final MinecraftClient a = MinecraftClient.getInstance();
   protected final Animation b = new Animation();
   protected final Animation c = new Animation();
   protected final Animation d = new Animation();
   protected float e = 8.0F;
   protected float f = 4.0F;
   protected float g = 12.0F;
   protected long h = 1000L;
   protected long i;
   protected boolean j = false;

   public Island() {
      this.i = System.currentTimeMillis();
      this.d.d(0.0);
      this.d.a(1.0, 0.2000000395026617, Easings.k);
   }

   public abstract float a();

   public abstract float b();

   public abstract void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7);

   public float c() {
      return this.e + this.a() + this.e;
   }

   public float d() {
      return this.f + this.b() + this.f;
   }

   public void e() {
      this.b.a();
      this.c.a();
      this.d.a();
      if (!this.j && System.currentTimeMillis() - this.i > this.h) {
         this.f();
      }
   }

   public void f() {
      if (!this.j) {
         this.j = true;
         this.d.a(0.0, 0.2000000395026617, Easings.j);
      }
   }

   public boolean g() {
      return this.j && this.d.j() <= 0.01000000374803169;
   }

   public boolean h() {
      return this.j;
   }

   public float i() {
      return (float)this.d.j();
   }

   public float j() {
      return this.e;
   }

   public float k() {
      return this.f;
   }

   public float l() {
      return this.g;
   }

   protected Color a(Color var1, float var2) {
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), (int)(var1.getAlpha() * var2));
   }
}
