package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({Screen.class})
public class ScreenNarrationMixin {
   @Inject(
      method = {"updateNarrator"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableUpdateNarrator(CallbackInfo var1) {
      var1.cancel();
   }

   @Inject(
      method = {"narrateScreenIfNarrationEnabled"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$disableInitialNarration(boolean var1, CallbackInfo var2) {
      var2.cancel();
   }
}
