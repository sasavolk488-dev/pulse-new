package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Fast Exp",
   b = "Ускоряет использование бутылочек опыта",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FastExpModule extends Module {
   @EventHandler
   @Compile
      private void a(UpdateEvent var1) {
      if (d.player == null || d.interactionManager == null) {
         return;
      }
      if (d.options.useKey.isPressed()) {
         for (var hand : net.minecraft.util.Hand.values()) {
            if (d.player.getStackInHand(hand).getItem() instanceof net.minecraft.item.ExperienceBottleItem) {
               if (d.interactionManager.interactItem(d.player, hand).isAccepted()) {
                  d.player.swingHand(hand);
               }
               break;
            }
         }
      }
   }

   static {
      NativeMethodLookup.lookup(FastExpModule.class, 59);
   }
}
