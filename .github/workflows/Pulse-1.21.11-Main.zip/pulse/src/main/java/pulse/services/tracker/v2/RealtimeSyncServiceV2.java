package pulse.services.tracker.v2;

import aethereal.NativeMethodLookup;
import java.awt.Color;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.ClickEvent.OpenUrl;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.Request.Builder;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.config.cloud.CloudConfigService;
import pulse.features.emote.EmoteManager;
import pulse.features.graffiti.GraffitiManager;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.ServerIntegrationHandler;
import pulse.features.modules.hud.components.WatermarkComponent;
import pulse.features.modules.hud.island.NotificationIsland;
import pulse.features.phrase.PhraseManager;
import pulse.features.resourcepack.ResourcePackService;
import pulse.utils.game.ChatUtils;
import pulse.utils.io.ModHashCache;
import pulse.services.accounts.UserInfo;

@Environment(EnvType.CLIENT)
public class RealtimeSyncServiceV2 extends WebSocketListener implements Runnable, SyncCallback {
   private static final long w = 60000L;
   private static final SecureRandom x = new SecureRandom();
   private static volatile PublicKey y;
   public static final int a = 1;
   public static final int b = 2;
   private final Map z = new ConcurrentHashMap();
   private final Set A = ConcurrentHashMap.newKeySet();
   private final ConcurrentLinkedQueue B = new ConcurrentLinkedQueue();
   private final Map C = new ConcurrentHashMap();
   private final ConcurrentHashMap<String, CompletableFuture<JSONObject>> D = new ConcurrentHashMap<>();
   public final TabSyncManager c;
   public final CloudConfigService d;
   public OkHttpClient e;
   public ScheduledExecutorService f;
   private WebSocket E;
   private ScheduledFuture F;
   private ScheduledFuture G;
   private volatile int H = 8;
   private volatile int I = 0;
   private volatile int J = 0;
   private volatile int K = 0;
   private volatile int L = 0;
   private volatile int M = 0;
   private volatile long N = 0L;
   private volatile long O = 0L;
   private volatile long P = 0L;
   private volatile long Q = 0L;
   private volatile long R = 0L;
   public volatile String g;
   public volatile String h;
   public volatile String i;
   public volatile String j;
   public volatile String k;
   public volatile String l;
   public volatile String m;
   public volatile String n;
   public volatile String o;
   public volatile String p;
   public volatile String q;
   public volatile String r;
   public volatile String s;
   public volatile String t;
   public volatile String u;
   public volatile String v;
   private volatile byte[] S;
   private volatile byte[] T;
   private volatile byte[] U;
   private volatile JSONArray V = new JSONArray();
   private volatile JSONArray W = new JSONArray();
   private volatile JSONArray X = new JSONArray();
   private volatile JSONArray Y = new JSONArray();
   private volatile boolean Z = false;
   private volatile double aa = 0.0;
   private volatile List ab;
   private volatile Set<String> ac;
   private volatile String ad;
   private volatile String ae;
   private volatile long af;
   private volatile String ag;
   private volatile boolean ah;
   private volatile boolean ai;
   private volatile int aj;
   private volatile int ak;
   private volatile int al;
   private volatile String am;
   private volatile String an;
   private volatile int ao;
   private volatile int ap;
   private volatile boolean aq;
   private volatile int ar;
   private volatile int as;
   private volatile int at;
   private volatile String au;
   private volatile boolean av;
   private volatile String aw;
   private volatile int ax;
   private volatile boolean ay;
   private volatile int az;
   private volatile int aA;
   private volatile int aB;
   private volatile int aC;
   private volatile int aD;
   private volatile int aE;
   private volatile String aF;
   private volatile double aG;
   private volatile double aH;
   private volatile double aI;
   private volatile int aJ;
   private volatile boolean aK;
   private volatile String aL;
   private volatile boolean aM;
   private volatile long aN;
   private volatile int aO;
   private volatile boolean aP;
   private volatile double aQ;
   private volatile double aR;
   private volatile double aS;
   private volatile String aT;
   private final ConcurrentLinkedQueue<JSONObject> aU = new ConcurrentLinkedQueue<>();
   private volatile int aV = -1;
   private static volatile RealtimeSyncServiceV2 aW;

   private RealtimeSyncServiceV2() {
      this.c = new TabSyncManager();
      this.d = new CloudConfigService(this);
      this.f = Executors.newSingleThreadScheduledExecutor(var0 -> {
         Thread var1 = new Thread(var0, "PulseSync-Thread");
         var1.setDaemon(true);
         return var1;
      });
      this.e = new OkHttpClient();
   }

   private static PublicKey M() {
      return null;
   }

   public boolean a() {
      return (this.H & 1) != 0;
   }

   public boolean b() {
      return (this.H & 4) != 0;
   }

   public int c() {
      return this.I;
   }

   public boolean d() {
      return (this.H & 8) != 0;
   }

   public boolean e() {
      return (this.H & 16) != 0;
   }

   public boolean f() {
      return this.Z;
   }

   public JSONArray g() {
      return this.Y;
   }

   public double h() {
      return this.aa;
   }

   public boolean i() {
      return (this.H & 32) != 0;
   }

   public boolean j() {
      return (this.H & 64) != 0;
   }

   public TabSyncManager k() {
      return this.c;
   }

   public JSONArray l() {
      return this.V;
   }

   public JSONArray m() {
      return this.W;
   }

   public JSONArray n() {
      return this.X;
   }

   public long o() {
      return this.P;
   }

   public long p() {
      return this.Q;
   }

   public String q() {
      return this.p;
   }

   public String r() {
      return this.q;
   }

   public String s() {
      return this.r;
   }

   public String t() {
      return this.s;
   }

   public byte[] u() {
      return this.S;
   }

   public long v() {
      return this.N;
   }

   public String w() {
      return this.i;
   }

   public String x() {
      return this.l;
   }

   public boolean a(String var1, String var2) {
      if (this.C.isEmpty()) {
         return true;
      } else {
         Object var3 = this.C.get(var1);
         if (var3 == null) {
            return true;
         } else {
            List var4 = (List)var3;
            if (var4.isEmpty()) {
               return true;
            } else if (var2 != null && !var2.isEmpty()) {
               String var5 = var2.toLowerCase();
               int var6 = var4.size();

               for (int var7 = 0; var7 < var6; var7++) {
                  String var8 = (String)var4.get(var7);
                  if (var5.contains(var8)) {
                     return true;
                  }
               }

               return false;
            } else {
               return true;
            }
         }
      }
   }

   @Override
   public void run() {
      Object var1 = this.B.poll();
      if (var1 != null) {
         int var2 = (Integer)var1;
         this.f(var2);
      }
   }

   private void f(int var1) {
      if (var1 == 1) {
         this.af();
      } else if (var1 == 2) {
         this.ag();
      } else if (var1 == 3) {
         this.E();
      } else if (var1 == 4) {
         this.ah();
      } else if (var1 == 5) {
         this.ai();
      } else if (var1 == 6) {
         this.aj();
      } else if (var1 == 7) {
         this.ak();
      } else if (var1 == 9) {
         this.al();
      } else if (var1 == 13) {
         this.am();
      } else if (var1 == 30) {
         this.N();
      } else if (var1 == 31) {
         this.O();
      } else if (var1 == 32) {
         this.Q();
      } else if (var1 == 33) {
         this.P();
      } else if (var1 == 40) {
         this.R();
      } else if (var1 == 41) {
         this.S();
      } else if (var1 == 42) {
         this.T();
      } else if (var1 == 43) {
         this.U();
      } else if (var1 == 44) {
         this.V();
      } else if (var1 == 45) {
         this.W();
      } else if (var1 == 46) {
         this.ae();
      } else if (var1 == 47) {
         this.X();
      } else if (var1 == 48) {
         this.Z();
      } else if (var1 == 55) {
         this.Y();
      } else if (var1 == 49) {
         this.aa();
      } else if (var1 == 52) {
         this.ab();
      } else if (var1 == 53) {
         this.ac();
      } else if (var1 == 54) {
         this.ad();
      }
   }

   private void N() {
      if (this.i != null) {
         this.a(30, 0, new JSONObject());
      }
   }

   private void O() {
      if (this.i != null) {
         if (this.ao != 0) {
            JSONObject var1 = new JSONObject();
            var1.put("targetUserId", this.ao);
            this.a(31, 0, var1);
            this.ao = 0;
         }
      }
   }

   private void P() {
      if (this.i != null) {
         if (this.ar != 0) {
            JSONObject var1 = new JSONObject();
            var1.put("friendId", this.ar);
            this.a(33, 0, var1);
            this.ar = 0;
         }
      }
   }

   private void Q() {
      if (this.i != null) {
         if (this.ap != 0) {
            JSONObject var1 = new JSONObject();
            var1.put("fromUserId", this.ap);
            var1.put("accept", this.aq);
            this.a(32, 0, var1);
            this.ap = 0;
         }
      }
   }

   private void R() {
      if (this.i != null) {
         this.a(40, 0, new JSONObject());
      }
   }

   private void S() {
      if (this.i != null) {
         if (this.as != 0) {
            JSONObject var1 = new JSONObject();
            var1.put("targetUserId", this.as);
            this.a(41, 0, var1);
            this.as = 0;
         }
      }
   }

   private void T() {
      if (this.i != null) {
         if (this.au != null) {
            JSONObject var1 = new JSONObject();
            var1.put("groupId", this.au);
            var1.put("accept", this.av);
            this.a(this.a(42, 0, var1));
            this.au = null;
         }
      }
   }

   private void U() {
      if (this.i != null) {
         JSONObject var1 = this.a(43, 0, new JSONObject());
         if (var1 != null && var1.optBoolean("ok", false)) {
            GroupManagerClient.a().e();
         } else {
            this.a(var1);
         }
      }
   }

   private void V() {
      if (this.i != null) {
         if (this.at != 0) {
            JSONObject var1 = new JSONObject();
            var1.put("targetUserId", this.at);
            this.a(this.a(44, 0, var1));
            this.at = 0;
         }
      }
   }

   private void W() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("x", this.aQ);
         var1.put("y", this.aR);
         var1.put("z", this.aS);
         if (this.aT != null) {
            var1.put("targetEntityNick", this.aT);
         } else {
            var1.put("targetEntityNick", JSONObject.NULL);
         }

         this.a(this.a(45, 0, var1));
      }
   }

   private void X() {
      if (this.i != null) {
         String var1 = this.aw;
         this.aw = null;
         if (var1 != null && !var1.trim().isEmpty()) {
            JSONObject var2 = new JSONObject();
            var2.put("text", var1);
            this.a(this.a(47, 0, var2));
         }
      }
   }

   private void Y() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("phraseId", this.aV);
         this.a(55, 0, var1);
      }
   }

   private void Z() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("emoteId", this.ax);
         var1.put("stop", this.ay);
         this.a(48, 0, var1);
      }
   }

   private void aa() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("graffitiId", this.az);
         var1.put("x", this.aA);
         var1.put("y", this.aB);
         var1.put("z", this.aC);
         var1.put("face", this.aD);
         var1.put("imageUp", this.aE);
         var1.put("dim", this.aF);
         JSONObject var2 = this.a(49, 0, var1);
         if (var2 != null && var2.has("charges")) {
            GraffitiManager.a().a(this.az, var2.optInt("charges", 0));
         }
      }
   }

   private void ab() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("hp", this.aG);
         var1.put("maxHp", this.aH);
         var1.put("abs", this.aI);
         this.a(52, 0, var1);
      }
   }

   private void ac() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("targetUserId", this.aJ);
         var1.put("force", this.aK);
         this.a(53, 0, var1);
      }
   }

   private void ad() {
      if (this.i != null) {
         JSONObject var1 = new JSONObject();
         var1.put("denied", this.aM);
         var1.put("data", this.aL != null ? this.aL : JSONObject.NULL);
         var1.put("hash", this.aN);
         var1.put("seq", this.aO);
         var1.put("beacon", this.aP);
         this.a(54, 0, var1);
      }
   }

   private void ae() {
      if (this.i != null) {
         JSONObject var1 = this.a(46, 0, new JSONObject());
         if (var1 != null && var1.optBoolean("ok", false)) {
            if (!var1.optBoolean("inGroup", false)) {
               GroupManagerClient.a().e();
            } else {
               if (var1.has("group") && !var1.isNull("group")) {
                  this.b(var1.getJSONObject("group"));
               }
            }
         }
      }
   }

   private void a(JSONObject var1) {
      if (var1 != null && !var1.optBoolean("ok", false)) {
         if ("NOT_IN_GROUP".equals(var1.optString("error", ""))) {
            GroupManagerClient.a().e();
         }
      }
   }

   public void y() {
      this.g(30);
   }

   public void a(int var1) {
      this.ao = var1;
      this.g(31);
   }

   public void a(int var1, boolean var2) {
      this.ap = var1;
      this.aq = var2;
      this.g(32);
   }

   public void b(int var1) {
      this.ar = var1;
      this.g(33);
   }

   public void z() {
      this.g(40);
   }

   public void c(int var1) {
      this.as = var1;
      this.g(41);
   }

   public void a(String var1, boolean var2) {
      this.au = var1;
      this.av = var2;
      this.g(42);
   }

   public void A() {
      this.g(43);
   }

   public void d(int var1) {
      this.at = var1;
      this.g(44);
   }

   public void a(double var1, double var3, double var5, String var7) {
      this.aQ = var1;
      this.aR = var3;
      this.aS = var5;
      this.aT = var7;
      this.g(45);
   }

   public void B() {
      this.g(46);
   }

   public void a(String var1) {
      this.aw = var1;
      this.g(47);
   }

   public void e(int var1) {
      this.aV = var1;
      this.g(55);
   }

   public void b(int var1, boolean var2) {
      this.ax = var1;
      this.ay = var2;
      this.g(48);
   }

   public void a(int var1, int var2, int var3, int var4, int var5, int var6, String var7) {
      this.az = var1;
      this.aA = var2;
      this.aB = var3;
      this.aC = var4;
      this.aD = var5;
      this.aE = var6;
      this.aF = var7;
      this.g(49);
   }

   public void a(double var1, double var3, double var5) {
      this.aG = var1;
      this.aH = var3;
      this.aI = var5;
      this.g(52);
   }

   public void c(int var1, boolean var2) {
      this.aJ = var1;
      this.aK = var2;
      this.g(53);
   }

   public void a(String var1, boolean var2, long var3, int var5, boolean var6) {
      this.aL = var1;
      this.aM = var2;
      this.aN = var3;
      this.aO = var5;
      this.aP = var6;
      this.g(54);
   }

   private void af() {
      if ((this.H & 1) != 0) {
         if (this.i != null) {
            String var1 = this.J == 0 ? "IN_MENU" : "IN_SERVER";
            JSONObject var2 = new JSONObject();
            var2.put("presence", var1);
            this.a(4, 0, var2);
         }
      }
   }

   private void ag() {
      if ((this.H & 1) != 0) {
         if (this.J == 1) {
            if (this.i != null) {
               this.K = this.c.d();
               JSONObject var1 = new JSONObject();
               var1.put("hash", this.c.e());
               JSONObject var2 = this.a(3, this.K, var1);
               if (var2 != null) {
                  if (!var2.optBoolean("ok", false)) {
                     this.a(var2, 4);
                  } else {
                     this.c.a(var2.optBoolean("match", false), var2.optBoolean("needResync", false));
                  }
               }
            }
         }
      }
   }

   private void ah() {
      if (this.i != null) {
         if ((this.H & 1) != 0) {
            if (this.J == 1) {
               if (this.ac != null) {
                  JSONArray var1 = new JSONArray();

                  for (String var3 : this.ac) {
                     var1.put(var3);
                  }

                  JSONObject var5 = new JSONObject();
                  var5.put("players", var1);
                  JSONObject var4 = this.a(1, this.K, var5);
                  if (var4 != null) {
                     if (!var4.optBoolean("ok", false)) {
                        this.a(var4, 2);
                     } else {
                        this.c.a(var4.getInt("epoch"), var4.getLong("hash"));
                     }
                  }
               }
            }
         }
      }
   }

   private void ai() {
      if (this.i != null) {
         if ((this.H & 1) != 0) {
            if (this.J == 1) {
               if (this.ab != null) {
                  JSONArray var1 = new JSONArray();
                  int var2 = this.ab.size();

                  for (int var3 = 0; var3 < var2; var3++) {
                     DeltaOp var4 = (DeltaOp)this.ab.get(var3);
                     JSONObject var5 = new JSONObject();
                     var5.put("op", var4.a);
                     var5.put("nick", var4.b);
                     var1.put(var5);
                  }

                  JSONObject var6 = new JSONObject();
                  var6.put("baseHash", this.O);
                  var6.put("ops", var1);
                  JSONObject var7 = this.a(2, this.K, var6);
                  if (var7 != null) {
                     if (!var7.optBoolean("ok", false)) {
                        this.a(var7, 3);
                     } else {
                        this.c.a(var7.getLong("hash"), false);
                     }
                  }
               }
            }
         }
      }
   }

   private void aj() {
      if (this.n != null) {
         JSONObject var1 = new JSONObject();
         var1.put("minecraft_nick", this.n);
         JSONObject var2 = this.a(6, 0, var1);
         if (var2 != null && var2.optBoolean("ok", false)) {
            this.m = this.n;
         }
      }
   }

   private void ak() {
      if (this.t != null) {
         JSONObject var1 = new JSONObject();
         var1.put("server_address", this.t);
         JSONObject var2 = this.a(7, 0, var1);
         if (var2 != null && var2.optBoolean("ok", false)) {
            this.u = this.t;
         }
      }
   }

   private void al() {
      if (this.i != null && (this.H & 2) != 0) {
         try {
            ModHashCache var1 = ModHashCache.b();
            if (var1 == null) {
               ModHashCache.a();
               if (++this.M <= 30) {
                  this.a(9, 2000L);
               }

               return;
            }

            this.M = 0;
            this.a(9, 0, var1.d());
         } catch (Exception var2) {
         }
      }
   }

   private void am() {
      if (this.i != null && (this.H & 2) != 0) {
         JSONObject var1;
         while ((var1 = this.aU.poll()) != null) {
            this.a(13, 0, var1);
         }
      }
   }

   public void C() {
      if (this.i != null) {
         this.g(9);
      }
   }

   public void a(String var1, String var2, String var3, String var4) {
      if (this.i != null && (this.H & 1) != 0 && var1 != null) {
         JSONObject var5 = new JSONObject();
         var5.put("event", var1);
         if (var2 != null) {
            var5.put("server", var2);
         }

         if (var3 != null) {
            var5.put("anarchy", var3);
         }

         if (var4 != null) {
            var5.put("nick", var4);
         }

         this.aU.offer(var5);
         this.g(13);
      }
   }

   public String b(String var1, String var2) {
      if (this.i != null && (this.H & 2) != 0) {
         JSONObject var3 = new JSONObject();
         if (var1 != null) {
            var3.put("server", var1);
         }

         if (var2 != null) {
            var3.put("nick", var2);
         }

         JSONObject var4 = this.a(14, 0, var3);
         return var4 != null && var4.optBoolean("ok", false) ? var4.optString("ticket", null) : null;
      } else {
         return null;
      }
   }

   private void a(JSONObject var1, int var2) {
      String var3 = var1.optString("error", "");
      if ("NO_KEY".equals(var3) || "DECRYPT_FAIL".equals(var3)) {
         this.H &= -4;
         this.S = null;
         this.T = null;
         this.U = null;
         this.N = 0L;
         this.A.clear();
         if (this.E != null) {
            this.E.close(1000, "crypto_error");
         }

         if ((this.H & 8) != 0) {
            int var4 = ++this.L;
            if (var4 <= 10) {
               this.a(3, Math.min(5000 * var4, 60000));
            }
         }
      } else if ("NEED_RESYNC".equals(var3)) {
         if (var2 == 3) {
            this.c.a(0L, true);
         } else {
            this.c.c();
         }
      }
   }

   private void g(int var1) {
      Integer var2 = var1;
      this.B.offer(var2);
      if (this.f != null) {
         this.f.execute(this);
      }
   }

   private void a(int var1, long var2) {
      Integer var4 = var1;
      this.B.offer(var4);
      if (this.f != null) {
         this.f.schedule(this, var2, TimeUnit.MILLISECONDS);
      }
   }

   public void c(String var1, String var2) {
      this.g = var1;
      this.h = var2;
   }

   public void D() {
      this.l = null;
      this.H |= 8;
      this.H &= -5;
   }

   public void E() {
      if ((this.H & 8) != 0) {
         long var1 = System.currentTimeMillis();
         if (this.R > var1) {
            long var14 = this.R - var1;
            this.a(3, var14);
         } else if (this.g != null) {
            String var3 = "";

            try {
               JSONObject var4 = new JSONObject();
               var4.put("token", this.g);
               var4.put("hwid", this.h);
               var4.put("clientType", "fabric-1.16.5");
               var4.put("clientVersion", "2.0.4");
               byte[] var5 = var4.toString().getBytes(StandardCharsets.UTF_8);
               byte[] var6 = "5e8v5cTyLMPf77C7".getBytes(StandardCharsets.UTF_8);
               byte[] var7 = new byte[256];

               for (int var8 = 0; var8 < 256; var8++) {
                  var7[var8] = (byte)var8;
               }

               int var17 = 0;

               for (int var9 = 0; var9 < 256; var9++) {
                  var17 = var17 + (var7[var9] & 255) + (var6[var9 % var6.length] & 255) & 0xFF;
                  byte var10 = var7[var9];
                  var7[var9] = var7[var17];
                  var7[var17] = var10;
               }

               byte[] var19 = new byte[var5.length];
               int var20 = 0;
               var17 = 0;

               for (int var11 = 0; var11 < var5.length; var11++) {
                  var20 = var20 + 1 & 0xFF;
                  var17 = var17 + (var7[var20] & 255) & 0xFF;
                  byte var12 = var7[var20];
                  var7[var20] = var7[var17];
                  var7[var17] = var12;
                  var19[var11] = (byte)(var5[var11] ^ var7[(var7[var20] & 255) + (var7[var17] & 255) & 0xFF]);
               }

               var3 = Base64.getUrlEncoder().withoutPadding().encodeToString(var19);
            } catch (Exception var13) {
            }

            String var15 = Pulse.h().replace("https://", "wss://").replace("http://", "ws://") + "/api/v2/realtime/ws?auth=" + var3;
            Request var16 = new Builder().url(var15).build();
            this.E = this.e.newWebSocket(var16, this);
         }
      }
   }

   public void b(String var1) {
      if (this.i != null && (this.H & 1) != 0) {
         if (var1 != null && !var1.isEmpty()) {
            if (!var1.equals(this.m)) {
               this.n = var1;
               this.g(6);
            }
         }
      }
   }

   public void c(String var1) {
      if (this.i != null && (this.H & 1) != 0) {
         if (var1 != null && !var1.isEmpty()) {
            if (!var1.equals(this.u)) {
               this.t = var1;
               this.g(7);
            }
         }
      }
   }

   public void F() {
      this.J = 1;
      if (this.i != null && (this.H & 1) != 0) {
         this.g(1);
      }

      if (this.G != null) {
         this.G.cancel(false);
      }

      Integer var1 = 2;
      this.B.offer(var1);
      if (this.f != null) {
         this.G = this.f.scheduleAtFixedRate(this, 10000L, 10000L, TimeUnit.MILLISECONDS);
      }
   }

   public void G() {
      this.J = 0;
      if (this.i != null && (this.H & 1) != 0) {
         this.g(1);
      }

      if (this.G != null) {
         this.G.cancel(false);
         this.G = null;
      }

      this.u = null;
      this.z.clear();
      this.c.b();
   }

   public boolean d(String var1) {
      return this.z.containsKey(var1);
   }

   public boolean H() {
      return !this.z.isEmpty();
   }

   public Integer d(String var1, String var2) {
      Object[] var3 = (Object[])this.z.get(var1);
      if (var3 == null) {
         return null;
      } else if (var3[1] == null) {
         return null;
      } else {
         Map var4 = (Map)var3[1];
         return (Integer)var4.get(var2);
      }
   }

   public int e(String var1) {
      Object[] var2 = (Object[])this.z.get(var1);
      return var2 != null && var2.length >= 4 && var2[3] != null ? (Integer)var2[3] : 2;
   }

   public void I() {
      this.z.clear();
      this.c.b();
   }

   public boolean J() {
      return false;
   }

   private boolean an() {
      return false;
   }

   public void f(String var1) {
      if (this.i != null && (this.H & 2) != 0 && this.S != null) {
         try {
            JSONObject var2 = new JSONObject().put("reason", var1);
            this.a(5, 0, var2);
         } catch (Exception var3) {
         }
      }

      this.K();
   }

   public void K() {
      this.H &= -10;
      if (this.F != null) {
         this.F.cancel(false);
         this.F = null;
      }

      if (this.G != null) {
         this.G.cancel(false);
         this.G = null;
      }

      this.c.g();
      if (this.E != null) {
         this.E.close(1000, "client_closed");
         this.E = null;
      }

      for (CompletableFuture var2 : this.D.values()) {
         var2.cancel(true);
      }

      this.D.clear();
      if (this.f != null) {
         this.f.shutdown();

         try {
            if (!this.f.awaitTermination(5L, TimeUnit.SECONDS)) {
               this.f.shutdownNow();
            }
         } catch (InterruptedException var3) {
            this.f.shutdownNow();
         }

         this.f = null;
      }

      if (this.e != null) {
         this.e.dispatcher().executorService().shutdown();
         this.e.connectionPool().evictAll();
         this.e = null;
      }

      this.z.clear();
      this.c.b();
      this.i = null;
      this.m = null;
   }

   public JSONObject a(int var1, int var2, JSONObject var3) {
      if ((this.H & 2) != 0 && this.S != null && this.i != null && this.E != null) {
         try {
            long var4 = System.currentTimeMillis() + this.N;
            String var6 = UUID.randomUUID().toString();
            byte[] var7 = new byte[12];
            x.nextBytes(var7);
            byte[] var8 = (this.i + "|" + var1 + "|" + var2 + "|" + var6 + "|" + var4).getBytes(StandardCharsets.UTF_8);
            Cipher var9 = Cipher.getInstance("AES/GCM/NoPadding");
            var9.init(1, new SecretKeySpec(this.S, "AES"), new GCMParameterSpec(128, var7));
            var9.updateAAD(var8);
            byte[] var10 = var9.doFinal(var3.toString().getBytes(StandardCharsets.UTF_8));
            JSONObject var11 = new JSONObject();
            var11.put("sid", this.i);
            var11.put("ts", var4);
            var11.put("id", var6);
            var11.put("e", var2);
            var11.put("t", var1);
            var11.put("iv", Base64.getEncoder().encodeToString(var7));
            var11.put("ct", Base64.getEncoder().encodeToString(var10));
            if (var1 == 4) {
               this.E.send(var11.toString());
               return null;
            } else {
               CompletableFuture var12 = new CompletableFuture();
               this.D.put(var6, var12);
               this.E.send(var11.toString());

               try {
                  return (JSONObject)var12.get(10L, TimeUnit.SECONDS);
               } catch (Exception var14) {
                  this.D.remove(var6);
                  return null;
               }
            }
         } catch (Exception var15) {
            return null;
         }
      } else {
         return null;
      }
   }

   @Override
   public void a(int var1, Set var2) {
      if (this.i != null && (this.H & 1) != 0 && this.J == 1) {
         this.K = var1;
         this.ac = var2;
         this.g(4);
      }
   }

   @Override
   public void a(int var1, long var2, List var4) {
      if (this.i != null && (this.H & 1) != 0 && this.J == 1) {
         this.K = var1;
         this.O = var2;
         this.ab = var4;
         this.g(5);
      }
   }

   @Override
   public void onOpen(WebSocket var1, Response var2) {
      this.H |= 1;
      this.L = 0;
      this.R = 0L;
      if (this.F != null) {
         this.F.cancel(false);
      }

      Integer var3 = 1;
      this.B.offer(var3);
      this.F = this.f.scheduleAtFixedRate(this, 30000L, 30000L, TimeUnit.MILLISECONDS);
      if (this.J == 1) {
         if (this.i != null) {
            this.g(1);
         }

         this.c.a();
      }
   }

   @Override
   public void onMessage(WebSocket var1, String var2) {
      try {
         JSONObject var3 = new JSONObject(var2);
         if (var3.has("_reqId")) {
            if (var3.has("_ts")) {
               long var16 = Math.abs(System.currentTimeMillis() + this.N - var3.getLong("_ts"));
               if (var16 > 60000L) {
                  return;
               }
            }

            String var17 = var3.getString("_reqId");
            CompletableFuture var5 = this.D.remove(var17);
            if (var5 != null) {
               var5.complete(var3);
            }

            return;
         }

         if (var3.has("t") && var3.has("iv") && var3.has("ct")) {
            if ((this.H & 2) == 0 || this.S == null || this.i == null) {
               return;
            }

            long var4 = var3.getLong("ts");
            long var6 = Math.abs(System.currentTimeMillis() + this.N - var4);
            if (var6 > 60000L) {
               return;
            }

            String var8 = var3.getString("id");
            if (this.A.contains(var8)) {
               return;
            }

            byte[] var9 = (this.i + "|" + var3.getInt("t") + "|" + var3.getInt("e") + "|" + var8 + "|" + var4).getBytes(StandardCharsets.UTF_8);
            byte[] var10 = Base64.getDecoder().decode(var3.getString("iv"));
            byte[] var11 = Base64.getDecoder().decode(var3.getString("ct"));
            Cipher var12 = Cipher.getInstance("AES/GCM/NoPadding");
            var12.init(2, new SecretKeySpec(this.S, "AES"), new GCMParameterSpec(128, var10));
            var12.updateAAD(var9);
            byte[] var13 = var12.doFinal(var11);
            this.A.add(var8);
            var3 = new JSONObject(new String(var13, StandardCharsets.UTF_8));
         }

         String var15 = var3.optString("type", "message");
         this.a(var3, var15);
      } catch (Exception var14) {
      }
   }

   private void a(JSONObject var1, String var2) {
      if ("connected".equals(var2)) {
         this.i = var1.getString("sessionId");
         this.j = var1.optString("sessionSecret", null);
         this.I = var1.getInt("userId");
         this.k = var1.getString("username");
         this.v = var1.optString("role", "user");
         HashMap var3 = new HashMap<>();
         if (var1.has("cosmetics") && !var1.isNull("cosmetics")) {
            JSONObject var4 = var1.getJSONObject("cosmetics");
            Iterator var5 = var4.keys();

            while (var5.hasNext()) {
               String var6 = (String)var5.next();
               if (!var4.isNull(var6)) {
                  var3.put(var6, var4.getInt(var6));
               }
            }
         } else if (var1.has("capeId") && !var1.isNull("capeId")) {
            var3.put("cape", var1.getInt("capeId"));
         }

         try {
            if (var1.optInt("v", 0) == 2 && "AES_GCM".equals(var1.optString("crypto", "")) && "HKDF_SHA256".equals(var1.optString("kdf", ""))) {
               String var37 = var1.optString("salt", null);
               String var56 = var1.optString("sessionSecret", null);
               if (var37 != null && var56 != null) {
                  byte[] var73 = Base64.getDecoder().decode(var37);
                  byte[] var7 = Base64.getDecoder().decode(var56);
                  if (var73.length == 16 && var7.length == 32) {
                     Mac var8 = Mac.getInstance("HmacSHA256");
                     var8.init(new SecretKeySpec(var73, "HmacSHA256"));
                     byte[] var9 = var8.doFinal(var7);
                     var8.init(new SecretKeySpec(var9, "HmacSHA256"));
                     var8.update(new byte[0]);
                     var8.update("pulse-v2".getBytes(StandardCharsets.UTF_8));
                     var8.update((byte)1);
                     byte[] var10 = new byte[32];
                     System.arraycopy(var8.doFinal(), 0, var10, 0, 32);
                     if (var10.length == 32) {
                        this.N = var1.optLong("ts", 0L) > 0L ? var1.optLong("ts", 0L) - System.currentTimeMillis() : 0L;
                        this.T = var73;
                        this.U = var7;
                        this.S = var10;
                        this.H |= 2;
                     }
                  }
               }
            }
         } catch (Exception var16) {
         }

         this.H |= 4;
         UserInfo var38 = new UserInfo(this.I, this.k, this.i, this.v);
         var38.a(var1.has("displayName") && !var1.isNull("displayName") ? var1.optString("displayName", null) : null);
         var38.a(var3);
         var38.a(var1.optDouble("balance", 0.0));
         var38.a(var1.optBoolean("giftAvailable", false));
         var38.a(var1.optLong("giftSecondsUntil", 0L));
         Pulse.a(var38);
         this.b(var1.optJSONArray("equippedEmotes"));
         this.a(var1.optJSONArray("equippedGraffiti"), var1.optJSONObject("graffitiCharges"));
         this.a(var1.optJSONArray("equippedPhrases"));
         if (var1.has("update") && !var1.isNull("update")) {
            JSONObject var57 = var1.getJSONObject("update");
            if (var57.optBoolean("needsUpdate", false)) {
               this.H |= 32;
            } else {
               this.H &= -33;
            }

            if (var57.optBoolean("forceUpdate", false)) {
               this.H |= 64;
            } else {
               this.H &= -65;
            }

            this.p = var57.optString("currentVersion", null);
            this.q = var57.optString("message", null);
            this.r = var57.optString("downloadUrl", null);
            this.s = var57.optString("changelog", null);
         }

         this.C.clear();
         if (var1.has("moduleRestrictions") && !var1.isNull("moduleRestrictions")) {
            JSONObject var58 = var1.getJSONObject("moduleRestrictions");
            Iterator var74 = var58.keys();

            while (var74.hasNext()) {
               String var85 = (String)var74.next();
               if (!var58.isNull(var85)) {
                  JSONArray var94 = var58.getJSONArray(var85);
                  ArrayList var102 = new ArrayList<>();
                  int var110 = var94.length();

                  for (int var11 = 0; var11 < var110; var11++) {
                     var102.add(var94.getString(var11).toLowerCase());
                  }

                  this.C.put(var85, var102);
               }
            }
         }

         ServerIntegrationHandler.a++;
         this.d.a(var1);
         if (this.m != null) {
            this.n = this.m;
            this.m = null;
            this.g(6);
         }

         if (this.u != null) {
            this.t = this.u;
            this.u = null;
            this.g(7);
         }

         this.g(30);
         this.g(46);
         this.M = 0;
         this.g(9);
      } else if ("auth_error".equals(var2)) {
         this.H &= -16;
         this.S = null;
         this.T = null;
         this.U = null;
         this.N = 0L;
         this.A.clear();
         this.l = var1.optString("error", "Ошибка авторизации");
      } else if ("kicked".equals(var2)) {
         this.H &= -16;
         this.i = null;
         this.S = null;
         this.T = null;
         this.U = null;
         this.N = 0L;
         this.A.clear();
         GroupManagerClient.a().e();
         Pulse.a(var1.optString("message", "Вы были отключены"));
      } else if ("crash".equals(var2)) {
         String var17 = var1.optString("message", "Pulse");
         this.H &= -16;
         MinecraftClient var39 = MinecraftClient.getInstance();
         if (var39 == null) {
            throw new RuntimeException(var17);
         }

         var39.execute(() -> {
            throw new RuntimeException(var17);
         });
      } else if ("bulk_sync".equals(var2)) {
         JSONArray var18 = var1.getJSONArray("players");
         int var40 = var18.length();

         for (int var59 = 0; var59 < var40; var59++) {
            JSONObject var75 = var18.getJSONObject(var59);
            String var86 = var75.getString("nick");
            HashMap var95 = new HashMap<>();
            if (var75.has("cosmetics") && !var75.isNull("cosmetics")) {
               JSONObject var103 = var75.getJSONObject("cosmetics");
               Iterator var111 = var103.keys();

               while (var111.hasNext()) {
                  String var116 = (String)var111.next();
                  if (!var103.isNull(var116)) {
                     var95.put(var116, var103.getInt(var116));
                  }
               }
            }

            Object[] var104 = new Object[]{var86, var95, System.currentTimeMillis(), var75.optInt("tier", 2)};
            this.z.put(var86, var104);
         }
      } else if ("mod_user_joined".equals(var2)) {
         String var19 = var1.getString("nick");
         HashMap var41 = new HashMap<>();
         if (var1.has("cosmetics") && !var1.isNull("cosmetics")) {
            JSONObject var60 = var1.getJSONObject("cosmetics");
            Iterator var76 = var60.keys();

            while (var76.hasNext()) {
               String var87 = (String)var76.next();
               if (!var60.isNull(var87)) {
                  var41.put(var87, var60.getInt(var87));
               }
            }
         }

         Object[] var61 = new Object[]{var19, var41, System.currentTimeMillis(), var1.optInt("tier", 2)};
         this.z.put(var19, var61);
      } else if ("mod_user_left".equals(var2)) {
         String var20 = var1.getString("nick");
         this.z.remove(var20);

         try {
            GraffitiManager.a().a(var20);
         } catch (Throwable var15) {
         }

         try {
            PhraseManager.a().b(var20);
         } catch (Throwable var14) {
         }
      } else if ("cosmetic_updated".equals(var2)) {
         String var21 = var1.getString("nick");
         String var42 = var1.getString("cosmeticType");
         Integer var62 = null;
         if (var1.has("cosmeticId") && !var1.isNull("cosmeticId")) {
            var62 = var1.getInt("cosmeticId");
         }

         MinecraftClient var77 = MinecraftClient.getInstance();
         if (var77.player != null) {
            String var88 = var77.player.getName().getString();
            if (var88.equalsIgnoreCase(var21)) {
               UserInfo var96 = Pulse.n();
               if (var96 != null) {
                  if (var62 != null) {
                     var96.k().put(var42, var62);
                  } else {
                     var96.k().remove(var42);
                  }
               }
            }
         }

         Object[] var89 = (Object[])this.z.get(var21);
         HashMap var97;
         if (var89 != null && var89[1] != null) {
            Map var105 = (Map)var89[1];
            var97 = new HashMap<>(var105);
         } else {
            var97 = new HashMap<>();
         }

         if (var62 != null) {
            var97.put(var42, var62);
         } else {
            var97.remove(var42);
         }

         Object[] var106 = new Object[]{var21, var97, System.currentTimeMillis(), var89 != null && var89.length > 3 && var89[3] != null ? var89[3] : 2};
         this.z.put(var21, var106);
      } else if ("need_resync".equals(var2)) {
         this.c.c();
      } else if ("notification".equals(var2)) {
         String var22 = var1.getString("title");
         String var43 = var1.optString("description", null);
         long var63 = var1.optLong("duration", 5000L);
         String var90 = var1.optString("notificationType", "BELL");
         boolean var98 = var1.optBoolean("duplicateToChat", false);
         int var107 = 49;
         int var112 = 49;
         int var117 = 69;
         boolean var12 = false;
         if (var1.has("iconColor") && !var1.isNull("iconColor")) {
            JSONObject var13 = var1.getJSONObject("iconColor");
            var107 = var13.optInt("r", 49);
            var112 = var13.optInt("g", 49);
            var117 = var13.optInt("b", 69);
            var12 = true;
         }

         this.am = null;
         this.an = null;
         if (var1.has("button") && !var1.isNull("button")) {
            JSONObject var120 = var1.getJSONObject("button");
            this.am = var120.optString("text", null);
            this.an = var120.optString("url", null);
         }

         this.ae = var43;
         this.af = var63;
         this.ag = var90;
         this.ah = var98;
         this.ai = var12;
         this.aj = var107;
         this.ak = var112;
         this.al = var117;
         this.ad = var22;
         MinecraftClient.getInstance().execute(new RealtimeSyncServiceV2.NotifRunnable());
      } else if ("events".equals(var2)) {
         if (var1.has("currentEvents")) {
            this.V = var1.getJSONArray("currentEvents");
         }

         if (var1.has("upcomingEvents")) {
            this.W = var1.getJSONArray("upcomingEvents");
         }

         if (var1.has("mines")) {
            this.X = var1.getJSONArray("mines");
         }

         if (var1.optBoolean("hasMines", this.X.length() > 0)) {
            this.H |= 16;
         } else {
            this.H &= -17;
         }

         this.Y = var1.has("bunkers") ? var1.getJSONArray("bunkers") : new JSONArray();
         this.Z = var1.optBoolean("hasBunkers", false) && this.Y.length() > 0;
         this.aa = var1.optDouble("coinRate", 0.0);
         this.Q = System.currentTimeMillis();
         this.P = System.currentTimeMillis();
      } else if ("premium_configs_refresh".equals(var2)) {
         if (var1.has("premiumConfigs")) {
            this.d.a(var1.getJSONArray("premiumConfigs"));
         }
      } else if ("premium_resource_packs_refresh".equals(var2)) {
         ResourcePackService.a().d();
      } else if ("chat".equals(var2)) {
         String var23 = var1.optString("text", null);
         if (var23 != null && !var23.isEmpty()) {
            ChatUtils.a((Object)var23);
         }
      } else if ("friends_list".equals(var2)) {
         JSONArray var24 = var1.getJSONArray("friends");
         ArrayList var44 = new ArrayList<>();

         for (int var64 = 0; var64 < var24.length(); var64++) {
            JSONObject var78 = var24.getJSONObject(var64);
            String var91 = var78.isNull("server") ? null : var78.optString("server", null);
            String var99 = var78.isNull("minecraftNick") ? null : var78.optString("minecraftNick", null);
            String var108 = var78.isNull("avatarUrl") ? null : var78.optString("avatarUrl", null);
            String var113 = var78.isNull("coverUrl") ? null : var78.optString("coverUrl", null);
            String var118 = var78.isNull("displayName") ? null : var78.optString("displayName", null);
            var44.add(
               new CloudFriendDataDto(
                  var78.getInt("userId"), var78.getString("username"), var118, var78.optString("status", "offline"), var91, var99, var108, var113
               )
            );
         }

         CloudFriendsCache.a().a(var44);
      } else if ("friend_profile_updated".equals(var2)) {
         int var25 = var1.getInt("userId");
         String var45 = var1.isNull("avatarUrl") ? null : var1.optString("avatarUrl", null);
         String var65 = var1.isNull("coverUrl") ? null : var1.optString("coverUrl", null);
         String var79 = var1.has("username") && !var1.isNull("username") ? var1.optString("username", null) : null;
         String var92 = var1.has("displayName") && !var1.isNull("displayName") ? var1.optString("displayName", null) : null;
         CloudFriendsCache.a().a(var25, var45, var65, var79, var92);
      } else if ("friend_presence".equals(var2)) {
         int var26 = var1.getInt("userId");
         String var46 = var1.optString("status", "offline");
         String var66 = var1.isNull("server") ? null : var1.optString("server", null);
         String var80 = var1.has("minecraftNick") && !var1.isNull("minecraftNick") ? var1.optString("minecraftNick", null) : null;
         CloudFriendsCache.a().a(var26, var46, var66, var80);
      } else if ("friend_request".equals(var2)) {
         int var27 = var1.optInt("fromUserId", 0);
         String var47 = var1.optString("fromUsername", "?");
         String var67 = var1.optString("chatMessage", "§aЗапрос в друзья от §f" + var47 + " ");
         this.a(var27, var47);
         this.b(var27, var67);
      } else if ("friend_added".equals(var2)) {
         int var28 = var1.getInt("userId");
         String var48 = var1.optString("username", "?");
         String var68 = var1.optString("chatMessage", "§aТеперь вы дружите с §f" + var48);
         CloudFriendsCache.a().a(var28, var48);
         ChatUtils.a((Object)var68);
         this.g(30);
      } else if ("friend_removed".equals(var2)) {
         int var29 = var1.getInt("userId");
         CloudFriendsCache.a().b(var29);
      } else if ("group_invite".equals(var2)) {
         String var30 = var1.getString("groupId");
         int var49 = var1.getInt("fromUserId");
         String var69 = var1.optString("fromUsername", "?");
         String var81 = var1.optString("chatMessage", "§aПриглашение в группу от §f" + var69 + " ");
         GroupManagerClient.a().a(var30, var49, var69);
         this.e(var30, var69);
         this.f(var30, var81);
      } else if ("group_state".equals(var2)) {
         this.b(var1);
      } else if ("group_disbanded".equals(var2)) {
         String var31 = var1.getString("groupId");
         String var50 = var1.optString("reason", "");
         GroupManagerClient.a().a(var31, var50);
         if (!var50.isEmpty()) {
            ChatUtils.a("§c" + var50);
         } else {
            ChatUtils.a("§cГруппа распущена");
         }
      } else if ("group_ping".equals(var2)) {
         String var32 = var1.optString("fromUsername", "?");
         double var51 = var1.getDouble("x");
         double var82 = var1.getDouble("y");
         double var100 = var1.getDouble("z");
         String var114 = var1.isNull("targetEntityNick") ? null : var1.optString("targetEntityNick", null);
         Integer var119 = var1.isNull("colorRgb") ? null : var1.getInt("colorRgb");
         HandlerRegistry.k.a(var32, var51, var82, var100, var114, var119);
      } else if ("group_message".equals(var2)) {
         int var33 = var1.optInt("fromUserId", 0);
         String var52 = var1.optString("fromUsername", "?");
         String var70 = var1.optString("text", "");
         Integer var83 = var1.isNull("colorRgb") ? null : var1.optInt("colorRgb");
         this.a(var33, var52, var70, var83);
      } else if ("emote_played".equals(var2)) {
         String var34 = var1.optString("nick", null);
         int var53 = var1.optInt("emoteId", -1);
         boolean var71 = var1.optBoolean("stop", false);
         this.a(var34, var53, var71);
      } else if ("phrase_said".equals(var2)) {
         String var35 = var1.optString("nick", null);
         int var54 = var1.optInt("phraseId", -1);
         if (var35 != null && var54 >= 0) {
            PhraseManager.a().a(var35, var54);
         }
      } else if ("equipped_phrases".equals(var2)) {
         this.a(var1.optJSONArray("phraseIds"));
      } else if ("equipped_emotes".equals(var2)) {
         this.b(var1.optJSONArray("emoteIds"));
      } else if ("graffiti_sprayed".equals(var2)) {
         String var36 = var1.optString("nick", null);
         int var55 = var1.optInt("graffitiId", -1);
         int var72 = var1.optInt("x", 0);
         int var84 = var1.optInt("y", 0);
         int var93 = var1.optInt("z", 0);
         int var101 = var1.optInt("face", -1);
         int var109 = var1.optInt("imageUp", -1);
         String var115 = var1.optString("dim", "");
         if (var36 != null && var55 >= 0 && var101 >= 0 && var101 <= 5) {
            MinecraftClient.getInstance().execute(() -> {
               try {
                  GraffitiManager.a().a(var36, var55, new BlockPos(var72, var84, var93), var101, var109, var115);
               } catch (Throwable var9x) {
               }
            });
         }
      } else if ("equipped_graffiti".equals(var2)) {
         this.a(var1.optJSONArray("graffitiIds"), var1.optJSONObject("charges"));
      } else if ("group_health".equals(var2)) {
         PartyHealthTracker.a()
            .a(var1.optInt("fromUserId", 0), (float)var1.optDouble("hp", 0.0), (float)var1.optDouble("maxHp", 20.0), (float)var1.optDouble("abs", 0.0));
      } else if ("group_inv_request".equals(var2)) {
         PartyInventoryTracker.a().b();
      } else if ("group_inv_snapshot".equals(var2)) {
         PartyInventoryTracker.a()
            .a(
               var1.optInt("fromUserId", 0),
               var1.isNull("data") ? null : var1.optString("data", null),
               var1.optBoolean("denied", false),
               var1.optBoolean("beacon", false),
               var1.optLong("hash", 0L)
            );
      }
   }

   private void a(JSONArray var1) {
      ArrayList var2 = new ArrayList<>();
      if (var1 != null) {
         for (int var3 = 0; var3 < var1.length(); var3++) {
            try {
               var2.add(var1.getInt(var3));
            } catch (Exception var5) {
            }
         }
      }

      PhraseManager.a().a(var2);
   }

   private void b(JSONArray var1) {
      ArrayList var2 = new ArrayList<>();
      if (var1 != null) {
         for (int var3 = 0; var3 < var1.length(); var3++) {
            try {
               var2.add(String.valueOf(var1.getInt(var3)));
            } catch (Exception var5) {
            }
         }
      }

      EmoteManager.a().a(var2);
   }

   private void a(JSONArray var1, JSONObject var2) {
      ArrayList var3 = new ArrayList<>();
      if (var1 != null) {
         for (int var4 = 0; var4 < var1.length(); var4++) {
            try {
               var3.add(var1.getInt(var4));
            } catch (Exception var9) {
            }
         }
      }

      HashMap var10 = new HashMap<>();
      if (var2 != null) {
         for (String var6 : var2.keySet()) {
            try {
               var10.put(Integer.parseInt(var6), var2.getInt(var6));
            } catch (Exception var8) {
            }
         }
      }

      GraffitiManager.a().a(var3, var10);
   }

   private void a(String var1, int var2, boolean var3) {
      if (var1 != null) {
         MinecraftClient var4 = MinecraftClient.getInstance();
         var4.execute(() -> {
            try {
               if (var4.world == null) {
                  return;
               }

               AbstractClientPlayerEntity var4x = null;

               for (AbstractClientPlayerEntity var6 : var4.world.getPlayers()) {
                  if (var1.equalsIgnoreCase(var6.getGameProfile().name())) {
                     var4x = var6;
                     break;
                  }
               }

               if (var4x == null) {
                  return;
               }

               if (var3) {
                  EmoteManager.a().a(var4x);
               } else {
                  EmoteManager.a().a(var4x, String.valueOf(var2));
               }
            } catch (Throwable var7) {
            }
         });
      }
   }

   private void a(int var1, String var2, String var3, Integer var4) {
      String var5 = var2;

      try {
         for (GroupMemberDto var7 : GroupManagerClient.a().d()) {
            if (var7.a() == var1) {
               if (var7.c() != null && !var7.c().isEmpty()) {
                  var5 = var7.c();
               }
               break;
            }
         }
      } catch (Exception var9) {
      }

      int var10 = var4 != null ? var4 : 16777215;
      MutableText var11 = Text.literal("[Группа] ")
         .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(5635925)))
         .append(Text.literal(var5).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(var10))))
         .append(Text.literal(": ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(8947848))))
         .append(Text.literal(var3).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))));
      MinecraftClient var8 = MinecraftClient.getInstance();
      var8.execute(() -> {
         if (var8.inGameHud != null) {
            var8.inGameHud.getChatHud().addMessage(var11);
         }
      });
   }

   private void b(JSONObject var1) {
      String var2 = var1.getString("groupId");
      int var3 = var1.getInt("leaderId");
      long var4 = var1.optLong("epoch", 0L);
      JSONArray var6 = var1.getJSONArray("members");
      ArrayList var7 = new ArrayList<>();
      boolean var8 = false;

      for (int var9 = 0; var9 < var6.length(); var9++) {
         JSONObject var10 = var6.getJSONObject(var9);
         int var11 = var10.getInt("userId");
         if (var11 == this.I) {
            var8 = true;
         }

         var7.add(
            new GroupMemberDto(
               var11,
               var10.isNull("username") ? null : var10.optString("username", null),
               var10.isNull("minecraftNick") ? null : var10.optString("minecraftNick", null),
               var10.has("displayName") && !var10.isNull("displayName") ? var10.optString("displayName", null) : null,
               var10.optString("status", "offline"),
               var10.isNull("server") ? null : var10.optString("server", null),
               var10.isNull("avatarUrl") ? null : var10.optString("avatarUrl", null),
               var10.isNull("coverUrl") ? null : var10.optString("coverUrl", null),
               var10.isNull("colorRgb") ? null : var10.getInt("colorRgb")
            )
         );
      }

      if (this.I != 0 && !var8) {
         GroupManagerClient var12 = GroupManagerClient.a();
         if (var2.equals(var12.g())) {
            var12.e();
         }
      } else {
         GroupManagerClient.a().a(var2, var3, var4, var7);
      }
   }

   private void a(int var1, String var2) {
      if (var1 != 0) {
         MinecraftClient.getInstance()
            .execute(
               () -> {
                  NotificationIsland var3 = NotificationIsland.a("Запрос в друзья")
                     .a("От " + var2)
                     .a(NotificationIsland.NotificationType.a)
                     .a(15000L)
                     .a("Принять", () -> this.a(var1, true))
                     .a("Отклонить", new Color(243, 82, 66), () -> this.a(var1, false))
                     .b();
                  WatermarkComponent.a(var3);
               }
            );
      }
   }

   private void e(String var1, String var2) {
      if (var1 != null) {
         MinecraftClient.getInstance()
            .execute(
               () -> {
                  NotificationIsland var3 = NotificationIsland.a("Приглашение в группу")
                     .a("От " + var2)
                     .a(NotificationIsland.NotificationType.a)
                     .a(15000L)
                     .a("Принять", () -> this.a(var1, true))
                     .a("Отклонить", new Color(243, 82, 66), () -> this.a(var1, false))
                     .b();
                  WatermarkComponent.a(var3);
               }
            );
      }
   }

   private void b(int var1, String var2) {
      MinecraftClient.getInstance()
         .execute(
            () -> {
               if (MinecraftClient.getInstance().player != null) {
                  MutableText var2x = ChatUtils.b("[Pulse] ").append(Text.literal("» ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))));
                  MutableText var3 = Text.literal(var2);
                  MutableText var4 = Text.literal("§a[Принять]");
                  var4.setStyle(
                     Style.EMPTY
                        .withColor(TextColor.fromRgb(5756778))
                        .withClickEvent(new OpenUrl(URI.create("pulse://friendaccept/" + var1)))
                        .withHoverEvent(new ShowText(Text.literal("Принять заявку")))
                  );
                  MutableText var5 = Text.literal(" ");
                  MutableText var6 = Text.literal("§c[Отклонить]");
                  var6.setStyle(
                     Style.EMPTY
                        .withColor(TextColor.fromRgb(15946306))
                        .withClickEvent(new OpenUrl(URI.create("pulse://frienddecline/" + var1)))
                        .withHoverEvent(new ShowText(Text.literal("Отклонить заявку")))
                  );
                  var2x.append(var3).append(var4).append(var5).append(var6);
                  MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(var2x);
               }
            }
         );
   }

   private void f(String var1, String var2) {
      MinecraftClient.getInstance()
         .execute(
            () -> {
               if (MinecraftClient.getInstance().player != null) {
                  MutableText var2x = ChatUtils.b("[Pulse] ").append(Text.literal("» ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))));
                  MutableText var3 = Text.literal(var2);
                  MutableText var4 = Text.literal("§a[Принять]");
                  var4.setStyle(
                     Style.EMPTY
                        .withColor(TextColor.fromRgb(5756778))
                        .withClickEvent(new OpenUrl(URI.create("pulse://groupaccept/" + var1)))
                        .withHoverEvent(new ShowText(Text.literal("Принять приглашение")))
                  );
                  MutableText var5 = Text.literal(" ");
                  MutableText var6 = Text.literal("§c[Отклонить]");
                  var6.setStyle(
                     Style.EMPTY
                        .withColor(TextColor.fromRgb(15946306))
                        .withClickEvent(new OpenUrl(URI.create("pulse://groupdecline/" + var1)))
                        .withHoverEvent(new ShowText(Text.literal("Отклонить приглашение")))
                  );
                  var2x.append(var3).append(var4).append(var5).append(var6);
                  MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(var2x);
               }
            }
         );
   }

   private void ao() {
      if (this.ad != null) {
         String var1 = this.ad;
         String var2 = this.ae;
         long var3 = this.af;
         String var5 = this.ag;
         boolean var6 = this.ah;
         boolean var7 = this.ai;
         int var8 = this.aj;
         int var9 = this.ak;
         int var10 = this.al;
         String var11 = this.am;
         String var12 = this.an;
         this.ad = null;
         NotificationIsland.Builder var13 = NotificationIsland.a(var1);
         if (var2 != null && !var2.isEmpty()) {
            var13.a(var2);
         }

         var13.a(var3);
         if ("WARNING".equalsIgnoreCase(var5)) {
            var13.a(NotificationIsland.NotificationType.b);
         } else if ("FIRE".equalsIgnoreCase(var5)) {
            var13.a(NotificationIsland.NotificationType.c);
         } else if ("CLOUD".equalsIgnoreCase(var5)) {
            var13.a(NotificationIsland.NotificationType.d);
         } else {
            var13.a(NotificationIsland.NotificationType.a);
         }

         if (var7) {
            var13.a(new Color(var8, var9, var10));
         }

         if (var11 != null && !var11.isEmpty()) {
            this.o = var12;
            var13.a(var11, new RealtimeSyncServiceV2.ButtonRunnable());
         }

         WatermarkComponent.a(var13.b());
         if (var6) {
            String var14 = var1;
            if (var2 != null && !var2.isEmpty()) {
               var14 = var1 + " - " + var2;
            }

            if (var12 != null && !var12.isEmpty()) {
               var14 = var14 + " &7| &b" + var12;
            }

            ChatUtils.a((Object)var14);
         }
      }
   }

   private void ap() {
      String var1 = this.o;
      this.o = null;
      if (var1 != null && !var1.isEmpty()) {
         try {
            URI var2 = new URI(var1);
            Util.getOperatingSystem().open(var2);
         } catch (Exception var3) {
         }
      }
   }

   @Override
   public void onClosed(WebSocket var1, int var2, String var3) {
      if (var1 == this.E) {
         this.H &= -4;
         this.S = null;
         this.T = null;
         this.U = null;
         this.N = 0L;
         this.A.clear();

         for (CompletableFuture var5 : this.D.values()) {
            var5.cancel(true);
         }

         this.D.clear();
         if (this.F != null) {
            this.F.cancel(false);
            this.F = null;
         }

         this.aq();
      }
   }

   @Override
   public void onFailure(WebSocket var1, Throwable var2, Response var3) {
      if (var1 == this.E) {
         this.H &= -4;
         this.S = null;
         this.T = null;
         this.U = null;
         this.N = 0L;
         this.A.clear();

         for (CompletableFuture var5 : this.D.values()) {
            var5.cancel(true);
         }

         this.D.clear();
         if (this.F != null) {
            this.F.cancel(false);
            this.F = null;
         }

         this.aq();
      }
   }

   private void aq() {
      if ((this.H & 8) != 0) {
         int var1 = ++this.L;
         if (var1 <= 10) {
            long var2 = Math.min(5000 * var1, 60000);
            this.R = System.currentTimeMillis() + var2;
            this.a(3, var2);
         } else {
            this.L = 0;
            this.R = System.currentTimeMillis() + 300000L;
            this.a(3, 300000L);
         }
      }
   }

   public static RealtimeSyncServiceV2 L() {
      if (aW == null) {
         synchronized (RealtimeSyncServiceV2.class) {
            if (aW == null) {
               aW = new RealtimeSyncServiceV2();
            }
         }
      }

      return aW;
   }

   static {
      NativeMethodLookup.lookup(RealtimeSyncServiceV2.class, 91);
   }

   @Environment(EnvType.CLIENT)
   private class ButtonRunnable implements Runnable {
      @Override
      public void run() {
         RealtimeSyncServiceV2.this.ap();
      }
   }

   @Environment(EnvType.CLIENT)
   private class NotifRunnable implements Runnable {
      @Override
      public void run() {
         RealtimeSyncServiceV2.this.ao();
      }
   }
}
