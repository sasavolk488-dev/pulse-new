package pulse.mixin;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.command.BatchingRenderCommandQueue;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl.ItemCommand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.utilities.MaceHelperModule;
import pulse.utils.render.vertex.PulseTintedItemCommand;

@Environment(EnvType.CLIENT)
@Mixin({BatchingRenderCommandQueue.class})
public abstract class BatchingRenderCommandQueueMixin {
   @Inject(
      method = {"submitItem"},
      at = {@At("TAIL")}
   )
   private void pulse$stampMaceTint(CallbackInfo var1) {
      int var2 = MaceHelperModule.n();
      if (var2 != 0) {
         List var3 = ((BatchingRenderCommandQueue)(Object)this).getItemCommands();
         if (!var3.isEmpty()) {
            ItemCommand var4 = (ItemCommand)var3.get(var3.size() - 1);
            ((PulseTintedItemCommand)(Object)var4).pulse$setTint(var2);
         }
      }
   }
}
