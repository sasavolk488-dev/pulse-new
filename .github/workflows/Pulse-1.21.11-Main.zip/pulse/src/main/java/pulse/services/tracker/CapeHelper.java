package pulse.services.tracker;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerModelPart;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import pulse.Pulse;
import pulse.features.cosmetic.CosmeticTextureManager;
import pulse.services.tracker.v2.ModUserTrackerV2;
import pulse.services.accounts.UserInfo;

@Environment(EnvType.CLIENT)
public class CapeHelper {
   private CapeHelper() {
   }

   public static Identifier a(AbstractClientPlayerEntity var0) {
      if (var0 == null) {
         return null;
      } else {
         MinecraftClient var1 = MinecraftClient.getInstance();
         boolean var2 = var1.player != null && var1.player.getId() == var0.getId();
         Integer var3;
         if (var2) {
            UserInfo var4 = Pulse.n();
            var3 = var4 != null ? var4.b() : null;
         } else {
            String var5 = var0.getGameProfile().name();
            var3 = ModUserTrackerV2.d().b(var5);
         }

         if (var3 == null) {
            return null;
         } else {
            Identifier var6 = CosmeticTextureManager.a().b(var3);
            return var6 != null ? var6 : CosmeticTextureManager.a().a(var3);
         }
      }
   }

   public static boolean b(AbstractClientPlayerEntity var0) {
      return c(var0) != null;
   }

   public static Identifier c(AbstractClientPlayerEntity var0) {
      if (var0 == null) {
         return null;
      } else {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1.player == null) {
            return null;
         } else {
            Identifier var2 = a(var0);
            if (var2 == null) {
               return null;
            } else if (!var0.isInvisible() && var0.isModelPartVisible(PlayerModelPart.CAPE)) {
               return !var0.getEquippedStack(EquipmentSlot.CHEST).isEmpty() && var0.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA
                  ? null
                  : var2;
            } else {
               return null;
            }
         }
      }
   }
}
