package pulse.features.modules.utilities.ft;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;

@Environment(EnvType.CLIENT)
public enum RegionSize {
   a(Blocks.IRON_BLOCK, 3),
   b(Blocks.GOLD_BLOCK, 5),
   c(Blocks.DIAMOND_BLOCK, 7),
   d(Blocks.DIAMOND_ORE, 10),
   e(Blocks.EMERALD_ORE, 15),
   f(Blocks.CHAIN_COMMAND_BLOCK, 25);

   private final Block g;
   private final int h;

   private RegionSize(Block var3, int var4) {
      this.g = var3;
      this.h = var4;
   }

   public Block a() {
      return this.g;
   }

   public int b() {
      return this.h;
   }

   public String c() {
      return this.h + "x" + this.h;
   }

   public int d() {
      return this.h * 2 + 1;
   }

   public RegionSize e() {
      RegionSize[] var1 = values();
      return var1[(this.ordinal() + 1) % var1.length];
   }

   public RegionSize f() {
      RegionSize[] var1 = values();
      return var1[(this.ordinal() - 1 + var1.length) % var1.length];
   }

   public static RegionSize a(int var0) {
      for (RegionSize var4 : values()) {
         if (var4.h == var0) {
            return var4;
         }
      }

      return a;
   }

   public static RegionSize a(Item var0) {
      if (var0 instanceof BlockItem var1) {
         Block var2 = var1.getBlock();

         for (RegionSize var6 : values()) {
            if (var6.g == var2) {
               return var6;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static RegionSize[] g() {
      return new RegionSize[]{a, b, c, d, e, f};
   }
}
