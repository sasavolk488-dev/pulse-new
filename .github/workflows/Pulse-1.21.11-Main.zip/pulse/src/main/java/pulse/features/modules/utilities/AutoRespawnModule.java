package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import pulse.core.event.impl.PlayerDeathEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.InputSetting;

@ModuleInfo(
   a = "Auto Respawn",
   b = "Автоматически возрождает игрока после смерти",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class AutoRespawnModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Авто возрождение", "Автоматически возрождаться после смерти", true);
   private final BooleanSetting b = new BooleanSetting("Отправлять команду после возрождения", "Отправлять команду после возрождения", false);
   private final InputSetting c = new InputSetting("Команда", InputSetting.InputType.b, "/home").c(this.b::q);
   private boolean f = false;
   private boolean g;
   private int h;

   @EventHandler
   @Compile
      public void a(PlayerDeathEvent var1) {
      if (var1.a() == d.player) {
         this.g = true;
      }
   }

   @EventHandler
   @Compile
   public void a(UpdateEvent var1) {
      InputSetting command = this.c;
      BooleanSetting sendCommand = this.b;
      BooleanSetting autoRespawn = this.a;
      if (d.player == null || d.world == null) {
         return;
      }
      if (d.currentScreen instanceof DeathScreen) {
         this.h++;
      }
      if (this.g && !(d.currentScreen instanceof DeathScreen) && d.player.age > 30) {
         pulse.utils.game.ChatUtils.a(command.i());
         this.g = false;
         this.h = 0;
      }
      if (d.currentScreen instanceof DeathScreen) {
         DeathScreen screen = (DeathScreen)d.currentScreen;
         if (!this.f) {
            this.f = true;
         }
         if ((Boolean)autoRespawn.q() && this.a(screen)) {
            d.player.requestRespawn();
            d.currentScreen = null;
            this.h = 0;
         }
      } else if (this.f && d.player.isAlive()) {
         this.f = false;
         if ((Boolean)sendCommand.q() && !command.i().isEmpty()) {
            pulse.utils.game.ChatUtils.a(command.i());
         }
      }
   }

   private boolean a(DeathScreen var1) {
      try {
         for (Object var3 : var1.children()) {
            if (var3 instanceof ButtonWidget var4 && var4.active) {
               return true;
            }
         }

         return false;
      } catch (Exception var5) {
         return false;
      }
   }

   @Compile
   @Override
      public void f() {
      super.f();
      this.f = false;
   }

   static {
      NativeMethodLookup.lookup(AutoRespawnModule.class, 53);
   }
}
