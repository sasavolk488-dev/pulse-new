package pulse.features.modules.utilities;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Item Scroller",
   b = "Быстрый перенос предметов зажатием Shift + ЛКМ",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class ItemScrollerModule extends Module {
   public final NumberSetting a = new NumberSetting("Задержка (мс)", 50.0F, 10.0F, 500.0F, 10.0F);
}
