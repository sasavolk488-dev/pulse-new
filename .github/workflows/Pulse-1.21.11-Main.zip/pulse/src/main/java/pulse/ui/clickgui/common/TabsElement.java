package pulse.ui.clickgui.common;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.ui.clickgui.common.provider.TabsProvider;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.ColorUtils;
import pulse.utils.render.LayerManager;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class TabsElement implements GuiElement {
   private final TabsProvider a;
   private static final float b = 19.0F;
   private static final float c = 35.5F;
   private static final float d = 6.0F;
   private static final Color e = ClickGuiColors.N;
   private final Map<Integer, Animation> f = new HashMap<>();
   private final Map<Integer, Animation> g = new HashMap<>();
   private final Map<Integer, Boolean> h = new HashMap<>();
   private final Map<Integer, Boolean> i = new HashMap<>();
   private final Map<Integer, Float> j = new HashMap<>();
   private final Map<Integer, Float> k = new HashMap<>();
   private String[] l;

   public TabsElement(TabsProvider var1) {
      this.a = var1;
      this.a();
   }

   private void a() {
      String[] var1 = this.a.c();
      this.l = var1;
      int var2 = this.a.d();
      FontRenderer var3 = Fonts.b[14];

      for (int var4 = 0; var4 < var1.length; var4++) {
         this.f.put(var4, new Animation());
         this.g.put(var4, new Animation());
         this.h.put(var4, false);
         boolean var5 = var4 == var2;
         this.i.put(var4, var5);
         this.f.get(var4).d(var5 ? 1.0 : 0.0);
         this.j.put(var4, var3.a(var1[var4]));
      }
   }

   private void b() {
      String[] var1 = this.a.c();
      if (this.l != null && var1.length == this.l.length) {
         for (int var2 = 0; var2 < var1.length; var2++) {
            if (!var1[var2].equals(this.l[var2])) {
               this.a();
               return;
            }
         }
      } else {
         this.a();
      }
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      this.b();
      float var7 = ClickGuiScreen.e();
      FontRenderer var8 = Fonts.b[14];
      String[] var9 = this.a.c();
      int var10 = this.a.d();
      if (var9.length != 0) {
         float var11 = var8.a("/");
         float var12 = var3 + 19.0F;
         float var13 = var4 + 19.0F;
         float var14 = 7.0F;
         float var15 = 0.0F;

         for (int var16 = 0; var16 < var9.length; var16++) {
            var15 += this.j.get(var16);
            if (var16 < var9.length - 1) {
               var15 += 12.0F + var11;
            }
         }

         LayerManager.a().a(LayerManager.Layer.c, var12, var13, var15, var14);
         boolean var26 = OverlayElement.a().b();
         boolean var17 = !MouseUtil.a(LayerManager.Layer.c, var5, var6) || var26;
         boolean var18 = false;

         for (int var19 = 0; var19 < var9.length; var19++) {
            this.k.put(var19, var12);
            boolean var20 = var19 == var10;
            boolean var21 = !var17 && MouseUtil.a(var12, var13, this.j.get(var19), var14, (double)var5, (double)var6);
            if (var21 && var9.length > 1 && !var20) {
               var18 = true;
            }

            if (var17 && this.h.get(var19)) {
               this.g.get(var19).a(0.0, 0.15000007154200193, Easings.h);
               this.h.put(var19, false);
            } else if (!var17 && var21 != this.h.get(var19)) {
               this.g.get(var19).a(var21 ? 1.0 : 0.0, 0.15000007154200193, Easings.h);
               this.h.put(var19, var21);
            }

            if (var20 != this.i.get(var19)) {
               this.f.get(var19).a(var20 ? 1.0 : 0.0, 0.20000000000910306, Easings.h);
               this.i.put(var19, var20);
            }

            this.f.get(var19).a();
            this.g.get(var19).a();
            float var22 = (float)this.f.get(var19).j();
            float var23 = (float)this.g.get(var19).j();
            Color var24;
            if (var9.length == 1) {
               var24 = ClickGuiColors.aa;
            } else {
               var24 = ColorUtils.a(ColorUtils.a(ClickGuiColors.b, e, var23 * (1.0F - var22)), ClickGuiColors.aa, var22);
            }

            var8.a(var9[var19], var12, var13, var24, var1);
            var12 += this.j.get(var19);
            if (var19 < var9.length - 1) {
               var12 += 6.0F;
               var8.a("/", var12, var13, ClickGuiColors.b, var1);
               var12 += var11 + 6.0F;
            }
         }

         if (var18 && !var17) {
            MouseUtil.g();
         }

         float var27 = var4 + 35.5F;
         var2.a((int)var3 + 19.0F, (int)var27, var7 - 38.0F, 0.5F, ClickGuiColors.a(ClickGuiColors.aa, 25), var1);
      }
   }

   @Override
   public void a(float var1, float var2, int var3, int var4) {
      if (MouseUtil.a(LayerManager.Layer.c, var3, var4)) {
         if (!OverlayElement.a().b()) {
            String[] var5 = this.a.c();
            if (var5.length > 1) {
               FontRenderer var6 = Fonts.b[14];
               float var7 = var2 + 19.0F;
               float var8 = 7.0F;

               for (int var9 = 0; var9 < var5.length; var9++) {
                  Float var10 = this.k.get(var9);
                  Float var11 = this.j.get(var9);
                  if (var10 != null && var11 != null && MouseUtil.a(var10, var7, var11, var8, (double)var3, (double)var4)) {
                     this.a.a(var9);
                     break;
                  }
               }
            }
         }
      }
   }
}
