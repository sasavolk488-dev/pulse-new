package pulse.features.modules.hud.components;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@Environment(EnvType.CLIENT)
public class HotKeysComponent extends DraggableComponent {
   private static final Color m = new Color(13, 13, 17);
   private static final Color n = new Color(17, 17, 23);
   private static final Color o = new Color(255, 255, 255);
   private static final Color p = new Color(223, 223, 243);
   private static final Color q = new Color(20, 20, 28);
   private static final Color r = new Color(16, 16, 21);
   private static final Color s = new Color(17, 17, 23);
   private static final Color t = new Color(23, 23, 30);
   private static final Color u = new Color(18, 18, 24);
   private static final Color v = new Color(115, 83, 255);
   private static final Color w = new Color(70, 46, 174);
   private static final float x = 8.5F;
   private static final float y = 8.0F;
   private static final float z = 24.0F;
   private static final float A = 16.0F;
   private static final float B = 5.0F;
   private static final float C = 12.0F;
   private static final float D = 2.0F;
   private static final float E = 12.0F;
   private static final float F = 6.0F;
   private static final float G = 6.5F;
   private static final float H = 0.5F;
   private static final float I = 82.0F;
   private static final double J = 0.1999999785833097;
   private static final long K = 1000L;
   private static final Comparator<HotKeysComponent.ModuleData> L = Comparator.comparing(var0 -> var0.b);
   private static final Map<Integer, String> M = new HashMap<>();
   private final Map<Module, HotKeysComponent.AnimatedModuleData> N = new LinkedHashMap<>();
   private final List<HotKeysComponent.DemoModuleData> O = new ArrayList<>();
   private final Animation P = new Animation();
   private final Animation Q = new Animation();
   private final Animation R = new Animation();
   private long S = 0L;
   private int T = 0;
   private boolean U = false;
   private boolean V = false;
   private boolean W = false;

   public HotKeysComponent(float var1, float var2) {
      super(var1, var2);
      this.R.d(0.0);
      this.v();
      this.a();
   }

   private void v() {
      this.O.add(new HotKeysComponent.DemoModuleData("Trails", "  G  "));
      this.O.add(new HotKeysComponent.DemoModuleData("Fast Swap", "  O  "));
      this.O.add(new HotKeysComponent.DemoModuleData("PVP Safe", "  B  "));
   }

   private boolean a(List<HotKeysComponent.ModuleData> var1) {
      return this.a.currentScreen instanceof ChatScreen && var1.isEmpty();
   }

   private void w() {
      if (!this.W) {
         if (ModuleRegistry.ay != null) {
            this.f().a(ModuleRegistry.ay);
            this.W = true;
         }
      }
   }

   @Override
   protected void a() {
      this.w();
      List<HotKeysComponent.ModuleData> var1 = this.x();
      boolean var2 = this.a(var1);
      float var3 = this.g();
      float var4 = 8.5F * var3;
      float var5 = 24.0F * var3;
      float var6 = 5.0F * var3;
      float var7 = 12.0F * var3;
      float var8 = 2.0F * var3;
      float var9 = 6.5F * var3;
      float var10 = 0.5F * var3;
      float var11 = 82.0F * var3;
      int var12 = Math.round(15.0F * var3);
      int var13 = Math.round(14.0F * var3);
      FontRenderer var14 = Fonts.a[Math.max(10, Math.min(48, var12))];
      FontRenderer var15 = Fonts.a[Math.max(10, Math.min(48, var13))];
      if (var2) {
         long var16 = System.currentTimeMillis();
         if (var16 - this.S >= 1000L) {
            this.T = (this.T + 1) % this.O.size();
            this.S = var16;
         }
      }

      HashSet var26 = new HashSet<>();

      for (HotKeysComponent.ModuleData var18 : var1) {
         var26.add(var18.a);
      }

      for (HotKeysComponent.AnimatedModuleData var29 : this.N.values()) {
         if (!var26.contains(var29.a) && !var29.f) {
            var29.f = true;
            var29.d.a(0.0, 0.1999999785833097, Easings.h);
         }
      }

      int var28 = 0;

      for (HotKeysComponent.ModuleData var19 : var1) {
         HotKeysComponent.AnimatedModuleData var20 = this.N.get(var19.a);
         if (var20 == null) {
            var20 = new HotKeysComponent.AnimatedModuleData(var19.a, var19.b, var19.c);
            var20.d.d(0.0);
            var20.d.a(1.0, 0.1999999785833097, Easings.h);
            var20.e.d(var28);
            this.N.put(var19.a, var20);
         } else {
            var20.b = var19.b;
            var20.c = var19.c;
            var20.f = false;
            if (var20.d.i() < 1.0) {
               var20.d.a(1.0, 0.1999999785833097, Easings.h);
            }

            if (Math.abs(var20.e.i() - var28) > 0.01000000422005875) {
               var20.e.a(var28, 0.1999999785833097, Easings.h);
            }
         }

         var28++;
      }

      this.N.entrySet().removeIf(var0 -> var0.getValue().f && var0.getValue().d.j() < 0.01000000422005875);

      for (HotKeysComponent.AnimatedModuleData var33 : this.N.values()) {
         var33.d.a();
         var33.e.a();
      }

      boolean var32 = this.V;
      this.V = false;
      int var34 = 0;
      if (var2) {
         this.V = true;
         var34 = 1;
      } else {
         for (HotKeysComponent.AnimatedModuleData var21 : this.N.values()) {
            if (!var21.f) {
               this.V = true;
               var34++;
            }
         }
      }

      if (this.V && !var32) {
         this.R.a(1.0, 0.1999999785833097, Easings.h);
      } else if (!this.V && var32) {
         this.R.a(0.0, 0.1999999785833097, Easings.h);
      } else if (this.V && this.R.i() < 1.0) {
         this.R.a(1.0, 0.1999999785833097, Easings.h);
      }

      this.R.a();
      float var37 = 0.0F;
      if (var2) {
         HotKeysComponent.DemoModuleData var38 = this.O.get(this.T);
         float var22 = var14.a(var38.a);
         float var23 = var15.a(var38.b) + var9 * 2.0F + var10 * 2.0F;
         var37 = var22 + 8.0F * var3 + var23;
      } else {
         for (HotKeysComponent.AnimatedModuleData var41 : this.N.values()) {
            if (!var41.f) {
               float var43 = var14.a(var41.b);
               float var24 = var15.a(var41.c) + var9 * 2.0F + var10 * 2.0F;
               float var25 = var43 + 8.0F * var3 + var24;
               var37 = Math.max(var37, var25);
            }
         }
      }

      float var40 = Math.max(var11, var37);
      float var42 = var4 * 2.0F + var40;
      float var44 = 1.0F * var3;
      float var45 = var34 == 0 ? 0.0F : var34 * var7 + (var34 - 1) * var8;
      float var46 = var5 + var44 + var6 + var45 + var6 + 2.0F * var3;
      if (!this.U) {
         this.Q.d(var42);
         this.P.d(var46);
         this.U = true;
      } else {
         if (Math.abs(this.Q.i() - var42) > 0.5) {
            this.Q.a(var42, 0.1999999785833097, Easings.h);
         }

         if (Math.abs(this.P.i() - var46) > 0.5) {
            this.P.a(var46, 0.1999999785833097, Easings.h);
         }
      }

      this.Q.a();
      this.P.a();
      this.d = (float)this.Q.j();
      this.e = (float)this.P.j();
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (this.a.player != null) {
         this.a();
         float var5 = (float)this.R.j();
         if (!(var5 < 0.01F)) {
            boolean var6 = this.a(this.x());
            float var7 = this.g();
            float var8 = 8.5F * var7;
            float var9 = 8.0F * var7;
            float var10 = 24.0F * var7;
            float var11 = 16.0F * var7;
            float var12 = 5.0F * var7;
            float var13 = 12.0F * var7;
            float var14 = 2.0F * var7;
            int var15 = Math.round(16.0F * var7);
            int var16 = Math.round(15.0F * var7);
            int var17 = Math.round(14.0F * var7);
            boolean var18 = var5 < 0.99F;
            if (var18) {
               var2.c(this.b, this.c, this.d, this.e, var1);
            }

            float var19 = var18 ? 1.0F : var5;
            FontRenderer var20 = Fonts.b[Math.max(10, Math.min(48, var15))];
            FontRenderer var21 = Fonts.a[Math.max(10, Math.min(48, var16))];
            FontRenderer var22 = Fonts.a[Math.max(10, Math.min(48, var17))];
            Color var23 = this.a(m, var19);
            Color var24 = this.a(n, var19);
            var2.a(this.b, this.c, this.d, this.e, var9, var23, var23, var24, var24, var1);
            float var25 = this.b + var8;
            float var26 = this.c + var10 / 2.0F;
            int var27 = Math.round(22.0F * var7);
            FontRenderer var28 = Fonts.d[Math.max(12, Math.min(48, var27))];
            float var29 = var28.a("\ue910");
            float var30 = var28.b("\ue910");
            float var31 = var25 + (var11 - var29) / 2.0F - 4.0F;
            float var32 = var26 - var30 / 4.0F + 0.5F;
            var28.a("\ue910", var31, var32, this.a(v, var19), this.a(w, var19), var1);
            float var33 = var26 - var20.b("Hot Keys") / 4.0F + 1.0F * var7;
            var20.a("Hot Keys", var25 + var11 - 2.0F * var7, var33, this.a(o, var19), var1);
            float var34 = this.c + var10;
            var2.a(this.b, var34, this.d, 1.0F * var7, 0.0F, this.a(q, var19), var1);
            float var35 = var34 + 1.0F * var7;
            float var36 = this.e - var10 - 1.0F * var7;
            var2.a().a(this.b, var35, this.d, var36, 0.0F, var1);
            float var37 = var34 + 1.0F * var7 + var12;
            if (var6) {
               HotKeysComponent.DemoModuleData var38 = this.O.get(this.T);
               this.a(var1, var2, var21, var22, var25, var37, var38, var19, var7);
            } else {
               for (HotKeysComponent.AnimatedModuleData var39 : this.N.values()) {
                  float var40 = (float)var39.d.j();
                  float var41 = var18 ? var40 : var40 * var5;
                  if (!(var41 < 0.01F)) {
                     float var42 = (float)var39.e.j();
                     float var43 = var37 + var42 * (var13 + var14);
                     this.a(var1, var2, var21, var22, var25, var43, var39, var41, var7);
                  }
               }
            }

            var2.a().a(var1);
            if (var18) {
               var2.a(var5, var1);
            }
         }
      }
   }

   private void a(
      MatrixStack var1, Render var2, FontRenderer var3, FontRenderer var4, float var5, float var6, HotKeysComponent.DemoModuleData var7, float var8, float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 8.5F * var9;
      float var12 = 6.5F * var9;
      float var13 = 0.5F * var9;
      float var14 = 12.0F * var9;
      float var15 = 6.0F * var9;
      float var16 = var6 + var10 / 2.0F;
      Color var17 = this.a(p, var8);
      float var18 = var16 - var3.b(var7.a) / 4.0F;
      var3.a(var7.a, var5, var18, var17, var1);
      float var19 = var4.a(var7.b) + var12 * 2.0F + var13 * 2.0F - 2.0F * var9;
      float var20 = this.b + this.d - var11 - var19;
      float var21 = var16 - var14 / 2.0F - var13;
      float var22 = var14 + var13 * 2.0F;
      Color var23 = this.a(t, var8);
      Color var24 = this.a(u, var8);
      Color var25 = this.a(r, var8);
      Color var26 = this.a(s, var8);
      var2.a(var20, var21, var19, var22, var15, var23, var23, var24, var24, var1);
      var2.a(var20 + var13, var21 + var13, var19 - var13 * 2.0F, var14, var15 - var13, var25, var25, var26, var26, var1);
      float var27 = var16 - var4.b(var7.b) / 4.0F;
      float var28 = var20 + (var19 - var4.a(var7.b)) / 2.0F;
      var4.a(var7.b, var28, var27, var17, var1);
   }

   private void a(
      MatrixStack var1,
      Render var2,
      FontRenderer var3,
      FontRenderer var4,
      float var5,
      float var6,
      HotKeysComponent.AnimatedModuleData var7,
      float var8,
      float var9
   ) {
      float var10 = 12.0F * var9;
      float var11 = 8.5F * var9;
      float var12 = 6.5F * var9;
      float var13 = 0.5F * var9;
      float var14 = 12.0F * var9;
      float var15 = 6.0F * var9;
      float var16 = var6 + var10 / 2.0F;
      Color var17 = this.a(p, var8);
      float var18 = var16 - var3.b(var7.b) / 4.0F;
      var3.a(var7.b, var5, var18, var17, var1);
      float var19 = var4.a(var7.c) + var12 * 2.0F + var13 * 2.0F - 2.0F * var9;
      float var20 = this.b + this.d - var11 - var19;
      float var21 = var16 - var14 / 2.0F - var13;
      float var22 = var14 + var13 * 2.0F;
      Color var23 = this.a(t, var8);
      Color var24 = this.a(u, var8);
      Color var25 = this.a(r, var8);
      Color var26 = this.a(s, var8);
      var2.a(var20, var21, var19, var22, var15, var23, var23, var24, var24, var1);
      var2.a(var20 + var13, var21 + var13, var19 - var13 * 2.0F, var14, var15 - var13, var25, var25, var26, var26, var1);
      float var27 = var16 - var4.b(var7.c) / 4.0F;
      float var28 = var20 + (var19 - var4.a(var7.c)) / 2.0F;
      var4.a(var7.c, var28, var27, var17, var1);
   }

   private Color a(Color var1, float var2) {
      int var3 = Math.max(0, Math.min(255, (int)(var1.getAlpha() * var2)));
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var3);
   }

   private List<HotKeysComponent.ModuleData> x() {
      ArrayList<HotKeysComponent.ModuleData> var1 = new ArrayList<>();

      for (Module var3 : ModuleRegistry.b()) {
         if (var3.k() && var3.j() > 0) {
            String var4 = "  " + this.b(var3.j()) + "  ";
            var1.add(new HotKeysComponent.ModuleData(var3, var3.g(), var4));
         }
      }

      var1.sort(L);
      return var1;
   }

   private String b(int var1) {
      return M.computeIfAbsent(var1, HotKeysComponent::c);
   }

   private static String c(int var0) {
      if (var0 <= 0) {
         return "None";
      } else if (var0 >= 1450) {
         int var1 = var0 - 1450;
         switch (var1) {
            case 0:
               return "LMB";
            case 1:
               return "RMB";
            case 2:
               return "MMB";
            default:
               return "M" + var1;
         }
      } else {
         switch (var0) {
            case 32:
               return "Space";
            case 39:
               return "'";
            case 44:
               return ",";
            case 45:
               return "-";
            case 46:
               return ".";
            case 47:
               return "/";
            case 59:
               return ";";
            case 61:
               return "=";
            case 91:
               return "[";
            case 92:
               return "\\";
            case 93:
               return "]";
            case 96:
               return "`";
            case 256:
               return "Esc";
            case 257:
               return "Enter";
            case 258:
               return "Tab";
            case 259:
               return "Back";
            case 260:
               return "Ins";
            case 261:
               return "Del";
            case 262:
               return "Right";
            case 263:
               return "Left";
            case 264:
               return "Down";
            case 265:
               return "Up";
            case 266:
               return "PgUp";
            case 267:
               return "PgDn";
            case 268:
               return "Home";
            case 269:
               return "End";
            case 280:
               return "Caps";
            case 281:
               return "Scroll";
            case 282:
               return "Num";
            case 283:
               return "Print";
            case 284:
               return "Pause";
            case 340:
               return "LShift";
            case 341:
               return "LCtrl";
            case 342:
               return "LAlt";
            case 343:
               return "LWin";
            case 344:
               return "RShift";
            case 345:
               return "RCtrl";
            case 346:
               return "RAlt";
            case 347:
               return "RWin";
            case 348:
               return "Menu";
            default:
               if (var0 >= 290 && var0 <= 301) {
                  return "F" + (var0 - 290 + 1);
               } else if (var0 >= 302 && var0 <= 314) {
                  return "F" + (var0 - 302 + 13);
               } else if (var0 >= 320 && var0 <= 329) {
                  return "Num" + (var0 - 320);
               } else {
                  switch (var0) {
                     case 330:
                        return "Num.";
                     case 331:
                        return "Num/";
                     case 332:
                        return "Num*";
                     case 333:
                        return "Num-";
                     case 334:
                        return "Num+";
                     case 335:
                        return "NumEnter";
                     case 336:
                        return "Num=";
                     default:
                        if (var0 >= 48 && var0 <= 57) {
                           return String.valueOf((char)var0);
                        } else {
                           return var0 >= 65 && var0 <= 90 ? String.valueOf((char)var0) : "Key" + var0;
                        }
                  }
               }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   private static class AnimatedModuleData {
      final Module a;
      String b;
      String c;
      final Animation d = new Animation();
      final Animation e = new Animation();
      boolean f = false;

      AnimatedModuleData(Module var1, String var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class DemoModuleData {
      final String a;
      final String b;

      DemoModuleData(String var1, String var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class ModuleData {
      final Module a;
      final String b;
      final String c;

      ModuleData(Module var1, String var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
