package pulse.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({PersistentProjectileEntity.class})
public interface PersistentProjectileEntityInvoker {
   @Invoker("isInGround")
   boolean pulse$isInGround();
}
