package pulse.core.settings;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class KeySetting extends Setting<Integer> {
   public KeySetting(String var1, String var2, int var3) {
      super(var1, var2, var3);
   }

   public KeySetting(String var1, int var2) {
      this(var1, "", var2);
   }

   public KeySetting(String var1) {
      this(var1, "", -1);
   }

   public int b() {
      return this.q();
   }

   public void a(int var1) {
      this.a(var1);
   }

   public boolean c() {
      return this.q() != -1;
   }

   public void d() {
      this.a(-1);
   }

   public String e() {
      int var1 = this.q();
      if (var1 == -1) {
         return "None";
      } else {
         String var2 = GLFW.glfwGetKeyName(var1, 0);
         if (var2 != null) {
            return var2.toUpperCase();
         } else {
            switch (var1) {
               case 32:
                  return "SPACE";
               case 256:
                  return "ESC";
               case 257:
                  return "ENTER";
               case 258:
                  return "TAB";
               case 259:
                  return "BACK";
               case 260:
                  return "INS";
               case 261:
                  return "DEL";
               case 262:
                  return "RIGHT";
               case 263:
                  return "LEFT";
               case 264:
                  return "DOWN";
               case 265:
                  return "UP";
               case 266:
                  return "PGUP";
               case 267:
                  return "PGDN";
               case 268:
                  return "HOME";
               case 269:
                  return "END";
               case 280:
                  return "CAPS";
               case 340:
                  return "LSHIFT";
               case 341:
                  return "LCTRL";
               case 342:
                  return "LALT";
               case 344:
                  return "RSHIFT";
               case 345:
                  return "RCTRL";
               case 346:
                  return "RALT";
               default:
                  return "KEY_" + var1;
            }
         }
      }
   }
}
