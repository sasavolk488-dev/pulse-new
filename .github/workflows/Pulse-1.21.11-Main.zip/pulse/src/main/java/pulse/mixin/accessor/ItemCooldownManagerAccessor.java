package pulse.mixin.accessor;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({ItemCooldownManager.class})
public interface ItemCooldownManagerAccessor {
   @Accessor("tick")
   int pulse$getTick();

   @Accessor("entries")
   Map<Identifier, ?> pulse$getEntries();
}
