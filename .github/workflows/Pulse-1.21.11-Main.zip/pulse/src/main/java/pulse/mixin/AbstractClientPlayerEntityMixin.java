package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.Identifier;
import net.minecraft.util.AssetInfo.TextureAssetInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.services.tracker.CapeHelper;

@Environment(EnvType.CLIENT)
@Mixin({AbstractClientPlayerEntity.class})
public abstract class AbstractClientPlayerEntityMixin {
   @Inject(
      method = {"getSkin"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void pulse$useCustomCapeTexture(CallbackInfoReturnable<SkinTextures> var1) {
      AbstractClientPlayerEntity var2 = (AbstractClientPlayerEntity)(Object)this;
      Identifier var3 = CapeHelper.c(var2);
      if (var3 != null) {
         SkinTextures var4 = (SkinTextures)var1.getReturnValue();
         TextureAssetInfo var5 = new TextureAssetInfo(var3, var3);
         SkinTextures var6 = new SkinTextures(var4.body(), var5, var4.elytra(), var4.model(), var4.secure());
         var1.setReturnValue(var6);
      }
   }
}
