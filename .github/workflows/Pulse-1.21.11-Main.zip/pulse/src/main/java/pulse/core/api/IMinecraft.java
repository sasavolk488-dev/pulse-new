package pulse.core.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;

@Environment(EnvType.CLIENT)
public interface IMinecraft {
   MinecraftClient d = MinecraftClient.getInstance();
   Window e = d.getWindow();

   static Window u() {
      return MinecraftClient.getInstance().getWindow();
   }
}
