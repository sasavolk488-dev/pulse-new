package pulse.features.modules.visuals.animations;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.utils.animation.util.Easing;
import pulse.utils.animation.util.Easings;

@Environment(EnvType.CLIENT)
public class HotbarAnimator {
   private float a = Float.NaN;
   private float b;
   private float c;
   private long d = 0L;
   private long e = 160L;
   private int f = -1;
   private final Easing g = Easings.h;

   public void a() {
      if (!Float.isNaN(this.a) && this.d != 0L) {
         long var1 = System.currentTimeMillis();
         double var3 = var1 - this.d;
         double var5 = this.e;
         if (var3 >= var5) {
            this.a = this.c;
            this.d = 0L;
         } else {
            double var7 = var3 / var5;
            double var9 = this.g.ease(var7);
            this.a = (float)(this.b + (this.c - this.b) * var9);
         }
      }
   }

   public void a(int var1, int var2, long var3) {
      this.e = Math.max(1L, var3);
      float var5 = var2 - 91 - 1 + var1 * 20;
      if (this.f == -1 || Float.isNaN(this.a)) {
         this.f = var1;
         this.a = var5;
         this.b = var5;
         this.c = var5;
         this.d = 0L;
      } else if (var1 != this.f) {
         this.b = this.a;
         this.c = var5;
         this.d = System.currentTimeMillis();
         this.f = var1;
      } else {
         this.c = var5;
         if (this.d == 0L) {
            this.a = var5;
         }
      }
   }

   public float b() {
      return Float.isNaN(this.a) ? 0.0F : this.a;
   }

   public boolean c() {
      return this.d != 0L;
   }

   public void d() {
      this.a = Float.NaN;
      this.d = 0L;
      this.f = -1;
   }
}
