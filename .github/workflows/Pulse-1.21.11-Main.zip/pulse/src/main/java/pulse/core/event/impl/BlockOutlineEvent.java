package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class BlockOutlineEvent extends CancellableEvent {
   private final MatrixStack a;
   private final VertexConsumer b;
   private final Entity c;
   private final double d;
   private final double e;
   private final double f;
   private final BlockPos g;
   private final BlockState h;

   @Generated
   public MatrixStack d() {
      return this.a;
   }

   @Generated
   public VertexConsumer e() {
      return this.b;
   }

   @Generated
   public Entity f() {
      return this.c;
   }

   @Generated
   public double g() {
      return this.d;
   }

   @Generated
   public double h() {
      return this.e;
   }

   @Generated
   public double i() {
      return this.f;
   }

   @Generated
   public BlockPos j() {
      return this.g;
   }

   @Generated
   public BlockState k() {
      return this.h;
   }

   @Generated
   public BlockOutlineEvent(MatrixStack var1, VertexConsumer var2, Entity var3, double var4, double var6, double var8, BlockPos var10, BlockState var11) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var6;
      this.f = var8;
      this.g = var10;
      this.h = var11;
   }
}
