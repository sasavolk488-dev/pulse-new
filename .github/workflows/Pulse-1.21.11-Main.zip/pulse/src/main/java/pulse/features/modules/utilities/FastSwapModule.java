package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import lombok.Generated;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.potion.Potion;
import net.minecraft.registry.entry.RegistryEntry;
import pulse.core.event.impl.KeyEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.KeySetting;
import pulse.core.settings.NumberSetting;
import pulse.utils.game.InvUtils;

@ModuleInfo(
   a = "Fast Swap",
   b = "Быстрый выбор предметов по нажатию клавиш",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class FastSwapModule extends Module {
   private final KeySetting a = new KeySetting("Кнопка хоруса", -1);
   private final KeySetting b = new KeySetting("Кнопка эндерпёрла", -1);
   private final KeySetting c = new KeySetting("Кнопка зелья исцеления", -1);
   private final KeySetting f = new KeySetting("Кнопка трапки", -1);
   private final KeySetting g = new KeySetting("Кнопка пласта", -1);
   private final KeySetting h = new KeySetting("Кнопка дезориентации", -1);
   private final KeySetting i = new KeySetting("Кнопка явной пыли", -1);
   private final KeySetting j = new KeySetting("Кнопка шаровой молнии", -1);
   private final KeySetting k = new KeySetting("Кнопка кома слизи", -1);
   private final KeySetting l = new KeySetting("Кнопка черепашьего захвата", -1);
   private final KeySetting m = new KeySetting("Кнопка паучьей судьбы", -1);
   private final KeySetting n = new KeySetting("Кнопка стана", -1);
   private final KeySetting o = new KeySetting("Кнопка магнитного шара", -1);
   private final KeySetting p = new KeySetting("Кнопка взрывной трапки", -1);
   private final KeySetting q = new KeySetting("Кнопка взрывной штучки", -1);
   private final KeySetting r = new KeySetting("Кнопка стана звезды", -1);
   private final KeySetting s = new KeySetting("Кнопка кома снега", -1);
   private final KeySetting t = new KeySetting("Кнопка заряда ветра", -1);
   private final BooleanSetting u = new BooleanSetting("Отображать бинды", true);
   private final NumberSetting v = new NumberSetting("Размер шрифта биндов", 1.0F, 0.5F, 2.0F, 0.1F);
   private final List<FastSwapModule.Action> w = Collections.unmodifiableList(
      Arrays.asList(
         new FastSwapModule.Action(this.f, var0 -> var0.getItem() == Items.NETHERITE_SCRAP),
         new FastSwapModule.Action(this.g, var0 -> var0.getItem() == Items.DRIED_KELP),
         new FastSwapModule.Action(this.h, var0 -> var0.getItem() == Items.ENDER_EYE),
         new FastSwapModule.Action(this.i, var0 -> var0.getItem() == Items.SUGAR),
         new FastSwapModule.Action(this.j, var0 -> var0.getItem() == Items.NETHER_STAR),
         new FastSwapModule.Action(this.k, var0 -> var0.getItem() == Items.SLIME_BALL),
         new FastSwapModule.Action(this.l, var0 -> var0.getItem() == Items.TURTLE_SCUTE),
         new FastSwapModule.Action(this.m, var0 -> var0.getItem() == Items.COBWEB),
         new FastSwapModule.Action(this.n, var0 -> var0.getItem() == Items.ENDER_EYE),
         new FastSwapModule.Action(this.o, var0 -> var0.getItem() == Items.FIREWORK_STAR),
         new FastSwapModule.Action(this.a, var0 -> var0.getItem() == Items.CHORUS_FRUIT),
         new FastSwapModule.Action(this.b, var0 -> var0.getItem() == Items.ENDER_PEARL),
         new FastSwapModule.Action(this.c, this::a),
         new FastSwapModule.Action(this.p, var0 -> var0.getItem() == Items.PRISMARINE_SHARD),
         new FastSwapModule.Action(this.q, var0 -> var0.getItem() == Items.FIRE_CHARGE),
         new FastSwapModule.Action(this.r, var0 -> var0.getItem() == Items.NETHER_STAR),
         new FastSwapModule.Action(this.s, var0 -> var0.getItem() == Items.SNOWBALL),
         new FastSwapModule.Action(this.t, var0 -> var0.getItem() == Items.WIND_CHARGE)
      )
   );

   @EventHandler
   @Compile
      public void a(KeyEvent var1) {
      if (d.player == null || d.currentScreen != null) {
         return;
      }
      int key = var1.a();
      java.util.Optional<?> slot = this.w.stream()
         .filter(action -> a(key, action))
         .findFirst()
         .flatMap(FastSwapModule::a);
      slot.ifPresent(value -> a((Integer)value));
   }

   public boolean a(ItemStack var1) {
      if (var1.getItem() != Items.POTION) {
         return false;
      } else {
         if (var1.getItem() instanceof PotionItem) {
            Optional var2 = var1.getOrDefault(DataComponentTypes.POTION_CONTENTS, PotionContentsComponent.DEFAULT).potion();
            if (var2.isPresent()) {
               for (StatusEffectInstance var4 : ((Potion)((RegistryEntry)var2.get()).value()).getEffects()) {
                  if (var4.getEffectType() == StatusEffects.INSTANT_HEALTH) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   @Generated
   public KeySetting n() {
      return this.a;
   }

   @Generated
   public KeySetting o() {
      return this.b;
   }

   @Generated
   public KeySetting p() {
      return this.c;
   }

   @Generated
   public KeySetting q() {
      return this.f;
   }

   @Generated
   public KeySetting r() {
      return this.g;
   }

   @Generated
   public KeySetting s() {
      return this.h;
   }

   @Generated
   public KeySetting t() {
      return this.i;
   }

   @Generated
   public KeySetting v() {
      return this.j;
   }

   @Generated
   public KeySetting w() {
      return this.k;
   }

   @Generated
   public KeySetting x() {
      return this.l;
   }

   @Generated
   public KeySetting y() {
      return this.m;
   }

   @Generated
   public KeySetting z() {
      return this.n;
   }

   @Generated
   public KeySetting A() {
      return this.o;
   }

   @Generated
   public KeySetting B() {
      return this.p;
   }

   @Generated
   public KeySetting C() {
      return this.q;
   }

   @Generated
   public KeySetting D() {
      return this.r;
   }

   @Generated
   public KeySetting E() {
      return this.s;
   }

   @Generated
   public KeySetting F() {
      return this.t;
   }

   @Generated
   public BooleanSetting G() {
      return this.u;
   }

   @Generated
   public NumberSetting H() {
      return this.v;
   }

   @Generated
   public List<FastSwapModule.Action> I() {
      return this.w;
   }

   public static void a(Integer var0) {
      d.player.getInventory().setSelectedSlot(var0);
   }

   public static Optional a(FastSwapModule.Action var0) {
      return InvUtils.a(var0.b, false, true);
   }

   public static boolean a(int var0, FastSwapModule.Action var1) {
      int var2 = var1.a.b();
      return var2 != -1 && var2 != 0 && var2 == var0;
   }

   static {
      NativeMethodLookup.lookup(FastSwapModule.class, 60);
   }

   @Environment(EnvType.CLIENT)
   public static final class Action {
      private final KeySetting a;
      private final Predicate<ItemStack> b;

      public Action(KeySetting var1, Predicate<ItemStack> var2) {
         this.a = var1;
         this.b = var2;
      }

      public KeySetting a() {
         return this.a;
      }

      public Predicate<ItemStack> b() {
         return this.b;
      }
   }
}
