package pulse.core.event.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class WorldChangeEvent extends Event {
}
