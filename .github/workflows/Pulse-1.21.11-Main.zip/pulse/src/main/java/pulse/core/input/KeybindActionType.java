package pulse.core.input;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum KeybindActionType {
   a,
   b;

   private static KeybindActionType[] a() {
      return new KeybindActionType[]{a, b};
   }
}
