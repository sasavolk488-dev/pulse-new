package pulse.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.LivingJumpEvent;
import pulse.core.event.impl.PlayerDeathEvent;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.CustomHandModule;

@Environment(EnvType.CLIENT)
@Mixin({LivingEntity.class})
public class LivingEntityMixin {
   @ModifyReturnValue(
      method = {"getHandSwingDuration"},
      at = {@At("RETURN")}
   )
   private int pulse$customHandSwingSpeed(int var1) {
      CustomHandModule var2 = ModuleRegistry.f;
      if (var2 != null && var2.k()) {
         LivingEntity var3 = (LivingEntity)(Object)this;
         int var4 = var2.b.c();
         if (var3.hasStatusEffect(StatusEffects.MINING_FATIGUE)) {
            var4 += (1 + var3.getStatusEffect(StatusEffects.MINING_FATIGUE).getAmplifier()) * 2;
         }

         return var4;
      } else {
         return var1;
      }
   }

   @Inject(
      method = {"jump"},
      at = {@At("HEAD")}
   )
   private void onJump(CallbackInfo var1) {
      EventHandler.a.post(new LivingJumpEvent((LivingEntity)(Object)this));
   }

   @Inject(
      method = {"handleStatus"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/LivingEntity;getDeathSound()Lnet/minecraft/sound/SoundEvent;"
      )}
   )
   private void onHandleStatus(byte var1, CallbackInfo var2) {
      LivingEntity var3 = (LivingEntity)(Object)this;
      if (var3 instanceof ClientPlayerEntity var4) {
         EventHandler.a.post(new PlayerDeathEvent(var4, var4.getX(), var4.getY(), var4.getZ()));
      }
   }
}
