package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class ItemUsedEvent extends CancellableEvent {
   private final ItemStack a;
   private final World b;
   private final LivingEntity c;

   @Generated
   public ItemStack d() {
      return this.a;
   }

   @Generated
   public World e() {
      return this.b;
   }

   @Generated
   public LivingEntity f() {
      return this.c;
   }

   @Generated
   public ItemUsedEvent(ItemStack var1, World var2, LivingEntity var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
