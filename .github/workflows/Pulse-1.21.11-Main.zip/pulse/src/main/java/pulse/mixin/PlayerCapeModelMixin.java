package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerCapeModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.render.BobjVanillaPose;

@Environment(EnvType.CLIENT)
@Mixin({PlayerCapeModel.class})
public abstract class PlayerCapeModelMixin {
   @Inject(
      method = {"setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V"},
      at = {@At("TAIL")}
   )
   private void pulse$followBobjBody(PlayerEntityRenderState var1, CallbackInfo var2) {
      if (EmoteManager.a().b()) {
         MinecraftClient var3 = MinecraftClient.getInstance();
         if (var3.world != null) {
            if (var3.world.getEntityById(var1.id) instanceof AbstractClientPlayerEntity var4) {
               EmoteManager.ActiveRenderData var6 = EmoteManager.a().c(var4);
               if (var6 != null) {
                  BobjVanillaPose.a(((BipedEntityModel)(Object)this).body, var6);
               }
            }
         }
      }
   }
}
