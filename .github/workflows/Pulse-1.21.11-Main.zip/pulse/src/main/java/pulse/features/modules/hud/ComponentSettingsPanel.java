package pulse.features.modules.hud;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.common.settings.BooleanSettingElement;
import pulse.ui.clickgui.common.settings.ColorSettingElement;
import pulse.ui.clickgui.common.settings.KeySettingElement;
import pulse.ui.clickgui.common.settings.ModeSettingElement;
import pulse.ui.clickgui.common.settings.NumberSettingElement;
import pulse.ui.clickgui.common.settings.SettingElement;
import pulse.ui.clickgui.common.settings.SettingsContainer;
import pulse.features.modules.Module;
import pulse.utils.render.Render;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.KeySetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.Setting;
import pulse.utils.input.MouseUtil;
import pulse.utils.render.TextureRegistry;

@Environment(EnvType.CLIENT)
public class ComponentSettingsPanel {
   public static final float a = 140.0F;
   public static final float b = 38.0F;
   public static final float c = 108.0F;
   public static final float d = 9.5F;
   public static final float e = 7.0F;
   private final Animation f = new Animation();
   private boolean g = false;
   private boolean h = false;
   private float i = 140.0F;
   private float j;
   private float k;
   private float l;
   private float m;
   private float n;
   private float o;
   private boolean p = true;
   private static final float q = 8.0F;
   private final SettingsContainer r;
   private NumberSettingElement s;
   private boolean t = false;

   public ComponentSettingsPanel() {
      this.r = new SettingsContainer();
      this.r.b(7.0F);
      this.r.a(108.0F);
      this.s = new NumberSettingElement("Масштаб", 1.0F, 1.0F, 2.0F, 0.1F);
      this.s.a(true);
      this.r.a(this.s);
      this.f.d(0.0);
   }

   public void a(Module var1) {
      if (!this.t && var1 != null) {
         this.r.a();
         this.s = null;

         for (Setting var3 : var1.m()) {
            if (var3.r()) {
               SettingElement var4 = this.a(var3);
               if (var4 != null) {
                  this.r.a(var4);
                  if (this.s == null && var4 instanceof NumberSettingElement && var3.l().equals("Масштаб")) {
                     this.s = (NumberSettingElement)var4;
                     this.s.a(true);
                  }
               }
            }
         }

         if (this.s == null) {
            this.s = new NumberSettingElement("Масштаб", 1.0F, 1.0F, 2.0F, 0.1F);
            this.s.a(true);
            this.r.a(0, this.s);
         }

         this.t = true;
      }
   }

   private SettingElement a(Setting<?> var1) {
      if (var1 instanceof BooleanSetting) {
         return new BooleanSettingElement((BooleanSetting)var1);
      } else if (var1 instanceof NumberSetting) {
         return new NumberSettingElement((NumberSetting)var1);
      } else if (var1 instanceof ModeSetting) {
         return new ModeSettingElement((ModeSetting)var1);
      } else if (var1 instanceof ColorSetting) {
         return new ColorSettingElement((ColorSetting)var1);
      } else {
         return var1 instanceof KeySetting ? new KeySettingElement((KeySetting)var1) : null;
      }
   }

   @Deprecated
   public void a(NumberSetting var1) {
      if (!this.t) {
         this.r.b(this.s);
         this.s = new NumberSettingElement(var1);
         this.s.a(true);
         this.r.a(0, this.s);
      }
   }

   public void a(float var1, float var2, float var3, float var4) {
      if (this.g && !this.h) {
         this.a();
      } else {
         this.l = var1;
         this.m = var2;
         this.n = var3;
         this.o = var4;
         float var5 = this.h();
         float var6 = var2 - 8.0F;
         this.p = var6 >= var5;
         this.j = Math.round(var1 + var3 / 2.0F - this.i / 2.0F);
         if (this.p) {
            this.k = Math.round(var2 - var5 - 8.0F);
         } else {
            this.k = Math.round(var2 + var4 + 8.0F);
         }

         this.g = true;
         this.h = false;
         this.f.a(1.0, 0.25, Easings.F);
      }
   }

   public void a() {
      if (this.g) {
         this.h = true;
         this.r.g();
         this.f.a(0.0, 0.15000002049292468, Easings.g);
      }
   }

   public void b() {
      this.g = false;
      this.h = false;
      this.f.d(0.0);
      this.r.g();
   }

   public boolean c() {
      return this.g;
   }

   public boolean d() {
      return this.h;
   }

   public boolean e() {
      return this.g && !this.h && this.f.j() > 0.5;
   }

   public boolean f() {
      return this.h && this.f.d() && this.f.j() < 0.01000000515966649;
   }

   public void g() {
      this.f.a();
      if (this.f()) {
         this.g = false;
         this.h = false;
      }
   }

   public float h() {
      float var1 = this.r.m();
      return Math.max(38.0F, Math.min(var1, 108.0F));
   }

   public void a(MatrixStack var1, Render var2, int var3, int var4) {
      if (this.g) {
         this.g();
         float var5 = (float)this.f.j();
         if (!(var5 < 0.01F)) {
            float var6 = this.h();
            this.j = Math.round(this.l + this.n / 2.0F - this.i / 2.0F);
            if (this.p) {
               this.k = Math.round(this.m - var6 - 8.0F);
            } else {
               this.k = Math.round(this.m + this.o + 8.0F);
            }

            float var7 = Math.max(0.0F, Math.min(1.0F, var5));
            int var8 = (int)(255.0F * var7);
            float var9 = this.j + this.i / 2.0F;
            float var10 = this.k + var6 / 2.0F;
            float var11 = this.i * var7;
            float var12 = var6 * var7;
            if (!(var11 < 1.0F) && !(var12 < 1.0F)) {
               float var13 = var9 - var11 / 2.0F;
               float var14 = var10 - var12 / 2.0F;
               Color var15 = ClickGuiColors.a(ClickGuiColors.q, var8);
               Color var16 = ClickGuiColors.a(ClickGuiColors.r, var8);
               var2.a(var13 - 0.5F * var7, var14 - 0.5F * var7, var11 + var7, var12 + var7, 9.5F * var7, var15, var15, var16, var16, var1);
               Color var17 = ClickGuiColors.a(ClickGuiColors.e, var8);
               Color var18 = ClickGuiColors.a(ClickGuiColors.f, var8);
               var2.a(var13, var14, var11, var12, 9.5F * var7, var17, var17, var18, var18, var1);
               TextureRegistry.TextureEntry var19 = TextureRegistry.b("arrow_v");
               if (var19 != null) {
                  Identifier var20 = var19.a();
                  float var21 = var19.b() / 2.0F * var7;
                  float var22 = var19.c() / 2.0F * var7;
                  float var23 = var13 + var11 / 2.0F;
                  float var24;
                  float var25;
                  if (this.p) {
                     var24 = var14 + var12 + var21 / 2.0F + 1.0F;
                     var25 = 90.0F;
                  } else {
                     var24 = var14 - var21 / 2.0F - 1.0F;
                     var25 = -90.0F;
                  }

                  Color var26 = ClickGuiColors.a(ClickGuiColors.aa, var8);
                  var1.push();
                  var1.translate(var23, var24, 0.0F);
                  var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var25));
                  var1.translate(-var23, -var24, 0.0F);
                  float var27 = var23 - var21 / 2.0F - 0.5F;
                  float var28 = var24 - var22 / 2.0F;
                  var2.a(var20, var27, var28, var21, var22, var26, var1);
                  var1.pop();
               }

               if (var7 > 0.1F) {
                  float var29 = var14 + 7.0F * var7;
                  float var30 = var12 - 7.0F * var7 - 6.0F * var7;
                  if (var30 < 1.0F || var11 < 1.0F) {
                     return;
                  }

                  var2.a().a(var13, var29, var11, var30, 9.5F * var7, var1);
                  int var31 = this.h ? -1 : var3;
                  int var32 = this.h ? -1 : var4;
                  this.r.a(var1, var2, var13, var14, var11, var12, var31, var32, var7, var7);
                  var2.a().a(var1);
               }
            }
         }
      }
   }

   public boolean a(int var1, int var2) {
      if (!this.g || this.h || this.f.j() < 0.5) {
         return false;
      } else {
         return !this.c(var1, var2) ? false : this.r.a(this.j, this.k, this.i, this.h(), var1, var2);
      }
   }

   public void b(int var1, int var2) {
      if (this.g) {
         this.r.c(var1, var2);
      }
   }

   public void a(int var1, int var2, double var3, double var5) {
      if (this.g && !this.h) {
         this.r.a(this.h(), var1, var2, var3, var5);
      }
   }

   public boolean a(float var1, int var2, int var3) {
      if (!this.g || this.h) {
         return false;
      } else if (this.c(var2, var3)) {
         this.r.a(var1, this.h());
         return true;
      } else {
         return false;
      }
   }

   public boolean c(int var1, int var2) {
      return this.g && !(this.f.j() < 0.5) ? MouseUtil.a(this.j, this.k, this.i, this.h(), (double)var1, (double)var2) : false;
   }

   public void b(float var1, float var2, float var3, float var4) {
      this.l = var1;
      this.m = var2;
      this.n = var3;
      this.o = var4;
   }

   public float i() {
      return this.s.f();
   }

   @Deprecated
   public void a(float var1) {
      this.s.a(Math.max(1.0F, Math.min(2.0F, var1)));
   }

   public void a(SettingElement var1) {
      this.r.a(var1);
   }

   public SettingsContainer j() {
      return this.r;
   }
}
