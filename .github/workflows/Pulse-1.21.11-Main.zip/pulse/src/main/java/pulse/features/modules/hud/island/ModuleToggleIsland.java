package pulse.features.modules.hud.island;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.ColorUtils;

@Environment(EnvType.CLIENT)
public class ModuleToggleIsland extends Island {
   private static final Color k = new Color(87, 215, 106);
   private static final Color l = new Color(215, 87, 87);
   private static final Color m = new Color(255, 255, 255);
   private static final float n = 6.5F;
   private static final float o = 9.5F;
   private static final float p = 13.0F;
   private static final float q = 10.0F;
   private final String r;
   private boolean s;
   private final Animation t = new Animation();

   public ModuleToggleIsland(String var1, boolean var2) {
      this.r = var1;
      this.s = var2;
      this.e = 8.0F;
      this.f = 4.5F;
      this.h = 1000L;
      this.t.d(var2 ? 1.0 : 0.0);
   }

   public String m() {
      return this.r;
   }

   public boolean n() {
      return this.s;
   }

   public void a(boolean var1) {
      if (this.s != var1) {
         this.s = var1;
         this.t.a(var1 ? 1.0 : 0.0, 0.15000000028376662, Easings.h);
         this.i = System.currentTimeMillis();
         this.j = false;
      }
   }

   @Override
   public void e() {
      super.e();
      this.t.a();
   }

   @Override
   public float a() {
      FontRenderer var1 = Fonts.b[14];
      FontRenderer var2 = Fonts.a[12];
      float var3 = var1.a(this.r);
      String var4 = "Выключен";
      float var5 = var2.a(var4);
      float var6 = var5 + 13.0F;
      return var3 + 10.0F + var6 + 60.0F;
   }

   @Override
   public float b() {
      return 13.0F;
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, float var7) {
      FontRenderer var8 = Fonts.b[14];
      FontRenderer var9 = Fonts.a[12];
      int var10 = (int)(var7 * 255.0F);
      float var11 = var4 + var6 / 2.0F;
      Color var12 = new Color(m.getRed(), m.getGreen(), m.getBlue(), var10);
      float var13 = var11 - var8.b(this.r) / 4.0F;
      var8.a(this.r, var3, var13, var12, var1);
      float var14 = (float)this.t.j();
      String var15 = this.s ? "Включен" : "Выключен";
      float var16 = var9.a(var15);
      float var17 = var16 + 13.0F;
      Color var18 = ColorUtils.a(l, k, var14);
      Color var19 = new Color(var18.getRed(), var18.getGreen(), var18.getBlue(), var10);
      float var20 = var3 + var5 - var17 + 2.0F;
      float var21 = var11 - 6.5F;
      var2.a(var20, var21, var17, 13.0F, 9.5F, var19, var1);
      float var22 = var11 - var9.b(var15) / 4.0F;
      var9.a(var15, var20 + 6.5F, var22, var12, var1);
   }
}
