package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class LivingJumpEvent extends Event {
   private final LivingEntity a;

   @Generated
   public LivingEntity a() {
      return this.a;
   }

   @Generated
   public LivingJumpEvent(LivingEntity var1) {
      this.a = var1;
   }
}
