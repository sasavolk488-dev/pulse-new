package pulse.features.modules.visuals;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Self Nametag",
   b = "Показывает ваш неймтег над головой в третьем лице",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class SelfNametagModule extends Module {
}
