package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.event.CancellableEvent;

@Environment(EnvType.CLIENT)
public class DropItemEvent extends CancellableEvent {
   private final int a;
   private final boolean b;

   public DropItemEvent(int var1, boolean var2) {
      this.a = var1;
      this.b = var2;
   }

   @Generated
   public int d() {
      return this.a;
   }

   @Generated
   public boolean e() {
      return this.b;
   }
}
