package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.core.event.EventHandler;
import pulse.core.event.impl.RightClickEvent;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.fakeplayer.FakePlayerModule;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayerInteractionManager.class})
public class ClientPlayerInteractionManagerMixin {
   @Inject(
      method = {"syncSelectedSlot"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$guardSyncWhenNoPlayer(CallbackInfo var1) {
      if (MinecraftClient.getInstance().player == null) {
         var1.cancel();
      }
   }

   @Inject(
      method = {"interactItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onInteractItem(PlayerEntity var1, Hand var2, CallbackInfoReturnable<ActionResult> var3) {
      ClientWorld var4 = MinecraftClient.getInstance().world;
      RightClickEvent var5 = new RightClickEvent(var1, var4, var2);
      EventHandler.a.post(var5);
      if (var5.c()) {
         var3.setReturnValue(ActionResult.FAIL);
      }
   }

   @Redirect(
      method = {"attackEntity"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"
      )
   )
   private void pulse$suppressAttackPacket(ClientPlayNetworkHandler var1, Packet<?> var2, PlayerEntity var3, Entity var4) {
      if (!this.pulse$isFakeTarget(var4)) {
         var1.sendPacket(var2);
      }
   }

   @Redirect(
      method = {"interactEntity"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"
      )
   )
   private void pulse$suppressInteractPacket(ClientPlayNetworkHandler var1, Packet<?> var2, PlayerEntity var3, Entity var4, Hand var5) {
      if (!this.pulse$isFakeTarget(var4)) {
         var1.sendPacket(var2);
      }
   }

   @Redirect(
      method = {"interactEntityAtLocation"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"
      )
   )
   private void pulse$suppressInteractAtPacket(ClientPlayNetworkHandler var1, Packet<?> var2, PlayerEntity var3, Entity var4, EntityHitResult var5, Hand var6) {
      if (!this.pulse$isFakeTarget(var4)) {
         var1.sendPacket(var2);
      }
   }

   @Unique
   private boolean pulse$isFakeTarget(Entity var1) {
      FakePlayerModule var2 = ModuleRegistry.ao;
      return var2 != null && var2.a(var1);
   }
}
