package pulse.services.tracker.v2;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CloudFriendDataDto {
   private final int a;
   private final String b;
   private final String c;
   private final String d;
   private final String e;
   private final String f;
   private final String g;
   private final String h;

   public CloudFriendDataDto(int var1, String var2, String var3, String var4, String var5, String var6, String var7) {
      this(var1, var2, null, var3, var4, var5, var6, var7);
   }

   public CloudFriendDataDto(int var1, String var2, String var3, String var4, String var5, String var6, String var7, String var8) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
      this.h = var8;
   }

   @Generated
   public int a() {
      return this.a;
   }

   @Generated
   public String b() {
      return this.b;
   }

   @Generated
   public String c() {
      return this.c;
   }

   @Generated
   public String d() {
      return this.d;
   }

   @Generated
   public String e() {
      return this.e;
   }

   @Generated
   public String f() {
      return this.f;
   }

   @Generated
   public String g() {
      return this.g;
   }

   @Generated
   public String h() {
      return this.h;
   }
}
