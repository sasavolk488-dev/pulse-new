package pulse.features.modules.utilities;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.HWJoinerHandler;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.InputSetting;
import pulse.core.settings.ModeSetting;

@ModuleInfo(
   a = "HW Joiner",
   b = "Автоматически подключается к выбранной анархии HolyWorld",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class HWJoinerModule extends Module {
   private static final String a = "Лайт 1.16";
   private static final String b = "Лайт 1.20";
   private static final int c = 1;
   private static final int f = 74;
   private static final int g = 1;
   private static final int h = 3;
   private final ModeSetting i = new ModeSetting("Режим", new String[]{"Лайт 1.16", "Лайт 1.20"}, 0);
   private final InputSetting j = new InputSetting("Номер анархии 1.16", InputSetting.InputType.d, "1", "1-74").c(() -> this.i.b("Лайт 1.16"));
   private final InputSetting k = new InputSetting("Номер анархии 1.20", InputSetting.InputType.d, "1", "1-3").c(() -> this.i.b("Лайт 1.20"));
   private final BooleanSetting l = new BooleanSetting("Дебаг в файл", false);

   @Override
   public void e() {
      super.e();
      boolean var1 = this.i.b("Лайт 1.20");
      HWJoinerHandler.HWMode var2 = var1 ? HWJoinerHandler.HWMode.b : HWJoinerHandler.HWMode.a;
      int var3 = var1 ? this.a(this.k, 1, 3) : this.a(this.j, 1, 74);
      boolean var4 = HandlerRegistry.r.a(var2, var3, this.l.q(), var1x -> {
         if (this.k()) {
            this.d();
         }
      });
      if (!var4) {
         this.d();
      }
   }

   @Override
   public void f() {
      super.f();
      HandlerRegistry.r.e();
   }

   private int a(InputSetting var1, int var2, int var3) {
      try {
         long var4 = Long.parseLong(var1.q().trim());
         return (int)Math.max((long)var2, Math.min((long)var3, var4));
      } catch (Exception var6) {
         return var2;
      }
   }
}
