package pulse.features.modules.visuals;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import pulse.core.event.impl.RenderHeadLayerEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.world.BillboardLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "Body Glow",
   b = "Глоу на энтити",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class BodyGlowModule extends Module {
   private static final Identifier a = Identifier.of("pulse", "textures/glow.png");
   private final NumberSetting b = new NumberSetting("Размер", 2.3F, 1.5F, 3.0F, 0.1F);
   private final NumberSetting c = new NumberSetting("Прозрачность", 1.0F, 0.0F, 1.0F, 0.01F);
   private final SeparatorSetting f = new SeparatorSetting("Цвет");
   private final BooleanSetting g = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting h = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.g.a());
   private final List<BodyGlowModule.BillboardSpec> i = new ArrayList<>();
   private final Vector3f j = new Vector3f();
   private final MatrixStack k = new MatrixStack();

   @EventHandler
   public void a(RenderHeadLayerEvent var1) {
      MatrixStack var2 = var1.c();
      LivingEntityRenderState var3 = var1.b();
      if (!var3.invisible) {
         Color var4 = this.n();
         float var5 = var4.getRed() / 255.0F;
         float var6 = var4.getGreen() / 255.0F;
         float var7 = var4.getBlue() / 255.0F;
         float var8 = var4.getAlpha() / 255.0F * this.c.b();
         if (!(var8 <= 0.0F)) {
            EntityModel var9 = var1.d();
            float var10 = var3.baseScale;
            this.i.clear();
            var9.getRootPart().forEachCuboid(var2, (var2x, var3x, var4x, var5x) -> {
               float var6x = (var5x.minX + var5x.maxX) * 0.5F / 16.0F;
               float var7x = (var5x.minY + var5x.maxY) * 0.5F / 16.0F;
               float var8x = (var5x.minZ + var5x.maxZ) * 0.5F / 16.0F;
               var2x.getPositionMatrix().transformPosition(var6x, var7x, var8x, this.j);
               float var9x = (var5x.maxX - var5x.minX) / 16.0F;
               float var10x = (var5x.maxY - var5x.minY) / 16.0F;
               float var11x = (var5x.maxZ - var5x.minZ) / 16.0F;
               float var12x = (float)Math.sqrt(var9x * var9x + var10x * var10x + var11x * var11x) * var10;
               this.i.add(new BodyGlowModule.BillboardSpec(new Vector3f(this.j), var12x));
            });
            if (!this.i.isEmpty()) {
               Quaternionf var11 = d.gameRenderer.getCamera().getRotation();
               Immediate var12 = d.getBufferBuilders().getEntityVertexConsumers();
               RenderLayer var13 = BillboardLayers.a(a, true, false);
               VertexConsumer var14 = var12.getBuffer(var13);
               float var15 = this.b.b();

               for (BodyGlowModule.BillboardSpec var17 : this.i) {
                  float var18 = var17.size * var15 * 0.5F;
                  this.k.push();
                  this.k.translate(var17.center.x, var17.center.y, var17.center.z);
                  this.k.multiply(var11);
                  Entry var19 = this.k.peek();
                  var14.vertex(var19, -var18, -var18, 0.0F).texture(0.0F, 0.0F).color(var5, var6, var7, var8);
                  var14.vertex(var19, var18, -var18, 0.0F).texture(1.0F, 0.0F).color(var5, var6, var7, var8);
                  var14.vertex(var19, var18, var18, 0.0F).texture(1.0F, 1.0F).color(var5, var6, var7, var8);
                  var14.vertex(var19, -var18, var18, 0.0F).texture(0.0F, 1.0F).color(var5, var6, var7, var8);
                  this.k.pop();
               }

               var12.draw(var13);
            }
         }
      }
   }

   private Color n() {
      return this.g.a() ? ModuleRegistry.aw.n() : this.h.a();
   }

   @Environment(EnvType.CLIENT)
   private record BillboardSpec(Vector3f center, float size) {
   }
}
