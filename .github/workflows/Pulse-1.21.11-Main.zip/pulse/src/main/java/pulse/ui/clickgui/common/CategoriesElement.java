package pulse.ui.clickgui.common;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.ui.clickgui.ClickGuiScreen;
import pulse.ui.clickgui.GuiElement;
import pulse.ui.clickgui.MenuType;
import pulse.config.cloud.CloudConfigManager;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.ColorUtils;
import pulse.utils.render.LayerManager;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class CategoriesElement implements GuiElement {
   private final ClickGuiScreen a;
   private final List<CategoriesElement.CategoryButton> b;
   private static final float c = 12.0F;
   private static final float d = 22.0F;
   private static final float e = 6.0F;
   private static final float f = 6.0F;
   private static final long g = 150L;
   private CategoriesElement.Position h = CategoriesElement.Position.a;
   private boolean i = false;
   private boolean j = false;
   private long k = 0L;
   private float l = 0.0F;
   private float m = 0.0F;
   private float n = 0.0F;
   private float o = 0.0F;
   private CategoriesElement.Position p = CategoriesElement.Position.a;
   private float q = 0.0F;
   private float r = 0.0F;
   private final Animation s = new Animation();
   private final Animation t = new Animation();
   private final Animation u = new Animation();
   private final Animation v = new Animation();
   private final Animation w = new Animation();
   private float x = 0.0F;
   private float y = 0.0F;
   private float z = 0.0F;
   private float A = 0.0F;
   private boolean B = false;
   private int C = -1;
   private int D = -1;
   private CategoriesElement.Position E = null;

   public CategoriesElement(ClickGuiScreen var1) {
      this.a = var1;
      this.b = new ArrayList<>();
      MenuType var2 = var1.l();

      for (MenuType var6 : MenuType.values()) {
         CategoriesElement.CategoryButton var7 = new CategoriesElement.CategoryButton(var6);
         boolean var8 = var6 == var2;
         var7.a(var8);
         this.b.add(var7);
      }

      this.u.d(0.0);
   }

   public CategoriesElement.Position a() {
      return this.h;
   }

   public void a(CategoriesElement.Position var1) {
      if (this.h != var1) {
         this.h = var1;
         this.B = false;
         CloudConfigManager.a().h();
      }
   }

   public boolean b() {
      return this.i;
   }

   public boolean c() {
      return this.j;
   }

   public boolean d() {
      return this.i || this.j;
   }

   public void e() {
      if (this.i) {
         this.i = false;
         MouseUtil.c();
         this.v.a(0.0, 0.1500000754983676, Easings.h);
         OverlayElement.a().b(false);
         this.h = this.p;
         this.s.d(this.z);
         this.t.d(this.A);
         this.s.a(this.q, 0.3000000691657327, Easings.h);
         this.t.a(this.r, 0.3000000691657327, Easings.h);
         boolean var1 = this.p != CategoriesElement.Position.a;
         this.u.a(var1 ? 1.0 : 0.0, 0.3000000691657327, Easings.h);
         this.E = null;
      }

      this.j = false;
      this.k = 0L;
   }

   private float f() {
      return 12.0F + 28.0F * this.b.size() - 6.0F;
   }

   private float g() {
      return 34.0F;
   }

   private float h() {
      return 34.0F;
   }

   private float i() {
      return 12.0F + 28.0F * this.b.size() - 6.0F;
   }

   private float b(CategoriesElement.Position var1) {
      return var1 == CategoriesElement.Position.a ? this.f() : this.h();
   }

   private float c(CategoriesElement.Position var1) {
      return var1 == CategoriesElement.Position.a ? this.g() : this.i();
   }

   private float j() {
      float var1 = (float)this.u.j();
      return this.f() + (this.h() - this.f()) * var1;
   }

   private float k() {
      float var1 = (float)this.u.j();
      return this.g() + (this.i() - this.g()) * var1;
   }

   private float a(float var1, CategoriesElement.Position var2) {
      float var3 = ClickGuiScreen.e();
      float var4 = this.b(var2);
      switch (var2) {
         case a:
            return (int)(var1 + (var3 - var4) / 2.0F);
         case b:
            return (int)(var1 - var4 - 12.0F);
         case c:
            return (int)(var1 + var3 + 12.0F);
         default:
            return var1;
      }
   }

   private float b(float var1, CategoriesElement.Position var2) {
      float var3 = ClickGuiScreen.f();
      float var4 = this.c(var2);
      switch (var2) {
         case a:
            return (int)(var1 + var3 + 12.0F);
         case b:
         case c:
            return (int)(var1 + (var3 - var4) / 2.0F);
         default:
            return var1;
      }
   }

   public void b(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      if (this.i) {
         this.v.a();
         float var7 = (float)this.v.j();
         this.a(var1, var2, var3, var4, var5, var6, var7);
      }
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6) {
      int var7 = IMinecraft.u().getWidth();
      int var8 = IMinecraft.u().getHeight();
      if (!this.B) {
         this.z = this.a(var3, this.h);
         this.A = this.b(var4, this.h);
         this.s.d(this.z);
         this.t.d(this.A);
         this.u.d(this.h == CategoriesElement.Position.a ? 0.0 : 1.0);
         this.C = var7;
         this.D = var8;
         this.B = true;
      }

      if (!this.i && !this.j && (var7 != this.C || var8 != this.D)) {
         float var9 = this.a(var3, this.h);
         float var10 = this.b(var4, this.h);
         this.z = var9;
         this.A = var10;
         this.s.d(var9);
         this.t.d(var10);
         this.C = var7;
         this.D = var8;
      }

      if (this.j && !this.i) {
         long var29 = System.currentTimeMillis() - this.k;
         if (var29 >= 150L) {
            this.a(var3, var4, this.l, this.m);
         }
      }

      if (!this.i) {
         this.s.a();
         this.t.a();
         this.u.a();
         this.z = (float)this.s.j();
         this.A = (float)this.t.j();
      }

      this.v.a();
      this.w.a();
      float var30;
      float var31;
      if (this.i) {
         float var11 = this.j();
         float var12 = this.k();
         float var13 = IMinecraft.u().getWidth() / 4.0F;
         float var14 = IMinecraft.u().getHeight() / 4.0F;
         float var15 = var5 - this.n;
         float var16 = var6 - this.o;
         float var17 = Math.max(0.0F, Math.min(var15, var13 * 2.0F - var11));
         float var18 = Math.max(0.0F, Math.min(var16, var14 * 2.0F - var12));
         float var19 = (float)this.w.j();
         var30 = this.x + (var17 - this.x) * var19;
         var31 = this.y + (var18 - this.y) * var19;
      } else {
         var30 = this.z;
         var31 = this.A;
      }

      float var32 = this.j();
      float var33 = this.k();
      LayerManager.a().a(LayerManager.Layer.b, var30, var31, var32, var33);
      int var34 = this.i ? 200 : 255;
      var2.a(
         var30 - 0.5F,
         var31 - 0.5F,
         var32 + 1.0F,
         var33 + 1.0F,
         9.5F,
         ClickGuiColors.a(ClickGuiColors.q, var34),
         ClickGuiColors.a(ClickGuiColors.q, var34),
         ClickGuiColors.a(ClickGuiColors.r, var34),
         ClickGuiColors.a(ClickGuiColors.r, var34),
         var1
      );
      var2.a(
         var30,
         var31,
         var32,
         var33,
         9.5F,
         ClickGuiColors.a(ClickGuiColors.f, var34),
         ClickGuiColors.a(ClickGuiColors.f, var34),
         ClickGuiColors.a(ClickGuiColors.e, var34),
         ClickGuiColors.a(ClickGuiColors.e, var34),
         var1
      );
      MenuType var35 = this.a.l();
      boolean var36 = false;
      float var37 = (float)this.u.j();
      boolean var38 = OverlayElement.a().b();
      boolean var39 = this.i || this.j || !MouseUtil.a(LayerManager.Layer.b, var5, var6) || var38;

      for (int var40 = 0; var40 < this.b.size(); var40++) {
         CategoriesElement.CategoryButton var20 = this.b.get(var40);
         float var21 = var30 + 6.0F + var40 * 28.0F;
         float var22 = var31 + 6.0F;
         float var23 = var30 + 6.0F;
         float var24 = var31 + 6.0F + var40 * 28.0F;
         float var25 = var21 + (var23 - var21) * var37;
         float var26 = var22 + (var24 - var22) * var37;
         boolean var27 = var20.a() == var35;
         var20.b(var27);
         boolean var28 = !var39 && MouseUtil.a(var25, var26, 22.0F, 22.0F, (double)var5, (double)var6);
         if (var28 && !var27) {
            var36 = true;
         }

         var20.a(var1, var2, var25, var26, var28, var39);
      }

      if (var36 && !var39) {
         MouseUtil.g();
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, int var5, int var6, float var7) {
      this.E = null;

      for (CategoriesElement.Position var11 : CategoriesElement.Position.values()) {
         if (var11 != this.h) {
            float var12 = this.a(var3, var11) - 2.0F;
            float var13 = this.b(var4, var11) - 2.0F;
            float var14 = this.b(var11);
            float var15 = this.c(var11);
            boolean var16 = MouseUtil.a(var12 - 15.0F, var13 - 15.0F, var14 + 30.0F, var15 + 30.0F, (double)var5, (double)var6);
            if (var16) {
               this.E = var11;
            }

            int var17 = var16 ? 50 : 25;
            Color var18 = ClickGuiColors.a(ClickGuiColors.aa, (int)(var17 * var7));
            var2.a(var12, var13, var14, var15, 9.5F, var18, var1);
         }
      }
   }

   @Compile
   @Override
   public void a(float var1, float var2, int var3, int var4) {
      Animation orientation = this.u;
      List<CategoriesElement.CategoryButton> buttons = this.b;
      ClickGuiScreen screen = this.a;
      if (this.i || this.j || !MouseUtil.a(LayerManager.Layer.b, var3, var4)
            || OverlayElement.a().b()) {
         return;
      }
      float x = this.z;
      float y = this.A;
      if (!MouseUtil.a(x, y, this.j(), this.k(), var3, var4)) {
         return;
      }
      float fraction = (float)orientation.j();
      for (int index = 0; index < buttons.size(); index++) {
         Object button = buttons.get(index);
         float horizontalX = index * 28.0F + x + 6.0F;
         float horizontalY = y + 6.0F;
         float buttonX = fraction * ((x + 6.0F) - horizontalX) + horizontalX;
         float buttonY = fraction * ((index * 28.0F + horizontalY) - horizontalY) + horizontalY;
         if (MouseUtil.a(buttonX, buttonY, 22.0F, 22.0F, var3, var4)) {
            screen.a(((CategoriesElement.CategoryButton)button).a());
            return;
         }
      }
      this.j = true;
      try {
         this.k = System.currentTimeMillis();
      } catch (RuntimeException | Error failure) {
         this.k = 0L;
         throw failure;
      }
      this.l = var3;
      this.m = var4;
      this.n = var3 - x;
      this.o = var4 - y;
      this.p = this.h;
      this.q = this.z;
      this.r = this.A;
   }

   private void a(float var1, float var2, float var3, float var4) {
      this.j = false;
      this.i = true;
      MouseUtil.b();
      this.x = this.z;
      this.y = this.A;
      float var5 = this.j();
      float var6 = this.k();
      this.n = var5 / 2.0F;
      this.o = var6 / 2.0F;
      this.w.d(0.0);
      this.w.a(1.0, 0.20000000046760208, Easings.h);
      this.v.a(1.0, 0.20000000046760208, Easings.h);
      OverlayElement.a().b(true);
   }

   public void c(float var1, float var2, int var3, int var4) {
      if (this.j && !this.i) {
         this.j = false;
         this.k = 0L;
      } else {
         if (this.i) {
            this.i = false;
            MouseUtil.c();
            this.v.a(0.0, 0.1500000754983676, Easings.h);
            OverlayElement.a().b(false);
            CategoriesElement.Position var5 = this.h;
            if (this.E != null) {
               var5 = this.E;
            }

            float var6 = this.j();
            float var7 = this.k();
            float var8 = IMinecraft.u().getWidth() / 4.0F;
            float var9 = IMinecraft.u().getHeight() / 4.0F;
            float var10 = var3 - this.n;
            float var11 = var4 - this.o;
            float var12 = Math.max(0.0F, Math.min(var10, var8 * 2.0F - var6));
            float var13 = Math.max(0.0F, Math.min(var11, var9 * 2.0F - var7));
            float var14 = (float)this.w.j();
            float var15 = this.x + (var12 - this.x) * var14;
            float var16 = this.y + (var13 - this.y) * var14;
            boolean var17 = this.h != CategoriesElement.Position.a;
            boolean var18 = var5 != CategoriesElement.Position.a;
            if (this.h != var5) {
               this.h = var5;
               CloudConfigManager.a().h();
            }

            float var19 = this.a(var1, this.h);
            float var20 = this.b(var2, this.h);
            this.s.d(var15);
            this.t.d(var16);
            this.s.a(var19, 0.3000000691657327, Easings.h);
            this.t.a(var20, 0.3000000691657327, Easings.h);
            if (var17 != var18) {
               float var21 = var18 ? 1.0F : 0.0F;
               this.u.a(var21, 0.3000000691657327, Easings.h);
            }

            this.E = null;
         }
      }
   }

   public void a(float var1, float var2, int var3, int var4, double var5, double var7) {
      if (this.j && !this.i) {
         this.l = var3;
         this.m = var4;
      }
   }

   static {
      NativeMethodLookup.lookup(CategoriesElement.class, 2);
   }

   @Environment(EnvType.CLIENT)
   private static class CategoryButton {
      private final MenuType a;
      private boolean b;
      private final Animation c = new Animation();
      private final Animation d = new Animation();
      private boolean e = false;

      public CategoryButton(MenuType var1) {
         this.a = var1;
         this.b = false;
      }

      public MenuType a() {
         return this.a;
      }

      public void a(boolean var1) {
         this.b = var1;
         this.c.d(var1 ? 1.0 : 0.0);
      }

      public void b(boolean var1) {
         if (this.b != var1) {
            this.b = var1;
            this.c.a(var1 ? 1.0 : 0.0, 0.25, Easings.h);
         }
      }

      public void a(MatrixStack var1, Render var2, float var3, float var4, boolean var5) {
         this.a(var1, var2, var3, var4, var5, false);
      }

      public void a(MatrixStack var1, Render var2, float var3, float var4, boolean var5, boolean var6) {
         if (var6 && this.e) {
            this.d.a(0.0, 0.15000001210737537, Easings.h);
            this.e = false;
         } else if (!var6 && var5 != this.e) {
            this.d.a(var5 ? 1.0 : 0.0, 0.15000001210737537, Easings.h);
            this.e = var5;
         }

         this.c.a();
         this.d.a();
         float var7 = (float)this.c.j();
         float var8 = (float)this.d.j();
         if (var7 > 0.01F) {
            var2.a(var3, var4 + 1.5F, 10.7F, ClickGuiColors.a(ClickGuiColors.ad, (int)(255.0F * var7 * 0.7F)), var1);
         }

         Color var9 = ClickGuiColors.q;
         Color var10 = ClickGuiColors.r;
         Color var11 = ClickGuiColors.C;
         Color var12 = ClickGuiColors.D;
         Color var13 = ColorUtils.a(var9, var11, var7);
         Color var14 = ColorUtils.a(var10, var12, var7);
         var2.a(var3 - 0.5F, var4 - 0.5F, 23.0F, 23.0F, 6.0F, var13, var13, var14, var14, var1);
         Color var15 = ClickGuiColors.f;
         Color var16 = ClickGuiColors.e;
         Color var17 = ClickGuiColors.y;
         Color var18 = ClickGuiColors.z;
         int var19 = (int)(var8 * 8.0F);
         Color var20 = ClickGuiColors.b(var15, var19);
         Color var21 = ClickGuiColors.b(var16, var19);
         Color var22 = ColorUtils.a(var20, var17, var7);
         Color var23 = ColorUtils.a(var21, var18, var7);
         var2.a(var3, var4, 22.0F, 22.0F, 6.0F, var22, var22, var23, var23, var1);
         FontRenderer var24 = Fonts.d[24];
         String var25 = this.a.b();
         Color var26 = ClickGuiColors.b;
         Color var27 = ClickGuiColors.a;
         Color var28 = ClickGuiColors.d;
         Color var29 = ColorUtils.a(ColorUtils.a(var26, var28, var8 * (1.0F - var7)), var27, var7);
         float var30 = var24.a(var25);
         float var31 = var24.b(var25);
         float var32 = var3 + 11.0F - var30 / 2.0F;
         float var33 = var4 + 11.0F - var31 / 4.0F;
         var24.a(var25, var32, var33, var29, var1);
      }
   }

   @Environment(EnvType.CLIENT)
   public static enum Position {
      a,
      b,
      c;

      private static CategoriesElement.Position[] a() {
         return new CategoriesElement.Position[]{a, b, c};
      }
   }
}
