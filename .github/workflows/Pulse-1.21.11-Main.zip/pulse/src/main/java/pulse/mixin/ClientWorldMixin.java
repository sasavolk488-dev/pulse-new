package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.OptimizationModule;
import pulse.features.modules.visuals.RenderTweaksModule;

@Environment(EnvType.CLIENT)
@Mixin({ClientWorld.class})
public abstract class ClientWorldMixin {
   @Inject(
      method = {"getLightningTicksLeft"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetLightningTicks(CallbackInfoReturnable<Integer> var1) {
      RenderTweaksModule var2 = ModuleRegistry.h;
      if (var2 != null && var2.n()) {
         var1.setReturnValue(0);
      }
   }

   @ModifyVariable(
      method = {"runQueuedChunkUpdates"},
      at = @At("STORE"),
      ordinal = 1
   )
   private int pulse$clampChunkUpdatesPerFrame(int var1) {
      OptimizationModule var2 = ModuleRegistry.W;
      return var2 != null ? var2.c(var1) : var1;
   }
}
