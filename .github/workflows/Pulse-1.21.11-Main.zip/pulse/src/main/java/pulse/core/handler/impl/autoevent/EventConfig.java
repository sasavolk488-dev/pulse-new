package pulse.core.handler.impl.autoevent;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.ui.clickgui.menu.markers.MarkerEntry;

@Environment(EnvType.CLIENT)
public class EventConfig {
   public final Color a;
   public final MarkerEntry.IconType b;

   public EventConfig(Color var1) {
      this.a = var1;
      this.b = MarkerEntry.IconType.j;
   }

   public EventConfig(Color var1, MarkerEntry.IconType var2) {
      this.a = var1;
      this.b = var2;
   }
}
