package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.hud.ChatHudLine.Visible;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.animations.ChatAnimationHolder;
import pulse.features.modules.visuals.animations.ChatMessageAnimator;

@Environment(EnvType.CLIENT)
@Mixin(
   targets = {"net/minecraft/client/gui/hud/ChatHud$1"}
)
public class ChatHudLineConsumerMixin {
   @Inject(
      method = {"accept"},
      at = {@At("HEAD")}
   )
   private void onAcceptHead(Visible var1, int var2, float var3, CallbackInfo var4) {
      if (ModuleRegistry.t != null && ModuleRegistry.t.k() && ModuleRegistry.t.c.a()) {
         ChatMessageAnimator var5 = ChatAnimationHolder.a(var1);
         ChatAnimationHolder.a = var5 != null ? var5.b() : 0.0F;
      } else {
         ChatAnimationHolder.a = 0.0F;
      }
   }
}
