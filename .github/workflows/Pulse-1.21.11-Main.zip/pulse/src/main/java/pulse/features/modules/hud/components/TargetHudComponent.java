package pulse.features.modules.hud.components;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.util.Identifier;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.handler.HandlerRegistry;
import pulse.features.modules.hud.DraggableComponent;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.StreamerModeModule;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@Environment(EnvType.CLIENT)
public class TargetHudComponent extends DraggableComponent {
   private static final Color m = new Color(13, 13, 17);
   private static final Color n = new Color(17, 17, 23);
   private static final Color o = new Color(255, 255, 255);
   private static final Color p = new Color(223, 223, 243);
   private static final Color q = new Color(23, 23, 30);
   private static final Color r = new Color(18, 18, 24);
   private static final Color s = new Color(17, 17, 23);
   private static final Color t = new Color(13, 13, 17);
   private static final Color u = new Color(115, 83, 255);
   private static final Color v = new Color(70, 46, 174);
   private static final Color w = new Color(115, 83, 255, 100);
   private static final Color x = new Color(17, 17, 23, 153);
   private static final Color y = new Color(16, 16, 21, 153);
   private static final float z = 130.0F;
   private static final float A = 42.0F;
   private static final float B = 8.0F;
   private static final float C = 7.0F;
   private static final float D = 6.0F;
   private static final float E = 5.0F;
   private static final float F = 22.0F;
   private static final float G = 4.0F;
   private static final float H = 3.5F;
   private static final float I = 2.0F;
   private static final float J = 2.0F;
   private static final float K = 12.0F;
   private static final float L = 9.5F;
   private static final float M = 5.0F;
   private static final double N = 0.1999999851282041;
   private final Animation O = new Animation();
   private final Animation P = new Animation();
   private final Animation Q = new Animation();
   private final Animation R = new Animation();
   private LivingEntity S = null;
   private String T = "";
   private float U = 0.0F;
   private String V = "";
   private float W = Float.NaN;
   private float X = 20.0F;
   private Identifier Y = null;
   private Identifier Z = null;
   private long aa = 0L;
   private String ab = null;
   private boolean ac = false;
   private boolean ad = false;
   private static final long ae = 100L;
   private static final float af = 12.0F;
   private static final int ag = 16;

   private String v() {
      StreamerModeModule var1 = ModuleRegistry.T;
      return var1 != null && var1.k() && var1.a.q() ? "pulse" : this.T;
   }

   public TargetHudComponent(float var1, float var2) {
      super(var1, var2);
      this.O.d(0.0);
      this.P.d(1.0);
      this.Q.d(1.0);
      this.R.d(0.0);
      this.d = 130.0F;
      this.e = 42.0F;
   }

   private void w() {
      if (!this.ad) {
         if (ModuleRegistry.au != null) {
            this.f().a(ModuleRegistry.au);
            this.ad = true;
         }
      }
   }

   @Override
   protected void a() {
      this.w();
      float var1 = this.g();
      this.d = 130.0F * var1;
      this.e = 42.0F * var1;
   }

   private boolean x() {
      return this.a.currentScreen instanceof ChatScreen;
   }

   private void y() {
      LivingEntity var1 = HandlerRegistry.e.h();
      if (var1 == null && this.x() && this.a.player != null) {
         var1 = this.a.player;
      }

      boolean var2 = this.ac;
      if (var1 != null) {
         this.ac = true;
         if (var1 != this.S) {
            this.S = (LivingEntity)var1;
            this.Q.d(0.0);
            this.Q.a(1.0, 0.1999999851282041, Easings.h);
            if (var1 instanceof PlayerEntity var3) {
               this.T = var3.getGameProfile().name();
               this.Y = this.a(var3);
            } else {
               this.T = var1.getName().getString();
               this.Y = null;
            }

            String var4 = this.z();
            if (var4 != null && !var4.equals(this.ab)) {
               this.ab = var4;
               this.R.d(0.0);
               this.R.a(1.0, 0.1999999851282041, Easings.h);
            } else if (var4 == null && this.ab != null) {
               this.R.a(0.0, 0.1999999851282041, Easings.h);
            }
         }

         this.U = this.a((LivingEntity)var1);
         this.X = var1.getMaxHealth();
         if (var1 instanceof PlayerEntity) {
            this.Y = this.a((PlayerEntity)var1);
         }
      } else {
         this.ac = false;
         this.S = null;
      }

      if (this.ac && !var2) {
         this.O.a(1.0, 0.1999999851282041, Easings.h);
         String var5 = this.z();
         if (var5 != null) {
            this.ab = var5;
            this.R.d(0.0);
            this.R.a(1.0, 0.1999999851282041, Easings.h);
         }
      } else if (!this.ac && var2) {
         this.O.a(0.0, 0.1999999851282041, Easings.h);
         if (this.ab != null) {
            this.R.a(0.0, 0.1999999851282041, Easings.h);
         }
      } else if (this.ac && this.O.i() < 1.0) {
         this.O.a(1.0, 0.1999999851282041, Easings.h);
      }

      float var6 = this.X > 0.0F ? this.U / this.X : 0.0F;
      if (Math.abs(this.P.i() - var6) > 0.010000000005457433) {
         this.P.a(var6, 0.1500000307848041, Easings.h);
      }

      this.O.a();
      this.P.a();
      this.Q.a();
      this.R.a();
   }

   @Override
   public void a(MatrixStack var1, Render var2, float var3, float var4) {
      if (this.a.player != null) {
         this.y();
         this.a();
         float var5 = (float)this.O.j();
         if (!(var5 < 0.01F)) {
            float var6 = (float)this.Q.j();
            float var7 = this.g();
            float var8 = 8.0F * var7;
            float var9 = 7.0F * var7;
            float var10 = 6.0F * var7;
            float var11 = 5.0F * var7;
            float var12 = 22.0F * var7;
            float var13 = 4.0F * var7;
            float var14 = 3.5F * var7;
            float var15 = 2.0F * var7;
            float var16 = 2.0F * var7;
            float var17 = 12.0F * var7;
            float var18 = 9.5F * var7;
            float var19 = 5.0F * var7;
            float var20 = 12.0F * var7;
            float var21 = 32.0F;
            float var22 = 16.0F;
            float var23 = Math.min(var7, var21 / var22);
            int var24 = Math.round(var22 * var23);
            int var25 = Math.round(13.0F * var23);
            int var26 = Math.round(12.0F * var23);
            boolean var27 = var5 < 0.99F;
            if (var27) {
               var2.c(this.b, this.c, this.d, this.e, var1);
            }

            float var28 = var27 ? 1.0F : var5;
            float var29 = var27 ? var6 : var5 * var6;
            FontRenderer var30 = Fonts.b[Math.max(10, Math.min((int)var21, var24))];
            FontRenderer var31 = Fonts.a[Math.max(10, Math.min((int)var21, var25))];
            FontRenderer var32 = Fonts.a[Math.max(10, Math.min((int)var21, var26))];
            Color var33 = this.a(m, var28);
            Color var34 = this.a(n, var28);
            var2.a(this.b, this.c, this.d, this.e, var8, var33, var33, var34, var34, var1);
            float var35 = this.b + var9;
            float var36 = this.c + var10;
            this.a(var1, var2, var35, var36, var29, var7);
            float var38 = var36 + var12 / 2.0F;
            float var39 = var35 + var12 + var11;
            if (this.U != this.W) {
               this.W = this.U;
               this.V = String.format("HP / %.1f", this.U).replace('.', ',');
            }

            String var40 = this.V;
            String var41 = this.v();
            float var42 = var30.b(var41) / 2.0F;
            float var43 = var31.b(var40) / 2.0F;
            float var44 = 2.0F * var7;
            float var45 = var42 + var44 + var43;
            float var46 = var38 - var45 / 2.0F;
            float var47 = this.b + this.d - var9;
            String var48 = this.A();
            float var49 = var47;
            boolean var50 = var48 != null && !var48.isEmpty();
            if (var50) {
               float var51 = var32.a(var48);
               float var52 = var51 + var19 * 2.0F;
               var49 = this.b + this.d - var9 - var52;
            }

            float var73;
            if (var50) {
               var73 = var49 - var39 - 5.0F * var7;
            } else {
               var73 = var47 - var39;
            }

            Color var74 = this.a(o, var29);
            float var53 = var30.a(var41);
            float var54 = var30.b(var41);
            if (var53 > var73) {
               var2.b(var39, var46 - 1.0F * var7, var73, var54 + 2.0F * var7, var1);
               var30.a(var41, var39, var46, var74, var1);
               var2.a(var1);
               float var55 = var39 + var73 - var20;
               float var56 = var46 - 1.0F * var7;
               float var57 = var54 + 2.0F * var7;
               float var58 = (var46 - this.c) / this.e;
               Color var59 = this.a(m, n, var58);
               Color var60 = this.a(new Color(var59.getRed(), var59.getGreen(), var59.getBlue(), 0), var28);
               Color var61 = this.a(var59, var28);
               var2.a(var55, var56, var20, 10.0F * var7, 0.0F, var60, var61, var60, var61, var1);
            } else {
               var30.a(var41, var39, var46, var74, var1);
            }

            Color var75 = this.a(p, var29);
            float var76 = var46 + var42 + var44;
            var31.a(var40, var39, var76, var75, var1);
            float var77 = this.b + this.d - var9;
            if (var50) {
               float var79 = (float)this.R.j();
               float var81 = var27 ? var79 : var5 * var79;
               if (var81 > 0.01F) {
                  float var82 = var32.a(var48);
                  float var84 = var82 + var19 * 2.0F;
                  float var62 = var46 - 1.0F * var7;
                  Color var63 = this.a(x, var81);
                  Color var64 = this.a(y, var81);
                  var2.a(var49, var62, var84, var17, var18, var63, var63, var64, var64, var1);
                  float var65 = var49 + var19;
                  float var66 = var62 + (var17 - var32.b(var48) / 2.0F) / 2.0F;
                  Color var67 = this.a(p, var81);
                  var32.a(var48, var65, var66, var67, var1);
                  var77 = var49 + var84;
               }
            }

            float var80 = this.c + this.e - var10 - var14;
            float var83 = var47 - var35;
            Color var85 = new Color(14, 14, 18);
            Color var86 = new Color(16, 16, 22);
            Color var87 = this.a(var85, var28);
            Color var88 = this.a(var86, var28);
            Color var89 = this.a(new Color(19, 19, 25), var28);
            Color var90 = this.a(new Color(19, 19, 26), var28);
            var2.a(var35 + 1.0F * var7, var80 + 1.0F * var7, var83 - 0.5F * var7, var14 - 0.5F * var7, var15, var89, var89, var90, var90, var1);
            var2.a(var35, var80, var83, var14, var15, var87, var87, var88, var88, var1);
            float var91 = (float)this.P.j();
            float var68 = var83 * Math.max(0.0F, Math.min(1.0F, var91));
            if (var68 > 1.0F * var7) {
               Color var69 = new Color(76, 46, 212, 52);
               Color var70 = this.a(var69, var29);
               var2.a(var35, var80, var68, var14, 5.0F * var7, var16, var70, var1);
               Color var71 = this.a(u, var29);
               Color var72 = this.a(v, var29);
               var2.a(var35, var80, var68, var14, var16, var71, var71, var72, var72, var1);
            }

            if (var27) {
               var2.a(var5, var1);
            }
         }
      }
   }

   private void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6) {
      float var7 = 22.0F * var6;
      float var8 = 4.0F * var6;
      Color var9 = this.a(q, var5);
      Color var10 = this.a(r, var5);
      var2.a(var3 - 0.5F * var6, var4 - 0.5F * var6, var7 + 1.0F * var6, var7 + 1.0F * var6, var8, var9, var9, var10, var10, var1);
      Identifier var11 = this.Y;
      if (var11 == null) {
         var11 = DefaultSkinHelper.getTexture();
      }

      if (this.Z == null || !this.Z.equals(var11)) {
         this.Z = var11;
         this.aa = System.currentTimeMillis();
      }

      boolean var12 = System.currentTimeMillis() - this.aa > 100L;
      if (var11 != null && var12) {
         Color var17 = this.a(Color.WHITE, var5);
         var2.b(var11, var3, var4, var7, var7, var8, 0.125F, 0.125F, 0.125F, 0.125F, var17, var1);
         var2.b(var11, var3, var4, var7, var7, var8, 0.625F, 0.125F, 0.125F, 0.125F, var17, var1);
         if (this.S != null && this.S.hurtTime > 0) {
            float var14 = this.S.hurtTime / 10.0F * 0.5F * var5;
            Color var15 = new Color(255, 0, 0, (int)(var14 * 155.0F));
            var2.a(var3, var4, var7, var7, var8, var15, var1);
         }
      } else if (var11 != null) {
         Color var13 = this.a(new Color(30, 30, 40), var5);
         var2.a(var3, var4, var7, var7, var8, var13, var1);
      } else {
         Color var16 = this.a(n, var5);
         var2.a(var3, var4, var7, var7, var8, var16, var1);
      }
   }

   private Identifier a(PlayerEntity var1) {
      if (var1 instanceof AbstractClientPlayerEntity var2) {
         Identifier var3 = var2.getSkin().body().texturePath();
         if (var3 != null) {
            return var3;
         }
      }

      return DefaultSkinHelper.getTexture();
   }

   private String z() {
      if (!(this.S instanceof PlayerEntity var1)) {
         return null;
      } else {
         String var2 = var1.getGameProfile().name();
         String var3 = this.b(var1);
         if (var3 != null && !var3.isEmpty()) {
            var3 = this.b(var3);
            int var4 = var3.indexOf(var2);
            if (var4 <= 0) {
               return null;
            } else {
               String var5 = var3.substring(0, var4).trim();
               if (var5.isEmpty()) {
                  return null;
               } else {
                  String[] var6 = var5.split("\\s+");
                  if (var6.length == 0) {
                     return null;
                  } else {
                     String var7 = var6[var6.length - 1];
                     return !this.a(var7) ? null : var7;
                  }
               }
            }
         } else {
            return null;
         }
      }
   }

   private String b(PlayerEntity var1) {
      if (this.a.getNetworkHandler() == null) {
         return null;
      } else {
         for (PlayerListEntry var3 : this.a.getNetworkHandler().getPlayerList()) {
            if (var3.getProfile() != null && var3.getProfile().name() != null && var3.getProfile().name().equalsIgnoreCase(var1.getGameProfile().name())) {
               if (var3.getDisplayName() != null) {
                  return var3.getDisplayName().getString();
               }

               return var3.getProfile().name();
            }
         }

         return null;
      }
   }

   private boolean a(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         if (var1.length() < 2) {
            return false;
         } else {
            for (char var5 : var1.toCharArray()) {
               boolean var6 = var5 >= 'A' && var5 <= 'Z' || var5 >= 'a' && var5 <= 'z';
               boolean var7 = var5 >= 1040 && var5 <= 1071 || var5 >= 1072 && var5 <= 1103 || var5 == 1025 || var5 == 1105;
               if (!var6 && !var7) {
                  return false;
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private String A() {
      if (this.R.j() < 0.010000000005457433) {
         if (this.R.i() == 0.0) {
            this.ab = null;
         }

         return null;
      } else {
         return this.ab;
      }
   }

   private Color a(Color var1, float var2) {
      int var3 = Math.max(0, Math.min(255, (int)(var1.getAlpha() * var2)));
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var3);
   }

   private Color a(Color var1, Color var2, float var3) {
      var3 = Math.max(0.0F, Math.min(1.0F, var3));
      int var4 = (int)(var1.getRed() + (var2.getRed() - var1.getRed()) * var3);
      int var5 = (int)(var1.getGreen() + (var2.getGreen() - var1.getGreen()) * var3);
      int var6 = (int)(var1.getBlue() + (var2.getBlue() - var1.getBlue()) * var3);
      int var7 = (int)(var1.getAlpha() + (var2.getAlpha() - var1.getAlpha()) * var3);
      return new Color(var4, var5, var6, var7);
   }

   private String b(String var1) {
      return var1 == null ? null : var1.replaceAll("§.", "");
   }

   private float a(LivingEntity var1) {
      if (this.a.world == null) {
         return var1.getHealth();
      } else {
         try {
            Scoreboard var2 = this.a.world.getScoreboard();
            ScoreboardObjective var3 = var2.getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
            if (var3 == null) {
               return var1.getHealth();
            } else {
               String var4 = var1 == this.S ? this.T : var1.getName().getString();
               if (var4.length() > 16) {
                  return var1.getHealth();
               } else {
                  ReadableScoreboardScore var5 = var2.getScore(var1, var3);
                  if (var5 == null) {
                     return var1.getHealth();
                  } else {
                     int var6 = var5.getScore();
                     return var6 == 0 ? var1.getHealth() : var6;
                  }
               }
            }
         } catch (Exception var7) {
            return var1.getHealth();
         }
      }
   }
}
