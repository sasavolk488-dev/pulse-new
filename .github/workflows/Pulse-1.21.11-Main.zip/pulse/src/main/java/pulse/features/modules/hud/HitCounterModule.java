package pulse.features.modules.hud;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import pulse.Pulse;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.KeyEvent;
import pulse.core.event.impl.MouseEvent;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.core.event.impl.UpdateEvent;
import pulse.core.event.impl.WorldChangeEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.ModeSetting;
import pulse.core.settings.NumberSetting;

@ModuleInfo(
   a = "Hit Counter",
   b = "Считает удары подряд по одной цели и показывает серию с полосой окна",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class HitCounterModule extends Module {
   private final BooleanSetting a = new BooleanSetting("Только игроки", true);
   private final NumberSetting b = new NumberSetting("Окно серии, сек", 4.0F, 1.0F, 15.0F, 0.5F);
   private final BooleanSetting c = new BooleanSetting("Обрывать при промахе", true);
   private final ModeSetting f = new ModeSetting("Позиция", new String[]{"Под прицелом", "Над хотбаром"}, "Под прицелом");
   private final BooleanSetting g = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting h = new ColorSetting("Свой цвет", new Color(120, 200, 255)).a(() -> !this.g.a());
   private static final int i = 2;
   private static final long j = 600L;
   private static final float k = 1.5F;
   private static final float l = 3.5F;
   private static final float m = 2.0F;
   private static final float n = 22.0F;
   private static final float o = 1.5F;
   private static final float p = 34.0F;
   private static final Color q = new Color(150, 150, 170);
   private static final Color r = new Color(0, 0, 0);
   private static final Color s = new Color(0, 0, 0);
   private static final Color t = new Color(255, 70, 70);
   private int u;
   private int v = -1;
   private long w;
   private boolean x;
   private int y;
   private int z = -1;
   private long A;
   private int B;
   private final Animation C = new Animation();
   private final Animation D = new Animation();
   private float E = -1.0F;

   @Override
   public void e() {
      super.e();
      this.o();
   }

   @Override
   public void f() {
      super.f();
      this.o();
   }

   @EventHandler
   private void a(AttackEvent var1) {
      Entity var2 = var1.a();
      if (d.player != null && this.b(var2)) {
         this.z = var2.getId();
         this.A = System.currentTimeMillis();
         this.B = var2 instanceof LivingEntity ? ((LivingEntity)var2).hurtTime : 0;
      }
   }

   @EventHandler
   private void a(UpdateEvent var1) {
      if (d.player != null && d.world != null) {
         long var2 = System.currentTimeMillis();
         if (!d.player.isAlive()) {
            this.d(true);
         } else {
            if (this.z != -1) {
               Entity var4 = d.world.getEntityById(this.z);
               if (var4 instanceof LivingEntity && var2 - this.A <= 600L) {
                  int var5 = ((LivingEntity)var4).hurtTime;
                  if (var5 > this.B) {
                     this.z = -1;
                     this.a(var4);
                  } else {
                     this.B = var5;
                  }
               } else {
                  this.z = -1;
               }
            }

            if (this.u > 0) {
               Entity var6 = d.world.getEntityById(this.v);
               if (var6 == null || !var6.isAlive() || var2 - this.w >= (long)(this.b.b() * 1000.0F)) {
                  this.d(false);
               }
            }
         }
      }
   }

   @EventHandler
   private void a(MouseEvent var1) {
      if (var1.e() == 1 && d.options != null) {
         if (d.options.attackKey.matchesMouse(new Click(var1.g(), var1.h(), new MouseInput(var1.d(), var1.f())))) {
            this.n();
         }
      }
   }

   @EventHandler
   private void a(KeyEvent var1) {
      if (var1.c() == 1 && d.options != null) {
         if (d.options.attackKey.matchesKey(new KeyInput(var1.a(), var1.b(), var1.d()))) {
            this.n();
         }
      }
   }

   @EventHandler
   private void a(WorldChangeEvent var1) {
      this.o();
   }

   private void n() {
      if (this.u > 0 && this.c.a()) {
         if (d.player != null && d.currentScreen == null) {
            HitResult var1 = d.crosshairTarget;
            if (var1 != null && var1.getType() != Type.MISS) {
               boolean var2 = var1.getType() == Type.ENTITY;
               if (!var2 || this.b(((EntityHitResult)var1).getEntity())) {
                  return;
               }
            }

            this.d(true);
         }
      }
   }

   private void a(Entity var1) {
      int var2 = var1.getId();
      if (this.v != var2) {
         this.u = 0;
      }

      this.v = var2;
      this.u++;
      this.x = false;
      this.w = System.currentTimeMillis();
      this.D.d(1.0);
      this.D.a(0.0, 0.4000000121555799, Easings.n);
   }

   private void d(boolean var1) {
      if (this.u > 0) {
         this.x = var1;
      }

      this.u = 0;
      this.v = -1;
      this.z = -1;
   }

   private void o() {
      this.u = 0;
      this.v = -1;
      this.w = 0L;
      this.z = -1;
      this.x = false;
      this.y = 0;
      this.C.d(0.0);
      this.D.d(0.0);
   }

   private boolean b(Entity var1) {
      if (var1 != null && var1 != d.player) {
         return this.a.a() ? var1 instanceof PlayerEntity : var1 instanceof LivingEntity;
      } else {
         return false;
      }
   }

   @EventHandler
   private void a(RenderHudPostEvent var1) {
      if (d.player != null && d.world != null && !d.options.hudHidden) {
         Render var2 = Pulse.l().p();
         if (var2 != null) {
            boolean var3 = this.u >= 2;
            double var4 = var3 ? 1.0 : 0.0;
            if (this.C.i() != var4) {
               this.C.a(var4, var3 ? 0.14000003119930826 : 0.2800001816665152, Easings.h);
            }

            this.C.a();
            this.D.a();
            float var6 = (float)this.C.j();
            if (!(var6 < 0.01F)) {
               if (var3) {
                  this.y = this.u;
               }

               if (this.y >= 2) {
                  Color var7 = !var3 && this.x ? t : this.p();
                  float var8 = var3 ? MathHelper.clamp(1.0F - (float)(System.currentTimeMillis() - this.w) / (this.b.b() * 1000.0F), 0.0F, 1.0F) : 0.0F;
                  this.a(var2, var1.a(), var7, var6, var8);
               }
            }
         }
      }
   }

   private void a(Render var1, MatrixStack var2, Color var3, float var4, float var5) {
      FontRenderer var6 = Fonts.b[26];
      if (this.E < 0.0F) {
         this.E = a(var6);
      }

      String var7 = String.valueOf(this.y);
      float var8 = var6.a("×");
      float var9 = var6.a(var7);
      float var10 = this.E * var7.length();
      float var11 = var6.b(var7) / 2.0F;
      float var12 = var8 + 1.5F + var10;
      float var13 = Math.max(var12, 22.0F);
      float var14 = var11 + 3.5F + 2.0F;
      float var15 = d.getWindow().getFramebufferWidth() / 2.0F;
      float var16 = d.getWindow().getFramebufferHeight() / 2.0F;
      float var17 = (var15 - var13) / 2.0F;
      float var18;
      if (this.f.b("Над хотбаром")) {
         float var19 = d.getWindow().getScaleFactor() / 2.0F;
         var18 = var16 - 55.0F * var19 - var14;
      } else {
         var18 = var16 / 2.0F + 34.0F;
      }

      float var26 = var17 + (var13 - var12) / 2.0F;
      a(var6, "×", var26, var18, q, var4, var2);
      float var20 = var26 + var8 + 1.5F + (var10 - var9) / 2.0F;
      float var21 = 1.0F + 0.18F * (float)this.D.j();
      float var22 = var20 + var9 / 2.0F;
      float var23 = var18 + var11 / 2.0F;
      var2.push();
      var2.translate(var22, var23, 0.0F);
      var2.scale(var21, var21, 1.0F);
      var2.translate(-var22, -var23, 0.0F);
      a(var6, var7, var20, var18, var3, var4, var2);
      var2.pop();
      float var24 = var18 + var11 + 3.5F;
      var1.a(var17, var24, var13, 2.0F, 1.0F, a(s, var4 * 0.35F), var2);
      float var25 = var13 * var5;
      if (var25 > 2.0F) {
         var1.a(var17, var24, var25, 2.0F, 1.0F, a(var3, var4), var2);
      }
   }

   private static void a(FontRenderer var0, String var1, float var2, float var3, Color var4, float var5, MatrixStack var6) {
      var0.a(var1, var2 + 1.5F, var3 + 1.5F, a(r, var5 * 0.55F), var6);
      var0.a(var1, var2, var3, a(var4, var5), var6);
   }

   private static float a(FontRenderer var0) {
      float var1 = 0.0F;

      for (char var2 = '0'; var2 <= '9'; var2++) {
         var1 = Math.max(var1, var0.a(var2));
      }

      return var1;
   }

   private Color p() {
      return this.g.a() ? ModuleRegistry.aw.n() : this.h.a();
   }

   private static Color a(Color var0, float var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), MathHelper.clamp((int)(var0.getAlpha() * var1), 0, 255));
   }
}
