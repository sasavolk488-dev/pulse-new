package pulse.ui.clickgui.common;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import pulse.utils.animation.Animation;
import pulse.utils.animation.util.Easings;
import pulse.ui.clickgui.ClickGuiColors;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.input.MouseUtil;

@Environment(EnvType.CLIENT)
public class InputFieldElement {
   private static final Set<InputFieldElement> a = Collections.newSetFromMap(new WeakHashMap<>());
   private static final float b = 4.0F;
   private final InputFieldElement.InputType c;
   private String d = "";
   private String e = "";
   private int f = 32;
   private float g;
   private float h;
   private float i;
   private float j;
   private float k = 4.0F;
   private float l = -1.0F;
   private float m = -1.0F;
   private float n = -1.0F;
   private float o = -1.0F;
   private boolean p = false;
   private float q = 8.0F;
   private boolean r = false;
   private boolean s = false;
   private int t = 0;
   private int u = -1;
   private int v = -1;
   private final Animation w = new Animation();
   private final Animation x = new Animation();
   private final Animation y = new Animation();
   private boolean z = false;
   private boolean A = true;
   private Consumer<String> B;
   private boolean C = false;
   private Color D = null;
   private Color E = null;
   private boolean F = false;
   private String G = "";

   public InputFieldElement(InputFieldElement.InputType var1) {
      this.c = var1;
      this.y.d(1.0);
      a.add(this);
   }

   public InputFieldElement(InputFieldElement.InputType var1, String var2) {
      this(var1);
      this.e = var2;
   }

   public InputFieldElement(InputFieldElement.InputType var1, String var2, String var3) {
      this(var1, var3);
      this.b(var2);
   }

   public void a(float var1, float var2) {
      this.g = var1;
      this.h = var2;
   }

   public void b(float var1, float var2) {
      this.i = var1;
      this.j = var2;
   }

   public void a(float var1) {
      this.k = var1;
      this.p = false;
   }

   public void a(float var1, float var2, float var3, float var4) {
      this.l = var1;
      this.m = var2;
      this.n = var3;
      this.o = var4;
      this.p = true;
   }

   public void b(float var1) {
      this.q = var1;
   }

   public void a(Color var1, Color var2) {
      this.D = var1;
      this.E = var2;
   }

   public void a(boolean var1) {
      this.F = var1;
   }

   public void a(int var1) {
      this.f = var1;
   }

   public void a(String var1) {
      this.e = var1;
   }

   public void b(boolean var1) {
      this.C = var1;
   }

   public void a(Consumer<String> var1) {
      this.B = var1;
   }

   public String a() {
      return this.c == InputFieldElement.InputType.e ? this.c(this.d) : this.d;
   }

   public String b() {
      return this.d;
   }

   private String c(String var1) {
      if (var1.isEmpty()) {
         return "";
      } else {
         StringBuilder var2 = new StringBuilder();

         for (int var3 = 0; var3 < var1.length(); var3++) {
            if (var3 > 0 && var3 % 4 == 0) {
               var2.append('-');
            }

            var2.append(var1.charAt(var3));
         }

         return var2.toString();
      }
   }

   private int c(int var1) {
      int var2 = 0;
      if (var1 > 3) {
         var2++;
      }

      if (var1 > 7) {
         var2++;
      }

      return var1 + var2;
   }

   public void b(String var1) {
      if (var1 == null) {
         var1 = "";
      }

      if (this.c == InputFieldElement.InputType.e) {
         var1 = var1.replace("-", "").toUpperCase();
      }

      StringBuilder var2 = new StringBuilder();

      for (char var6 : var1.toCharArray()) {
         if (this.b(var6, var2.length())) {
            var2.append(this.c == InputFieldElement.InputType.e ? Character.toUpperCase(var6) : var6);
         }
      }

      this.d = var2.toString();
      this.t = Math.min(this.t, this.d.length());
      this.w();
      this.k();
   }

   public int c() {
      if (!this.d.isEmpty() && !this.d.equals("-")) {
         try {
            return Integer.parseInt(this.d);
         } catch (NumberFormatException var2) {
            return 0;
         }
      } else {
         return 0;
      }
   }

   public void b(int var1) {
      this.b(String.valueOf(var1));
   }

   public boolean d() {
      return this.r;
   }

   public void c(boolean var1) {
      if (this.r != var1) {
         this.r = var1;
         this.w.a(var1 ? 1.0 : 0.0, 0.20000000856584893, Easings.h);
         if (var1) {
            this.y.d(1.0);
            this.A = false;
            this.y.a(0.3000000261138894, 0.5, Easings.i);
         }
      }
   }

   public void d(boolean var1) {
      this.s = var1;
      if (var1) {
         this.r = false;
         this.x.d(0.0);
      }
   }

   public boolean e() {
      return this.s;
   }

   private boolean b(char var1, int var2) {
      switch (this.c) {
         case a:
         default:
            return !Character.isISOControl(var1);
         case b:
         case c:
            return var1 >= '0' && var1 <= '9' || var1 == '-' && var2 == 0 && !this.d.contains("-");
         case d:
            return var1 >= 'a' && var1 <= 'z' || var1 >= 'A' && var1 <= 'Z' || var1 >= '0' && var1 <= '9' || var1 == '_';
         case e:
            return var1 >= 'a' && var1 <= 'z' || var1 >= 'A' && var1 <= 'Z' || var1 >= '0' && var1 <= '9';
         case f:
            return var1 != ' '
                  && var1 != '\\'
                  && var1 != '/'
                  && var1 != ':'
                  && var1 != '*'
                  && var1 != '?'
                  && var1 != '"'
                  && var1 != '<'
                  && var1 != '>'
                  && var1 != '|'
               ? !Character.isISOControl(var1)
               : false;
      }
   }

   private static void a(InputFieldElement var0) {
      for (InputFieldElement var2 : a) {
         if (var2 != var0 && var2.r) {
            var2.r = false;
            var2.w.a(0.0, 0.20000000856584893, Easings.h);
            var2.G = "";
         }
      }
   }

   private void k() {
      this.G = "";
      if (this.c == InputFieldElement.InputType.d && !this.d.isEmpty()) {
         List<String> var1 = this.l();
         String var2 = this.d.toLowerCase(Locale.ROOT);

         for (String var4 : var1) {
            if (var4.toLowerCase(Locale.ROOT).startsWith(var2) && !var4.equalsIgnoreCase(this.d)) {
               this.G = var4.substring(this.d.length());
               break;
            }
         }
      }
   }

   private List<String> l() {
      ArrayList<String> var1 = new ArrayList<>();
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.getNetworkHandler() != null) {
         for (PlayerListEntry var5 : var2.getNetworkHandler().getPlayerList()) {
            if (var5.getProfile() != null && var5.getProfile().name() != null) {
               var1.add(var5.getProfile().name());
            }
         }
      }

      return var1;
   }

   private void m() {
      if (!this.G.isEmpty()) {
         this.d = this.d + this.G;
         this.t = this.d.length();
         this.G = "";
         this.w();
         this.z();
      }
   }

   public static boolean f() {
      for (InputFieldElement var1 : a) {
         if (var1.r) {
            return true;
         }
      }

      return false;
   }

   public void a(MatrixStack var1, Render var2, float var3, float var4, float var5, float var6, int var7, int var8, float var9) {
      this.g = var3;
      this.h = var4;
      this.i = var5;
      this.j = var6;
      this.w.a();
      this.x.a();
      if (this.r) {
         this.y.a();
         if (this.y.d()) {
            this.A = !this.A;
            this.y.a(this.A ? 1.0 : 0.3000000261138894, 0.5, Easings.i);
         }
      } else {
         this.y.d(1.0);
         this.A = true;
      }

      int var10 = (int)(255.0F * var9);
      boolean var11 = !this.F && OverlayElement.a().b();
      boolean var12 = !this.s && !var11 && MouseUtil.a(var3, var4, var5, var6, (double)var7, (double)var8);
      if (var11 && this.z) {
         this.x.a(0.0, 0.15000007200432816, Easings.h);
         this.z = false;
      } else if (!var11 && var12 != this.z) {
         this.x.a(var12 ? 1.0 : 0.0, 0.15000007200432816, Easings.h);
         this.z = var12;
      }

      float var13 = (float)this.x.j();
      int var14 = (int)(var13 * 3.0F);
      Color var15 = this.D != null ? this.D : ClickGuiColors.e;
      Color var16 = this.E != null ? this.E : ClickGuiColors.f;
      Color var17 = ClickGuiColors.a(ClickGuiColors.b(var15, var14), var10);
      Color var18 = ClickGuiColors.a(ClickGuiColors.b(var16, var14), var10);
      if (this.p) {
         var2.a(var3, var4, var5, var6, this.l, this.m, this.o, this.n, var17, var17, var18, var18, var1);
      } else {
         var2.a(var3, var4, var5, var6, this.k, var17, var17, var18, var18, var1);
      }

      FontRenderer var19 = Fonts.a[14];
      float var20 = var3 + this.q;
      float var21 = var5 - this.q * 2.0F;
      var2.a().a(var20 - 1.0F, var4, var21 + 2.0F, var6, var1);
      float var22 = var4 + var6 / 2.0F - var19.b("A") / 4.0F;
      String var23 = this.c == InputFieldElement.InputType.e ? this.c(this.d) : this.d;
      int var24 = this.c == InputFieldElement.InputType.e ? this.c(this.t) : this.t;
      if (this.d.isEmpty() && !this.r) {
         if (!this.e.isEmpty()) {
            Color var34 = ClickGuiColors.a(ClickGuiColors.b, var10);
            float var37 = var20;
            if (this.C) {
               var37 = var3 + (var5 - var19.a(this.e)) / 2.0F;
            }

            var19.a(this.e, var37, var22, var34, var1);
         }
      } else {
         if (this.v()) {
            int var25 = Math.min(this.u, this.v);
            int var26 = Math.max(this.u, this.v);
            int var27 = this.c == InputFieldElement.InputType.e ? this.c(var25) : var25;
            int var28 = this.c == InputFieldElement.InputType.e ? this.c(var26) : var26;
            float var29 = var20 + var19.a(var23, var27);
            float var30 = var20 + var19.a(var23, var28);
            if (this.C && !var23.isEmpty()) {
               float var31 = var19.a(var23);
               float var32 = (var5 - this.q * 2.0F - var31) / 2.0F;
               var29 += var32;
               var30 += var32;
            }

            float var46 = var30 - var29;
            Color var47 = ClickGuiColors.b(ClickGuiColors.A, var9);
            var2.a(var29, var4 + 2.0F, var46, var6 - 4.0F, 2.0F, var47, var1);
         }

         Color var33 = ClickGuiColors.a(ClickGuiColors.a, var10);
         float var36 = var20;
         if (this.C && !var23.isEmpty()) {
            var36 = var3 + (var5 - var19.a(var23)) / 2.0F;
         }

         var19.a(var23, var36, var22, var33, var1);
         if (this.c == InputFieldElement.InputType.d && !this.G.isEmpty() && this.r) {
            float var39 = var36 + var19.a(var23);
            Color var42 = ClickGuiColors.a(ClickGuiColors.d, var10);
            var19.a(this.G, var39, var22, var42, var1);
         }

         if (this.r && !this.v() && !var23.isEmpty()) {
            float var40 = (float)this.y.j();
            if (var40 > 0.3F) {
               float var43 = var20 + var19.a(var23, var24);
               if (this.C) {
                  float var44 = var19.a(var23);
                  var43 += (var5 - this.q * 2.0F - var44) / 2.0F;
               }

               Color var45 = ClickGuiColors.a(ClickGuiColors.a, var9 * var40);
               var2.a(var43, var4 + 3.0F, 1.0F, var6 - 6.0F, var45, var1);
            }
         }
      }

      if (this.d.isEmpty() && this.r) {
         float var35 = (float)this.y.j();
         float var38 = var20;
         if (this.C) {
            var38 = var3 + var5 / 2.0F;
         }

         Color var41 = ClickGuiColors.a(ClickGuiColors.a, var9 * var35);
         var2.a(var38, var4 + 3.0F, 1.0F, var6 - 6.0F, var41, var1);
      }

      var2.a().a(var1);
      if ((var12 || this.r) && !var11) {
         MouseUtil.g();
      }
   }

   public boolean a(int var1, int var2) {
      if (this.s) {
         return false;
      } else if (MouseUtil.a(this.g, this.h, this.i, this.j, (double)var1, (double)var2)) {
         a(this);
         if (!this.r) {
            this.r = true;
            this.w.a(1.0, 0.20000000856584893, Easings.h);
            this.y.d(1.0);
            this.A = false;
            this.y.a(0.3000000261138894, 0.5, Easings.i);
         }

         FontRenderer var3 = Fonts.a[14];
         float var4 = this.g + this.q;
         float var5 = var1 - var4;
         if (this.C && !this.d.isEmpty()) {
            float var6 = var3.a(this.d);
            var5 -= (this.i - this.q * 2.0F - var6) / 2.0F;
         }

         this.t = var3.a(this.d, var5);
         this.w();
         return true;
      } else {
         if (this.r) {
            this.r = false;
            this.w.a(0.0, 0.20000000856584893, Easings.h);
            this.z();
         }

         return false;
      }
   }

   public boolean a(int var1, int var2, int var3) {
      if (!this.r) {
         return false;
      } else {
         boolean var4 = (var3 & 2) != 0;
         boolean var5 = (var3 & 1) != 0;
         if (var4) {
            switch (var1) {
               case 65:
                  this.r();
                  return true;
               case 67:
                  this.s();
                  return true;
               case 86:
                  this.t();
                  return true;
               case 88:
                  this.u();
                  return true;
            }
         }

         switch (var1) {
            case 256:
               this.r = false;
               this.w.a(0.0, 0.20000000856584893, Easings.h);
               this.w();
               this.G = "";
               return true;
            case 257:
               this.r = false;
               this.w.a(0.0, 0.20000000856584893, Easings.h);
               this.w();
               this.G = "";
               this.z();
               return true;
            case 258:
               if (this.c == InputFieldElement.InputType.d && !this.G.isEmpty()) {
                  this.m();
                  return true;
               }

               this.r = false;
               this.w.a(0.0, 0.20000000856584893, Easings.h);
               this.w();
               this.G = "";
               this.z();
               return true;
            case 259:
               this.n();
               return true;
            case 260:
            case 264:
            case 265:
            case 266:
            case 267:
            default:
               return false;
            case 261:
               this.o();
               return true;
            case 262:
               this.b(var5, var4);
               return true;
            case 263:
               this.a(var5, var4);
               return true;
            case 268:
               this.e(var5);
               return true;
            case 269:
               this.f(var5);
               return true;
         }
      }
   }

   public boolean a(char var1, int var2) {
      if (!this.r) {
         return false;
      } else if (Character.isISOControl(var1)) {
         return false;
      } else if (!this.b(var1, this.t)) {
         return true;
      } else {
         int var3 = this.c == InputFieldElement.InputType.e ? 12 : this.f;
         if (this.d.length() >= var3 && !this.v()) {
            return true;
         } else {
            if (this.v()) {
               this.x();
            }

            if (this.c == InputFieldElement.InputType.e) {
               var1 = Character.toUpperCase(var1);
            }

            if (this.d.length() < var3) {
               this.d = this.d.substring(0, this.t) + var1 + this.d.substring(this.t);
               this.t++;
               this.y();
               this.k();
            }

            return true;
         }
      }
   }

   private void n() {
      if (this.v()) {
         this.x();
      } else if (this.t > 0) {
         this.d = this.d.substring(0, this.t - 1) + this.d.substring(this.t);
         this.t--;
      }

      this.y();
      this.k();
   }

   private void o() {
      if (this.v()) {
         this.x();
      } else if (this.t < this.d.length()) {
         this.d = this.d.substring(0, this.t) + this.d.substring(this.t + 1);
      }

      this.y();
      this.k();
   }

   private void a(boolean var1, boolean var2) {
      int var3 = this.t;
      if (var2) {
         var3 = this.p();
      } else {
         var3 = Math.max(0, this.t - 1);
      }

      if (var1) {
         if (!this.v()) {
            this.u = this.t;
         }

         this.v = var3;
      } else {
         if (this.v()) {
            var3 = Math.min(this.u, this.v);
         }

         this.w();
      }

      this.t = var3;
      this.y();
   }

   private void b(boolean var1, boolean var2) {
      int var3 = this.t;
      if (var2) {
         var3 = this.q();
      } else {
         var3 = Math.min(this.d.length(), this.t + 1);
      }

      if (var1) {
         if (!this.v()) {
            this.u = this.t;
         }

         this.v = var3;
      } else {
         if (this.v()) {
            var3 = Math.max(this.u, this.v);
         }

         this.w();
      }

      this.t = var3;
      this.y();
   }

   private void e(boolean var1) {
      if (var1) {
         if (!this.v()) {
            this.u = this.t;
         }

         this.v = 0;
      } else {
         this.w();
      }

      this.t = 0;
      this.y();
   }

   private void f(boolean var1) {
      if (var1) {
         if (!this.v()) {
            this.u = this.t;
         }

         this.v = this.d.length();
      } else {
         this.w();
      }

      this.t = this.d.length();
      this.y();
   }

   private int p() {
      if (this.t == 0) {
         return 0;
      } else {
         int var1 = this.t - 1;

         while (var1 > 0 && Character.isWhitespace(this.d.charAt(var1))) {
            var1--;
         }

         while (var1 > 0 && !Character.isWhitespace(this.d.charAt(var1 - 1))) {
            var1--;
         }

         return var1;
      }
   }

   private int q() {
      if (this.t >= this.d.length()) {
         return this.d.length();
      } else {
         int var1 = this.t;

         while (var1 < this.d.length() && !Character.isWhitespace(this.d.charAt(var1))) {
            var1++;
         }

         while (var1 < this.d.length() && Character.isWhitespace(this.d.charAt(var1))) {
            var1++;
         }

         return var1;
      }
   }

   private void r() {
      this.u = 0;
      this.v = this.d.length();
      this.t = this.d.length();
   }

   private void s() {
      if (this.v()) {
         int var1 = Math.min(this.u, this.v);
         int var2 = Math.max(this.u, this.v);
         String var3 = this.d.substring(var1, var2);
         MinecraftClient.getInstance().keyboard.setClipboard(var3);
      }
   }

   private void t() {
      String var1 = MinecraftClient.getInstance().keyboard.getClipboard();
      if (var1 != null && !var1.isEmpty()) {
         var1 = var1.replaceAll("[\\r\\n\\t]", "");
         StringBuilder var2 = new StringBuilder();

         for (int var3 = 0; var3 < var1.length(); var3++) {
            char var4 = var1.charAt(var3);
            if (this.b(var4, this.t + var2.length())) {
               var2.append(var4);
            }
         }

         var1 = var2.toString();
         if (this.v()) {
            this.x();
         }

         int var7 = this.f - this.d.length();
         if (var1.length() > var7) {
            var1 = var1.substring(0, var7);
         }

         if (!var1.isEmpty()) {
            this.d = this.d.substring(0, this.t) + var1 + this.d.substring(this.t);
            this.t = this.t + var1.length();
         }

         this.y();
         this.k();
      }
   }

   private void u() {
      if (this.v()) {
         this.s();
         this.x();
         this.k();
      }
   }

   private boolean v() {
      return this.u != -1 && this.v != -1 && this.u != this.v;
   }

   private void w() {
      this.u = -1;
      this.v = -1;
   }

   private void x() {
      if (this.v()) {
         int var1 = Math.min(this.u, this.v);
         int var2 = Math.max(this.u, this.v);
         this.d = this.d.substring(0, var1) + this.d.substring(var2);
         this.t = var1;
         this.w();
      }
   }

   private void y() {
      this.y.d(1.0);
      this.A = false;
      this.y.a(0.3000000261138894, 0.5, Easings.i);
   }

   private void z() {
      if (this.B != null) {
         this.B.accept(this.d);
      }
   }

   public float g() {
      return this.g;
   }

   public float h() {
      return this.h;
   }

   public float i() {
      return this.i;
   }

   public float j() {
      return this.j;
   }

   @Environment(EnvType.CLIENT)
   public static enum InputType {
      a,
      b,
      c,
      d,
      e,
      f;

      private static InputFieldElement.InputType[] a() {
         return new InputFieldElement.InputType[]{a, b, c, d, e, f};
      }
   }
}
