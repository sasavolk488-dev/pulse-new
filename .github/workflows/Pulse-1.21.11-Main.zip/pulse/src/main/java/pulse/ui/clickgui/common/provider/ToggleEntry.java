package pulse.ui.clickgui.common.provider;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Module;

@Environment(EnvType.CLIENT)
public interface ToggleEntry {
   String a();

   boolean b();

   void a(boolean var1);

   default boolean c() {
      return true;
   }

   default boolean d() {
      return true;
   }

   default Module e() {
      return null;
   }

   default int f() {
      Module var1 = this.e();
      return var1 != null ? var1.j() : 0;
   }

   default void a(int var1) {
      Module var2 = this.e();
      if (var2 != null) {
         var2.a(var1);
      }
   }

   default boolean g() {
      Module var1 = this.e();
      return var1 != null && !var1.m().isEmpty();
   }

   default boolean h() {
      return this.d();
   }
}
