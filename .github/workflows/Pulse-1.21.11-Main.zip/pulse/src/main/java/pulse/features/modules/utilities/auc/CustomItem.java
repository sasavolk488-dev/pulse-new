package pulse.features.modules.utilities.auc;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Uuids;

@Environment(EnvType.CLIENT)
public class CustomItem implements AucItem {
   private final String a;
   private final String b;
   private final NbtCompound c;
   private final Item d;
   private final PotionContentsComponent e;
   private final List<Text> f;

   public CustomItem(String var1, String var2, NbtCompound var3, Item var4, int var5, PotionContentsComponent var6, List<Text> var7) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var6;
      this.f = var7;
   }

   public CustomItem(String var1, NbtCompound var2, Item var3, int var4, PotionContentsComponent var5, List<Text> var6) {
      this(var1, null, var2, var3, var4, var5, var6);
   }

   public CustomItem(String var1, NbtCompound var2, Item var3, int var4) {
      this(var1, null, var2, var3, var4, null, null);
   }

   @Override
   public String a() {
      return this.a;
   }

   @Override
   public String b() {
      return this.b != null ? this.b : this.a;
   }

   @Override
   public ItemStack c() {
      ItemStack var1 = new ItemStack(this.d);
      var1.set(DataComponentTypes.CUSTOM_NAME, Text.literal(this.a));
      if (this.d == Items.POTION) {
         String var3 = this.a;

         int var2 = switch (var3) {
            case "Хлопушка" -> 16735488;
            case "Святая вода" -> 49664;
            case "Снотворное" -> 16777215;
            case "Зелье гнева" -> 6092799;
            case "Зелье паладина" -> 65280;
            case "Зелье ассасина" -> 16775936;
            case "Зелье радиации" -> 16711902;
            default -> 3694022;
         };
         var1.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(Optional.empty(), Optional.of(var2), List.of(), Optional.empty()));
      } else if (this.e != null) {
         var1.set(DataComponentTypes.POTION_CONTENTS, this.e);
      }

      if (this.f != null) {
         var1.set(DataComponentTypes.LORE, new LoreComponent(this.f));
      }

      if (this.d == Items.TOTEM_OF_UNDYING) {
         var1.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
      }

      if (this.c != null) {
         NbtCompound var6 = this.c.copy();
         if (this.d == Items.PLAYER_HEAD && var6.getCompound("SkullOwner").isPresent()) {
            NbtCompound var7 = var6.getCompoundOrEmpty("SkullOwner");
            UUID var8 = var7.getIntArray("Id").map(Uuids::toUuid).orElse(new UUID(0L, 0L));
            GameProfile var5 = new GameProfile(var8, "");
            var1.set(DataComponentTypes.PROFILE, ProfileComponent.ofStatic(var5));
            var6.remove("SkullOwner");
         }

         if (!var6.isEmpty()) {
            var1.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(var6));
         }
      }

      return var1;
   }
}
