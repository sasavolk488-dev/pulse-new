package pulse.core.settings;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class Setting<T> {
   private final String a;
   private final String b;
   private T c;
   private T d;
   private T e;
   private T f;
   private Supplier<Boolean> g = () -> true;

   public String l() {
      return this.a;
   }

   public String m() {
      return this.b;
   }

   public Supplier<Boolean> n() {
      return this.g;
   }

   public T o() {
      return this.d;
   }

   public T p() {
      return this.e;
   }

   public T q() {
      return this.c;
   }

   public void a(T var1) {
      this.c = (T)var1;
   }

   public Setting(String var1, String var2, T var3) {
      this.a = var1;
      this.b = var2;
      this.c = (T)var3;
      this.d = (T)var3;
   }

   public Setting(String var1, String var2, T var3, T var4, T var5) {
      this(var1, var2, (T)var3);
      this.e = (T)var4;
      this.f = (T)var5;
   }

   public void c_() {
      this.c = this.d;
   }

   public Setting<T> b(Supplier<Boolean> var1) {
      this.g = var1;
      return this;
   }

   public boolean r() {
      return this.g.get();
   }
}
