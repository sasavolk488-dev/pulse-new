package pulse.features.graffiti;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

@Environment(EnvType.CLIENT)
public record GraffitiDecal(String worldKey, BlockPos pos, Direction face, Direction imageUp, GraffitiEntry entry, long placedAt, String owner) {
   public boolean a(BlockPos var1, Direction var2) {
      return this.pos.equals(var1) && this.face == var2;
   }
}
