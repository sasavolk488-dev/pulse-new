package pulse.features.emote.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.bobj.BobjModel;
import pulse.features.emote.bobj.BobjSkinning;

@Environment(EnvType.CLIENT)
public final class BobjVanillaPose {
   private static final float c = 1.0F;
   static final float a = 16.0F;
   static final float b = 24.0F;

   private BobjVanillaPose() {
   }

   public static void a(PlayerEntityModel var0, EmoteManager.ActiveRenderData var1) {
      BobjModel var2 = var1.model();
      float[][] var3 = var2.a(var1.action(), var1.frame());
      BobjLegSegments.a(var0, var2, var3);
      a(var0.head, var3, var2.a("head"));
      a(var0.body, var3, var2.a("low_body"));
      a(var0.rightArm, var3, var2.a("right_arm"));
      a(var0.leftArm, var3, var2.a("left_arm"));
      a(var0.rightLeg, var3, var2, "right_leg", "low_leg_right");
      a(var0.leftLeg, var3, var2, "left_leg", "low_left_leg");
   }

   public static void a(BipedEntityModel<?> var0, EmoteManager.ActiveRenderData var1) {
      BobjModel var2 = var1.model();
      float[][] var3 = var2.a(var1.action(), var1.frame());
      a(var0.head, var3, var2.a("head"));
      a(var0.body, var3, var2.a("low_body"));
      a(var0.rightArm, var3, var2.a("right_arm"));
      a(var0.leftArm, var3, var2.a("left_arm"));
      a(var0.rightLeg, var3, var2, "right_leg", "low_leg_right");
      a(var0.leftLeg, var3, var2, "left_leg", "low_left_leg");
   }

   public static void a(ModelPart var0, EmoteManager.ActiveRenderData var1) {
      BobjModel var2 = var1.model();
      float[][] var3 = var2.a(var1.action(), var1.frame());
      a(var0, var3, var2.a("low_body"));
   }

   private static void a(ModelPart var0, float[][] var1, int var2) {
      if (var2 >= 0 && var2 < var1.length) {
         float[] var3 = var1[var2];
         a(var0, var3);
         a(var0, a(var3));
      }
   }

   private static void a(ModelPart var0, float[][] var1, BobjModel var2, String var3, String var4) {
      int var5 = var2.a(var3);
      if (var5 >= 0 && var5 < var1.length) {
         int var6 = var2.a(var4);
         if (var6 >= 0 && var6 < var1.length) {
            float[] var7 = var1[var5];
            float[] var8 = var1[var6];
            float var9 = var0.originX / 16.0F;
            float var10 = (24.0F - var0.originY) / 16.0F;
            float var11 = -var0.originZ / 16.0F;
            float[] var12 = new float[3];
            BobjSkinning.a(var7, var9, var10, var11, var12);
            float[] var13 = new float[3];
            BobjSkinning.a(var8, var9, 0.0F, var11, var13);
            var0.originX = var12[0] * 16.0F;
            var0.originY = 24.0F - var12[1] * 16.0F;
            var0.originZ = -var12[2] * 16.0F;
            float var14 = var13[0] - var12[0];
            float var15 = var13[1] - var12[1];
            float var16 = var13[2] - var12[2];
            if (var14 * var14 + var15 * var15 + var16 * var16 < 1.0E-8F) {
               a(var0, a(var7));
            } else {
               Quaternionf var17 = new Quaternionf().rotationTo(0.0F, -1.0F, 0.0F, var14, var15, var16);
               Quaternionf var18 = a(var7);
               Quaternionf var19 = new Quaternionf(0.0F, var18.y, 0.0F, var18.w);
               if (var19.lengthSquared() > 1.0E-6F) {
                  var19.normalize();
               } else {
                  var19.identity();
               }

               a(var0, var17.mul(var19));
            }
         } else {
            a(var0, var1, var5);
         }
      }
   }

   private static void a(ModelPart var0, float[] var1) {
      float var2 = var0.originX / 16.0F;
      float var3 = (24.0F - var0.originY) / 16.0F;
      float var4 = -var0.originZ / 16.0F;
      float[] var5 = new float[3];
      BobjSkinning.a(var1, var2, var3, var4, var5);
      var0.originX = var5[0] * 16.0F;
      var0.originY = 24.0F - var5[1] * 16.0F;
      var0.originZ = -var5[2] * 16.0F;
   }

   static Quaternionf a(float[] var0) {
      return new Quaternionf().setFromUnnormalized(new Matrix3f(var0[0], var0[4], var0[8], var0[1], var0[5], var0[9], var0[2], var0[6], var0[10]));
   }

   static void a(ModelPart var0, Quaternionf var1) {
      Quaternionf var2 = new Quaternionf(var1.x, -var1.y, -var1.z, var1.w);
      Vector3f var3 = new Matrix3f().set(var2).getEulerAnglesZYX(new Vector3f());
      var0.setAngles(var3.x, var3.y, var3.z);
   }
}
