package pulse.features.modules.visuals;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;

@ModuleInfo(
   a = "Item Physic",
   b = "Реалистичная физика выпавших предметов",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class ItemPhysicModule extends Module {
}
