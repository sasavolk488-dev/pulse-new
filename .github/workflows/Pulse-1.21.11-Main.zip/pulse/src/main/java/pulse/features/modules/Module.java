package pulse.features.modules;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import pulse.config.cloud.CloudConfigManager;
import pulse.core.event.EventHandler;
import pulse.core.handler.HandlerRegistry;
import pulse.core.handler.impl.ServerIntegrationHandler;
import pulse.features.modules.hud.components.WatermarkComponent;
import pulse.core.api.IMinecraft;
import pulse.core.settings.Setting;

@Environment(EnvType.CLIENT)
public abstract class Module implements IMinecraft {
   private final String a;
   private final String b;
   private final Category c;
   private int f = 0;
   private boolean g;
   private volatile boolean h = true;
   private volatile long i = 0L;
   private volatile long j = -1L;
   private boolean k = false;
   private final List<Setting<?>> l = new ArrayList<>();

   public void a(int var1) {
      if (this.f != var1) {
         this.f = var1;
         CloudConfigManager.a().h();
      }
   }

   public boolean a() {
      return this.k;
   }

   public void a(boolean var1) {
      this.k = var1;
   }

   public Module() {
      ModuleInfo var1 = this.getClass().getAnnotation(ModuleInfo.class);
      this.a = var1.a();
      this.b = var1.b();
      this.c = var1.c();
   }

   public void b() {
      for (Field var4 : this.getClass().getDeclaredFields()) {
         var4.setAccessible(true);

         try {
            if (var4.get(this) instanceof Setting var6) {
               this.l.add(var6);
            }
         } catch (IllegalAccessException var7) {
            var7.printStackTrace();
         }
      }
   }

   public void b(boolean var1) {
      if (this.k != var1) {
         this.k = var1;
         CloudConfigManager.a().h();
      }

      if (!var1 || HandlerRegistry.a.a(this.a)) {
         this.c(var1);
      }
   }

   public void c(boolean var1) {
      if (this.g != var1) {
         this.g = var1;
         if (var1) {
            this.e();
         } else {
            this.f();
         }

         WatermarkComponent.a(this.a, var1);
      }
   }

   public void c() {
      this.c(this.k);
   }

   public void d() {
      this.b(!this.g);
   }

   public void e() {
      EventHandler.a.subscribe(this);
   }

   public void f() {
      EventHandler.a.unsubscribe(this);
   }

   public String g() {
      return this.a;
   }

   public String h() {
      return this.b;
   }

   public Category i() {
      return this.c;
   }

   public int j() {
      return this.f;
   }

   public boolean k() {
      if (!this.g) {
         return false;
      } else {
         long var1 = System.currentTimeMillis();
         long var3 = ServerIntegrationHandler.a;
         if (var3 != this.j || var1 - this.i > 250L) {
            this.h = HandlerRegistry.a.a(this.a);
            this.i = var1;
            this.j = var3;
         }

         return this.h;
      }
   }

   public boolean l() {
      return this.g;
   }

   public List<Setting<?>> m() {
      return this.l;
   }
}
