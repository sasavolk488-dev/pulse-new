package pulse.features.modules.visuals;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.entity.model.ModelWithHead;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.MathHelper;
import org.joml.Quaternionf;
import pulse.core.event.impl.FrameEvent;
import pulse.core.event.impl.RenderHeadLayerEvent;
import pulse.core.event.impl.WorldOverlayEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.features.modules.ModuleRegistry;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.core.settings.BooleanSetting;
import pulse.core.settings.ColorSetting;
import pulse.core.settings.NumberSetting;
import pulse.core.settings.SeparatorSetting;

@ModuleInfo(
   a = "China Hat",
   b = "Отображает китайскую шляпу на голове игрока",
   c = Category.VISUALS
)
@Environment(EnvType.CLIENT)
public class ChinaHatModule extends Module {
   private final NumberSetting a = new NumberSetting("Высота", 0.3F, 0.1F, 0.6F, 0.05F);
   private final NumberSetting b = new NumberSetting("Прозрачность", 0.5F, 0.1F, 1.0F, 0.05F);
   private final BooleanSetting c = new BooleanSetting("Обводка", true);
   private final SeparatorSetting f = new SeparatorSetting("Цвет");
   private final BooleanSetting g = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting h = new ColorSetting("Кастомный цвет", new Color(100, 180, 255)).a(() -> !this.g.a());
   private static final float i = 0.06981317F;
   private static final float j = (float) Math.PI;
   private static final int k = 180;
   private static final float l = 0.0055555557F;
   private final float[] m = new float[3];
   private final Quaternionf n = new Quaternionf();
   private final Quaternionf o = new Quaternionf();
   private float[] p;
   private int q = Integer.MIN_VALUE;
   private Entry r;
   private double s;
   private boolean t = false;

   @EventHandler
   public void a(FrameEvent var1) {
      this.t = true;
   }

   @EventHandler
   public void a(RenderHeadLayerEvent var1) {
      if (this.t) {
         if (var1.d() instanceof ModelWithHead) {
            if (var1.a() instanceof PlayerEntity var2) {
               if (var2 instanceof ClientPlayerEntity) {
                  if (!var2.isBaby()) {
                     MatrixStack var6 = var1.c();
                     LivingEntity var4 = var1.a();
                     float var5 = this.a(var4);
                     var6.push();
                     ((ModelWithHead)var1.d()).getHead().applyTransform(var6);
                     var6.translate(0.0F, var5, 0.0F);
                     var6.multiply(this.n.rotationZ((float)Math.toRadians(180.0)));
                     var6.multiply(this.o.rotationY((float)Math.toRadians(90.0)));
                     this.r = var6.peek().copy();
                     this.s = var4.getBoundingBox().maxX - var4.getBoundingBox().minX;
                     var6.pop();
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void a(WorldOverlayEvent var1) {
      this.t = false;
      Entry var2 = this.r;
      if (var2 != null) {
         this.r = null;
         Color var3 = this.n();
         float var4 = var3.getRed() / 255.0F;
         float var5 = var3.getGreen() / 255.0F;
         float var6 = var3.getBlue() / 255.0F;
         Color.RGBtoHSB(var3.getRed(), var3.getGreen(), var3.getBlue(), this.m);
         float var7 = this.m[0];
         float var8 = this.m[1];
         float var9 = this.m[2];
         int var10 = var3.getRGB();
         if (this.p == null || this.q != var10) {
            if (this.p == null) {
               this.p = new float[543];
            }

            for (int var11 = 0; var11 <= 180; var11++) {
               float var12 = (float)Math.sin(var11 * 0.0055555557F * (float) Math.PI) * 0.08F;
               float var13 = (var7 + var12) % 1.0F;
               if (var13 < 0.0F) {
                  var13++;
               }

               int var14 = Color.HSBtoRGB(var13, var8, var9);
               int var15 = var11 * 3;
               this.p[var15] = (var14 >> 16 & 0xFF) / 255.0F;
               this.p[var15 + 1] = (var14 >> 8 & 0xFF) / 255.0F;
               this.p[var15 + 2] = (var14 & 0xFF) / 255.0F;
            }

            this.q = var10;
         }

         float var37 = this.a.b();
         float var38 = this.b.b();
         float var39 = var38 * 0.5F;
         double var40 = this.s;
         Immediate var16 = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer var17 = var16.getBuffer(BlockOverlayLayers.f);
         float var18 = 0.0F;
         float var19 = 0.0F;
         float var20 = var4;
         float var21 = var5;
         float var22 = var6;

         for (int var23 = 0; var23 <= 180; var23++) {
            float var24 = var23 * 0.06981317F;
            float var25 = (float)(MathHelper.sin(var24) * var40);
            float var26 = (float)(MathHelper.cos(var24) * var40);
            int var27 = var23 * 3;
            float var28 = this.p[var27];
            float var29 = this.p[var27 + 1];
            float var30 = this.p[var27 + 2];
            if (var23 > 0) {
               var17.vertex(var2, var18, 0.0F, var19).color(var20, var21, var22, var39).normal(var2, 0.0F, 1.0F, 0.0F);
               var17.vertex(var2, var25, 0.0F, var26).color(var28, var29, var30, var39).normal(var2, 0.0F, 1.0F, 0.0F);
               var17.vertex(var2, 0.0F, var37, 0.0F).color(var4, var5, var6, var38).normal(var2, 0.0F, 1.0F, 0.0F);
               var17.vertex(var2, var18, 0.0F, var19).color(var20, var21, var22, var39).normal(var2, 0.0F, 1.0F, 0.0F);
               var17.vertex(var2, 0.0F, var37, 0.0F).color(var4, var5, var6, var38).normal(var2, 0.0F, 1.0F, 0.0F);
               var17.vertex(var2, var25, 0.0F, var26).color(var28, var29, var30, var39).normal(var2, 0.0F, 1.0F, 0.0F);
            }

            var18 = var25;
            var19 = var26;
            var20 = var28;
            var21 = var29;
            var22 = var30;
         }

         if (this.c.a()) {
            VertexConsumer var46 = var16.getBuffer(BlockOverlayLayers.h);
            var18 = 0.0F;
            var19 = 0.0F;
            var20 = 0.0F;
            var21 = 0.0F;
            var22 = 0.0F;

            for (int var47 = 0; var47 <= 180; var47++) {
               float var48 = var47 * 0.06981317F;
               float var49 = (float)(MathHelper.sin(var48) * var40);
               float var50 = (float)(MathHelper.cos(var48) * var40);
               int var51 = var47 * 3;
               float var52 = this.p[var51];
               float var53 = this.p[var51 + 1];
               float var31 = this.p[var51 + 2];
               if (var47 > 0) {
                  float var32 = var49 - var18;
                  float var33 = var50 - var19;
                  float var34 = (float)Math.sqrt(var32 * var32 + var33 * var33);
                  if (var34 < 1.0E-6F) {
                     var34 = 1.0F;
                  }

                  float var35 = var32 / var34;
                  float var36 = var33 / var34;
                  var46.vertex(var2, var18, 0.0F, var19).color(var20, var21, var22, var38).normal(var2, var35, 0.0F, var36).lineWidth(2.0F);
                  var46.vertex(var2, var49, 0.0F, var50).color(var52, var53, var31, var38).normal(var2, var35, 0.0F, var36).lineWidth(2.0F);
               }

               var18 = var49;
               var19 = var50;
               var20 = var52;
               var21 = var53;
               var22 = var31;
            }
         }

         var16.draw(BlockOverlayLayers.f);
         if (this.c.a()) {
            var16.draw(BlockOverlayLayers.h);
         }
      }
   }

   private float a(LivingEntity var1) {
      float var2 = -0.38F;
      if (var1.getEquippedStack(EquipmentSlot.HEAD).isIn(ItemTags.HEAD_ARMOR)) {
         var2 -= 0.11F;
      }

      return var2;
   }

   private Color n() {
      return this.g.a() ? ModuleRegistry.aw.n() : this.h.a();
   }
}
