package pulse.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.RenderCommandQueue;
import net.minecraft.client.render.command.ModelCommandRenderer.CrumblingOverlayCommand;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import pulse.features.emote.EmoteManager;
import pulse.features.emote.render.BobjLegSegments;
import pulse.features.emote.render.LegSegmentOwner;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.visuals.HitColorModule;
import pulse.utils.render.ArmorRenderState;
import pulse.utils.render.ColorUtils;

@Environment(EnvType.CLIENT)
@Mixin({EquipmentRenderer.class})
public class EquipmentRendererMixin {
   @Unique
   private static final double PULSE$BASE_BIAS = 0.06;
   @Unique
   private static final double PULSE$TRIM_BIAS = 0.09;

   @Unique
   private static float pulse$biasScale(double var0, double var2) {
      double var4 = Math.sqrt(Math.max(var2, 1.0E-4));
      return (float)Math.max(0.5, 1.0 - var0 / Math.max(var4, var0 * 2.0));
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/util/Identifier;II)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/RenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      ),
      index = 6,
      require = 0
   )
   private int pulse$modifyArmorHitColor(int var1) {
      HitColorModule var2 = ModuleRegistry.m;
      if (var2 != null && var2.o() && var2.p() && ArmorRenderState.a()) {
         Color var3 = var2.n();
         return ColorUtils.a(var3.getRed(), var3.getGreen(), var3.getBlue(), 255);
      } else {
         return var1;
      }
   }

   @WrapOperation(
      method = {"render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/util/Identifier;II)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/RenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
      )}
   )
   private void pulse$splitLegs(
      RenderCommandQueue var1,
      Model<Object> var2,
      Object var3,
      MatrixStack var4,
      RenderLayer var5,
      int var6,
      int var7,
      int var8,
      Sprite var9,
      int var10,
      CrumblingOverlayCommand var11,
      Operation<Void> var12
   ) {
      boolean var13 = pulse$isEmotingPlayer(var3);
      if (var13) {
         double var14 = var3 instanceof PlayerEntityRenderState var16 ? var16.squaredDistanceToCamera : 1.0;
         float var19 = pulse$biasScale(var9 != null ? 0.09 : 0.06, var14);
         var4.push();
         Matrix4f var17 = var4.peek().getPositionMatrix();
         var17.set(new Matrix4f().scaling(var19).mul(var17));
         var12.call(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
         var4.pop();
      } else {
         var12.call(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
      }

      if (BobjLegSegments.c()
         && var2 instanceof BipedEntityModel
         && pulse$isEmotingPlayer(var3)
         && var3 instanceof PlayerEntityRenderState var18
         && LegSegmentOwner.c(var18.id)) {
         boolean var15 = BobjLegSegments.d();
         boolean var20 = var9 != null;
         float[] var21 = BobjLegSegments.e();
         var1.submitCustom(var4, var5, (var7x, var8x) -> {
            VertexConsumer var9x = var20 ? var9.getTextureSpecificVertexConsumer(var8x) : var8x;
            BobjLegSegments.a(var21);
            BobjLegSegments.a(var7x, var9x, var6, var7, var8, var15, var20);
         });
      }
   }

   @Unique
   private static boolean pulse$isEmotingPlayer(Object var0) {
      if (var0 instanceof PlayerEntityRenderState var1) {
         if (!EmoteManager.a().b()) {
            return false;
         } else {
            MinecraftClient var2 = MinecraftClient.getInstance();
            if (var2.world == null) {
               return false;
            } else {
               return var2.world.getEntityById(var1.id) instanceof AbstractClientPlayerEntity var3 ? EmoteManager.a().c(var3) != null : false;
            }
         }
      } else {
         return false;
      }
   }
}
