package pulse.services.tracker.v2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class GroupManagerClient {
   private static final GroupManagerClient a = new GroupManagerClient();
   private volatile String b;
   private volatile int c;
   private volatile long d;
   private volatile List<GroupMemberDto> e = Collections.emptyList();
   private final Map<String, GroupInviteInfo> f = new ConcurrentHashMap<>();
   private final AtomicLong g = new AtomicLong(0L);

   public static GroupManagerClient a() {
      return a;
   }

   public long b() {
      return this.g.get();
   }

   public boolean c() {
      return this.b != null;
   }

   public boolean a(int var1) {
      return this.c() && this.c == var1;
   }

   public boolean b(int var1) {
      for (GroupMemberDto var3 : this.e) {
         if (var3.a() == var1) {
            return true;
         }
      }

      return false;
   }

   public List<GroupMemberDto> d() {
      return new ArrayList<>(this.e);
   }

   public void a(String var1, int var2, long var3, List<GroupMemberDto> var5) {
      if (var3 <= 0L || this.d <= 0L || var1 == null || !var1.equals(this.b) || var3 > this.d) {
         this.b = var1;
         this.c = var2;
         this.d = var3;
         this.e = var5 != null ? var5 : Collections.emptyList();
         this.f.remove(var1);
         this.g.incrementAndGet();
         HashSet var6 = new HashSet();

         for (GroupMemberDto var8 : this.e) {
            var6.add(var8.a());
         }

         PartyHealthTracker.a().a(var6);
         PartyInventoryTracker.a().a(var6);
         PartyHealthReporter.d();
         PartyInventoryReporter.e();
      }
   }

   public void a(String var1, String var2) {
      if (var1 != null && var1.equals(this.b)) {
         this.e();
      }

      this.f.remove(var1);
   }

   public void e() {
      String var1 = this.b;
      this.b = null;
      this.c = 0;
      this.d = 0L;
      this.e = Collections.emptyList();
      if (var1 != null) {
         this.f.remove(var1);
      }

      this.g.incrementAndGet();
      PartyHealthTracker.a().b();
      PartyInventoryTracker.a().d();
   }

   public void a(String var1, int var2, String var3) {
      this.f.put(var1, new GroupInviteInfo(var1, var2, var3));
      this.g.incrementAndGet();
   }

   public void a(String var1) {
      this.f.remove(var1);
      this.g.incrementAndGet();
   }

   public List<GroupInviteInfo> f() {
      return new ArrayList<>(this.f.values());
   }

   @Generated
   public String g() {
      return this.b;
   }

   @Generated
   public int h() {
      return this.c;
   }

   @Generated
   public long i() {
      return this.d;
   }
}
