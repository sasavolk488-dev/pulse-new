package pulse.features.modules.hud;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.TntEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import pulse.Pulse;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;

@ModuleInfo(
   a = "TNT Timer",
   b = "Пульсирующая иконка динамита и время до взрыва, когда рядом опасное ТНТ",
   c = Category.HUD
)
@Environment(EnvType.CLIENT)
public class TNTTimerModule extends Module {
   private static final double a = 8.0;
   private static final float b = 24.0F;
   private static final ItemStack c = new ItemStack(Items.TNT);
   private double f = 0.0;
   private long g = 0L;

   @EventHandler(
      priority = -200
   )
   private void a(RenderHudPostEvent var1) {
      if (d.player != null && d.world != null) {
         Render var2 = Pulse.l().p();
         if (var2 != null) {
            int var3 = Integer.MAX_VALUE;
            int var4 = 0;
            double var5 = 64.0;

            for (Entity var8 : d.world.getEntities()) {
               if (var8 instanceof TntEntity var9 && !(var9.squaredDistanceTo(d.player) > var5)) {
                  var4++;
                  var3 = Math.min(var3, var9.getFuse());
               }
            }

            if (var4 != 0) {
               float var25 = Math.max(0, var3) / 20.0F;
               float var26 = 1.0F - Math.min(var25, 4.0F) / 4.0F;
               float var27 = 2.0F + var26 * 6.0F;
               long var10 = System.nanoTime();
               double var12 = this.g == 0L ? 0.0 : (var10 - this.g) / 1.0E9;
               this.g = var10;
               this.f = (this.f + Math.min(var12, 0.10000002254098087) * var27 * 3.1415933092488793 * 2.0) % 6.2831856573659834;
               float var14 = (float)(Math.sin(this.f) + 1.0) / 2.0F;
               float var15 = 0.55F + 0.45F * var14;
               float var16 = 1.0F + (0.08F + 0.22F * var26) * var14;
               float var17 = d.getWindow().getFramebufferWidth() / 4.0F;
               float var18 = d.getWindow().getFramebufferHeight() / 2.0F - 100.0F;
               MatrixStack var19 = var1.a();
               var19.push();
               var19.translate(var17, var18, 0.0F);
               var19.scale(var16, var16, 1.0F);
               var19.translate(-var17, -var18, 0.0F);
               HudItemSpriteRenderer.a(var2, var19, c, var17 - 12.0F, var18 - 12.0F, 24.0F, var15);
               var19.pop();
               String var20 = String.format("%.1fс", var25) + (var4 > 1 ? " (x" + var4 + ")" : "");
               int var21 = (int)(255.0F * (1.0F - var26));
               Color var22 = new Color(255, var21, var21);
               FontRenderer var23 = Fonts.b[18];
               float var24 = var23.a(var20);
               var23.a(var20, var17 - var24 / 2.0F, var18 + 12.0F + 4.0F, var22, var19);
            }
         }
      }
   }
}
