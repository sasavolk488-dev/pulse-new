package pulse.features.phrase;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.zip.GZIPInputStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.json.JSONArray;
import org.json.JSONObject;
import pulse.Pulse;
import pulse.utils.net.ApiRouter;

@Environment(EnvType.CLIENT)
public final class PhraseBundleManager {
   private static final int a = 6;
   private static final int b = 5000;

   private PhraseBundleManager() {
   }

   public static void a() {
      new Thread(PhraseBundleManager::b, "Phrase-Bundle-Loader").start();
   }

   private static void b() {
      Pulse.m().info("[Phrase] загрузка phrase-bundle, хосты: {}", ApiRouter.a());
      int var0 = 0;

      for (int var1 = 0; var1 < 6; var1++) {
         String var2 = ApiRouter.a().get(var0) + "/cosmetics/phrase-bundle";

         try {
            URL var3 = new URL(var2);
            HttpURLConnection var4 = (HttpURLConnection)var3.openConnection();
            var4.setRequestMethod("GET");
            var4.setConnectTimeout(15000);
            var4.setReadTimeout(30000);
            var4.setRequestProperty("Accept-Encoding", "gzip");
            String var5 = f();
            if (var5 != null && !var5.isEmpty()) {
               var4.setRequestProperty("If-None-Match", var5);
            }

            int var6 = var4.getResponseCode();
            String var7 = var4.getHeaderField("ETag");
            String var8;
            if (var6 == 304) {
               var8 = g();
               if (var8 == null) {
                  Pulse.m().warn("[Phrase] 304, но локальный кэш отсутствует — перезапрос без ETag");
                  var4.disconnect();

                  try {
                     Files.deleteIfExists(e());
                  } catch (Exception var11) {
                  }
                  continue;
               }

               Pulse.m().info("[Phrase] bundle: кэш актуален (304), читаю с диска");
            } else if (var6 == 200) {
               var8 = a(var4);
               a(var8, var7);
               Pulse.m().info("[Phrase] bundle: свежий ответ ({} KB), кэш обновлён{}", var8.length() / 1024, var7 != null ? " (etag=" + var7 + ")" : "");
            } else {
               Pulse.m().warn("[Phrase] bundle: HTTP {}", var6);
               var8 = g();
               if (var8 == null) {
                  return;
               }

               Pulse.m().info("[Phrase] bundle: использую stale-кэш");
            }

            a(var8);
            return;
         } catch (SocketTimeoutException var12) {
            Pulse.m().warn("[Phrase] таймаут bundle (попытка {}/{}, {})", var1 + 1, 6, var2);
            var0 = a(var0);
            if (!b(var1)) {
               return;
            }
         } catch (Exception var13) {
            Pulse.m().error("[Phrase] ошибка загрузки phrase-bundle (попытка {}/{}, {}): {}", var1 + 1, 6, var2, var13.toString());
            var0 = a(var0);
            if (!b(var1)) {
               return;
            }
         }
      }

      String var14 = g();
      if (var14 != null) {
         Pulse.m().info("[Phrase] bundle: попытки исчерпаны, использую кэш");

         try {
            a(var14);
         } catch (Exception var10) {
         }
      } else {
         Pulse.m().error("[Phrase] не удалось загрузить phrase-bundle после {} попыток", 6);
      }
   }

   private static int a(int var0) {
      return (var0 + 1) % ApiRouter.a().size();
   }

   private static boolean b(int var0) {
      if (var0 >= 5) {
         return true;
      } else {
         try {
            Thread.sleep(5000L);
            return true;
         } catch (InterruptedException var2) {
            Thread.currentThread().interrupt();
            return false;
         }
      }
   }

   private static void a(String var0) {
      JSONObject var1 = new JSONObject(var0);
      if (!var1.optBoolean("success", false)) {
         Pulse.m().warn("[Phrase] bundle: сервер вернул ошибку");
      } else {
         JSONArray var2 = var1.optJSONArray("data");
         if (var2 != null) {
            PhraseManager var3 = PhraseManager.a();
            var3.b();
            PhraseAudio.b();
            int var4 = 0;

            for (int var5 = 0; var5 < var2.length(); var5++) {
               JSONObject var6 = var2.getJSONObject(var5);
               int var7 = var6.optInt("id", -1);
               if (var7 >= 0) {
                  try {
                     String var8 = var6.optString("name", "Фраза " + var7);
                     String var9 = var6.optString("text", var8);
                     var3.a(var7, var8, var9, null);
                     if (!var6.isNull("icon_base64")) {
                        a(var7, var6.getString("icon_base64"));
                     }

                     if (!var6.isNull("audio_base64")) {
                        PhraseAudio.a(var7, Base64.getDecoder().decode(var6.getString("audio_base64")), var6.optString("audio_ext", "mp3"));
                     }

                     var4++;
                  } catch (Throwable var10) {
                     Pulse.m().warn("[Phrase] bundle: skip id={}: {}", var7, var10.toString());
                  }
               }
            }

            Pulse.m().info("[Phrase] bundle: загружено {} фраз (из {})", var4, var2.length());
         }
      }
   }

   private static void a(int var0, String var1) {
      try {
         byte[] var2 = Base64.getDecoder().decode(var1);
         NativeImage var3 = NativeImage.read(new ByteArrayInputStream(var2));
         Identifier var4 = Identifier.of("pulse", "phrase_icon/" + var0);
         Runnable var5 = () -> {
            MinecraftClient.getInstance().getTextureManager().registerTexture(var4, new NativeImageBackedTexture(var4::toString, var3));
            PhraseManager.a().a(var0, var4);
         };
         MinecraftClient var6 = MinecraftClient.getInstance();
         if (var6.isOnThread()) {
            var5.run();
         } else {
            var6.execute(var5);
         }
      } catch (Exception var7) {
         Pulse.m().warn("[Phrase] bundle: иконка id={} не загрузилась: {}", var0, var7.toString());
      }
   }

   private static String a(HttpURLConnection var0) throws Exception {
      InputStream var1 = var0.getInputStream();
      InputStream var2 = "gzip".equalsIgnoreCase(var0.getContentEncoding()) ? new GZIPInputStream(var1) : var1;

      String var7;
      try (
         InputStream var3 = var2;
         ByteArrayOutputStream var4 = new ByteArrayOutputStream();
      ) {
         byte[] var5 = new byte[8192];

         int var6;
         while ((var6 = var3.read(var5)) != -1) {
            var4.write(var5, 0, var6);
         }

         var7 = var4.toString(StandardCharsets.UTF_8);
      }

      return var7;
   }

   private static Path c() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("pulse_cache");
   }

   private static Path d() {
      return c().resolve("phrase_bundle.json");
   }

   private static Path e() {
      return c().resolve("phrase_bundle.etag");
   }

   private static String f() {
      try {
         Path var0 = e();
         if (Files.exists(var0)) {
            return Files.readString(var0, StandardCharsets.UTF_8).trim();
         }
      } catch (Exception var1) {
      }

      return null;
   }

   private static String g() {
      try {
         Path var0 = d();
         if (Files.exists(var0)) {
            return Files.readString(var0, StandardCharsets.UTF_8);
         }
      } catch (Exception var1) {
      }

      return null;
   }

   private static void a(String var0, String var1) {
      try {
         Files.createDirectories(c());
         Files.writeString(d(), var0, StandardCharsets.UTF_8);
         if (var1 != null) {
            Files.writeString(e(), var1, StandardCharsets.UTF_8);
         }
      } catch (Exception var3) {
         Pulse.m().warn("[Phrase] не удалось сохранить кэш bundle: {}", var3.getMessage());
      }
   }
}
