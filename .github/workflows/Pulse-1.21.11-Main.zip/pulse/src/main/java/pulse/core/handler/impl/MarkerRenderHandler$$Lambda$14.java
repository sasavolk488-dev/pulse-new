package pulse.core.handler.impl;

import java.util.function.ToDoubleFunction;

public final class MarkerRenderHandler$$Lambda$14 implements ToDoubleFunction {
   @Override
   public double applyAsDouble(Object var1) {
      return MarkerRenderHandler.a((MarkerRenderHandler.VisibleMarker)var1);
   }
}
