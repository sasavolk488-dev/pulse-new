package pulse.core.settings;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class BooleanSetting extends Setting<Boolean> {
   public BooleanSetting(String var1, String var2, boolean var3) {
      super(var1, var2, var3);
   }

   public BooleanSetting(String var1, boolean var2) {
      this(var1, "", var2);
   }

   public boolean a() {
      return this.q();
   }

   public void a(boolean var1) {
      this.a(Boolean.valueOf(var1));
   }

   public void b() {
      this.a(Boolean.valueOf(!this.q()));
   }

   public BooleanSetting a(Supplier<Boolean> var1) {
      super.b(var1);
      return this;
   }

   @Override
   public Setting b(Supplier var1) {
      return this.a(var1);
   }
}
