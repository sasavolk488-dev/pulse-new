package pulse.core.input;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class KeyNames {
   private KeyNames() {
   }

   @Compile
   public static String a(int var0) {
      if (var0 >= 1450) {
         return "M" + (var0 - 1449);
      }
      String name = b(var0);
      return name != null ? name : pulse.utils.input.KeyUtils.a(var0);
   }

   private static String b(int var0) {
      if (var0 >= 65 && var0 <= 90) {
         return String.valueOf((char)(65 + (var0 - 65)));
      } else if (var0 >= 48 && var0 <= 57) {
         return String.valueOf((char)(48 + (var0 - 48)));
      } else {
         switch (var0) {
            case 39:
               return "'";
            case 44:
               return ",";
            case 45:
               return "-";
            case 46:
               return ".";
            case 47:
               return "/";
            case 59:
               return ";";
            case 61:
               return "=";
            case 91:
               return "[";
            case 92:
               return "\\";
            case 93:
               return "]";
            case 96:
               return "`";
            case 161:
               return "<";
            case 162:
               return ">";
            default:
               return null;
         }
      }
   }

   static {
      NativeMethodLookup.lookup(KeyNames.class, 36);
   }
}
