package pulse.features.modules.utilities.ft;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public record SoundSignature(Identifier soundId, SoundCategory category, float volume, float pitch, float volumeTolerance, float pitchTolerance) {
   private static final float g = 0.06F;

   public SoundSignature(Identifier var1, SoundCategory var2, float var3, float var4) {
      this(var1, var2, var3, var4, 0.06F, 0.06F);
   }

   public boolean a(DetectedSound var1) {
      if (!this.soundId.equals(var1.soundId())) {
         return false;
      } else {
         return this.category != null && this.category != var1.category()
            ? false
            : Math.abs(var1.volume() - this.volume) <= this.volumeTolerance && Math.abs(var1.pitch() - this.pitch) <= this.pitchTolerance;
      }
   }
}
