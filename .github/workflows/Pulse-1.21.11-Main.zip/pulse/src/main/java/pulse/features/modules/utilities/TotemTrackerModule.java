package pulse.features.modules.utilities;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import pulse.core.event.impl.AttackEvent;
import pulse.core.event.impl.TotemPopEvent;
import pulse.features.modules.Category;
import pulse.features.modules.Module;
import pulse.features.modules.ModuleInfo;
import pulse.utils.game.ChatUtils;
import pulse.utils.time.TimeUtils;

@ModuleInfo(
   a = "Totem Tracker",
   b = "Отслеживает потерю тотемов у атакованных сущностей",
   c = Category.UTILITIES
)
@Environment(EnvType.CLIENT)
public class TotemTrackerModule extends Module {
   private final Map<UUID, TimeUtils> a = new HashMap<>();
   private static final long b = 5000L;
   private int c = -1;

   @EventHandler
   @Compile
   public void a(AttackEvent var1) {
      if (d.player == null) {
         return;
      }
      if (var1.a() instanceof LivingEntity) {
         LivingEntity var2 = (LivingEntity)var1.a();
         if (var2 != d.player) {
            UUID var3 = var2.getUuid();
            this.a.put(var3, new TimeUtils());
         }
      }
   }

   @EventHandler
   @Compile
   public void a(TotemPopEvent var1) {
      if (d.player == null) {
         return;
      }
      LivingEntity var2 = var1.a();
      if (var2 != d.player) {
         UUID var3 = var2.getUuid();
         TimeUtils var4 = this.a.get(var3);
         if (var4 != null && !var4.a(5000L)) {
            this.a(var2, var1.b());
         }
         this.n();
      }
   }

   private void a(LivingEntity var1, ItemStack var2) {
      int var3 = d.player.age;
      if (var3 != this.c) {
         this.c = var3;
         String var4 = var1.getName().getString();
         boolean var5 = var2.hasGlint();
         String var6 = var5 ? "§aТалик: ✔" : "§cТалик: ❌";
         String var7 = "§f" + var4 + " §7потерял тотем. " + var6;
         ChatUtils.a((Object)var7);
      }
   }

   private void n() {
      this.a.entrySet().removeIf(var0 -> var0.getValue().a(5000L));
   }

   @Compile
   @Override
   public void f() {
      super.f();
      this.a.clear();
      this.c = -1;
   }

   static {
      NativeMethodLookup.lookup(TotemTrackerModule.class, 77);
   }
}
