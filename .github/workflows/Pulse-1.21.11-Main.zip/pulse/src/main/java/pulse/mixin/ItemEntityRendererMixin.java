package pulse.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.core.api.IItemEntityState;
import pulse.features.modules.ModuleRegistry;
import pulse.features.modules.utilities.ShulkerPreviewModule;

@Environment(EnvType.CLIENT)
@Mixin({ItemEntityRenderer.class})
public abstract class ItemEntityRendererMixin {
   @Unique
   private Random pulse$random;
   @Unique
   private static final ThreadLocal<ItemEntityRenderState> pulse$activeState = new ThreadLocal<>();

   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V"},
      at = {@At("HEAD")}
   )
   private void pulse$captureState(ItemEntity var1, ItemEntityRenderState var2, float var3, CallbackInfo var4) {
      pulse$activeState.set(var2);
   }

   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V"},
      at = {@At("TAIL")}
   )
   private void pulse$finalizeState(ItemEntity var1, ItemEntityRenderState var2, float var3, CallbackInfo var4) {
      ((IItemEntityState)var2).pulse$setOnGround(var1.isOnGround());
      pulse$activeState.set(null);
   }

   @Redirect(
      method = {"updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/ItemEntity;getStack()Lnet/minecraft/item/ItemStack;"
      )
   )
   private ItemStack pulse$swapToRedShulker(ItemEntity var1) {
      ItemStack var2 = var1.getStack();
      ItemEntityRenderState var3 = pulse$activeState.get();
      if (var3 == null) {
         return var2;
      } else {
         ShulkerPreviewModule var4 = ModuleRegistry.ar;
         IItemEntityState var5 = (IItemEntityState)var3;
         if (var4 != null && var4.k() && var4.n() && ShulkerPreviewModule.a(var2) && ShulkerPreviewModule.c(var2)) {
            var5.pulse$setShouldScale(true);
            return new ItemStack(Items.RED_SHULKER_BOX, var2.getCount());
         } else {
            var5.pulse$setShouldScale(false);
            return var2;
         }
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At("HEAD")}
   )
   private void pulse$scaleNonEmptyShulker(
      ItemEntityRenderState var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5
   ) {
      IItemEntityState var6 = (IItemEntityState)var1;
      if (var6.pulse$isShouldScale() && (ModuleRegistry.v == null || !ModuleRegistry.v.k())) {
         var2.scale(2.0F, 2.0F, 2.0F);
         var6.pulse$setShouldScale(false);
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pulse$renderPhysic(ItemEntityRenderState var1, MatrixStack var2, OrderedRenderCommandQueue var3, CameraRenderState var4, CallbackInfo var5) {
      if (ModuleRegistry.v != null && ModuleRegistry.v.k()) {
         ItemRenderState var6 = var1.itemRenderState;
         if (var6.isEmpty()) {
            var5.cancel();
         } else {
            Box var7 = var6.getModelBoundingBox();
            boolean var8 = (float)var7.getLengthZ() > 0.0625F;
            int var9 = var1.renderedAmount;
            if (var9 <= 0) {
               var5.cancel();
            } else {
               IItemEntityState var10 = (IItemEntityState)var1;
               boolean var11 = var10.pulse$isOnGround();
               boolean var12 = var10.pulse$isShouldScale();
               if (this.pulse$random == null) {
                  this.pulse$random = Random.create();
               }

               this.pulse$random.setSeed(var1.seed);
               var2.push();
               if (var12) {
                  var2.scale(2.0F, 2.0F, 2.0F);
                  var10.pulse$setShouldScale(false);
               }

               float var13 = var1.age;
               int var14 = var1.light;
               int var15 = var1.outlineColor;
               if (var8) {
                  var2.translate(0.0, 0.08, 0.0);
                  float var16 = var11 ? var1.seed * 137 % 360 : var13 * 40.0F;
                  var2.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var16));

                  for (int var17 = 0; var17 < var9; var17++) {
                     var2.push();
                     if (var17 > 0) {
                        float var18 = (this.pulse$random.nextFloat() * 2.0F - 1.0F) * 0.035F;
                        float var19 = (this.pulse$random.nextFloat() * 2.0F - 1.0F) * 0.035F;
                        float var20 = (this.pulse$random.nextFloat() * 2.0F - 1.0F) * 0.035F;
                        var2.translate(var18, var19, var20);
                     }

                     var6.render(var2, var3, var14, OverlayTexture.DEFAULT_UV, var15);
                     var2.pop();
                  }
               } else {
                  var2.translate(0.0, 0.04, 0.0);
                  float var21 = var11 ? var1.seed * 137 % 360 : var13 * 40.0F;
                  var2.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F));
                  var2.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var21));

                  for (int var22 = 0; var22 < var9; var22++) {
                     var2.push();
                     if (var22 > 0) {
                        float var23 = (this.pulse$random.nextFloat() * 2.0F - 1.0F) * 0.035F;
                        float var24 = (this.pulse$random.nextFloat() * 2.0F - 1.0F) * 0.035F;
                        var2.translate(var23, 0.035F * var22, var24);
                     }

                     var6.render(var2, var3, var14, OverlayTexture.DEFAULT_UV, var15);
                     var2.pop();
                  }
               }

               var2.pop();
               var5.cancel();
            }
         }
      }
   }
}
