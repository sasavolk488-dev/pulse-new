package pulse.core.handler.impl;

import aethereal.NativeMethodLookup;
import aethereal.api.Compile;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart.Cuboid;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import pulse.Pulse;
import pulse.ui.clickgui.menu.markers.MarkerSettings;
import pulse.core.event.impl.RenderEvent;
import pulse.core.event.impl.RenderHudPostEvent;
import pulse.core.handler.Handler;
import pulse.core.handler.HandlerInfo;
import pulse.core.api.IMinecraft;
import pulse.utils.render.Fonts;
import pulse.utils.render.Render;
import pulse.utils.render.font.FontRenderer;
import pulse.utils.render.world.BlockOverlayLayers;
import pulse.utils.render.world.PingLayers;
import pulse.services.tracker.v2.GroupManagerClient;
import pulse.services.tracker.v2.GroupMemberDto;
import pulse.services.tracker.v2.RealtimeSyncServiceV2;
import pulse.utils.game.ChatUtils;
import pulse.utils.render.TextureRegistry;
import pulse.services.accounts.UserInfo;

@HandlerInfo
@Environment(EnvType.CLIENT)
public class PlayerPingHandler extends Handler implements IMinecraft {
   public static final long a = 5000L;
   private static final double b = 200.0;
   private static final String c = "\ue908";
   private static final int f = 24;
   private static final int g = 12;
   private static final int h = 10;
   private static final float i = -8.0F;
   private static final float j = -4.0F;
   private static final float k = 0.7F;
   private static final float l = 4.0F;
   private static final float m = 36.0F;
   private static final float n = 22.0F;
   private static final int o = 16;
   private static final float p = 2.0F;
   private static final float q = 0.85F;
   private static final float r = 0.94F;
   private static final float s = 1.0F;
   private final List<PlayerPingHandler.PingEntry> t = new ArrayList<>();
   private static final int u = 10;
   private static final long v = 30000L;
   private final ArrayDeque<Long> w = new ArrayDeque<>();
   private static int x = 0;
   private static RenderLayer y = null;
   private static Identifier z = null;

   private boolean e() {
      long var1 = System.currentTimeMillis();

      while (!this.w.isEmpty() && var1 - this.w.peekFirst() > 30000L) {
         this.w.pollFirst();
      }

      if (this.w.size() >= 10) {
         long var3 = this.w.peekFirst();
         long var5 = Math.max(1L, (30000L - (var1 - var3)) / 1000L);
         if (d.player != null) {
            ChatUtils.a("§cСлишком часто! Подожди §f" + var5 + "§c сек.");
         }

         return false;
      } else {
         this.w.addLast(var1);
         return true;
      }
   }

   private String f() {
      UserInfo var1 = Pulse.n();
      if (var1 != null && var1.g() != null && !var1.g().isEmpty()) {
         return var1.g();
      } else {
         return d.player != null ? d.player.getName().getString() : "?";
      }
   }

   private Integer g() {
      UserInfo var1 = Pulse.n();
      if (var1 == null) {
         return null;
      } else {
         for (GroupMemberDto var3 : GroupManagerClient.a().d()) {
            if (var3.a() == var1.f()) {
               return var3.i();
            }
         }

         return null;
      }
   }

   public void d() {
      if (d.player != null && d.world != null) {
         if (this.e()) {
            Vec3d var1 = d.player.getCameraPosVec(1.0F);
            Vec3d var2 = d.player.getRotationVec(1.0F);
            Vec3d var3 = var1.add(var2.multiply(200.0));
            BlockHitResult var4 = d.world.raycast(new RaycastContext(var1, var3, ShapeType.OUTLINE, FluidHandling.NONE, d.player));
            double var5 = var4.getType() == Type.BLOCK ? var1.distanceTo(var4.getPos()) : 1.7976922776554304E308;
            LivingEntity var7 = null;
            double var8 = var5;

            for (Entity var11 : d.world.getEntities()) {
               if (var11 instanceof LivingEntity && var11 != d.player && !var11.isInvisibleTo(d.player)) {
                  Box var12 = var11.getBoundingBox().expand(0.30000015143456643);
                  Optional var13 = var12.raycast(var1, var3);
                  if (var13.isPresent()) {
                     double var14 = var1.distanceTo((Vec3d)var13.get());
                     if (var14 < var8) {
                        var8 = var14;
                        var7 = (LivingEntity)var11;
                     }
                  }
               }
            }

            if (var7 != null) {
               LivingEntityRenderState var17 = this.a(var7);
               this.a(var7.getEntityPos(), this.f(), true, var7, var7.getBodyYaw(), var7.getHeight(), var7.isBaby(), var17);
               Integer var19 = this.g();
               if (var19 != null && !this.t.isEmpty()) {
                  this.t.get(this.t.size() - 1).e = var19;
               }

               if (GroupManagerClient.a().c()) {
                  String var20 = var7 instanceof PlayerEntity ? var7.getName().getString() : null;
                  RealtimeSyncServiceV2.L().a(var7.getX(), var7.getY(), var7.getZ(), var20);
               }
            } else if (var4.getType() == Type.BLOCK) {
               Vec3d var16 = new Vec3d(var4.getBlockPos().getX() + 0.5, var4.getBlockPos().getY() + 1.0, var4.getBlockPos().getZ() + 0.5);
               this.a(var16, this.f(), true);
               Integer var18 = this.g();
               if (var18 != null && !this.t.isEmpty()) {
                  this.t.get(this.t.size() - 1).e = var18;
               }

               if (GroupManagerClient.a().c()) {
                  RealtimeSyncServiceV2.L().a(var16.x, var16.y, var16.z, null);
               }
            }
         }
      }
   }

   public void a(String var1, double var2, double var4, double var6, String var8) {
      this.a(var1, var2, var4, var6, var8, null);
   }

   public void a(String var1, double var2, double var4, double var6, String var8, Integer var9) {
      d.execute(() -> this.b(var1, var2, var4, var6, var8, var9));
   }

   private void b(String var1, double var2, double var4, double var6, String var8, Integer var9) {
      if (d.world != null) {
         Vec3d var10 = new Vec3d(var2, var4, var6);
         LivingEntity var11 = null;
         if (var8 != null && !var8.isEmpty()) {
            for (Entity var13 : d.world.getEntities()) {
               if (var13 instanceof PlayerEntity && var8.equalsIgnoreCase(var13.getName().getString())) {
                  var11 = (LivingEntity)var13;
                  break;
               }
            }
         }

         if (var11 != null) {
            LivingEntityRenderState var14 = this.a(var11);
            this.a(var11.getEntityPos(), var1, false, var11, var11.getBodyYaw(), var11.getHeight(), var11.isBaby(), var14);
         } else {
            this.a(var10, var1, false);
         }

         if (var9 != null && !this.t.isEmpty()) {
            this.t.get(this.t.size() - 1).e = var9;
         }
      }
   }

   public void a(Vec3d var1, String var2, boolean var3) {
      this.t.add(new PlayerPingHandler.PingEntry(var1, var2, System.currentTimeMillis(), var3));
      this.a(var1, var3);
   }

   private LivingEntityRenderState a(LivingEntity var1) {
      try {
         if (!(d.getEntityRenderDispatcher().getRenderer(var1) instanceof LivingEntityRenderer var3)) {
            return null;
         } else {
            LivingEntityRenderState var4 = (LivingEntityRenderState)var3.createRenderState();
            var3.updateRenderState(var1, var4, 1.0F);
            return var4;
         }
      } catch (Throwable var5) {
         return null;
      }
   }

   public void a(Vec3d var1, String var2, boolean var3, LivingEntity var4, float var5, float var6, boolean var7, LivingEntityRenderState var8) {
      this.t.add(new PlayerPingHandler.PingEntry(var1, var2, System.currentTimeMillis(), var3, var4, var5, var6, var7, var8));
      this.a(var1, var3);
   }

   private void a(Vec3d var1, boolean var2) {
      if (MarkerSettings.c() && d.world != null && d.player != null) {
         float var3 = var2 ? 1.8F : 1.2F;
         Vec3d var4 = d.player.getEntityPos();
         d.world.playSoundClient(var4.x, var4.y, var4.z, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), SoundCategory.PLAYERS, 0.4F, var3, false);
      }
   }

   @EventHandler
   @Compile
   public void a(RenderEvent var1) {
      var pings = this.t;
      if (pings.isEmpty()) {
         return;
      }
      this.i();
      if (d.world == null) {
         return;
      }
      boolean blockPings = false;
      boolean entityPings = false;
      for (PlayerPingHandler.PingEntry ping : pings) {
         if (ping.a()) {
            entityPings = true;
         } else {
            blockPings = true;
         }
         if (blockPings && entityPings) {
            break;
         }
      }
      Camera camera = d.gameRenderer.getCamera();
      if (blockPings) {
         this.a(var1.a(), camera);
      }
      if (entityPings) {
         this.a(var1.a(), camera, var1.b());
      }
   }

   private void a(MatrixStack var1, Camera var2) {
      Immediate var3 = d.getBufferBuilders().getEntityVertexConsumers();
      VertexConsumer var4 = var3.getBuffer(PingLayers.b);
      Vec3d var5 = var2.getCameraPos();
      Matrix4f var6 = var1.peek().getPositionMatrix();
      float var7 = 1.0F;

      for (PlayerPingHandler.PingEntry var9 : this.t) {
         if (!var9.a()) {
            float var10 = Math.min(1.0F, (float)var9.b() / 5000.0F);
            float[] var11 = this.a(var9);
            float var12 = var11[0];
            float var13 = var11[1];
            float var14 = var11[2];
            float var16 = (float)(var9.a.x - var5.x);
            float var17 = (float)(var9.a.y + 0.02500000470505951 - var5.y);
            float var18 = (float)(var9.a.z - var5.z);
            var4.vertex(var6, var16 - var7, var17, var18 - var7).texture(0.0F, 0.0F).color(var12, var13, var14, var10);
            var4.vertex(var6, var16 - var7, var17, var18 + var7).texture(0.0F, 1.0F).color(var12, var13, var14, var10);
            var4.vertex(var6, var16 + var7, var17, var18 + var7).texture(1.0F, 1.0F).color(var12, var13, var14, var10);
            var4.vertex(var6, var16 + var7, var17, var18 - var7).texture(1.0F, 0.0F).color(var12, var13, var14, var10);
         }
      }

      var3.draw(PingLayers.b);
   }

   private float[] a(MatrixStack var1, Vec3d var2, double var3, double var5, double var7, float var9) {
      var1.push();
      var1.translate(var3 - var2.x, var5 - var2.y, var7 - var2.z);
      Matrix4f var10 = new Matrix4f(var1.peek().getPositionMatrix());
      var1.pop();
      float var11 = var9 / 2.0F;
      float[][] var12 = new float[][]{
         {-var11, 0.0F, -var11, 0.0F, 0.0F}, {-var11, 0.0F, var11, 0.0F, 1.0F}, {var11, 0.0F, var11, 1.0F, 1.0F}, {var11, 0.0F, -var11, 1.0F, 0.0F}
      };
      int[] var13 = new int[]{0, 1, 2, 0, 2, 3};
      float[] var14 = new float[30];
      Vector4f var15 = new Vector4f();
      int var16 = 0;

      for (int var20 : var13) {
         var15.set(var12[var20][0], var12[var20][1], var12[var20][2], 1.0F);
         var10.transform(var15);
         var14[var16++] = var15.x;
         var14[var16++] = var15.y;
         var14[var16++] = var15.z;
         var14[var16++] = var12[var20][3];
         var14[var16++] = var12[var20][4];
      }

      return var14;
   }

   private void a(MatrixStack var1, Camera var2, float var3) {
      Identifier var4 = h();
      if (var4 != null) {
         RenderLayer var5 = this.a(var4);
         if (var5 != null) {
            Vec3d var6 = var2.getCameraPos();
            Immediate var7 = d.getBufferBuilders().getEntityVertexConsumers();
            VertexConsumer var8 = var7.getBuffer(BlockOverlayLayers.d);
            float var9 = 2.5F;
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);

            for (PlayerPingHandler.PingEntry var11 : this.t) {
               if (var11.a()) {
                  LivingEntity var12 = var11.f;
                  if (var12 != null && d.getEntityRenderDispatcher().getRenderer(var12) instanceof LivingEntityRenderer var14) {
                     EntityModel var15 = var14.getModel();
                     long var16 = var11.b();
                     float var18 = 1.0F;
                     if (var16 < 100L) {
                        var18 = (float)var16 / 100.0F;
                     }

                     if (var16 >= 4500L) {
                        float var19 = (float)(var16 - 4500L) / 500.0F;
                        var18 = Math.max(0.0F, 1.0F - var19);
                     }

                     if (!(var18 <= 0.01F)) {
                        LivingEntityRenderState var31 = var11.j;
                        if (var31 != null) {
                           var15.setAngles(var31);
                           float var20 = (float)var16 / 1000.0F;
                           float var21 = (float)(0.5 + 0.5 * Math.sin(var20 * 2.5));
                           float var22 = 1.0F + var21 * 0.008F;
                           float var23 = var18 * (0.6F + 0.25F * var21);
                           double var24 = d.player == null ? 0.0 : d.player.getEntityPos().distanceTo(var11.a);
                           float var26 = 1.0F / (1.0F + (float)var24 * 0.02F);
                           float var27 = (2.5F + var21 * 0.3F) * var26;
                           float[] var28 = this.a(var11);
                           int var29 = ColorHelper.getArgb(
                              Math.max(1, (int)(var23 * 255.0F)), (int)(var28[0] * 255.0F), (int)(var28[1] * 255.0F), (int)(var28[2] * 255.0F)
                           );
                           boolean[] var30 = a(var15);
                           GL11.glLineWidth(Math.max(0.3F, var27));
                           this.a(var1, var11.a, var6, var11.g, var12, var22);
                           this.a(var1, var8, var15, var12, var28[0], var28[1], var28[2], var23, Math.max(0.3F, var27));
                           var1.pop();
                           a(var15, var30);
                        }
                     }
                  }
               }
            }

            var7.draw(BlockOverlayLayers.d);
            GL11.glDisable(2848);
         }
      }
   }

   private void a(MatrixStack var1, VertexConsumer var2, EntityModel var3, LivingEntity var4, float var5, float var6, float var7, float var8, float var9) {
      try {
         var3.getRootPart().forEachCuboid(var1, (var6x, var7x, var8x, var9x) -> {
            if (!a(var7x)) {
               a(var6x, var2, var9x, var5, var6, var7, var8, var9);
            }
         });
      } catch (Throwable var11) {
         Pulse.m().warn("[PlayerPing] failed to render model cuboid outline", var11);
         Box var10 = var4.getBoundingBox().offset(-var4.getX(), -var4.getY(), -var4.getZ());
         a(var1.peek(), var2, var10, var5, var6, var7, var8, var9);
      }
   }

   private static boolean a(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         int var1 = var0.lastIndexOf(47);
         String var2 = var1 >= 0 ? var0.substring(var1 + 1) : var0;
         return var2.equals("hat")
            || var2.equals("jacket")
            || var2.equals("left_sleeve")
            || var2.equals("right_sleeve")
            || var2.equals("left_pants")
            || var2.equals("right_pants");
      } else {
         return false;
      }
   }

   private static void a(Entry var0, VertexConsumer var1, Cuboid var2, float var3, float var4, float var5, float var6, float var7) {
      a(
         var0,
         var1,
         new Box(var2.minX / 16.0F, var2.minY / 16.0F, var2.minZ / 16.0F, var2.maxX / 16.0F, var2.maxY / 16.0F, var2.maxZ / 16.0F),
         var3,
         var4,
         var5,
         var6,
         var7
      );
   }

   private static void a(Entry var0, VertexConsumer var1, Box var2, float var3, float var4, float var5, float var6, float var7) {
      float var8 = (float)var2.minX;
      float var9 = (float)var2.minY;
      float var10 = (float)var2.minZ;
      float var11 = (float)var2.maxX;
      float var12 = (float)var2.maxY;
      float var13 = (float)var2.maxZ;
      a(var0, var1, var8, var9, var10, var11, var9, var10, var3, var4, var5, var6, var7);
      a(var0, var1, var11, var9, var10, var11, var9, var13, var3, var4, var5, var6, var7);
      a(var0, var1, var11, var9, var13, var8, var9, var13, var3, var4, var5, var6, var7);
      a(var0, var1, var8, var9, var13, var8, var9, var10, var3, var4, var5, var6, var7);
      a(var0, var1, var8, var12, var10, var11, var12, var10, var3, var4, var5, var6, var7);
      a(var0, var1, var11, var12, var10, var11, var12, var13, var3, var4, var5, var6, var7);
      a(var0, var1, var11, var12, var13, var8, var12, var13, var3, var4, var5, var6, var7);
      a(var0, var1, var8, var12, var13, var8, var12, var10, var3, var4, var5, var6, var7);
      a(var0, var1, var8, var9, var10, var8, var12, var10, var3, var4, var5, var6, var7);
      a(var0, var1, var11, var9, var10, var11, var12, var10, var3, var4, var5, var6, var7);
      a(var0, var1, var11, var9, var13, var11, var12, var13, var3, var4, var5, var6, var7);
      a(var0, var1, var8, var9, var13, var8, var12, var13, var3, var4, var5, var6, var7);
   }

   private static void a(
      Entry var0,
      VertexConsumer var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12
   ) {
      float var13 = var5 - var2;
      float var14 = var6 - var3;
      float var15 = var7 - var4;
      float var16 = (float)Math.sqrt(var13 * var13 + var14 * var14 + var15 * var15);
      if (!(var16 < 1.0E-6F)) {
         var13 /= var16;
         var14 /= var16;
         var15 /= var16;
         var1.vertex(var0, var2, var3, var4).color(var8, var9, var10, var11).normal(var0, var13, var14, var15).lineWidth(var12);
         var1.vertex(var0, var5, var6, var7).color(var8, var9, var10, var11).normal(var0, var13, var14, var15).lineWidth(var12);
      }
   }

   private RenderLayer a(Identifier var1) {
      if (y == null) {
         y = PingLayers.a(var1);
      }

      return y;
   }

   private void a(MatrixStack var1, Vec3d var2, Vec3d var3, float var4, LivingEntity var5, float var6) {
      var1.push();
      var1.translate(var2.x - var3.x, var2.y - var3.y, var2.z - var3.z);
      var1.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(var4 + 180.0F));
      var1.scale(-var6, -var6, var6);
      if (var5 instanceof AbstractClientPlayerEntity) {
         var1.scale(0.9375F, 0.9375F, 0.9375F);
      }

      if (var5.isBaby()) {
         var1.scale(0.5F, 0.5F, 0.5F);
      }

      var1.translate(0.0, -1.5010003655441202, 0.0);
   }

   private static boolean[] a(EntityModel<?> var0) {
      if (!(var0 instanceof PlayerEntityModel var1)) {
         return null;
      } else {
         boolean[] var3 = new boolean[]{
            var1.hat.visible, var1.jacket.visible, var1.leftSleeve.visible, var1.rightSleeve.visible, var1.leftPants.visible, var1.rightPants.visible
         };
         var1.hat.visible = false;
         var1.jacket.visible = false;
         var1.leftSleeve.visible = false;
         var1.rightSleeve.visible = false;
         var1.leftPants.visible = false;
         var1.rightPants.visible = false;
         return var3;
      }
   }

   private static void a(EntityModel<?> var0, boolean[] var1) {
      if (var1 != null && var0 instanceof PlayerEntityModel var2) {
         var2.hat.visible = var1[0];
         var2.jacket.visible = var1[1];
         var2.leftSleeve.visible = var1[2];
         var2.rightSleeve.visible = var1[3];
         var2.leftPants.visible = var1[4];
         var2.rightPants.visible = var1[5];
      }
   }

   private static Identifier h() {
      if (z != null) {
         return z;
      } else {
         MinecraftClient var0 = MinecraftClient.getInstance();
         if (!var0.isOnThread()) {
            return null;
         } else {
            try {
               NativeImage var1 = new NativeImage(1, 1, false);
               var1.setColorArgb(0, 0, -1);
               NativeImageBackedTexture var2 = new NativeImageBackedTexture(() -> "pulse-white-1x1", var1);
               Identifier var3 = Identifier.of("pulse", "white_1x1");
               var0.getTextureManager().registerTexture(var3, var2);
               z = var3;
               return var3;
            } catch (Throwable var4) {
               return null;
            }
         }
      }
   }

   @EventHandler(
      priority = -100
   )
   @Compile
   public void a(RenderHudPostEvent var1) {
      List<PlayerPingHandler.PingEntry> pings = this.t;
      if (pings.isEmpty() || d.player == null) {
         return;
      }
      Render render = pulse.Pulse.l().p();
      if (render == null) {
         return;
      }
      MatrixStack matrices = var1.a();
      FontRenderer iconFont = Fonts.d[24];
      FontRenderer nameFont = Fonts.b[12];
      FontRenderer distanceFont = Fonts.b[10];
      for (PlayerPingHandler.PingEntry ping : pings) {
         long age = ping.b();
         float alpha = age < 100L ? (float)age / 100.0F : 1.0F;
         if (age >= 4500L) {
            alpha = Math.max(0.0F, 1.0F - (float)(age - 4500L) / 500.0F);
         }
         if (!(alpha > 0.01F)) {
            continue;
         }
         float bounce = 0.0F;
         if (age < 300L) {
            float progress = 1.0F - (float)Math.pow((double)(1.0F - (float)age / 300.0F), 3.0);
            bounce = (1.0F - progress) * 4.0F;
         }
         float bob = 0.0F;
         if (age >= 500L) {
            bob = (float)Math.sin((double)((float)(age - 500L) / 1500.0F * 6.2831855F)) * 0.05F;
         }
         float lift = ping.a() ? ping.h + 0.3F : 0.7F;
         Vec3d projected = pulse.utils.render.ScreenUtils.a(new Vec3d(ping.a.x, ping.a.y + (double)lift + (double)bounce + (double)bob, ping.a.z));
         float width = d.getWindow().getFramebufferWidth() / pulse.utils.render.ScaleUtils.d();
         float height = d.getWindow().getFramebufferHeight() / pulse.utils.render.ScaleUtils.d();
         boolean onScreen = projected != null && projected.x >= -20.0 && projected.x <= (double)(width + 20.0F)
            && projected.y >= -20.0 && projected.y <= (double)(height + 20.0F);
         if (!onScreen) {
            if (MarkerSettings.d()) {
               this.a(matrices, render, ping, alpha, width, height);
            }
            continue;
         }
         float x = (float)projected.x;
         float y = (float)projected.y;
         float[] rgb = this.a(ping);
         Color iconColor = new Color(rgb[0], rgb[1], rgb[2], alpha);
         float iconWidth = iconFont.a("");
         float iconHeight = iconFont.b("");
         iconFont.a("", (double)(x - iconWidth * 0.5F), (double)(y - iconHeight), iconColor, matrices);
         String name = ping.b;
         String distance = (int)d.player.getEntityPos().distanceTo(ping.a) + " м";
         float nameWidth = nameFont.a(name);
         float nameHeight = nameFont.b(name);
         float distanceWidth = distanceFont.a(distance);
         float nameY = y - 8.0F;
         Color textColor = new Color(1.0F, 1.0F, 1.0F, alpha);
         Color shadowColor = new Color(0.0F, 0.0F, 0.0F, alpha * 0.7F);
         float nameX = x - nameWidth * 0.5F;
         nameFont.a(name, (double)(nameX + 1.0F), (double)(nameY + 1.0F), shadowColor, matrices);
         nameFont.a(name, (double)nameX, (double)nameY, textColor, matrices);
         float distanceY = nameHeight + nameY - 4.0F;
         float distanceX = x - distanceWidth * 0.5F;
         distanceFont.a(distance, (double)(distanceX + 1.0F), (double)(distanceY + 1.0F), shadowColor, matrices);
         distanceFont.a(distance, (double)distanceX, (double)distanceY, textColor, matrices);
      }
   }

   private void a(MatrixStack var1, Render var2, PlayerPingHandler.PingEntry var3, float var4, float var5, float var6) {
      Camera var7 = d.gameRenderer.getCamera();
      if (var7 != null) {
         Vec3d var8 = var3.a.subtract(var7.getCameraPos());
         if (!(var8.lengthSquared() < 9.999995680610973E-5)) {
            var8 = var8.normalize();
            Vec3d var9 = Vec3d.fromPolar(var7.getPitch(), var7.getYaw());
            Vec3d var10 = Vec3d.fromPolar(var7.getPitch() - 90.0F, var7.getYaw());
            Vec3d var11 = var9.crossProduct(var10);
            double var12 = var8.dotProduct(var11);
            double var14 = -var8.dotProduct(var10);
            double var16 = Math.sqrt(var12 * var12 + var14 * var14);
            if (var16 < 9.999995348043437E-4) {
               var12 = 0.0;
               var14 = 1.0;
            } else {
               var12 /= var16;
               var14 /= var16;
            }

            float var18 = var5 / 2.0F;
            float var19 = var6 / 2.0F;
            double var20 = var12 != 0.0 ? (var18 - 36.0F) / Math.abs(var12) : 1.7976922776554304E308;
            double var22 = var14 != 0.0 ? (var19 - 36.0F) / Math.abs(var14) : 1.7976922776554304E308;
            double var24 = Math.min(var20, var22);
            float var26 = var18 + (float)(var12 * var24);
            float var27 = var19 + (float)(var14 * var24);
            float[] var28 = this.a(var3);
            Color var29 = new Color(var28[0], var28[1], var28[2], var4);
            float var30 = (float)Math.sin(var3.b() / 300.0) * 1.5F;
            float var31 = var26 + (float)(var12 * var30);
            float var32 = var27 + (float)(var14 * var30);
            float var33 = (float)Math.toDegrees(Math.atan2(var14, var12));
            TextureRegistry.TextureEntry var34 = TextureRegistry.b("pointer");
            if (var34 != null) {
               float var35 = 22.0F;
               var1.push();
               var1.translate(var31, var32, 0.0F);
               var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var33 + 90.0F));
               var1.translate(-var31, -var32, 0.0F);
               var2.a(var34.a(), var31 - var35 / 2.0F, var32 - var35 / 2.0F, var35, var35, var29, var1);
               var1.pop();
            }

            String var46 = (int)d.player.getEntityPos().distanceTo(var3.a) + " м";
            FontRenderer var36 = Fonts.b[16];
            float var37 = var36.a(var46);
            float var38 = var36.b(var46) / 2.0F;
            float var39 = 15.0F + var38 / 2.0F;
            float var40 = var26 - (float)(var12 * var39);
            float var41 = var27 - (float)(var14 * var39);
            Color var42 = new Color(0.0F, 0.0F, 0.0F, var4 * 0.7F);
            var36.a(var46, var40 - var37 / 2.0F + 1.0F, var41 - var38 / 2.0F + 1.0F, var42, var1);
            var36.a(var46, var40 - var37 / 2.0F, var41 - var38 / 2.0F, new Color(1.0F, 1.0F, 1.0F, var4), var1);
         }
      }
   }

   private float[] a(PlayerPingHandler.PingEntry var1) {
      if (var1.e != null) {
         int var2 = var1.e;
         return new float[]{(var2 >> 16 & 0xFF) / 255.0F, (var2 >> 8 & 0xFF) / 255.0F, (var2 & 0xFF) / 255.0F};
      } else {
         return new float[]{0.85F, 0.94F, 1.0F};
      }
   }

   private void i() {
      long var1 = System.currentTimeMillis();
      Iterator var3 = this.t.iterator();

      while (var3.hasNext()) {
         if (var1 - ((PlayerPingHandler.PingEntry)var3.next()).c >= 5000L) {
            var3.remove();
         }
      }
   }

   static {
      NativeMethodLookup.lookup(PlayerPingHandler.class, 30);
   }

   @Environment(EnvType.CLIENT)
   public static class PingEntry {
      public final Vec3d a;
      public final String b;
      public final long c;
      public final boolean d;
      public Integer e;
      public final LivingEntity f;
      public final float g;
      public final float h;
      public final boolean i;
      public final LivingEntityRenderState j;

      public PingEntry(Vec3d var1, String var2, long var3, boolean var5) {
         this(var1, var2, var3, var5, null, 0.0F, 0.0F, false, null);
      }

      public PingEntry(Vec3d var1, String var2, long var3, boolean var5, LivingEntity var6, float var7, float var8, boolean var9, LivingEntityRenderState var10) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var5;
         this.f = var6;
         this.g = var7;
         this.h = var8;
         this.i = var9;
         this.j = var10;
      }

      public boolean a() {
         return this.f != null;
      }

      public long b() {
         return System.currentTimeMillis() - this.c;
      }
   }
}
