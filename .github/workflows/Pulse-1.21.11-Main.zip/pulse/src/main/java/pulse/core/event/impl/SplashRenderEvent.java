package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class SplashRenderEvent extends Event {
   private final DrawContext a;
   private final long b;
   private final long c;

   @Generated
   public DrawContext a() {
      return this.a;
   }

   @Generated
   public long b() {
      return this.b;
   }

   @Generated
   public long c() {
      return this.c;
   }

   @Generated
   public SplashRenderEvent(DrawContext var1, long var2, long var4) {
      this.a = var1;
      this.b = var2;
      this.c = var4;
   }
}
