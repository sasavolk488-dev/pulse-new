package pulse.core.event.impl;

import lombok.Generated;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerEntity;
import pulse.core.event.Event;

@Environment(EnvType.CLIENT)
public class PlayerDeathEvent extends Event {
   private final PlayerEntity a;
   private final double b;
   private final double c;
   private final double d;

   @Generated
   public PlayerEntity a() {
      return this.a;
   }

   @Generated
   public double b() {
      return this.b;
   }

   @Generated
   public double c() {
      return this.c;
   }

   @Generated
   public double d() {
      return this.d;
   }

   @Generated
   public PlayerDeathEvent(PlayerEntity var1, double var2, double var4, double var6) {
      this.a = var1;
      this.b = var2;
      this.c = var4;
      this.d = var6;
   }
}
