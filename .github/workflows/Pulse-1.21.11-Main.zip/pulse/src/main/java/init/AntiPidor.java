package init;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.ModInitializer;
import pulse.Pulse;

@Environment(EnvType.CLIENT)
public class AntiPidor implements ModInitializer {
   @Override
   public void onInitialize() {
      Pulse.l().b();
   }
}
//antipidorleak