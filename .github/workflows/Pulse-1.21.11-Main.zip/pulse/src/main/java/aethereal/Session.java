package aethereal;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Session {
   public static native String uid();

   public static native String username();

   public static native String hwid();

   public static native String role();

   public static native String[] a();

   public static native String[] b();

   public static native String[] c();

   public static native String[] d();
}
