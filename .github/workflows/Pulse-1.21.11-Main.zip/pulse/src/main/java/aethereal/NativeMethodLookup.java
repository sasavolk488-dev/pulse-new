package aethereal;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;

public final class NativeMethodLookup {

   private NativeMethodLookup() {
   }

   public static void lookup(Class<?> clazz, int value) {
   }

   public static byte[] jc$bind() {
      return new byte[0];
   }

   public static Lookup lookupIn(String className) throws Exception {
      return MethodHandles.lookup();
   }
}

